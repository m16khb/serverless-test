"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/types.js
var require_types = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/platform/node/globalThis.js
var require_globalThis = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/platform/node/globalThis.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2._globalThis = void 0;
    exports2._globalThis = typeof globalThis === "object" ? globalThis : global;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/platform/node/index.js
var require_node = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/platform/node/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_globalThis(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/platform/index.js
var require_platform = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/platform/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_node(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/version.js
var require_version = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "1.0.4";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/internal/semver.js
var require_semver = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/internal/semver.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isCompatible = exports2._makeCompatibilityCheck = void 0;
    var version_1 = require_version();
    var re = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
    function _makeCompatibilityCheck(ownVersion) {
      var acceptedVersions = /* @__PURE__ */ new Set([ownVersion]);
      var rejectedVersions = /* @__PURE__ */ new Set();
      var myVersionMatch = ownVersion.match(re);
      if (!myVersionMatch) {
        return function() {
          return false;
        };
      }
      var ownVersionParsed = {
        major: +myVersionMatch[1],
        minor: +myVersionMatch[2],
        patch: +myVersionMatch[3],
        prerelease: myVersionMatch[4]
      };
      if (ownVersionParsed.prerelease != null) {
        return function isExactmatch(globalVersion) {
          return globalVersion === ownVersion;
        };
      }
      function _reject(v) {
        rejectedVersions.add(v);
        return false;
      }
      function _accept(v) {
        acceptedVersions.add(v);
        return true;
      }
      return function isCompatible(globalVersion) {
        if (acceptedVersions.has(globalVersion)) {
          return true;
        }
        if (rejectedVersions.has(globalVersion)) {
          return false;
        }
        var globalVersionMatch = globalVersion.match(re);
        if (!globalVersionMatch) {
          return _reject(globalVersion);
        }
        var globalVersionParsed = {
          major: +globalVersionMatch[1],
          minor: +globalVersionMatch[2],
          patch: +globalVersionMatch[3],
          prerelease: globalVersionMatch[4]
        };
        if (globalVersionParsed.prerelease != null) {
          return _reject(globalVersion);
        }
        if (ownVersionParsed.major !== globalVersionParsed.major) {
          return _reject(globalVersion);
        }
        if (ownVersionParsed.major === 0) {
          if (ownVersionParsed.minor === globalVersionParsed.minor && ownVersionParsed.patch <= globalVersionParsed.patch) {
            return _accept(globalVersion);
          }
          return _reject(globalVersion);
        }
        if (ownVersionParsed.minor <= globalVersionParsed.minor) {
          return _accept(globalVersion);
        }
        return _reject(globalVersion);
      };
    }
    exports2._makeCompatibilityCheck = _makeCompatibilityCheck;
    exports2.isCompatible = _makeCompatibilityCheck(version_1.VERSION);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/internal/global-utils.js
var require_global_utils = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/internal/global-utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.unregisterGlobal = exports2.getGlobal = exports2.registerGlobal = void 0;
    var platform_1 = require_platform();
    var version_1 = require_version();
    var semver_1 = require_semver();
    var major = version_1.VERSION.split(".")[0];
    var GLOBAL_OPENTELEMETRY_API_KEY = Symbol.for("opentelemetry.js.api." + major);
    var _global = platform_1._globalThis;
    function registerGlobal(type, instance, diag2, allowOverride) {
      var _a;
      if (allowOverride === void 0) {
        allowOverride = false;
      }
      var api = _global[GLOBAL_OPENTELEMETRY_API_KEY] = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) !== null && _a !== void 0 ? _a : {
        version: version_1.VERSION
      };
      if (!allowOverride && api[type]) {
        var err = new Error("@opentelemetry/api: Attempted duplicate registration of API: " + type);
        diag2.error(err.stack || err.message);
        return false;
      }
      if (api.version !== version_1.VERSION) {
        var err = new Error("@opentelemetry/api: All API registration versions must match");
        diag2.error(err.stack || err.message);
        return false;
      }
      api[type] = instance;
      diag2.debug("@opentelemetry/api: Registered a global for " + type + " v" + version_1.VERSION + ".");
      return true;
    }
    exports2.registerGlobal = registerGlobal;
    function getGlobal(type) {
      var _a, _b;
      var globalVersion = (_a = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _a === void 0 ? void 0 : _a.version;
      if (!globalVersion || !semver_1.isCompatible(globalVersion)) {
        return;
      }
      return (_b = _global[GLOBAL_OPENTELEMETRY_API_KEY]) === null || _b === void 0 ? void 0 : _b[type];
    }
    exports2.getGlobal = getGlobal;
    function unregisterGlobal(type, diag2) {
      diag2.debug("@opentelemetry/api: Unregistering a global for " + type + " v" + version_1.VERSION + ".");
      var api = _global[GLOBAL_OPENTELEMETRY_API_KEY];
      if (api) {
        delete api[type];
      }
    }
    exports2.unregisterGlobal = unregisterGlobal;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/ComponentLogger.js
var require_ComponentLogger = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/ComponentLogger.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DiagComponentLogger = void 0;
    var global_utils_1 = require_global_utils();
    var DiagComponentLogger = function() {
      function DiagComponentLogger2(props) {
        this._namespace = props.namespace || "DiagComponentLogger";
      }
      DiagComponentLogger2.prototype.debug = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        return logProxy("debug", this._namespace, args);
      };
      DiagComponentLogger2.prototype.error = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        return logProxy("error", this._namespace, args);
      };
      DiagComponentLogger2.prototype.info = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        return logProxy("info", this._namespace, args);
      };
      DiagComponentLogger2.prototype.warn = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        return logProxy("warn", this._namespace, args);
      };
      DiagComponentLogger2.prototype.verbose = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        return logProxy("verbose", this._namespace, args);
      };
      return DiagComponentLogger2;
    }();
    exports2.DiagComponentLogger = DiagComponentLogger;
    function logProxy(funcName, namespace, args) {
      var logger = global_utils_1.getGlobal("diag");
      if (!logger) {
        return;
      }
      args.unshift(namespace);
      return logger[funcName].apply(logger, args);
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/types.js
var require_types2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DiagLogLevel = void 0;
    var DiagLogLevel;
    (function(DiagLogLevel2) {
      DiagLogLevel2[DiagLogLevel2["NONE"] = 0] = "NONE";
      DiagLogLevel2[DiagLogLevel2["ERROR"] = 30] = "ERROR";
      DiagLogLevel2[DiagLogLevel2["WARN"] = 50] = "WARN";
      DiagLogLevel2[DiagLogLevel2["INFO"] = 60] = "INFO";
      DiagLogLevel2[DiagLogLevel2["DEBUG"] = 70] = "DEBUG";
      DiagLogLevel2[DiagLogLevel2["VERBOSE"] = 80] = "VERBOSE";
      DiagLogLevel2[DiagLogLevel2["ALL"] = 9999] = "ALL";
    })(DiagLogLevel = exports2.DiagLogLevel || (exports2.DiagLogLevel = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/internal/logLevelLogger.js
var require_logLevelLogger = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/internal/logLevelLogger.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createLogLevelDiagLogger = void 0;
    var types_1 = require_types2();
    function createLogLevelDiagLogger(maxLevel, logger) {
      if (maxLevel < types_1.DiagLogLevel.NONE) {
        maxLevel = types_1.DiagLogLevel.NONE;
      } else if (maxLevel > types_1.DiagLogLevel.ALL) {
        maxLevel = types_1.DiagLogLevel.ALL;
      }
      logger = logger || {};
      function _filterFunc(funcName, theLevel) {
        var theFunc = logger[funcName];
        if (typeof theFunc === "function" && maxLevel >= theLevel) {
          return theFunc.bind(logger);
        }
        return function() {
        };
      }
      return {
        error: _filterFunc("error", types_1.DiagLogLevel.ERROR),
        warn: _filterFunc("warn", types_1.DiagLogLevel.WARN),
        info: _filterFunc("info", types_1.DiagLogLevel.INFO),
        debug: _filterFunc("debug", types_1.DiagLogLevel.DEBUG),
        verbose: _filterFunc("verbose", types_1.DiagLogLevel.VERBOSE)
      };
    }
    exports2.createLogLevelDiagLogger = createLogLevelDiagLogger;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/api/diag.js
var require_diag = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/api/diag.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DiagAPI = void 0;
    var ComponentLogger_1 = require_ComponentLogger();
    var logLevelLogger_1 = require_logLevelLogger();
    var types_1 = require_types2();
    var global_utils_1 = require_global_utils();
    var API_NAME = "diag";
    var DiagAPI = function() {
      function DiagAPI2() {
        function _logProxy(funcName) {
          return function() {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
            }
            var logger = global_utils_1.getGlobal("diag");
            if (!logger)
              return;
            return logger[funcName].apply(logger, args);
          };
        }
        var self2 = this;
        self2.setLogger = function(logger, logLevel2) {
          var _a, _b;
          if (logLevel2 === void 0) {
            logLevel2 = types_1.DiagLogLevel.INFO;
          }
          if (logger === self2) {
            var err = new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
            self2.error((_a = err.stack) !== null && _a !== void 0 ? _a : err.message);
            return false;
          }
          var oldLogger = global_utils_1.getGlobal("diag");
          var newLogger = logLevelLogger_1.createLogLevelDiagLogger(logLevel2, logger);
          if (oldLogger) {
            var stack = (_b = new Error().stack) !== null && _b !== void 0 ? _b : "<failed to generate stacktrace>";
            oldLogger.warn("Current logger will be overwritten from " + stack);
            newLogger.warn("Current logger will overwrite one already registered from " + stack);
          }
          return global_utils_1.registerGlobal("diag", newLogger, self2, true);
        };
        self2.disable = function() {
          global_utils_1.unregisterGlobal(API_NAME, self2);
        };
        self2.createComponentLogger = function(options) {
          return new ComponentLogger_1.DiagComponentLogger(options);
        };
        self2.verbose = _logProxy("verbose");
        self2.debug = _logProxy("debug");
        self2.info = _logProxy("info");
        self2.warn = _logProxy("warn");
        self2.error = _logProxy("error");
      }
      DiagAPI2.instance = function() {
        if (!this._instance) {
          this._instance = new DiagAPI2();
        }
        return this._instance;
      };
      return DiagAPI2;
    }();
    exports2.DiagAPI = DiagAPI;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/internal/baggage-impl.js
var require_baggage_impl = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/internal/baggage-impl.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BaggageImpl = void 0;
    var BaggageImpl = function() {
      function BaggageImpl2(entries) {
        this._entries = entries ? new Map(entries) : /* @__PURE__ */ new Map();
      }
      BaggageImpl2.prototype.getEntry = function(key) {
        var entry = this._entries.get(key);
        if (!entry) {
          return void 0;
        }
        return Object.assign({}, entry);
      };
      BaggageImpl2.prototype.getAllEntries = function() {
        return Array.from(this._entries.entries()).map(function(_a) {
          var k = _a[0], v = _a[1];
          return [k, v];
        });
      };
      BaggageImpl2.prototype.setEntry = function(key, entry) {
        var newBaggage = new BaggageImpl2(this._entries);
        newBaggage._entries.set(key, entry);
        return newBaggage;
      };
      BaggageImpl2.prototype.removeEntry = function(key) {
        var newBaggage = new BaggageImpl2(this._entries);
        newBaggage._entries.delete(key);
        return newBaggage;
      };
      BaggageImpl2.prototype.removeEntries = function() {
        var keys = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          keys[_i] = arguments[_i];
        }
        var newBaggage = new BaggageImpl2(this._entries);
        for (var _a = 0, keys_1 = keys; _a < keys_1.length; _a++) {
          var key = keys_1[_a];
          newBaggage._entries.delete(key);
        }
        return newBaggage;
      };
      BaggageImpl2.prototype.clear = function() {
        return new BaggageImpl2();
      };
      return BaggageImpl2;
    }();
    exports2.BaggageImpl = BaggageImpl;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/internal/symbol.js
var require_symbol = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/internal/symbol.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.baggageEntryMetadataSymbol = void 0;
    exports2.baggageEntryMetadataSymbol = Symbol("BaggageEntryMetadata");
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/utils.js
var require_utils = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.baggageEntryMetadataFromString = exports2.createBaggage = void 0;
    var diag_1 = require_diag();
    var baggage_impl_1 = require_baggage_impl();
    var symbol_1 = require_symbol();
    var diag2 = diag_1.DiagAPI.instance();
    function createBaggage(entries) {
      if (entries === void 0) {
        entries = {};
      }
      return new baggage_impl_1.BaggageImpl(new Map(Object.entries(entries)));
    }
    exports2.createBaggage = createBaggage;
    function baggageEntryMetadataFromString(str) {
      if (typeof str !== "string") {
        diag2.error("Cannot create baggage metadata from unknown type: " + typeof str);
        str = "";
      }
      return {
        __TYPE__: symbol_1.baggageEntryMetadataSymbol,
        toString: function() {
          return str;
        }
      };
    }
    exports2.baggageEntryMetadataFromString = baggageEntryMetadataFromString;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/common/Exception.js
var require_Exception = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/common/Exception.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/common/Time.js
var require_Time = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/common/Time.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/consoleLogger.js
var require_consoleLogger = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/consoleLogger.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DiagConsoleLogger = void 0;
    var consoleMap = [
      { n: "error", c: "error" },
      { n: "warn", c: "warn" },
      { n: "info", c: "info" },
      { n: "debug", c: "debug" },
      { n: "verbose", c: "trace" }
    ];
    var DiagConsoleLogger2 = function() {
      function DiagConsoleLogger3() {
        function _consoleFunc(funcName) {
          return function() {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
            }
            if (console) {
              var theFunc = console[funcName];
              if (typeof theFunc !== "function") {
                theFunc = console.log;
              }
              if (typeof theFunc === "function") {
                return theFunc.apply(console, args);
              }
            }
          };
        }
        for (var i = 0; i < consoleMap.length; i++) {
          this[consoleMap[i].n] = _consoleFunc(consoleMap[i].c);
        }
      }
      return DiagConsoleLogger3;
    }();
    exports2.DiagConsoleLogger = DiagConsoleLogger2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/index.js
var require_diag2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/diag/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_consoleLogger(), exports2);
    __exportStar(require_types2(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/propagation/TextMapPropagator.js
var require_TextMapPropagator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/propagation/TextMapPropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.defaultTextMapSetter = exports2.defaultTextMapGetter = void 0;
    exports2.defaultTextMapGetter = {
      get: function(carrier, key) {
        if (carrier == null) {
          return void 0;
        }
        return carrier[key];
      },
      keys: function(carrier) {
        if (carrier == null) {
          return [];
        }
        return Object.keys(carrier);
      }
    };
    exports2.defaultTextMapSetter = {
      set: function(carrier, key, value) {
        if (carrier == null) {
          return;
        }
        carrier[key] = value;
      }
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/attributes.js
var require_attributes = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/attributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/link.js
var require_link = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/link.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/context/context.js
var require_context = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/context/context.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ROOT_CONTEXT = exports2.createContextKey = void 0;
    function createContextKey(description) {
      return Symbol.for(description);
    }
    exports2.createContextKey = createContextKey;
    var BaseContext = function() {
      function BaseContext2(parentContext) {
        var self2 = this;
        self2._currentContext = parentContext ? new Map(parentContext) : /* @__PURE__ */ new Map();
        self2.getValue = function(key) {
          return self2._currentContext.get(key);
        };
        self2.setValue = function(key, value) {
          var context = new BaseContext2(self2._currentContext);
          context._currentContext.set(key, value);
          return context;
        };
        self2.deleteValue = function(key) {
          var context = new BaseContext2(self2._currentContext);
          context._currentContext.delete(key);
          return context;
        };
      }
      return BaseContext2;
    }();
    exports2.ROOT_CONTEXT = new BaseContext();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/context/NoopContextManager.js
var require_NoopContextManager = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/context/NoopContextManager.js"(exports2) {
    "use strict";
    var __spreadArray = exports2 && exports2.__spreadArray || function(to, from) {
      for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
      return to;
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoopContextManager = void 0;
    var context_1 = require_context();
    var NoopContextManager = function() {
      function NoopContextManager2() {
      }
      NoopContextManager2.prototype.active = function() {
        return context_1.ROOT_CONTEXT;
      };
      NoopContextManager2.prototype.with = function(_context, fn, thisArg) {
        var args = [];
        for (var _i = 3; _i < arguments.length; _i++) {
          args[_i - 3] = arguments[_i];
        }
        return fn.call.apply(fn, __spreadArray([thisArg], args));
      };
      NoopContextManager2.prototype.bind = function(_context, target) {
        return target;
      };
      NoopContextManager2.prototype.enable = function() {
        return this;
      };
      NoopContextManager2.prototype.disable = function() {
        return this;
      };
      return NoopContextManager2;
    }();
    exports2.NoopContextManager = NoopContextManager;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/api/context.js
var require_context2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/api/context.js"(exports2) {
    "use strict";
    var __spreadArray = exports2 && exports2.__spreadArray || function(to, from) {
      for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
      return to;
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ContextAPI = void 0;
    var NoopContextManager_1 = require_NoopContextManager();
    var global_utils_1 = require_global_utils();
    var diag_1 = require_diag();
    var API_NAME = "context";
    var NOOP_CONTEXT_MANAGER = new NoopContextManager_1.NoopContextManager();
    var ContextAPI = function() {
      function ContextAPI2() {
      }
      ContextAPI2.getInstance = function() {
        if (!this._instance) {
          this._instance = new ContextAPI2();
        }
        return this._instance;
      };
      ContextAPI2.prototype.setGlobalContextManager = function(contextManager) {
        return global_utils_1.registerGlobal(API_NAME, contextManager, diag_1.DiagAPI.instance());
      };
      ContextAPI2.prototype.active = function() {
        return this._getContextManager().active();
      };
      ContextAPI2.prototype.with = function(context, fn, thisArg) {
        var _a;
        var args = [];
        for (var _i = 3; _i < arguments.length; _i++) {
          args[_i - 3] = arguments[_i];
        }
        return (_a = this._getContextManager()).with.apply(_a, __spreadArray([context, fn, thisArg], args));
      };
      ContextAPI2.prototype.bind = function(context, target) {
        return this._getContextManager().bind(context, target);
      };
      ContextAPI2.prototype._getContextManager = function() {
        return global_utils_1.getGlobal(API_NAME) || NOOP_CONTEXT_MANAGER;
      };
      ContextAPI2.prototype.disable = function() {
        this._getContextManager().disable();
        global_utils_1.unregisterGlobal(API_NAME, diag_1.DiagAPI.instance());
      };
      return ContextAPI2;
    }();
    exports2.ContextAPI = ContextAPI;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/trace_flags.js
var require_trace_flags = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/trace_flags.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TraceFlags = void 0;
    var TraceFlags;
    (function(TraceFlags2) {
      TraceFlags2[TraceFlags2["NONE"] = 0] = "NONE";
      TraceFlags2[TraceFlags2["SAMPLED"] = 1] = "SAMPLED";
    })(TraceFlags = exports2.TraceFlags || (exports2.TraceFlags = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/invalid-span-constants.js
var require_invalid_span_constants = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/invalid-span-constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.INVALID_SPAN_CONTEXT = exports2.INVALID_TRACEID = exports2.INVALID_SPANID = void 0;
    var trace_flags_1 = require_trace_flags();
    exports2.INVALID_SPANID = "0000000000000000";
    exports2.INVALID_TRACEID = "00000000000000000000000000000000";
    exports2.INVALID_SPAN_CONTEXT = {
      traceId: exports2.INVALID_TRACEID,
      spanId: exports2.INVALID_SPANID,
      traceFlags: trace_flags_1.TraceFlags.NONE
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/NonRecordingSpan.js
var require_NonRecordingSpan = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/NonRecordingSpan.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NonRecordingSpan = void 0;
    var invalid_span_constants_1 = require_invalid_span_constants();
    var NonRecordingSpan = function() {
      function NonRecordingSpan2(_spanContext) {
        if (_spanContext === void 0) {
          _spanContext = invalid_span_constants_1.INVALID_SPAN_CONTEXT;
        }
        this._spanContext = _spanContext;
      }
      NonRecordingSpan2.prototype.spanContext = function() {
        return this._spanContext;
      };
      NonRecordingSpan2.prototype.setAttribute = function(_key, _value) {
        return this;
      };
      NonRecordingSpan2.prototype.setAttributes = function(_attributes) {
        return this;
      };
      NonRecordingSpan2.prototype.addEvent = function(_name, _attributes) {
        return this;
      };
      NonRecordingSpan2.prototype.setStatus = function(_status) {
        return this;
      };
      NonRecordingSpan2.prototype.updateName = function(_name) {
        return this;
      };
      NonRecordingSpan2.prototype.end = function(_endTime) {
      };
      NonRecordingSpan2.prototype.isRecording = function() {
        return false;
      };
      NonRecordingSpan2.prototype.recordException = function(_exception, _time) {
      };
      return NonRecordingSpan2;
    }();
    exports2.NonRecordingSpan = NonRecordingSpan;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/context-utils.js
var require_context_utils = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/context-utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getSpanContext = exports2.setSpanContext = exports2.deleteSpan = exports2.setSpan = exports2.getSpan = void 0;
    var context_1 = require_context();
    var NonRecordingSpan_1 = require_NonRecordingSpan();
    var SPAN_KEY = context_1.createContextKey("OpenTelemetry Context Key SPAN");
    function getSpan(context) {
      return context.getValue(SPAN_KEY) || void 0;
    }
    exports2.getSpan = getSpan;
    function setSpan(context, span) {
      return context.setValue(SPAN_KEY, span);
    }
    exports2.setSpan = setSpan;
    function deleteSpan(context) {
      return context.deleteValue(SPAN_KEY);
    }
    exports2.deleteSpan = deleteSpan;
    function setSpanContext(context, spanContext) {
      return setSpan(context, new NonRecordingSpan_1.NonRecordingSpan(spanContext));
    }
    exports2.setSpanContext = setSpanContext;
    function getSpanContext(context) {
      var _a;
      return (_a = getSpan(context)) === null || _a === void 0 ? void 0 : _a.spanContext();
    }
    exports2.getSpanContext = getSpanContext;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/spancontext-utils.js
var require_spancontext_utils = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/spancontext-utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.wrapSpanContext = exports2.isSpanContextValid = exports2.isValidSpanId = exports2.isValidTraceId = void 0;
    var invalid_span_constants_1 = require_invalid_span_constants();
    var NonRecordingSpan_1 = require_NonRecordingSpan();
    var VALID_TRACEID_REGEX = /^([0-9a-f]{32})$/i;
    var VALID_SPANID_REGEX = /^[0-9a-f]{16}$/i;
    function isValidTraceId(traceId) {
      return VALID_TRACEID_REGEX.test(traceId) && traceId !== invalid_span_constants_1.INVALID_TRACEID;
    }
    exports2.isValidTraceId = isValidTraceId;
    function isValidSpanId(spanId) {
      return VALID_SPANID_REGEX.test(spanId) && spanId !== invalid_span_constants_1.INVALID_SPANID;
    }
    exports2.isValidSpanId = isValidSpanId;
    function isSpanContextValid(spanContext) {
      return isValidTraceId(spanContext.traceId) && isValidSpanId(spanContext.spanId);
    }
    exports2.isSpanContextValid = isSpanContextValid;
    function wrapSpanContext(spanContext) {
      return new NonRecordingSpan_1.NonRecordingSpan(spanContext);
    }
    exports2.wrapSpanContext = wrapSpanContext;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/NoopTracer.js
var require_NoopTracer = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/NoopTracer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoopTracer = void 0;
    var context_1 = require_context2();
    var context_utils_1 = require_context_utils();
    var NonRecordingSpan_1 = require_NonRecordingSpan();
    var spancontext_utils_1 = require_spancontext_utils();
    var context = context_1.ContextAPI.getInstance();
    var NoopTracer = function() {
      function NoopTracer2() {
      }
      NoopTracer2.prototype.startSpan = function(name, options, context2) {
        var root = Boolean(options === null || options === void 0 ? void 0 : options.root);
        if (root) {
          return new NonRecordingSpan_1.NonRecordingSpan();
        }
        var parentFromContext = context2 && context_utils_1.getSpanContext(context2);
        if (isSpanContext(parentFromContext) && spancontext_utils_1.isSpanContextValid(parentFromContext)) {
          return new NonRecordingSpan_1.NonRecordingSpan(parentFromContext);
        } else {
          return new NonRecordingSpan_1.NonRecordingSpan();
        }
      };
      NoopTracer2.prototype.startActiveSpan = function(name, arg2, arg3, arg4) {
        var opts;
        var ctx;
        var fn;
        if (arguments.length < 2) {
          return;
        } else if (arguments.length === 2) {
          fn = arg2;
        } else if (arguments.length === 3) {
          opts = arg2;
          fn = arg3;
        } else {
          opts = arg2;
          ctx = arg3;
          fn = arg4;
        }
        var parentContext = ctx !== null && ctx !== void 0 ? ctx : context.active();
        var span = this.startSpan(name, opts, parentContext);
        var contextWithSpanSet = context_utils_1.setSpan(parentContext, span);
        return context.with(contextWithSpanSet, fn, void 0, span);
      };
      return NoopTracer2;
    }();
    exports2.NoopTracer = NoopTracer;
    function isSpanContext(spanContext) {
      return typeof spanContext === "object" && typeof spanContext["spanId"] === "string" && typeof spanContext["traceId"] === "string" && typeof spanContext["traceFlags"] === "number";
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/ProxyTracer.js
var require_ProxyTracer = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/ProxyTracer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ProxyTracer = void 0;
    var NoopTracer_1 = require_NoopTracer();
    var NOOP_TRACER = new NoopTracer_1.NoopTracer();
    var ProxyTracer = function() {
      function ProxyTracer2(_provider, name, version) {
        this._provider = _provider;
        this.name = name;
        this.version = version;
      }
      ProxyTracer2.prototype.startSpan = function(name, options, context) {
        return this._getTracer().startSpan(name, options, context);
      };
      ProxyTracer2.prototype.startActiveSpan = function(_name, _options, _context, _fn) {
        var tracer = this._getTracer();
        return Reflect.apply(tracer.startActiveSpan, tracer, arguments);
      };
      ProxyTracer2.prototype._getTracer = function() {
        if (this._delegate) {
          return this._delegate;
        }
        var tracer = this._provider.getDelegateTracer(this.name, this.version);
        if (!tracer) {
          return NOOP_TRACER;
        }
        this._delegate = tracer;
        return this._delegate;
      };
      return ProxyTracer2;
    }();
    exports2.ProxyTracer = ProxyTracer;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/NoopTracerProvider.js
var require_NoopTracerProvider = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/NoopTracerProvider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoopTracerProvider = void 0;
    var NoopTracer_1 = require_NoopTracer();
    var NoopTracerProvider = function() {
      function NoopTracerProvider2() {
      }
      NoopTracerProvider2.prototype.getTracer = function(_name, _version) {
        return new NoopTracer_1.NoopTracer();
      };
      return NoopTracerProvider2;
    }();
    exports2.NoopTracerProvider = NoopTracerProvider;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/ProxyTracerProvider.js
var require_ProxyTracerProvider = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/ProxyTracerProvider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ProxyTracerProvider = void 0;
    var ProxyTracer_1 = require_ProxyTracer();
    var NoopTracerProvider_1 = require_NoopTracerProvider();
    var NOOP_TRACER_PROVIDER = new NoopTracerProvider_1.NoopTracerProvider();
    var ProxyTracerProvider = function() {
      function ProxyTracerProvider2() {
      }
      ProxyTracerProvider2.prototype.getTracer = function(name, version) {
        var _a;
        return (_a = this.getDelegateTracer(name, version)) !== null && _a !== void 0 ? _a : new ProxyTracer_1.ProxyTracer(this, name, version);
      };
      ProxyTracerProvider2.prototype.getDelegate = function() {
        var _a;
        return (_a = this._delegate) !== null && _a !== void 0 ? _a : NOOP_TRACER_PROVIDER;
      };
      ProxyTracerProvider2.prototype.setDelegate = function(delegate) {
        this._delegate = delegate;
      };
      ProxyTracerProvider2.prototype.getDelegateTracer = function(name, version) {
        var _a;
        return (_a = this._delegate) === null || _a === void 0 ? void 0 : _a.getTracer(name, version);
      };
      return ProxyTracerProvider2;
    }();
    exports2.ProxyTracerProvider = ProxyTracerProvider;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/Sampler.js
var require_Sampler = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/Sampler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/SamplingResult.js
var require_SamplingResult = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/SamplingResult.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SamplingDecision = void 0;
    var SamplingDecision;
    (function(SamplingDecision2) {
      SamplingDecision2[SamplingDecision2["NOT_RECORD"] = 0] = "NOT_RECORD";
      SamplingDecision2[SamplingDecision2["RECORD"] = 1] = "RECORD";
      SamplingDecision2[SamplingDecision2["RECORD_AND_SAMPLED"] = 2] = "RECORD_AND_SAMPLED";
    })(SamplingDecision = exports2.SamplingDecision || (exports2.SamplingDecision = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/span_context.js
var require_span_context = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/span_context.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/span_kind.js
var require_span_kind = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/span_kind.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SpanKind = void 0;
    var SpanKind;
    (function(SpanKind2) {
      SpanKind2[SpanKind2["INTERNAL"] = 0] = "INTERNAL";
      SpanKind2[SpanKind2["SERVER"] = 1] = "SERVER";
      SpanKind2[SpanKind2["CLIENT"] = 2] = "CLIENT";
      SpanKind2[SpanKind2["PRODUCER"] = 3] = "PRODUCER";
      SpanKind2[SpanKind2["CONSUMER"] = 4] = "CONSUMER";
    })(SpanKind = exports2.SpanKind || (exports2.SpanKind = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/span.js
var require_span = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/span.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/SpanOptions.js
var require_SpanOptions = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/SpanOptions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/status.js
var require_status = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/status.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SpanStatusCode = void 0;
    var SpanStatusCode;
    (function(SpanStatusCode2) {
      SpanStatusCode2[SpanStatusCode2["UNSET"] = 0] = "UNSET";
      SpanStatusCode2[SpanStatusCode2["OK"] = 1] = "OK";
      SpanStatusCode2[SpanStatusCode2["ERROR"] = 2] = "ERROR";
    })(SpanStatusCode = exports2.SpanStatusCode || (exports2.SpanStatusCode = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/trace_state.js
var require_trace_state = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/trace_state.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/tracer_provider.js
var require_tracer_provider = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/tracer_provider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/tracer.js
var require_tracer = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/trace/tracer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/context/types.js
var require_types3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/context/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/api/trace.js
var require_trace = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/api/trace.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TraceAPI = void 0;
    var global_utils_1 = require_global_utils();
    var ProxyTracerProvider_1 = require_ProxyTracerProvider();
    var spancontext_utils_1 = require_spancontext_utils();
    var context_utils_1 = require_context_utils();
    var diag_1 = require_diag();
    var API_NAME = "trace";
    var TraceAPI = function() {
      function TraceAPI2() {
        this._proxyTracerProvider = new ProxyTracerProvider_1.ProxyTracerProvider();
        this.wrapSpanContext = spancontext_utils_1.wrapSpanContext;
        this.isSpanContextValid = spancontext_utils_1.isSpanContextValid;
        this.deleteSpan = context_utils_1.deleteSpan;
        this.getSpan = context_utils_1.getSpan;
        this.getSpanContext = context_utils_1.getSpanContext;
        this.setSpan = context_utils_1.setSpan;
        this.setSpanContext = context_utils_1.setSpanContext;
      }
      TraceAPI2.getInstance = function() {
        if (!this._instance) {
          this._instance = new TraceAPI2();
        }
        return this._instance;
      };
      TraceAPI2.prototype.setGlobalTracerProvider = function(provider) {
        var success = global_utils_1.registerGlobal(API_NAME, this._proxyTracerProvider, diag_1.DiagAPI.instance());
        if (success) {
          this._proxyTracerProvider.setDelegate(provider);
        }
        return success;
      };
      TraceAPI2.prototype.getTracerProvider = function() {
        return global_utils_1.getGlobal(API_NAME) || this._proxyTracerProvider;
      };
      TraceAPI2.prototype.getTracer = function(name, version) {
        return this.getTracerProvider().getTracer(name, version);
      };
      TraceAPI2.prototype.disable = function() {
        global_utils_1.unregisterGlobal(API_NAME, diag_1.DiagAPI.instance());
        this._proxyTracerProvider = new ProxyTracerProvider_1.ProxyTracerProvider();
      };
      return TraceAPI2;
    }();
    exports2.TraceAPI = TraceAPI;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/propagation/NoopTextMapPropagator.js
var require_NoopTextMapPropagator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/propagation/NoopTextMapPropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoopTextMapPropagator = void 0;
    var NoopTextMapPropagator = function() {
      function NoopTextMapPropagator2() {
      }
      NoopTextMapPropagator2.prototype.inject = function(_context, _carrier) {
      };
      NoopTextMapPropagator2.prototype.extract = function(context, _carrier) {
        return context;
      };
      NoopTextMapPropagator2.prototype.fields = function() {
        return [];
      };
      return NoopTextMapPropagator2;
    }();
    exports2.NoopTextMapPropagator = NoopTextMapPropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/context-helpers.js
var require_context_helpers = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/baggage/context-helpers.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.deleteBaggage = exports2.setBaggage = exports2.getBaggage = void 0;
    var context_1 = require_context();
    var BAGGAGE_KEY = context_1.createContextKey("OpenTelemetry Baggage Key");
    function getBaggage(context) {
      return context.getValue(BAGGAGE_KEY) || void 0;
    }
    exports2.getBaggage = getBaggage;
    function setBaggage(context, baggage) {
      return context.setValue(BAGGAGE_KEY, baggage);
    }
    exports2.setBaggage = setBaggage;
    function deleteBaggage(context) {
      return context.deleteValue(BAGGAGE_KEY);
    }
    exports2.deleteBaggage = deleteBaggage;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/api/propagation.js
var require_propagation = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/api/propagation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.PropagationAPI = void 0;
    var global_utils_1 = require_global_utils();
    var NoopTextMapPropagator_1 = require_NoopTextMapPropagator();
    var TextMapPropagator_1 = require_TextMapPropagator();
    var context_helpers_1 = require_context_helpers();
    var utils_1 = require_utils();
    var diag_1 = require_diag();
    var API_NAME = "propagation";
    var NOOP_TEXT_MAP_PROPAGATOR = new NoopTextMapPropagator_1.NoopTextMapPropagator();
    var PropagationAPI = function() {
      function PropagationAPI2() {
        this.createBaggage = utils_1.createBaggage;
        this.getBaggage = context_helpers_1.getBaggage;
        this.setBaggage = context_helpers_1.setBaggage;
        this.deleteBaggage = context_helpers_1.deleteBaggage;
      }
      PropagationAPI2.getInstance = function() {
        if (!this._instance) {
          this._instance = new PropagationAPI2();
        }
        return this._instance;
      };
      PropagationAPI2.prototype.setGlobalPropagator = function(propagator) {
        return global_utils_1.registerGlobal(API_NAME, propagator, diag_1.DiagAPI.instance());
      };
      PropagationAPI2.prototype.inject = function(context, carrier, setter) {
        if (setter === void 0) {
          setter = TextMapPropagator_1.defaultTextMapSetter;
        }
        return this._getGlobalPropagator().inject(context, carrier, setter);
      };
      PropagationAPI2.prototype.extract = function(context, carrier, getter) {
        if (getter === void 0) {
          getter = TextMapPropagator_1.defaultTextMapGetter;
        }
        return this._getGlobalPropagator().extract(context, carrier, getter);
      };
      PropagationAPI2.prototype.fields = function() {
        return this._getGlobalPropagator().fields();
      };
      PropagationAPI2.prototype.disable = function() {
        global_utils_1.unregisterGlobal(API_NAME, diag_1.DiagAPI.instance());
      };
      PropagationAPI2.prototype._getGlobalPropagator = function() {
        return global_utils_1.getGlobal(API_NAME) || NOOP_TEXT_MAP_PROPAGATOR;
      };
      return PropagationAPI2;
    }();
    exports2.PropagationAPI = PropagationAPI;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/index.js
var require_src = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.diag = exports2.propagation = exports2.trace = exports2.context = exports2.INVALID_SPAN_CONTEXT = exports2.INVALID_TRACEID = exports2.INVALID_SPANID = exports2.isValidSpanId = exports2.isValidTraceId = exports2.isSpanContextValid = exports2.baggageEntryMetadataFromString = void 0;
    __exportStar(require_types(), exports2);
    var utils_1 = require_utils();
    Object.defineProperty(exports2, "baggageEntryMetadataFromString", { enumerable: true, get: function() {
      return utils_1.baggageEntryMetadataFromString;
    } });
    __exportStar(require_Exception(), exports2);
    __exportStar(require_Time(), exports2);
    __exportStar(require_diag2(), exports2);
    __exportStar(require_TextMapPropagator(), exports2);
    __exportStar(require_attributes(), exports2);
    __exportStar(require_link(), exports2);
    __exportStar(require_ProxyTracer(), exports2);
    __exportStar(require_ProxyTracerProvider(), exports2);
    __exportStar(require_Sampler(), exports2);
    __exportStar(require_SamplingResult(), exports2);
    __exportStar(require_span_context(), exports2);
    __exportStar(require_span_kind(), exports2);
    __exportStar(require_span(), exports2);
    __exportStar(require_SpanOptions(), exports2);
    __exportStar(require_status(), exports2);
    __exportStar(require_trace_flags(), exports2);
    __exportStar(require_trace_state(), exports2);
    __exportStar(require_tracer_provider(), exports2);
    __exportStar(require_tracer(), exports2);
    var spancontext_utils_1 = require_spancontext_utils();
    Object.defineProperty(exports2, "isSpanContextValid", { enumerable: true, get: function() {
      return spancontext_utils_1.isSpanContextValid;
    } });
    Object.defineProperty(exports2, "isValidTraceId", { enumerable: true, get: function() {
      return spancontext_utils_1.isValidTraceId;
    } });
    Object.defineProperty(exports2, "isValidSpanId", { enumerable: true, get: function() {
      return spancontext_utils_1.isValidSpanId;
    } });
    var invalid_span_constants_1 = require_invalid_span_constants();
    Object.defineProperty(exports2, "INVALID_SPANID", { enumerable: true, get: function() {
      return invalid_span_constants_1.INVALID_SPANID;
    } });
    Object.defineProperty(exports2, "INVALID_TRACEID", { enumerable: true, get: function() {
      return invalid_span_constants_1.INVALID_TRACEID;
    } });
    Object.defineProperty(exports2, "INVALID_SPAN_CONTEXT", { enumerable: true, get: function() {
      return invalid_span_constants_1.INVALID_SPAN_CONTEXT;
    } });
    __exportStar(require_context(), exports2);
    __exportStar(require_types3(), exports2);
    var context_1 = require_context2();
    exports2.context = context_1.ContextAPI.getInstance();
    var trace_1 = require_trace();
    exports2.trace = trace_1.TraceAPI.getInstance();
    var propagation_1 = require_propagation();
    exports2.propagation = propagation_1.PropagationAPI.getInstance();
    var diag_1 = require_diag();
    exports2.diag = diag_1.DiagAPI.instance();
    exports2.default = {
      trace: exports2.trace,
      context: exports2.context,
      propagation: exports2.propagation,
      diag: exports2.diag
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/context-async-hooks/build/src/AbstractAsyncHooksContextManager.js
var require_AbstractAsyncHooksContextManager = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/context-async-hooks/build/src/AbstractAsyncHooksContextManager.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AbstractAsyncHooksContextManager = void 0;
    var events_1 = require("events");
    var ADD_LISTENER_METHODS = [
      "addListener",
      "on",
      "once",
      "prependListener",
      "prependOnceListener"
    ];
    var AbstractAsyncHooksContextManager = class {
      constructor() {
        this._kOtListeners = Symbol("OtListeners");
      }
      bind(context, target) {
        if (target instanceof events_1.EventEmitter) {
          return this._bindEventEmitter(context, target);
        }
        if (typeof target === "function") {
          return this._bindFunction(context, target);
        }
        return target;
      }
      _bindFunction(context, target) {
        const manager = this;
        const contextWrapper = function(...args) {
          return manager.with(context, () => target.apply(this, args));
        };
        Object.defineProperty(contextWrapper, "length", {
          enumerable: false,
          configurable: true,
          writable: false,
          value: target.length
        });
        return contextWrapper;
      }
      _bindEventEmitter(context, ee) {
        const map = this._getPatchMap(ee);
        if (map !== void 0)
          return ee;
        this._createPatchMap(ee);
        ADD_LISTENER_METHODS.forEach((methodName) => {
          if (ee[methodName] === void 0)
            return;
          ee[methodName] = this._patchAddListener(ee, ee[methodName], context);
        });
        if (typeof ee.removeListener === "function") {
          ee.removeListener = this._patchRemoveListener(ee, ee.removeListener);
        }
        if (typeof ee.off === "function") {
          ee.off = this._patchRemoveListener(ee, ee.off);
        }
        if (typeof ee.removeAllListeners === "function") {
          ee.removeAllListeners = this._patchRemoveAllListeners(ee, ee.removeAllListeners);
        }
        return ee;
      }
      _patchRemoveListener(ee, original) {
        const contextManager = this;
        return function(event, listener) {
          var _a;
          const events = (_a = contextManager._getPatchMap(ee)) === null || _a === void 0 ? void 0 : _a[event];
          if (events === void 0) {
            return original.call(this, event, listener);
          }
          const patchedListener = events.get(listener);
          return original.call(this, event, patchedListener || listener);
        };
      }
      _patchRemoveAllListeners(ee, original) {
        const contextManager = this;
        return function(event) {
          const map = contextManager._getPatchMap(ee);
          if (map !== void 0) {
            if (arguments.length === 0) {
              contextManager._createPatchMap(ee);
            } else if (map[event] !== void 0) {
              delete map[event];
            }
          }
          return original.apply(this, arguments);
        };
      }
      _patchAddListener(ee, original, context) {
        const contextManager = this;
        return function(event, listener) {
          let map = contextManager._getPatchMap(ee);
          if (map === void 0) {
            map = contextManager._createPatchMap(ee);
          }
          let listeners = map[event];
          if (listeners === void 0) {
            listeners = /* @__PURE__ */ new WeakMap();
            map[event] = listeners;
          }
          const patchedListener = contextManager.bind(context, listener);
          listeners.set(listener, patchedListener);
          return original.call(this, event, patchedListener);
        };
      }
      _createPatchMap(ee) {
        const map = /* @__PURE__ */ Object.create(null);
        ee[this._kOtListeners] = map;
        return map;
      }
      _getPatchMap(ee) {
        return ee[this._kOtListeners];
      }
    };
    exports2.AbstractAsyncHooksContextManager = AbstractAsyncHooksContextManager;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/context-async-hooks/build/src/AsyncHooksContextManager.js
var require_AsyncHooksContextManager = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/context-async-hooks/build/src/AsyncHooksContextManager.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AsyncHooksContextManager = void 0;
    var api_1 = require_src();
    var asyncHooks = require("async_hooks");
    var AbstractAsyncHooksContextManager_1 = require_AbstractAsyncHooksContextManager();
    var AsyncHooksContextManager = class extends AbstractAsyncHooksContextManager_1.AbstractAsyncHooksContextManager {
      constructor() {
        super();
        this._contexts = /* @__PURE__ */ new Map();
        this._stack = [];
        this._asyncHook = asyncHooks.createHook({
          init: this._init.bind(this),
          before: this._before.bind(this),
          after: this._after.bind(this),
          destroy: this._destroy.bind(this),
          promiseResolve: this._destroy.bind(this)
        });
      }
      active() {
        var _a;
        return (_a = this._stack[this._stack.length - 1]) !== null && _a !== void 0 ? _a : api_1.ROOT_CONTEXT;
      }
      with(context, fn, thisArg, ...args) {
        this._enterContext(context);
        try {
          return fn.call(thisArg, ...args);
        } finally {
          this._exitContext();
        }
      }
      enable() {
        this._asyncHook.enable();
        return this;
      }
      disable() {
        this._asyncHook.disable();
        this._contexts.clear();
        this._stack = [];
        return this;
      }
      _init(uid, type) {
        if (type === "TIMERWRAP")
          return;
        const context = this._stack[this._stack.length - 1];
        if (context !== void 0) {
          this._contexts.set(uid, context);
        }
      }
      _destroy(uid) {
        this._contexts.delete(uid);
      }
      _before(uid) {
        const context = this._contexts.get(uid);
        if (context !== void 0) {
          this._enterContext(context);
        }
      }
      _after() {
        this._exitContext();
      }
      _enterContext(context) {
        this._stack.push(context);
      }
      _exitContext() {
        this._stack.pop();
      }
    };
    exports2.AsyncHooksContextManager = AsyncHooksContextManager;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/context-async-hooks/build/src/AsyncLocalStorageContextManager.js
var require_AsyncLocalStorageContextManager = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/context-async-hooks/build/src/AsyncLocalStorageContextManager.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AsyncLocalStorageContextManager = void 0;
    var api_1 = require_src();
    var async_hooks_1 = require("async_hooks");
    var AbstractAsyncHooksContextManager_1 = require_AbstractAsyncHooksContextManager();
    var AsyncLocalStorageContextManager = class extends AbstractAsyncHooksContextManager_1.AbstractAsyncHooksContextManager {
      constructor() {
        super();
        this._asyncLocalStorage = new async_hooks_1.AsyncLocalStorage();
      }
      active() {
        var _a;
        return (_a = this._asyncLocalStorage.getStore()) !== null && _a !== void 0 ? _a : api_1.ROOT_CONTEXT;
      }
      with(context, fn, thisArg, ...args) {
        const cb = thisArg == null ? fn : fn.bind(thisArg);
        return this._asyncLocalStorage.run(context, cb, ...args);
      }
      enable() {
        return this;
      }
      disable() {
        this._asyncLocalStorage.disable();
        return this;
      }
    };
    exports2.AsyncLocalStorageContextManager = AsyncLocalStorageContextManager;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/context-async-hooks/build/src/index.js
var require_src2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/context-async-hooks/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_AsyncHooksContextManager(), exports2);
    __exportStar(require_AsyncLocalStorageContextManager(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/suppress-tracing.js
var require_suppress_tracing = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/suppress-tracing.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isTracingSuppressed = exports2.unsuppressTracing = exports2.suppressTracing = void 0;
    var api_1 = require_src();
    var SUPPRESS_TRACING_KEY = (0, api_1.createContextKey)("OpenTelemetry SDK Context Key SUPPRESS_TRACING");
    function suppressTracing(context) {
      return context.setValue(SUPPRESS_TRACING_KEY, true);
    }
    exports2.suppressTracing = suppressTracing;
    function unsuppressTracing(context) {
      return context.deleteValue(SUPPRESS_TRACING_KEY);
    }
    exports2.unsuppressTracing = unsuppressTracing;
    function isTracingSuppressed(context) {
      return context.getValue(SUPPRESS_TRACING_KEY) === true;
    }
    exports2.isTracingSuppressed = isTracingSuppressed;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/baggage/constants.js
var require_constants = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/baggage/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BAGGAGE_MAX_TOTAL_LENGTH = exports2.BAGGAGE_MAX_PER_NAME_VALUE_PAIRS = exports2.BAGGAGE_MAX_NAME_VALUE_PAIRS = exports2.BAGGAGE_HEADER = exports2.BAGGAGE_ITEMS_SEPARATOR = exports2.BAGGAGE_PROPERTIES_SEPARATOR = exports2.BAGGAGE_KEY_PAIR_SEPARATOR = void 0;
    exports2.BAGGAGE_KEY_PAIR_SEPARATOR = "=";
    exports2.BAGGAGE_PROPERTIES_SEPARATOR = ";";
    exports2.BAGGAGE_ITEMS_SEPARATOR = ",";
    exports2.BAGGAGE_HEADER = "baggage";
    exports2.BAGGAGE_MAX_NAME_VALUE_PAIRS = 180;
    exports2.BAGGAGE_MAX_PER_NAME_VALUE_PAIRS = 4096;
    exports2.BAGGAGE_MAX_TOTAL_LENGTH = 8192;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/baggage/utils.js
var require_utils2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/baggage/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.parseKeyPairsIntoRecord = exports2.parsePairKeyValue = exports2.getKeyPairs = exports2.serializeKeyPairs = void 0;
    var api_1 = require_src();
    var constants_1 = require_constants();
    function serializeKeyPairs(keyPairs) {
      return keyPairs.reduce((hValue, current) => {
        const value = `${hValue}${hValue !== "" ? constants_1.BAGGAGE_ITEMS_SEPARATOR : ""}${current}`;
        return value.length > constants_1.BAGGAGE_MAX_TOTAL_LENGTH ? hValue : value;
      }, "");
    }
    exports2.serializeKeyPairs = serializeKeyPairs;
    function getKeyPairs(baggage) {
      return baggage.getAllEntries().map(([key, value]) => {
        let entry = `${encodeURIComponent(key)}=${encodeURIComponent(value.value)}`;
        if (value.metadata !== void 0) {
          entry += constants_1.BAGGAGE_PROPERTIES_SEPARATOR + value.metadata.toString();
        }
        return entry;
      });
    }
    exports2.getKeyPairs = getKeyPairs;
    function parsePairKeyValue(entry) {
      const valueProps = entry.split(constants_1.BAGGAGE_PROPERTIES_SEPARATOR);
      if (valueProps.length <= 0)
        return;
      const keyPairPart = valueProps.shift();
      if (!keyPairPart)
        return;
      const keyPair = keyPairPart.split(constants_1.BAGGAGE_KEY_PAIR_SEPARATOR);
      if (keyPair.length !== 2)
        return;
      const key = decodeURIComponent(keyPair[0].trim());
      const value = decodeURIComponent(keyPair[1].trim());
      let metadata;
      if (valueProps.length > 0) {
        metadata = (0, api_1.baggageEntryMetadataFromString)(valueProps.join(constants_1.BAGGAGE_PROPERTIES_SEPARATOR));
      }
      return { key, value, metadata };
    }
    exports2.parsePairKeyValue = parsePairKeyValue;
    function parseKeyPairsIntoRecord(value) {
      if (typeof value !== "string" || value.length === 0)
        return {};
      return value.split(constants_1.BAGGAGE_ITEMS_SEPARATOR).map((entry) => {
        return parsePairKeyValue(entry);
      }).filter((keyPair) => keyPair !== void 0 && keyPair.value.length > 0).reduce((headers, keyPair) => {
        headers[keyPair.key] = keyPair.value;
        return headers;
      }, {});
    }
    exports2.parseKeyPairsIntoRecord = parseKeyPairsIntoRecord;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/baggage/propagation/W3CBaggagePropagator.js
var require_W3CBaggagePropagator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/baggage/propagation/W3CBaggagePropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.W3CBaggagePropagator = void 0;
    var api_1 = require_src();
    var suppress_tracing_1 = require_suppress_tracing();
    var constants_1 = require_constants();
    var utils_1 = require_utils2();
    var W3CBaggagePropagator = class {
      inject(context, carrier, setter) {
        const baggage = api_1.propagation.getBaggage(context);
        if (!baggage || (0, suppress_tracing_1.isTracingSuppressed)(context))
          return;
        const keyPairs = (0, utils_1.getKeyPairs)(baggage).filter((pair) => {
          return pair.length <= constants_1.BAGGAGE_MAX_PER_NAME_VALUE_PAIRS;
        }).slice(0, constants_1.BAGGAGE_MAX_NAME_VALUE_PAIRS);
        const headerValue = (0, utils_1.serializeKeyPairs)(keyPairs);
        if (headerValue.length > 0) {
          setter.set(carrier, constants_1.BAGGAGE_HEADER, headerValue);
        }
      }
      extract(context, carrier, getter) {
        const headerValue = getter.get(carrier, constants_1.BAGGAGE_HEADER);
        const baggageString = Array.isArray(headerValue) ? headerValue.join(constants_1.BAGGAGE_ITEMS_SEPARATOR) : headerValue;
        if (!baggageString)
          return context;
        const baggage = {};
        if (baggageString.length === 0) {
          return context;
        }
        const pairs = baggageString.split(constants_1.BAGGAGE_ITEMS_SEPARATOR);
        pairs.forEach((entry) => {
          const keyPair = (0, utils_1.parsePairKeyValue)(entry);
          if (keyPair) {
            const baggageEntry = { value: keyPair.value };
            if (keyPair.metadata) {
              baggageEntry.metadata = keyPair.metadata;
            }
            baggage[keyPair.key] = baggageEntry;
          }
        });
        if (Object.entries(baggage).length === 0) {
          return context;
        }
        return api_1.propagation.setBaggage(context, api_1.propagation.createBaggage(baggage));
      }
      fields() {
        return [constants_1.BAGGAGE_HEADER];
      }
    };
    exports2.W3CBaggagePropagator = W3CBaggagePropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/attributes.js
var require_attributes2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/attributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isAttributeValue = exports2.isAttributeKey = exports2.sanitizeAttributes = void 0;
    var api_1 = require_src();
    function sanitizeAttributes(attributes) {
      const out = {};
      if (typeof attributes !== "object" || attributes == null) {
        return out;
      }
      for (const [key, val] of Object.entries(attributes)) {
        if (!isAttributeKey(key)) {
          api_1.diag.warn(`Invalid attribute key: ${key}`);
          continue;
        }
        if (!isAttributeValue(val)) {
          api_1.diag.warn(`Invalid attribute value set for key: ${key}`);
          continue;
        }
        if (Array.isArray(val)) {
          out[key] = val.slice();
        } else {
          out[key] = val;
        }
      }
      return out;
    }
    exports2.sanitizeAttributes = sanitizeAttributes;
    function isAttributeKey(key) {
      return typeof key === "string" && key.length > 0;
    }
    exports2.isAttributeKey = isAttributeKey;
    function isAttributeValue(val) {
      if (val == null) {
        return true;
      }
      if (Array.isArray(val)) {
        return isHomogeneousAttributeValueArray(val);
      }
      return isValidPrimitiveAttributeValue(val);
    }
    exports2.isAttributeValue = isAttributeValue;
    function isHomogeneousAttributeValueArray(arr) {
      let type;
      for (const element of arr) {
        if (element == null)
          continue;
        if (!type) {
          if (isValidPrimitiveAttributeValue(element)) {
            type = typeof element;
            continue;
          }
          return false;
        }
        if (typeof element === type) {
          continue;
        }
        return false;
      }
      return true;
    }
    function isValidPrimitiveAttributeValue(val) {
      switch (typeof val) {
        case "number":
        case "boolean":
        case "string":
          return true;
      }
      return false;
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/logging-error-handler.js
var require_logging_error_handler = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/logging-error-handler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.loggingErrorHandler = void 0;
    var api_1 = require_src();
    function loggingErrorHandler() {
      return (ex) => {
        api_1.diag.error(stringifyException(ex));
      };
    }
    exports2.loggingErrorHandler = loggingErrorHandler;
    function stringifyException(ex) {
      if (typeof ex === "string") {
        return ex;
      } else {
        return JSON.stringify(flattenException(ex));
      }
    }
    function flattenException(ex) {
      const result = {};
      let current = ex;
      while (current !== null) {
        Object.getOwnPropertyNames(current).forEach((propertyName) => {
          if (result[propertyName])
            return;
          const value = current[propertyName];
          if (value) {
            result[propertyName] = String(value);
          }
        });
        current = Object.getPrototypeOf(current);
      }
      return result;
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/global-error-handler.js
var require_global_error_handler = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/global-error-handler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.globalErrorHandler = exports2.setGlobalErrorHandler = void 0;
    var logging_error_handler_1 = require_logging_error_handler();
    var delegateHandler = (0, logging_error_handler_1.loggingErrorHandler)();
    function setGlobalErrorHandler(handler) {
      delegateHandler = handler;
    }
    exports2.setGlobalErrorHandler = setGlobalErrorHandler;
    function globalErrorHandler(ex) {
      try {
        delegateHandler(ex);
      } catch (_a) {
      }
    }
    exports2.globalErrorHandler = globalErrorHandler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/sampling.js
var require_sampling = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/sampling.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TracesSamplerValues = void 0;
    var TracesSamplerValues;
    (function(TracesSamplerValues2) {
      TracesSamplerValues2["AlwaysOff"] = "always_off";
      TracesSamplerValues2["AlwaysOn"] = "always_on";
      TracesSamplerValues2["ParentBasedAlwaysOff"] = "parentbased_always_off";
      TracesSamplerValues2["ParentBasedAlwaysOn"] = "parentbased_always_on";
      TracesSamplerValues2["ParentBasedTraceIdRatio"] = "parentbased_traceidratio";
      TracesSamplerValues2["TraceIdRatio"] = "traceidratio";
    })(TracesSamplerValues = exports2.TracesSamplerValues || (exports2.TracesSamplerValues = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/environment.js
var require_environment = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/environment.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.parseEnvironment = exports2.DEFAULT_ENVIRONMENT = exports2.DEFAULT_ATTRIBUTE_COUNT_LIMIT = exports2.DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT = void 0;
    var api_1 = require_src();
    var sampling_1 = require_sampling();
    var DEFAULT_LIST_SEPARATOR = ",";
    var ENVIRONMENT_NUMBERS_KEYS = [
      "OTEL_BSP_EXPORT_TIMEOUT",
      "OTEL_BSP_MAX_EXPORT_BATCH_SIZE",
      "OTEL_BSP_MAX_QUEUE_SIZE",
      "OTEL_BSP_SCHEDULE_DELAY",
      "OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT",
      "OTEL_ATTRIBUTE_COUNT_LIMIT",
      "OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT",
      "OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT",
      "OTEL_SPAN_EVENT_COUNT_LIMIT",
      "OTEL_SPAN_LINK_COUNT_LIMIT",
      "OTEL_EXPORTER_OTLP_TIMEOUT",
      "OTEL_EXPORTER_OTLP_TRACES_TIMEOUT",
      "OTEL_EXPORTER_OTLP_METRICS_TIMEOUT",
      "OTEL_EXPORTER_JAEGER_AGENT_PORT"
    ];
    function isEnvVarANumber(key) {
      return ENVIRONMENT_NUMBERS_KEYS.indexOf(key) > -1;
    }
    var ENVIRONMENT_LISTS_KEYS = [
      "OTEL_NO_PATCH_MODULES",
      "OTEL_PROPAGATORS"
    ];
    function isEnvVarAList(key) {
      return ENVIRONMENT_LISTS_KEYS.indexOf(key) > -1;
    }
    exports2.DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT = Infinity;
    exports2.DEFAULT_ATTRIBUTE_COUNT_LIMIT = 128;
    exports2.DEFAULT_ENVIRONMENT = {
      CONTAINER_NAME: "",
      ECS_CONTAINER_METADATA_URI_V4: "",
      ECS_CONTAINER_METADATA_URI: "",
      HOSTNAME: "",
      KUBERNETES_SERVICE_HOST: "",
      NAMESPACE: "",
      OTEL_BSP_EXPORT_TIMEOUT: 3e4,
      OTEL_BSP_MAX_EXPORT_BATCH_SIZE: 512,
      OTEL_BSP_MAX_QUEUE_SIZE: 2048,
      OTEL_BSP_SCHEDULE_DELAY: 5e3,
      OTEL_EXPORTER_JAEGER_AGENT_HOST: "",
      OTEL_EXPORTER_JAEGER_AGENT_PORT: 6832,
      OTEL_EXPORTER_JAEGER_ENDPOINT: "",
      OTEL_EXPORTER_JAEGER_PASSWORD: "",
      OTEL_EXPORTER_JAEGER_USER: "",
      OTEL_EXPORTER_OTLP_ENDPOINT: "",
      OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: "",
      OTEL_EXPORTER_OTLP_METRICS_ENDPOINT: "",
      OTEL_EXPORTER_OTLP_HEADERS: "",
      OTEL_EXPORTER_OTLP_TRACES_HEADERS: "",
      OTEL_EXPORTER_OTLP_METRICS_HEADERS: "",
      OTEL_EXPORTER_OTLP_TIMEOUT: 1e4,
      OTEL_EXPORTER_OTLP_TRACES_TIMEOUT: 1e4,
      OTEL_EXPORTER_OTLP_METRICS_TIMEOUT: 1e4,
      OTEL_EXPORTER_ZIPKIN_ENDPOINT: "http://localhost:9411/api/v2/spans",
      OTEL_LOG_LEVEL: api_1.DiagLogLevel.INFO,
      OTEL_NO_PATCH_MODULES: [],
      OTEL_PROPAGATORS: ["tracecontext", "baggage"],
      OTEL_RESOURCE_ATTRIBUTES: "",
      OTEL_SERVICE_NAME: "",
      OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT: exports2.DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT,
      OTEL_ATTRIBUTE_COUNT_LIMIT: exports2.DEFAULT_ATTRIBUTE_COUNT_LIMIT,
      OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT: exports2.DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT,
      OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT: exports2.DEFAULT_ATTRIBUTE_COUNT_LIMIT,
      OTEL_SPAN_EVENT_COUNT_LIMIT: 128,
      OTEL_SPAN_LINK_COUNT_LIMIT: 128,
      OTEL_TRACES_EXPORTER: "none",
      OTEL_TRACES_SAMPLER: sampling_1.TracesSamplerValues.ParentBasedAlwaysOn,
      OTEL_TRACES_SAMPLER_ARG: "",
      OTEL_EXPORTER_OTLP_INSECURE: "",
      OTEL_EXPORTER_OTLP_TRACES_INSECURE: "",
      OTEL_EXPORTER_OTLP_METRICS_INSECURE: "",
      OTEL_EXPORTER_OTLP_CERTIFICATE: "",
      OTEL_EXPORTER_OTLP_TRACES_CERTIFICATE: "",
      OTEL_EXPORTER_OTLP_METRICS_CERTIFICATE: "",
      OTEL_EXPORTER_OTLP_COMPRESSION: "",
      OTEL_EXPORTER_OTLP_TRACES_COMPRESSION: "",
      OTEL_EXPORTER_OTLP_METRICS_COMPRESSION: "",
      OTEL_EXPORTER_OTLP_CLIENT_KEY: "",
      OTEL_EXPORTER_OTLP_TRACES_CLIENT_KEY: "",
      OTEL_EXPORTER_OTLP_METRICS_CLIENT_KEY: "",
      OTEL_EXPORTER_OTLP_CLIENT_CERTIFICATE: "",
      OTEL_EXPORTER_OTLP_TRACES_CLIENT_CERTIFICATE: "",
      OTEL_EXPORTER_OTLP_METRICS_CLIENT_CERTIFICATE: ""
    };
    function parseNumber(name, environment, values, min = -Infinity, max = Infinity) {
      if (typeof values[name] !== "undefined") {
        const value = Number(values[name]);
        if (!isNaN(value)) {
          if (value < min) {
            environment[name] = min;
          } else if (value > max) {
            environment[name] = max;
          } else {
            environment[name] = value;
          }
        }
      }
    }
    function parseStringList(name, output, input, separator = DEFAULT_LIST_SEPARATOR) {
      const givenValue = input[name];
      if (typeof givenValue === "string") {
        output[name] = givenValue.split(separator).map((v) => v.trim());
      }
    }
    var logLevelMap = {
      ALL: api_1.DiagLogLevel.ALL,
      VERBOSE: api_1.DiagLogLevel.VERBOSE,
      DEBUG: api_1.DiagLogLevel.DEBUG,
      INFO: api_1.DiagLogLevel.INFO,
      WARN: api_1.DiagLogLevel.WARN,
      ERROR: api_1.DiagLogLevel.ERROR,
      NONE: api_1.DiagLogLevel.NONE
    };
    function setLogLevelFromEnv(key, environment, values) {
      const value = values[key];
      if (typeof value === "string") {
        const theLevel = logLevelMap[value.toUpperCase()];
        if (theLevel != null) {
          environment[key] = theLevel;
        }
      }
    }
    function parseEnvironment(values) {
      const environment = {};
      for (const env in exports2.DEFAULT_ENVIRONMENT) {
        const key = env;
        switch (key) {
          case "OTEL_LOG_LEVEL":
            setLogLevelFromEnv(key, environment, values);
            break;
          default:
            if (isEnvVarANumber(key)) {
              parseNumber(key, environment, values);
            } else if (isEnvVarAList(key)) {
              parseStringList(key, environment, values);
            } else {
              const value = values[key];
              if (typeof value !== "undefined" && value !== null) {
                environment[key] = String(value);
              }
            }
        }
      }
      return environment;
    }
    exports2.parseEnvironment = parseEnvironment;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/environment.js
var require_environment2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/environment.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getEnv = void 0;
    var os = require("os");
    var environment_1 = require_environment();
    function getEnv2() {
      const processEnv = (0, environment_1.parseEnvironment)(process.env);
      return Object.assign({
        HOSTNAME: os.hostname()
      }, environment_1.DEFAULT_ENVIRONMENT, processEnv);
    }
    exports2.getEnv = getEnv2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/globalThis.js
var require_globalThis2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/globalThis.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2._globalThis = void 0;
    exports2._globalThis = typeof globalThis === "object" ? globalThis : global;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/hex-to-base64.js
var require_hex_to_base64 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/hex-to-base64.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.hexToBase64 = void 0;
    function hexToBase64(hexStr) {
      const hexStrLen = hexStr.length;
      let hexAsciiCharsStr = "";
      for (let i = 0; i < hexStrLen; i += 2) {
        const hexPair = hexStr.substring(i, i + 2);
        const hexVal = parseInt(hexPair, 16);
        hexAsciiCharsStr += String.fromCharCode(hexVal);
      }
      return Buffer.from(hexAsciiCharsStr, "ascii").toString("base64");
    }
    exports2.hexToBase64 = hexToBase64;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/RandomIdGenerator.js
var require_RandomIdGenerator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/RandomIdGenerator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RandomIdGenerator = void 0;
    var SPAN_ID_BYTES = 8;
    var TRACE_ID_BYTES = 16;
    var RandomIdGenerator = class {
      constructor() {
        this.generateTraceId = getIdGenerator(TRACE_ID_BYTES);
        this.generateSpanId = getIdGenerator(SPAN_ID_BYTES);
      }
    };
    exports2.RandomIdGenerator = RandomIdGenerator;
    var SHARED_BUFFER = Buffer.allocUnsafe(TRACE_ID_BYTES);
    function getIdGenerator(bytes) {
      return function generateId() {
        for (let i = 0; i < bytes / 4; i++) {
          SHARED_BUFFER.writeUInt32BE(Math.random() * 2 ** 32 >>> 0, i * 4);
        }
        for (let i = 0; i < bytes; i++) {
          if (SHARED_BUFFER[i] > 0) {
            break;
          } else if (i === bytes - 1) {
            SHARED_BUFFER[bytes - 1] = 1;
          }
        }
        return SHARED_BUFFER.toString("hex", 0, bytes);
      };
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/performance.js
var require_performance = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/performance.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.otperformance = void 0;
    var perf_hooks_1 = require("perf_hooks");
    exports2.otperformance = perf_hooks_1.performance;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/version.js
var require_version2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "1.3.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/trace/SemanticAttributes.js
var require_SemanticAttributes = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/trace/SemanticAttributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MessageTypeValues = exports2.RpcGrpcStatusCodeValues = exports2.MessagingOperationValues = exports2.MessagingDestinationKindValues = exports2.HttpFlavorValues = exports2.NetHostConnectionSubtypeValues = exports2.NetHostConnectionTypeValues = exports2.NetTransportValues = exports2.FaasInvokedProviderValues = exports2.FaasDocumentOperationValues = exports2.FaasTriggerValues = exports2.DbCassandraConsistencyLevelValues = exports2.DbSystemValues = exports2.SemanticAttributes = void 0;
    exports2.SemanticAttributes = {
      AWS_LAMBDA_INVOKED_ARN: "aws.lambda.invoked_arn",
      DB_SYSTEM: "db.system",
      DB_CONNECTION_STRING: "db.connection_string",
      DB_USER: "db.user",
      DB_JDBC_DRIVER_CLASSNAME: "db.jdbc.driver_classname",
      DB_NAME: "db.name",
      DB_STATEMENT: "db.statement",
      DB_OPERATION: "db.operation",
      DB_MSSQL_INSTANCE_NAME: "db.mssql.instance_name",
      DB_CASSANDRA_KEYSPACE: "db.cassandra.keyspace",
      DB_CASSANDRA_PAGE_SIZE: "db.cassandra.page_size",
      DB_CASSANDRA_CONSISTENCY_LEVEL: "db.cassandra.consistency_level",
      DB_CASSANDRA_TABLE: "db.cassandra.table",
      DB_CASSANDRA_IDEMPOTENCE: "db.cassandra.idempotence",
      DB_CASSANDRA_SPECULATIVE_EXECUTION_COUNT: "db.cassandra.speculative_execution_count",
      DB_CASSANDRA_COORDINATOR_ID: "db.cassandra.coordinator.id",
      DB_CASSANDRA_COORDINATOR_DC: "db.cassandra.coordinator.dc",
      DB_HBASE_NAMESPACE: "db.hbase.namespace",
      DB_REDIS_DATABASE_INDEX: "db.redis.database_index",
      DB_MONGODB_COLLECTION: "db.mongodb.collection",
      DB_SQL_TABLE: "db.sql.table",
      EXCEPTION_TYPE: "exception.type",
      EXCEPTION_MESSAGE: "exception.message",
      EXCEPTION_STACKTRACE: "exception.stacktrace",
      EXCEPTION_ESCAPED: "exception.escaped",
      FAAS_TRIGGER: "faas.trigger",
      FAAS_EXECUTION: "faas.execution",
      FAAS_DOCUMENT_COLLECTION: "faas.document.collection",
      FAAS_DOCUMENT_OPERATION: "faas.document.operation",
      FAAS_DOCUMENT_TIME: "faas.document.time",
      FAAS_DOCUMENT_NAME: "faas.document.name",
      FAAS_TIME: "faas.time",
      FAAS_CRON: "faas.cron",
      FAAS_COLDSTART: "faas.coldstart",
      FAAS_INVOKED_NAME: "faas.invoked_name",
      FAAS_INVOKED_PROVIDER: "faas.invoked_provider",
      FAAS_INVOKED_REGION: "faas.invoked_region",
      NET_TRANSPORT: "net.transport",
      NET_PEER_IP: "net.peer.ip",
      NET_PEER_PORT: "net.peer.port",
      NET_PEER_NAME: "net.peer.name",
      NET_HOST_IP: "net.host.ip",
      NET_HOST_PORT: "net.host.port",
      NET_HOST_NAME: "net.host.name",
      NET_HOST_CONNECTION_TYPE: "net.host.connection.type",
      NET_HOST_CONNECTION_SUBTYPE: "net.host.connection.subtype",
      NET_HOST_CARRIER_NAME: "net.host.carrier.name",
      NET_HOST_CARRIER_MCC: "net.host.carrier.mcc",
      NET_HOST_CARRIER_MNC: "net.host.carrier.mnc",
      NET_HOST_CARRIER_ICC: "net.host.carrier.icc",
      PEER_SERVICE: "peer.service",
      ENDUSER_ID: "enduser.id",
      ENDUSER_ROLE: "enduser.role",
      ENDUSER_SCOPE: "enduser.scope",
      THREAD_ID: "thread.id",
      THREAD_NAME: "thread.name",
      CODE_FUNCTION: "code.function",
      CODE_NAMESPACE: "code.namespace",
      CODE_FILEPATH: "code.filepath",
      CODE_LINENO: "code.lineno",
      HTTP_METHOD: "http.method",
      HTTP_URL: "http.url",
      HTTP_TARGET: "http.target",
      HTTP_HOST: "http.host",
      HTTP_SCHEME: "http.scheme",
      HTTP_STATUS_CODE: "http.status_code",
      HTTP_FLAVOR: "http.flavor",
      HTTP_USER_AGENT: "http.user_agent",
      HTTP_REQUEST_CONTENT_LENGTH: "http.request_content_length",
      HTTP_REQUEST_CONTENT_LENGTH_UNCOMPRESSED: "http.request_content_length_uncompressed",
      HTTP_RESPONSE_CONTENT_LENGTH: "http.response_content_length",
      HTTP_RESPONSE_CONTENT_LENGTH_UNCOMPRESSED: "http.response_content_length_uncompressed",
      HTTP_SERVER_NAME: "http.server_name",
      HTTP_ROUTE: "http.route",
      HTTP_CLIENT_IP: "http.client_ip",
      AWS_DYNAMODB_TABLE_NAMES: "aws.dynamodb.table_names",
      AWS_DYNAMODB_CONSUMED_CAPACITY: "aws.dynamodb.consumed_capacity",
      AWS_DYNAMODB_ITEM_COLLECTION_METRICS: "aws.dynamodb.item_collection_metrics",
      AWS_DYNAMODB_PROVISIONED_READ_CAPACITY: "aws.dynamodb.provisioned_read_capacity",
      AWS_DYNAMODB_PROVISIONED_WRITE_CAPACITY: "aws.dynamodb.provisioned_write_capacity",
      AWS_DYNAMODB_CONSISTENT_READ: "aws.dynamodb.consistent_read",
      AWS_DYNAMODB_PROJECTION: "aws.dynamodb.projection",
      AWS_DYNAMODB_LIMIT: "aws.dynamodb.limit",
      AWS_DYNAMODB_ATTRIBUTES_TO_GET: "aws.dynamodb.attributes_to_get",
      AWS_DYNAMODB_INDEX_NAME: "aws.dynamodb.index_name",
      AWS_DYNAMODB_SELECT: "aws.dynamodb.select",
      AWS_DYNAMODB_GLOBAL_SECONDARY_INDEXES: "aws.dynamodb.global_secondary_indexes",
      AWS_DYNAMODB_LOCAL_SECONDARY_INDEXES: "aws.dynamodb.local_secondary_indexes",
      AWS_DYNAMODB_EXCLUSIVE_START_TABLE: "aws.dynamodb.exclusive_start_table",
      AWS_DYNAMODB_TABLE_COUNT: "aws.dynamodb.table_count",
      AWS_DYNAMODB_SCAN_FORWARD: "aws.dynamodb.scan_forward",
      AWS_DYNAMODB_SEGMENT: "aws.dynamodb.segment",
      AWS_DYNAMODB_TOTAL_SEGMENTS: "aws.dynamodb.total_segments",
      AWS_DYNAMODB_COUNT: "aws.dynamodb.count",
      AWS_DYNAMODB_SCANNED_COUNT: "aws.dynamodb.scanned_count",
      AWS_DYNAMODB_ATTRIBUTE_DEFINITIONS: "aws.dynamodb.attribute_definitions",
      AWS_DYNAMODB_GLOBAL_SECONDARY_INDEX_UPDATES: "aws.dynamodb.global_secondary_index_updates",
      MESSAGING_SYSTEM: "messaging.system",
      MESSAGING_DESTINATION: "messaging.destination",
      MESSAGING_DESTINATION_KIND: "messaging.destination_kind",
      MESSAGING_TEMP_DESTINATION: "messaging.temp_destination",
      MESSAGING_PROTOCOL: "messaging.protocol",
      MESSAGING_PROTOCOL_VERSION: "messaging.protocol_version",
      MESSAGING_URL: "messaging.url",
      MESSAGING_MESSAGE_ID: "messaging.message_id",
      MESSAGING_CONVERSATION_ID: "messaging.conversation_id",
      MESSAGING_MESSAGE_PAYLOAD_SIZE_BYTES: "messaging.message_payload_size_bytes",
      MESSAGING_MESSAGE_PAYLOAD_COMPRESSED_SIZE_BYTES: "messaging.message_payload_compressed_size_bytes",
      MESSAGING_OPERATION: "messaging.operation",
      MESSAGING_CONSUMER_ID: "messaging.consumer_id",
      MESSAGING_RABBITMQ_ROUTING_KEY: "messaging.rabbitmq.routing_key",
      MESSAGING_KAFKA_MESSAGE_KEY: "messaging.kafka.message_key",
      MESSAGING_KAFKA_CONSUMER_GROUP: "messaging.kafka.consumer_group",
      MESSAGING_KAFKA_CLIENT_ID: "messaging.kafka.client_id",
      MESSAGING_KAFKA_PARTITION: "messaging.kafka.partition",
      MESSAGING_KAFKA_TOMBSTONE: "messaging.kafka.tombstone",
      RPC_SYSTEM: "rpc.system",
      RPC_SERVICE: "rpc.service",
      RPC_METHOD: "rpc.method",
      RPC_GRPC_STATUS_CODE: "rpc.grpc.status_code",
      RPC_JSONRPC_VERSION: "rpc.jsonrpc.version",
      RPC_JSONRPC_REQUEST_ID: "rpc.jsonrpc.request_id",
      RPC_JSONRPC_ERROR_CODE: "rpc.jsonrpc.error_code",
      RPC_JSONRPC_ERROR_MESSAGE: "rpc.jsonrpc.error_message",
      MESSAGE_TYPE: "message.type",
      MESSAGE_ID: "message.id",
      MESSAGE_COMPRESSED_SIZE: "message.compressed_size",
      MESSAGE_UNCOMPRESSED_SIZE: "message.uncompressed_size"
    };
    exports2.DbSystemValues = {
      OTHER_SQL: "other_sql",
      MSSQL: "mssql",
      MYSQL: "mysql",
      ORACLE: "oracle",
      DB2: "db2",
      POSTGRESQL: "postgresql",
      REDSHIFT: "redshift",
      HIVE: "hive",
      CLOUDSCAPE: "cloudscape",
      HSQLDB: "hsqldb",
      PROGRESS: "progress",
      MAXDB: "maxdb",
      HANADB: "hanadb",
      INGRES: "ingres",
      FIRSTSQL: "firstsql",
      EDB: "edb",
      CACHE: "cache",
      ADABAS: "adabas",
      FIREBIRD: "firebird",
      DERBY: "derby",
      FILEMAKER: "filemaker",
      INFORMIX: "informix",
      INSTANTDB: "instantdb",
      INTERBASE: "interbase",
      MARIADB: "mariadb",
      NETEZZA: "netezza",
      PERVASIVE: "pervasive",
      POINTBASE: "pointbase",
      SQLITE: "sqlite",
      SYBASE: "sybase",
      TERADATA: "teradata",
      VERTICA: "vertica",
      H2: "h2",
      COLDFUSION: "coldfusion",
      CASSANDRA: "cassandra",
      HBASE: "hbase",
      MONGODB: "mongodb",
      REDIS: "redis",
      COUCHBASE: "couchbase",
      COUCHDB: "couchdb",
      COSMOSDB: "cosmosdb",
      DYNAMODB: "dynamodb",
      NEO4J: "neo4j",
      GEODE: "geode",
      ELASTICSEARCH: "elasticsearch",
      MEMCACHED: "memcached",
      COCKROACHDB: "cockroachdb"
    };
    exports2.DbCassandraConsistencyLevelValues = {
      ALL: "all",
      EACH_QUORUM: "each_quorum",
      QUORUM: "quorum",
      LOCAL_QUORUM: "local_quorum",
      ONE: "one",
      TWO: "two",
      THREE: "three",
      LOCAL_ONE: "local_one",
      ANY: "any",
      SERIAL: "serial",
      LOCAL_SERIAL: "local_serial"
    };
    exports2.FaasTriggerValues = {
      DATASOURCE: "datasource",
      HTTP: "http",
      PUBSUB: "pubsub",
      TIMER: "timer",
      OTHER: "other"
    };
    exports2.FaasDocumentOperationValues = {
      INSERT: "insert",
      EDIT: "edit",
      DELETE: "delete"
    };
    exports2.FaasInvokedProviderValues = {
      ALIBABA_CLOUD: "alibaba_cloud",
      AWS: "aws",
      AZURE: "azure",
      GCP: "gcp"
    };
    exports2.NetTransportValues = {
      IP_TCP: "ip_tcp",
      IP_UDP: "ip_udp",
      IP: "ip",
      UNIX: "unix",
      PIPE: "pipe",
      INPROC: "inproc",
      OTHER: "other"
    };
    exports2.NetHostConnectionTypeValues = {
      WIFI: "wifi",
      WIRED: "wired",
      CELL: "cell",
      UNAVAILABLE: "unavailable",
      UNKNOWN: "unknown"
    };
    exports2.NetHostConnectionSubtypeValues = {
      GPRS: "gprs",
      EDGE: "edge",
      UMTS: "umts",
      CDMA: "cdma",
      EVDO_0: "evdo_0",
      EVDO_A: "evdo_a",
      CDMA2000_1XRTT: "cdma2000_1xrtt",
      HSDPA: "hsdpa",
      HSUPA: "hsupa",
      HSPA: "hspa",
      IDEN: "iden",
      EVDO_B: "evdo_b",
      LTE: "lte",
      EHRPD: "ehrpd",
      HSPAP: "hspap",
      GSM: "gsm",
      TD_SCDMA: "td_scdma",
      IWLAN: "iwlan",
      NR: "nr",
      NRNSA: "nrnsa",
      LTE_CA: "lte_ca"
    };
    exports2.HttpFlavorValues = {
      HTTP_1_0: "1.0",
      HTTP_1_1: "1.1",
      HTTP_2_0: "2.0",
      SPDY: "SPDY",
      QUIC: "QUIC"
    };
    exports2.MessagingDestinationKindValues = {
      QUEUE: "queue",
      TOPIC: "topic"
    };
    exports2.MessagingOperationValues = {
      RECEIVE: "receive",
      PROCESS: "process"
    };
    exports2.RpcGrpcStatusCodeValues = {
      OK: 0,
      CANCELLED: 1,
      UNKNOWN: 2,
      INVALID_ARGUMENT: 3,
      DEADLINE_EXCEEDED: 4,
      NOT_FOUND: 5,
      ALREADY_EXISTS: 6,
      PERMISSION_DENIED: 7,
      RESOURCE_EXHAUSTED: 8,
      FAILED_PRECONDITION: 9,
      ABORTED: 10,
      OUT_OF_RANGE: 11,
      UNIMPLEMENTED: 12,
      INTERNAL: 13,
      UNAVAILABLE: 14,
      DATA_LOSS: 15,
      UNAUTHENTICATED: 16
    };
    exports2.MessageTypeValues = {
      SENT: "SENT",
      RECEIVED: "RECEIVED"
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/trace/index.js
var require_trace2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/trace/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_SemanticAttributes(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/resource/SemanticResourceAttributes.js
var require_SemanticResourceAttributes = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/resource/SemanticResourceAttributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TelemetrySdkLanguageValues = exports2.OsTypeValues = exports2.HostArchValues = exports2.AwsEcsLaunchtypeValues = exports2.CloudPlatformValues = exports2.CloudProviderValues = exports2.SemanticResourceAttributes = void 0;
    exports2.SemanticResourceAttributes = {
      CLOUD_PROVIDER: "cloud.provider",
      CLOUD_ACCOUNT_ID: "cloud.account.id",
      CLOUD_REGION: "cloud.region",
      CLOUD_AVAILABILITY_ZONE: "cloud.availability_zone",
      CLOUD_PLATFORM: "cloud.platform",
      AWS_ECS_CONTAINER_ARN: "aws.ecs.container.arn",
      AWS_ECS_CLUSTER_ARN: "aws.ecs.cluster.arn",
      AWS_ECS_LAUNCHTYPE: "aws.ecs.launchtype",
      AWS_ECS_TASK_ARN: "aws.ecs.task.arn",
      AWS_ECS_TASK_FAMILY: "aws.ecs.task.family",
      AWS_ECS_TASK_REVISION: "aws.ecs.task.revision",
      AWS_EKS_CLUSTER_ARN: "aws.eks.cluster.arn",
      AWS_LOG_GROUP_NAMES: "aws.log.group.names",
      AWS_LOG_GROUP_ARNS: "aws.log.group.arns",
      AWS_LOG_STREAM_NAMES: "aws.log.stream.names",
      AWS_LOG_STREAM_ARNS: "aws.log.stream.arns",
      CONTAINER_NAME: "container.name",
      CONTAINER_ID: "container.id",
      CONTAINER_RUNTIME: "container.runtime",
      CONTAINER_IMAGE_NAME: "container.image.name",
      CONTAINER_IMAGE_TAG: "container.image.tag",
      DEPLOYMENT_ENVIRONMENT: "deployment.environment",
      DEVICE_ID: "device.id",
      DEVICE_MODEL_IDENTIFIER: "device.model.identifier",
      DEVICE_MODEL_NAME: "device.model.name",
      FAAS_NAME: "faas.name",
      FAAS_ID: "faas.id",
      FAAS_VERSION: "faas.version",
      FAAS_INSTANCE: "faas.instance",
      FAAS_MAX_MEMORY: "faas.max_memory",
      HOST_ID: "host.id",
      HOST_NAME: "host.name",
      HOST_TYPE: "host.type",
      HOST_ARCH: "host.arch",
      HOST_IMAGE_NAME: "host.image.name",
      HOST_IMAGE_ID: "host.image.id",
      HOST_IMAGE_VERSION: "host.image.version",
      K8S_CLUSTER_NAME: "k8s.cluster.name",
      K8S_NODE_NAME: "k8s.node.name",
      K8S_NODE_UID: "k8s.node.uid",
      K8S_NAMESPACE_NAME: "k8s.namespace.name",
      K8S_POD_UID: "k8s.pod.uid",
      K8S_POD_NAME: "k8s.pod.name",
      K8S_CONTAINER_NAME: "k8s.container.name",
      K8S_REPLICASET_UID: "k8s.replicaset.uid",
      K8S_REPLICASET_NAME: "k8s.replicaset.name",
      K8S_DEPLOYMENT_UID: "k8s.deployment.uid",
      K8S_DEPLOYMENT_NAME: "k8s.deployment.name",
      K8S_STATEFULSET_UID: "k8s.statefulset.uid",
      K8S_STATEFULSET_NAME: "k8s.statefulset.name",
      K8S_DAEMONSET_UID: "k8s.daemonset.uid",
      K8S_DAEMONSET_NAME: "k8s.daemonset.name",
      K8S_JOB_UID: "k8s.job.uid",
      K8S_JOB_NAME: "k8s.job.name",
      K8S_CRONJOB_UID: "k8s.cronjob.uid",
      K8S_CRONJOB_NAME: "k8s.cronjob.name",
      OS_TYPE: "os.type",
      OS_DESCRIPTION: "os.description",
      OS_NAME: "os.name",
      OS_VERSION: "os.version",
      PROCESS_PID: "process.pid",
      PROCESS_EXECUTABLE_NAME: "process.executable.name",
      PROCESS_EXECUTABLE_PATH: "process.executable.path",
      PROCESS_COMMAND: "process.command",
      PROCESS_COMMAND_LINE: "process.command_line",
      PROCESS_COMMAND_ARGS: "process.command_args",
      PROCESS_OWNER: "process.owner",
      PROCESS_RUNTIME_NAME: "process.runtime.name",
      PROCESS_RUNTIME_VERSION: "process.runtime.version",
      PROCESS_RUNTIME_DESCRIPTION: "process.runtime.description",
      SERVICE_NAME: "service.name",
      SERVICE_NAMESPACE: "service.namespace",
      SERVICE_INSTANCE_ID: "service.instance.id",
      SERVICE_VERSION: "service.version",
      TELEMETRY_SDK_NAME: "telemetry.sdk.name",
      TELEMETRY_SDK_LANGUAGE: "telemetry.sdk.language",
      TELEMETRY_SDK_VERSION: "telemetry.sdk.version",
      TELEMETRY_AUTO_VERSION: "telemetry.auto.version",
      WEBENGINE_NAME: "webengine.name",
      WEBENGINE_VERSION: "webengine.version",
      WEBENGINE_DESCRIPTION: "webengine.description"
    };
    exports2.CloudProviderValues = {
      ALIBABA_CLOUD: "alibaba_cloud",
      AWS: "aws",
      AZURE: "azure",
      GCP: "gcp"
    };
    exports2.CloudPlatformValues = {
      ALIBABA_CLOUD_ECS: "alibaba_cloud_ecs",
      ALIBABA_CLOUD_FC: "alibaba_cloud_fc",
      AWS_EC2: "aws_ec2",
      AWS_ECS: "aws_ecs",
      AWS_EKS: "aws_eks",
      AWS_LAMBDA: "aws_lambda",
      AWS_ELASTIC_BEANSTALK: "aws_elastic_beanstalk",
      AZURE_VM: "azure_vm",
      AZURE_CONTAINER_INSTANCES: "azure_container_instances",
      AZURE_AKS: "azure_aks",
      AZURE_FUNCTIONS: "azure_functions",
      AZURE_APP_SERVICE: "azure_app_service",
      GCP_COMPUTE_ENGINE: "gcp_compute_engine",
      GCP_CLOUD_RUN: "gcp_cloud_run",
      GCP_KUBERNETES_ENGINE: "gcp_kubernetes_engine",
      GCP_CLOUD_FUNCTIONS: "gcp_cloud_functions",
      GCP_APP_ENGINE: "gcp_app_engine"
    };
    exports2.AwsEcsLaunchtypeValues = {
      EC2: "ec2",
      FARGATE: "fargate"
    };
    exports2.HostArchValues = {
      AMD64: "amd64",
      ARM32: "arm32",
      ARM64: "arm64",
      IA64: "ia64",
      PPC32: "ppc32",
      PPC64: "ppc64",
      X86: "x86"
    };
    exports2.OsTypeValues = {
      WINDOWS: "windows",
      LINUX: "linux",
      DARWIN: "darwin",
      FREEBSD: "freebsd",
      NETBSD: "netbsd",
      OPENBSD: "openbsd",
      DRAGONFLYBSD: "dragonflybsd",
      HPUX: "hpux",
      AIX: "aix",
      SOLARIS: "solaris",
      Z_OS: "z_os"
    };
    exports2.TelemetrySdkLanguageValues = {
      CPP: "cpp",
      DOTNET: "dotnet",
      ERLANG: "erlang",
      GO: "go",
      JAVA: "java",
      NODEJS: "nodejs",
      PHP: "php",
      PYTHON: "python",
      RUBY: "ruby",
      WEBJS: "webjs"
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/resource/index.js
var require_resource = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/resource/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_SemanticResourceAttributes(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/index.js
var require_src3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/semantic-conventions/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_trace2(), exports2);
    __exportStar(require_resource(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/sdk-info.js
var require_sdk_info = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/sdk-info.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SDK_INFO = void 0;
    var version_1 = require_version2();
    var semantic_conventions_1 = require_src3();
    exports2.SDK_INFO = {
      [semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_NAME]: "opentelemetry",
      [semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_NAME]: "node",
      [semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_LANGUAGE]: semantic_conventions_1.TelemetrySdkLanguageValues.NODEJS,
      [semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_VERSION]: version_1.VERSION
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/timer-util.js
var require_timer_util = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/timer-util.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.unrefTimer = void 0;
    function unrefTimer(timer) {
      timer.unref();
    }
    exports2.unrefTimer = unrefTimer;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/index.js
var require_node2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/node/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_environment2(), exports2);
    __exportStar(require_globalThis2(), exports2);
    __exportStar(require_hex_to_base64(), exports2);
    __exportStar(require_RandomIdGenerator(), exports2);
    __exportStar(require_performance(), exports2);
    __exportStar(require_sdk_info(), exports2);
    __exportStar(require_timer_util(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/index.js
var require_platform2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/platform/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_node2(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/time.js
var require_time = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/time.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isTimeInput = exports2.isTimeInputHrTime = exports2.hrTimeToMicroseconds = exports2.hrTimeToMilliseconds = exports2.hrTimeToNanoseconds = exports2.hrTimeToTimeStamp = exports2.hrTimeDuration = exports2.timeInputToHrTime = exports2.hrTime = void 0;
    var platform_1 = require_platform2();
    var NANOSECOND_DIGITS = 9;
    var SECOND_TO_NANOSECONDS = Math.pow(10, NANOSECOND_DIGITS);
    function numberToHrtime(epochMillis) {
      const epochSeconds = epochMillis / 1e3;
      const seconds = Math.trunc(epochSeconds);
      const nanos = Number((epochSeconds - seconds).toFixed(NANOSECOND_DIGITS)) * SECOND_TO_NANOSECONDS;
      return [seconds, nanos];
    }
    function getTimeOrigin() {
      let timeOrigin = platform_1.otperformance.timeOrigin;
      if (typeof timeOrigin !== "number") {
        const perf = platform_1.otperformance;
        timeOrigin = perf.timing && perf.timing.fetchStart;
      }
      return timeOrigin;
    }
    function hrTime(performanceNow) {
      const timeOrigin = numberToHrtime(getTimeOrigin());
      const now = numberToHrtime(typeof performanceNow === "number" ? performanceNow : platform_1.otperformance.now());
      let seconds = timeOrigin[0] + now[0];
      let nanos = timeOrigin[1] + now[1];
      if (nanos > SECOND_TO_NANOSECONDS) {
        nanos -= SECOND_TO_NANOSECONDS;
        seconds += 1;
      }
      return [seconds, nanos];
    }
    exports2.hrTime = hrTime;
    function timeInputToHrTime(time) {
      if (isTimeInputHrTime(time)) {
        return time;
      } else if (typeof time === "number") {
        if (time < getTimeOrigin()) {
          return hrTime(time);
        } else {
          return numberToHrtime(time);
        }
      } else if (time instanceof Date) {
        return numberToHrtime(time.getTime());
      } else {
        throw TypeError("Invalid input type");
      }
    }
    exports2.timeInputToHrTime = timeInputToHrTime;
    function hrTimeDuration(startTime, endTime) {
      let seconds = endTime[0] - startTime[0];
      let nanos = endTime[1] - startTime[1];
      if (nanos < 0) {
        seconds -= 1;
        nanos += SECOND_TO_NANOSECONDS;
      }
      return [seconds, nanos];
    }
    exports2.hrTimeDuration = hrTimeDuration;
    function hrTimeToTimeStamp(time) {
      const precision = NANOSECOND_DIGITS;
      const tmp = `${"0".repeat(precision)}${time[1]}Z`;
      const nanoString = tmp.substr(tmp.length - precision - 1);
      const date = new Date(time[0] * 1e3).toISOString();
      return date.replace("000Z", nanoString);
    }
    exports2.hrTimeToTimeStamp = hrTimeToTimeStamp;
    function hrTimeToNanoseconds(time) {
      return time[0] * SECOND_TO_NANOSECONDS + time[1];
    }
    exports2.hrTimeToNanoseconds = hrTimeToNanoseconds;
    function hrTimeToMilliseconds(time) {
      return Math.round(time[0] * 1e3 + time[1] / 1e6);
    }
    exports2.hrTimeToMilliseconds = hrTimeToMilliseconds;
    function hrTimeToMicroseconds(time) {
      return Math.round(time[0] * 1e6 + time[1] / 1e3);
    }
    exports2.hrTimeToMicroseconds = hrTimeToMicroseconds;
    function isTimeInputHrTime(value) {
      return Array.isArray(value) && value.length === 2 && typeof value[0] === "number" && typeof value[1] === "number";
    }
    exports2.isTimeInputHrTime = isTimeInputHrTime;
    function isTimeInput(value) {
      return isTimeInputHrTime(value) || typeof value === "number" || value instanceof Date;
    }
    exports2.isTimeInput = isTimeInput;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/types.js
var require_types4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/common/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/ExportResult.js
var require_ExportResult = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/ExportResult.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ExportResultCode = void 0;
    var ExportResultCode;
    (function(ExportResultCode2) {
      ExportResultCode2[ExportResultCode2["SUCCESS"] = 0] = "SUCCESS";
      ExportResultCode2[ExportResultCode2["FAILED"] = 1] = "FAILED";
    })(ExportResultCode = exports2.ExportResultCode || (exports2.ExportResultCode = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/propagation/composite.js
var require_composite = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/propagation/composite.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.CompositePropagator = void 0;
    var api_1 = require_src();
    var CompositePropagator = class {
      constructor(config = {}) {
        var _a;
        this._propagators = (_a = config.propagators) !== null && _a !== void 0 ? _a : [];
        this._fields = Array.from(new Set(this._propagators.map((p) => typeof p.fields === "function" ? p.fields() : []).reduce((x, y) => x.concat(y), [])));
      }
      inject(context, carrier, setter) {
        for (const propagator of this._propagators) {
          try {
            propagator.inject(context, carrier, setter);
          } catch (err) {
            api_1.diag.warn(`Failed to inject with ${propagator.constructor.name}. Err: ${err.message}`);
          }
        }
      }
      extract(context, carrier, getter) {
        return this._propagators.reduce((ctx, propagator) => {
          try {
            return propagator.extract(ctx, carrier, getter);
          } catch (err) {
            api_1.diag.warn(`Failed to inject with ${propagator.constructor.name}. Err: ${err.message}`);
          }
          return ctx;
        }, context);
      }
      fields() {
        return this._fields.slice();
      }
    };
    exports2.CompositePropagator = CompositePropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/internal/validators.js
var require_validators = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/internal/validators.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.validateValue = exports2.validateKey = void 0;
    var VALID_KEY_CHAR_RANGE = "[_0-9a-z-*/]";
    var VALID_KEY = `[a-z]${VALID_KEY_CHAR_RANGE}{0,255}`;
    var VALID_VENDOR_KEY = `[a-z0-9]${VALID_KEY_CHAR_RANGE}{0,240}@[a-z]${VALID_KEY_CHAR_RANGE}{0,13}`;
    var VALID_KEY_REGEX = new RegExp(`^(?:${VALID_KEY}|${VALID_VENDOR_KEY})$`);
    var VALID_VALUE_BASE_REGEX = /^[ -~]{0,255}[!-~]$/;
    var INVALID_VALUE_COMMA_EQUAL_REGEX = /,|=/;
    function validateKey(key) {
      return VALID_KEY_REGEX.test(key);
    }
    exports2.validateKey = validateKey;
    function validateValue(value) {
      return VALID_VALUE_BASE_REGEX.test(value) && !INVALID_VALUE_COMMA_EQUAL_REGEX.test(value);
    }
    exports2.validateValue = validateValue;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/TraceState.js
var require_TraceState = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/TraceState.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TraceState = void 0;
    var validators_1 = require_validators();
    var MAX_TRACE_STATE_ITEMS = 32;
    var MAX_TRACE_STATE_LEN = 512;
    var LIST_MEMBERS_SEPARATOR = ",";
    var LIST_MEMBER_KEY_VALUE_SPLITTER = "=";
    var TraceState = class {
      constructor(rawTraceState) {
        this._internalState = /* @__PURE__ */ new Map();
        if (rawTraceState)
          this._parse(rawTraceState);
      }
      set(key, value) {
        const traceState = this._clone();
        if (traceState._internalState.has(key)) {
          traceState._internalState.delete(key);
        }
        traceState._internalState.set(key, value);
        return traceState;
      }
      unset(key) {
        const traceState = this._clone();
        traceState._internalState.delete(key);
        return traceState;
      }
      get(key) {
        return this._internalState.get(key);
      }
      serialize() {
        return this._keys().reduce((agg, key) => {
          agg.push(key + LIST_MEMBER_KEY_VALUE_SPLITTER + this.get(key));
          return agg;
        }, []).join(LIST_MEMBERS_SEPARATOR);
      }
      _parse(rawTraceState) {
        if (rawTraceState.length > MAX_TRACE_STATE_LEN)
          return;
        this._internalState = rawTraceState.split(LIST_MEMBERS_SEPARATOR).reverse().reduce((agg, part) => {
          const listMember = part.trim();
          const i = listMember.indexOf(LIST_MEMBER_KEY_VALUE_SPLITTER);
          if (i !== -1) {
            const key = listMember.slice(0, i);
            const value = listMember.slice(i + 1, part.length);
            if ((0, validators_1.validateKey)(key) && (0, validators_1.validateValue)(value)) {
              agg.set(key, value);
            } else {
            }
          }
          return agg;
        }, /* @__PURE__ */ new Map());
        if (this._internalState.size > MAX_TRACE_STATE_ITEMS) {
          this._internalState = new Map(Array.from(this._internalState.entries()).reverse().slice(0, MAX_TRACE_STATE_ITEMS));
        }
      }
      _keys() {
        return Array.from(this._internalState.keys()).reverse();
      }
      _clone() {
        const traceState = new TraceState();
        traceState._internalState = new Map(this._internalState);
        return traceState;
      }
    };
    exports2.TraceState = TraceState;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/W3CTraceContextPropagator.js
var require_W3CTraceContextPropagator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/W3CTraceContextPropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.W3CTraceContextPropagator = exports2.parseTraceParent = exports2.TRACE_STATE_HEADER = exports2.TRACE_PARENT_HEADER = void 0;
    var api_1 = require_src();
    var suppress_tracing_1 = require_suppress_tracing();
    var TraceState_1 = require_TraceState();
    exports2.TRACE_PARENT_HEADER = "traceparent";
    exports2.TRACE_STATE_HEADER = "tracestate";
    var VERSION = "00";
    var VERSION_PART = "(?!ff)[\\da-f]{2}";
    var TRACE_ID_PART = "(?![0]{32})[\\da-f]{32}";
    var PARENT_ID_PART = "(?![0]{16})[\\da-f]{16}";
    var FLAGS_PART = "[\\da-f]{2}";
    var TRACE_PARENT_REGEX = new RegExp(`^\\s?(${VERSION_PART})-(${TRACE_ID_PART})-(${PARENT_ID_PART})-(${FLAGS_PART})(-.*)?\\s?$`);
    function parseTraceParent(traceParent) {
      const match = TRACE_PARENT_REGEX.exec(traceParent);
      if (!match)
        return null;
      if (match[1] === "00" && match[5])
        return null;
      return {
        traceId: match[2],
        spanId: match[3],
        traceFlags: parseInt(match[4], 16)
      };
    }
    exports2.parseTraceParent = parseTraceParent;
    var W3CTraceContextPropagator = class {
      inject(context, carrier, setter) {
        const spanContext = api_1.trace.getSpanContext(context);
        if (!spanContext || (0, suppress_tracing_1.isTracingSuppressed)(context) || !(0, api_1.isSpanContextValid)(spanContext))
          return;
        const traceParent = `${VERSION}-${spanContext.traceId}-${spanContext.spanId}-0${Number(spanContext.traceFlags || api_1.TraceFlags.NONE).toString(16)}`;
        setter.set(carrier, exports2.TRACE_PARENT_HEADER, traceParent);
        if (spanContext.traceState) {
          setter.set(carrier, exports2.TRACE_STATE_HEADER, spanContext.traceState.serialize());
        }
      }
      extract(context, carrier, getter) {
        const traceParentHeader = getter.get(carrier, exports2.TRACE_PARENT_HEADER);
        if (!traceParentHeader)
          return context;
        const traceParent = Array.isArray(traceParentHeader) ? traceParentHeader[0] : traceParentHeader;
        if (typeof traceParent !== "string")
          return context;
        const spanContext = parseTraceParent(traceParent);
        if (!spanContext)
          return context;
        spanContext.isRemote = true;
        const traceStateHeader = getter.get(carrier, exports2.TRACE_STATE_HEADER);
        if (traceStateHeader) {
          const state = Array.isArray(traceStateHeader) ? traceStateHeader.join(",") : traceStateHeader;
          spanContext.traceState = new TraceState_1.TraceState(typeof state === "string" ? state : void 0);
        }
        return api_1.trace.setSpanContext(context, spanContext);
      }
      fields() {
        return [exports2.TRACE_PARENT_HEADER, exports2.TRACE_STATE_HEADER];
      }
    };
    exports2.W3CTraceContextPropagator = W3CTraceContextPropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/IdGenerator.js
var require_IdGenerator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/IdGenerator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/rpc-metadata.js
var require_rpc_metadata = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/rpc-metadata.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getRPCMetadata = exports2.deleteRPCMetadata = exports2.setRPCMetadata = exports2.RPCType = void 0;
    var api_1 = require_src();
    var RPC_METADATA_KEY = (0, api_1.createContextKey)("OpenTelemetry SDK Context Key RPC_METADATA");
    var RPCType;
    (function(RPCType2) {
      RPCType2["HTTP"] = "http";
    })(RPCType = exports2.RPCType || (exports2.RPCType = {}));
    function setRPCMetadata(context, meta) {
      return context.setValue(RPC_METADATA_KEY, meta);
    }
    exports2.setRPCMetadata = setRPCMetadata;
    function deleteRPCMetadata(context) {
      return context.deleteValue(RPC_METADATA_KEY);
    }
    exports2.deleteRPCMetadata = deleteRPCMetadata;
    function getRPCMetadata(context) {
      return context.getValue(RPC_METADATA_KEY);
    }
    exports2.getRPCMetadata = getRPCMetadata;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOffSampler.js
var require_AlwaysOffSampler = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOffSampler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AlwaysOffSampler = void 0;
    var api_1 = require_src();
    var AlwaysOffSampler = class {
      shouldSample() {
        return {
          decision: api_1.SamplingDecision.NOT_RECORD
        };
      }
      toString() {
        return "AlwaysOffSampler";
      }
    };
    exports2.AlwaysOffSampler = AlwaysOffSampler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOnSampler.js
var require_AlwaysOnSampler = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOnSampler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AlwaysOnSampler = void 0;
    var api_1 = require_src();
    var AlwaysOnSampler = class {
      shouldSample() {
        return {
          decision: api_1.SamplingDecision.RECORD_AND_SAMPLED
        };
      }
      toString() {
        return "AlwaysOnSampler";
      }
    };
    exports2.AlwaysOnSampler = AlwaysOnSampler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/sampler/ParentBasedSampler.js
var require_ParentBasedSampler = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/sampler/ParentBasedSampler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ParentBasedSampler = void 0;
    var api_1 = require_src();
    var global_error_handler_1 = require_global_error_handler();
    var AlwaysOffSampler_1 = require_AlwaysOffSampler();
    var AlwaysOnSampler_1 = require_AlwaysOnSampler();
    var ParentBasedSampler = class {
      constructor(config) {
        var _a, _b, _c, _d;
        this._root = config.root;
        if (!this._root) {
          (0, global_error_handler_1.globalErrorHandler)(new Error("ParentBasedSampler must have a root sampler configured"));
          this._root = new AlwaysOnSampler_1.AlwaysOnSampler();
        }
        this._remoteParentSampled = (_a = config.remoteParentSampled) !== null && _a !== void 0 ? _a : new AlwaysOnSampler_1.AlwaysOnSampler();
        this._remoteParentNotSampled = (_b = config.remoteParentNotSampled) !== null && _b !== void 0 ? _b : new AlwaysOffSampler_1.AlwaysOffSampler();
        this._localParentSampled = (_c = config.localParentSampled) !== null && _c !== void 0 ? _c : new AlwaysOnSampler_1.AlwaysOnSampler();
        this._localParentNotSampled = (_d = config.localParentNotSampled) !== null && _d !== void 0 ? _d : new AlwaysOffSampler_1.AlwaysOffSampler();
      }
      shouldSample(context, traceId, spanName, spanKind, attributes, links) {
        const parentContext = api_1.trace.getSpanContext(context);
        if (!parentContext || !(0, api_1.isSpanContextValid)(parentContext)) {
          return this._root.shouldSample(context, traceId, spanName, spanKind, attributes, links);
        }
        if (parentContext.isRemote) {
          if (parentContext.traceFlags & api_1.TraceFlags.SAMPLED) {
            return this._remoteParentSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
          }
          return this._remoteParentNotSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
        }
        if (parentContext.traceFlags & api_1.TraceFlags.SAMPLED) {
          return this._localParentSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
        }
        return this._localParentNotSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
      }
      toString() {
        return `ParentBased{root=${this._root.toString()}, remoteParentSampled=${this._remoteParentSampled.toString()}, remoteParentNotSampled=${this._remoteParentNotSampled.toString()}, localParentSampled=${this._localParentSampled.toString()}, localParentNotSampled=${this._localParentNotSampled.toString()}}`;
      }
    };
    exports2.ParentBasedSampler = ParentBasedSampler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/sampler/TraceIdRatioBasedSampler.js
var require_TraceIdRatioBasedSampler = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/trace/sampler/TraceIdRatioBasedSampler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TraceIdRatioBasedSampler = void 0;
    var api_1 = require_src();
    var TraceIdRatioBasedSampler = class {
      constructor(_ratio = 0) {
        this._ratio = _ratio;
        this._ratio = this._normalize(_ratio);
        this._upperBound = Math.floor(this._ratio * 4294967295);
      }
      shouldSample(context, traceId) {
        return {
          decision: (0, api_1.isValidTraceId)(traceId) && this._accumulate(traceId) < this._upperBound ? api_1.SamplingDecision.RECORD_AND_SAMPLED : api_1.SamplingDecision.NOT_RECORD
        };
      }
      toString() {
        return `TraceIdRatioBased{${this._ratio}}`;
      }
      _normalize(ratio) {
        if (typeof ratio !== "number" || isNaN(ratio))
          return 0;
        return ratio >= 1 ? 1 : ratio <= 0 ? 0 : ratio;
      }
      _accumulate(traceId) {
        let accumulation = 0;
        for (let i = 0; i < traceId.length / 8; i++) {
          const pos = i * 8;
          const part = parseInt(traceId.slice(pos, pos + 8), 16);
          accumulation = (accumulation ^ part) >>> 0;
        }
        return accumulation;
      }
    };
    exports2.TraceIdRatioBasedSampler = TraceIdRatioBasedSampler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/lodash.merge.js
var require_lodash_merge = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/lodash.merge.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isPlainObject = void 0;
    var objectTag = "[object Object]";
    var nullTag = "[object Null]";
    var undefinedTag = "[object Undefined]";
    var funcProto = Function.prototype;
    var funcToString = funcProto.toString;
    var objectCtorString = funcToString.call(Object);
    var getPrototype = overArg(Object.getPrototypeOf, Object);
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var symToStringTag = Symbol ? Symbol.toStringTag : void 0;
    var nativeObjectToString = objectProto.toString;
    function overArg(func, transform) {
      return function(arg) {
        return func(transform(arg));
      };
    }
    function isPlainObject(value) {
      if (!isObjectLike(value) || baseGetTag(value) !== objectTag) {
        return false;
      }
      const proto = getPrototype(value);
      if (proto === null) {
        return true;
      }
      const Ctor = hasOwnProperty.call(proto, "constructor") && proto.constructor;
      return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString.call(Ctor) === objectCtorString;
    }
    exports2.isPlainObject = isPlainObject;
    function isObjectLike(value) {
      return value != null && typeof value == "object";
    }
    function baseGetTag(value) {
      if (value == null) {
        return value === void 0 ? undefinedTag : nullTag;
      }
      return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
    }
    function getRawTag(value) {
      const isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
      let unmasked = false;
      try {
        value[symToStringTag] = void 0;
        unmasked = true;
      } catch (e) {
      }
      const result = nativeObjectToString.call(value);
      if (unmasked) {
        if (isOwn) {
          value[symToStringTag] = tag;
        } else {
          delete value[symToStringTag];
        }
      }
      return result;
    }
    function objectToString(value) {
      return nativeObjectToString.call(value);
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/merge.js
var require_merge = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/merge.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.merge = void 0;
    var lodash_merge_1 = require_lodash_merge();
    var MAX_LEVEL = 20;
    function merge(...args) {
      let result = args.shift();
      const objects = /* @__PURE__ */ new WeakMap();
      while (args.length > 0) {
        result = mergeTwoObjects(result, args.shift(), 0, objects);
      }
      return result;
    }
    exports2.merge = merge;
    function takeValue(value) {
      if (isArray(value)) {
        return value.slice();
      }
      return value;
    }
    function mergeTwoObjects(one, two, level = 0, objects) {
      let result;
      if (level > MAX_LEVEL) {
        return void 0;
      }
      level++;
      if (isPrimitive(one) || isPrimitive(two) || isFunction(two)) {
        result = takeValue(two);
      } else if (isArray(one)) {
        result = one.slice();
        if (isArray(two)) {
          for (let i = 0, j = two.length; i < j; i++) {
            result.push(takeValue(two[i]));
          }
        } else if (isObject(two)) {
          const keys = Object.keys(two);
          for (let i = 0, j = keys.length; i < j; i++) {
            const key = keys[i];
            result[key] = takeValue(two[key]);
          }
        }
      } else if (isObject(one)) {
        if (isObject(two)) {
          if (!shouldMerge(one, two)) {
            return two;
          }
          result = Object.assign({}, one);
          const keys = Object.keys(two);
          for (let i = 0, j = keys.length; i < j; i++) {
            const key = keys[i];
            const twoValue = two[key];
            if (isPrimitive(twoValue)) {
              if (typeof twoValue === "undefined") {
                delete result[key];
              } else {
                result[key] = twoValue;
              }
            } else {
              const obj1 = result[key];
              const obj2 = twoValue;
              if (wasObjectReferenced(one, key, objects) || wasObjectReferenced(two, key, objects)) {
                delete result[key];
              } else {
                if (isObject(obj1) && isObject(obj2)) {
                  const arr1 = objects.get(obj1) || [];
                  const arr2 = objects.get(obj2) || [];
                  arr1.push({ obj: one, key });
                  arr2.push({ obj: two, key });
                  objects.set(obj1, arr1);
                  objects.set(obj2, arr2);
                }
                result[key] = mergeTwoObjects(result[key], twoValue, level, objects);
              }
            }
          }
        } else {
          result = two;
        }
      }
      return result;
    }
    function wasObjectReferenced(obj, key, objects) {
      const arr = objects.get(obj[key]) || [];
      for (let i = 0, j = arr.length; i < j; i++) {
        const info = arr[i];
        if (info.key === key && info.obj === obj) {
          return true;
        }
      }
      return false;
    }
    function isArray(value) {
      return Array.isArray(value);
    }
    function isFunction(value) {
      return typeof value === "function";
    }
    function isObject(value) {
      return !isPrimitive(value) && !isArray(value) && !isFunction(value) && typeof value === "object";
    }
    function isPrimitive(value) {
      return typeof value === "string" || typeof value === "number" || typeof value === "boolean" || typeof value === "undefined" || value instanceof Date || value instanceof RegExp || value === null;
    }
    function shouldMerge(one, two) {
      if (!(0, lodash_merge_1.isPlainObject)(one) || !(0, lodash_merge_1.isPlainObject)(two)) {
        return false;
      }
      return true;
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/url.js
var require_url = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/url.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isUrlIgnored = exports2.urlMatches = void 0;
    function urlMatches(url, urlToMatch) {
      if (typeof urlToMatch === "string") {
        return url === urlToMatch;
      } else {
        return !!url.match(urlToMatch);
      }
    }
    exports2.urlMatches = urlMatches;
    function isUrlIgnored(url, ignoredUrls) {
      if (!ignoredUrls) {
        return false;
      }
      for (const ignoreUrl of ignoredUrls) {
        if (urlMatches(url, ignoreUrl)) {
          return true;
        }
      }
      return false;
    }
    exports2.isUrlIgnored = isUrlIgnored;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/wrap.js
var require_wrap = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/wrap.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isWrapped = void 0;
    function isWrapped(func) {
      return typeof func === "function" && typeof func.__original === "function" && typeof func.__unwrap === "function" && func.__wrapped === true;
    }
    exports2.isWrapped = isWrapped;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/promise.js
var require_promise = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/promise.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Deferred = void 0;
    var Deferred = class {
      constructor() {
        this._promise = new Promise((resolve, reject) => {
          this._resolve = resolve;
          this._reject = reject;
        });
      }
      get promise() {
        return this._promise;
      }
      resolve(val) {
        this._resolve(val);
      }
      reject(err) {
        this._reject(err);
      }
    };
    exports2.Deferred = Deferred;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/callback.js
var require_callback = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/utils/callback.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BindOnceFuture = void 0;
    var promise_1 = require_promise();
    var BindOnceFuture = class {
      constructor(_callback, _that) {
        this._callback = _callback;
        this._that = _that;
        this._isCalled = false;
        this._deferred = new promise_1.Deferred();
      }
      get isCalled() {
        return this._isCalled;
      }
      get promise() {
        return this._deferred.promise;
      }
      call(...args) {
        if (!this._isCalled) {
          this._isCalled = true;
          try {
            Promise.resolve(this._callback.call(this._that, ...args)).then((val) => this._deferred.resolve(val), (err) => this._deferred.reject(err));
          } catch (err) {
            this._deferred.reject(err);
          }
        }
        return this._deferred.promise;
      }
    };
    exports2.BindOnceFuture = BindOnceFuture;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/index.js
var require_src4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/core/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.baggageUtils = void 0;
    __exportStar(require_W3CBaggagePropagator(), exports2);
    __exportStar(require_attributes2(), exports2);
    __exportStar(require_global_error_handler(), exports2);
    __exportStar(require_logging_error_handler(), exports2);
    __exportStar(require_time(), exports2);
    __exportStar(require_types4(), exports2);
    __exportStar(require_ExportResult(), exports2);
    __exportStar(require_version2(), exports2);
    exports2.baggageUtils = require_utils2();
    __exportStar(require_platform2(), exports2);
    __exportStar(require_composite(), exports2);
    __exportStar(require_W3CTraceContextPropagator(), exports2);
    __exportStar(require_IdGenerator(), exports2);
    __exportStar(require_rpc_metadata(), exports2);
    __exportStar(require_AlwaysOffSampler(), exports2);
    __exportStar(require_AlwaysOnSampler(), exports2);
    __exportStar(require_ParentBasedSampler(), exports2);
    __exportStar(require_TraceIdRatioBasedSampler(), exports2);
    __exportStar(require_suppress_tracing(), exports2);
    __exportStar(require_TraceState(), exports2);
    __exportStar(require_environment(), exports2);
    __exportStar(require_merge(), exports2);
    __exportStar(require_sampling(), exports2);
    __exportStar(require_url(), exports2);
    __exportStar(require_wrap(), exports2);
    __exportStar(require_callback(), exports2);
    __exportStar(require_version2(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/common.js
var require_common = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/common.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.B3_DEBUG_FLAG_KEY = void 0;
    var api_1 = require_src();
    exports2.B3_DEBUG_FLAG_KEY = (0, api_1.createContextKey)("OpenTelemetry Context Key B3 Debug Flag");
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/constants.js
var require_constants2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.X_B3_FLAGS = exports2.X_B3_PARENT_SPAN_ID = exports2.X_B3_SAMPLED = exports2.X_B3_SPAN_ID = exports2.X_B3_TRACE_ID = exports2.B3_CONTEXT_HEADER = void 0;
    exports2.B3_CONTEXT_HEADER = "b3";
    exports2.X_B3_TRACE_ID = "x-b3-traceid";
    exports2.X_B3_SPAN_ID = "x-b3-spanid";
    exports2.X_B3_SAMPLED = "x-b3-sampled";
    exports2.X_B3_PARENT_SPAN_ID = "x-b3-parentspanid";
    exports2.X_B3_FLAGS = "x-b3-flags";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/B3MultiPropagator.js
var require_B3MultiPropagator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/B3MultiPropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.B3MultiPropagator = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    var common_1 = require_common();
    var constants_1 = require_constants2();
    var VALID_SAMPLED_VALUES = /* @__PURE__ */ new Set([true, "true", "True", "1", 1]);
    var VALID_UNSAMPLED_VALUES = /* @__PURE__ */ new Set([false, "false", "False", "0", 0]);
    function isValidSampledValue(sampled) {
      return sampled === api_1.TraceFlags.SAMPLED || sampled === api_1.TraceFlags.NONE;
    }
    function parseHeader(header) {
      return Array.isArray(header) ? header[0] : header;
    }
    function getHeaderValue(carrier, getter, key) {
      const header = getter.get(carrier, key);
      return parseHeader(header);
    }
    function getTraceId(carrier, getter) {
      const traceId = getHeaderValue(carrier, getter, constants_1.X_B3_TRACE_ID);
      if (typeof traceId === "string") {
        return traceId.padStart(32, "0");
      }
      return "";
    }
    function getSpanId(carrier, getter) {
      const spanId = getHeaderValue(carrier, getter, constants_1.X_B3_SPAN_ID);
      if (typeof spanId === "string") {
        return spanId;
      }
      return "";
    }
    function getDebug(carrier, getter) {
      const debug = getHeaderValue(carrier, getter, constants_1.X_B3_FLAGS);
      return debug === "1" ? "1" : void 0;
    }
    function getTraceFlags(carrier, getter) {
      const traceFlags = getHeaderValue(carrier, getter, constants_1.X_B3_SAMPLED);
      const debug = getDebug(carrier, getter);
      if (debug === "1" || VALID_SAMPLED_VALUES.has(traceFlags)) {
        return api_1.TraceFlags.SAMPLED;
      }
      if (traceFlags === void 0 || VALID_UNSAMPLED_VALUES.has(traceFlags)) {
        return api_1.TraceFlags.NONE;
      }
      return;
    }
    var B3MultiPropagator = class {
      inject(context, carrier, setter) {
        const spanContext = api_1.trace.getSpanContext(context);
        if (!spanContext || !(0, api_1.isSpanContextValid)(spanContext) || (0, core_1.isTracingSuppressed)(context))
          return;
        const debug = context.getValue(common_1.B3_DEBUG_FLAG_KEY);
        setter.set(carrier, constants_1.X_B3_TRACE_ID, spanContext.traceId);
        setter.set(carrier, constants_1.X_B3_SPAN_ID, spanContext.spanId);
        if (debug === "1") {
          setter.set(carrier, constants_1.X_B3_FLAGS, debug);
        } else if (spanContext.traceFlags !== void 0) {
          setter.set(carrier, constants_1.X_B3_SAMPLED, (api_1.TraceFlags.SAMPLED & spanContext.traceFlags) === api_1.TraceFlags.SAMPLED ? "1" : "0");
        }
      }
      extract(context, carrier, getter) {
        const traceId = getTraceId(carrier, getter);
        const spanId = getSpanId(carrier, getter);
        const traceFlags = getTraceFlags(carrier, getter);
        const debug = getDebug(carrier, getter);
        if ((0, api_1.isValidTraceId)(traceId) && (0, api_1.isValidSpanId)(spanId) && isValidSampledValue(traceFlags)) {
          context = context.setValue(common_1.B3_DEBUG_FLAG_KEY, debug);
          return api_1.trace.setSpanContext(context, {
            traceId,
            spanId,
            isRemote: true,
            traceFlags
          });
        }
        return context;
      }
      fields() {
        return [
          constants_1.X_B3_TRACE_ID,
          constants_1.X_B3_SPAN_ID,
          constants_1.X_B3_FLAGS,
          constants_1.X_B3_SAMPLED,
          constants_1.X_B3_PARENT_SPAN_ID
        ];
      }
    };
    exports2.B3MultiPropagator = B3MultiPropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/B3SinglePropagator.js
var require_B3SinglePropagator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/B3SinglePropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.B3SinglePropagator = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    var common_1 = require_common();
    var constants_1 = require_constants2();
    var B3_CONTEXT_REGEX = /((?:[0-9a-f]{16}){1,2})-([0-9a-f]{16})(?:-([01d](?![0-9a-f])))?(?:-([0-9a-f]{16}))?/;
    var PADDING = "0".repeat(16);
    var SAMPLED_VALUES = /* @__PURE__ */ new Set(["d", "1"]);
    var DEBUG_STATE = "d";
    function convertToTraceId128(traceId) {
      return traceId.length === 32 ? traceId : `${PADDING}${traceId}`;
    }
    function convertToTraceFlags(samplingState) {
      if (samplingState && SAMPLED_VALUES.has(samplingState)) {
        return api_1.TraceFlags.SAMPLED;
      }
      return api_1.TraceFlags.NONE;
    }
    var B3SinglePropagator = class {
      inject(context, carrier, setter) {
        const spanContext = api_1.trace.getSpanContext(context);
        if (!spanContext || !(0, api_1.isSpanContextValid)(spanContext) || (0, core_1.isTracingSuppressed)(context))
          return;
        const samplingState = context.getValue(common_1.B3_DEBUG_FLAG_KEY) || spanContext.traceFlags & 1;
        const value = `${spanContext.traceId}-${spanContext.spanId}-${samplingState}`;
        setter.set(carrier, constants_1.B3_CONTEXT_HEADER, value);
      }
      extract(context, carrier, getter) {
        const header = getter.get(carrier, constants_1.B3_CONTEXT_HEADER);
        const b3Context = Array.isArray(header) ? header[0] : header;
        if (typeof b3Context !== "string")
          return context;
        const match = b3Context.match(B3_CONTEXT_REGEX);
        if (!match)
          return context;
        const [, extractedTraceId, spanId, samplingState] = match;
        const traceId = convertToTraceId128(extractedTraceId);
        if (!(0, api_1.isValidTraceId)(traceId) || !(0, api_1.isValidSpanId)(spanId))
          return context;
        const traceFlags = convertToTraceFlags(samplingState);
        if (samplingState === DEBUG_STATE) {
          context = context.setValue(common_1.B3_DEBUG_FLAG_KEY, samplingState);
        }
        return api_1.trace.setSpanContext(context, {
          traceId,
          spanId,
          isRemote: true,
          traceFlags
        });
      }
      fields() {
        return [constants_1.B3_CONTEXT_HEADER];
      }
    };
    exports2.B3SinglePropagator = B3SinglePropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/types.js
var require_types5 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.B3InjectEncoding = void 0;
    var B3InjectEncoding;
    (function(B3InjectEncoding2) {
      B3InjectEncoding2[B3InjectEncoding2["SINGLE_HEADER"] = 0] = "SINGLE_HEADER";
      B3InjectEncoding2[B3InjectEncoding2["MULTI_HEADER"] = 1] = "MULTI_HEADER";
    })(B3InjectEncoding = exports2.B3InjectEncoding || (exports2.B3InjectEncoding = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/B3Propagator.js
var require_B3Propagator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/B3Propagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.B3Propagator = void 0;
    var core_1 = require_src4();
    var B3MultiPropagator_1 = require_B3MultiPropagator();
    var B3SinglePropagator_1 = require_B3SinglePropagator();
    var constants_1 = require_constants2();
    var types_1 = require_types5();
    var B3Propagator = class {
      constructor(config = {}) {
        this._b3MultiPropagator = new B3MultiPropagator_1.B3MultiPropagator();
        this._b3SinglePropagator = new B3SinglePropagator_1.B3SinglePropagator();
        if (config.injectEncoding === types_1.B3InjectEncoding.MULTI_HEADER) {
          this._inject = this._b3MultiPropagator.inject;
          this._fields = this._b3MultiPropagator.fields();
        } else {
          this._inject = this._b3SinglePropagator.inject;
          this._fields = this._b3SinglePropagator.fields();
        }
      }
      inject(context, carrier, setter) {
        if ((0, core_1.isTracingSuppressed)(context)) {
          return;
        }
        this._inject(context, carrier, setter);
      }
      extract(context, carrier, getter) {
        const header = getter.get(carrier, constants_1.B3_CONTEXT_HEADER);
        const b3Context = Array.isArray(header) ? header[0] : header;
        if (b3Context) {
          return this._b3SinglePropagator.extract(context, carrier, getter);
        } else {
          return this._b3MultiPropagator.extract(context, carrier, getter);
        }
      }
      fields() {
        return this._fields;
      }
    };
    exports2.B3Propagator = B3Propagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/index.js
var require_src5 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-b3/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_B3Propagator(), exports2);
    __exportStar(require_constants2(), exports2);
    __exportStar(require_types5(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/enums.js
var require_enums = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/enums.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ExceptionEventName = void 0;
    exports2.ExceptionEventName = "exception";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/Span.js
var require_Span = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/Span.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Span = void 0;
    var api = require_src();
    var core_1 = require_src4();
    var semantic_conventions_1 = require_src3();
    var enums_1 = require_enums();
    var Span = class {
      constructor(parentTracer, context, spanName, spanContext, kind, parentSpanId, links = [], startTime = (0, core_1.hrTime)()) {
        this.attributes = {};
        this.links = [];
        this.events = [];
        this.status = {
          code: api.SpanStatusCode.UNSET
        };
        this.endTime = [0, 0];
        this._ended = false;
        this._duration = [-1, -1];
        this.name = spanName;
        this._spanContext = spanContext;
        this.parentSpanId = parentSpanId;
        this.kind = kind;
        this.links = links;
        this.startTime = (0, core_1.timeInputToHrTime)(startTime);
        this.resource = parentTracer.resource;
        this.instrumentationLibrary = parentTracer.instrumentationLibrary;
        this._spanLimits = parentTracer.getSpanLimits();
        this._spanProcessor = parentTracer.getActiveSpanProcessor();
        this._spanProcessor.onStart(this, context);
        this._attributeValueLengthLimit = this._spanLimits.attributeValueLengthLimit || 0;
      }
      spanContext() {
        return this._spanContext;
      }
      setAttribute(key, value) {
        if (value == null || this._isSpanEnded())
          return this;
        if (key.length === 0) {
          api.diag.warn(`Invalid attribute key: ${key}`);
          return this;
        }
        if (!(0, core_1.isAttributeValue)(value)) {
          api.diag.warn(`Invalid attribute value set for key: ${key}`);
          return this;
        }
        if (Object.keys(this.attributes).length >= this._spanLimits.attributeCountLimit && !Object.prototype.hasOwnProperty.call(this.attributes, key)) {
          return this;
        }
        this.attributes[key] = this._truncateToSize(value);
        return this;
      }
      setAttributes(attributes) {
        for (const [k, v] of Object.entries(attributes)) {
          this.setAttribute(k, v);
        }
        return this;
      }
      addEvent(name, attributesOrStartTime, startTime) {
        if (this._isSpanEnded())
          return this;
        if (this._spanLimits.eventCountLimit === 0) {
          api.diag.warn("No events allowed.");
          return this;
        }
        if (this.events.length >= this._spanLimits.eventCountLimit) {
          api.diag.warn("Dropping extra events.");
          this.events.shift();
        }
        if ((0, core_1.isTimeInput)(attributesOrStartTime)) {
          if (typeof startTime === "undefined") {
            startTime = attributesOrStartTime;
          }
          attributesOrStartTime = void 0;
        }
        if (typeof startTime === "undefined") {
          startTime = (0, core_1.hrTime)();
        }
        const attributes = (0, core_1.sanitizeAttributes)(attributesOrStartTime);
        this.events.push({
          name,
          attributes,
          time: (0, core_1.timeInputToHrTime)(startTime)
        });
        return this;
      }
      setStatus(status) {
        if (this._isSpanEnded())
          return this;
        this.status = status;
        return this;
      }
      updateName(name) {
        if (this._isSpanEnded())
          return this;
        this.name = name;
        return this;
      }
      end(endTime = (0, core_1.hrTime)()) {
        if (this._isSpanEnded()) {
          api.diag.error("You can only call end() on a span once.");
          return;
        }
        this._ended = true;
        this.endTime = (0, core_1.timeInputToHrTime)(endTime);
        this._duration = (0, core_1.hrTimeDuration)(this.startTime, this.endTime);
        if (this._duration[0] < 0) {
          api.diag.warn("Inconsistent start and end time, startTime > endTime", this.startTime, this.endTime);
        }
        this._spanProcessor.onEnd(this);
      }
      isRecording() {
        return this._ended === false;
      }
      recordException(exception, time = (0, core_1.hrTime)()) {
        const attributes = {};
        if (typeof exception === "string") {
          attributes[semantic_conventions_1.SemanticAttributes.EXCEPTION_MESSAGE] = exception;
        } else if (exception) {
          if (exception.code) {
            attributes[semantic_conventions_1.SemanticAttributes.EXCEPTION_TYPE] = exception.code.toString();
          } else if (exception.name) {
            attributes[semantic_conventions_1.SemanticAttributes.EXCEPTION_TYPE] = exception.name;
          }
          if (exception.message) {
            attributes[semantic_conventions_1.SemanticAttributes.EXCEPTION_MESSAGE] = exception.message;
          }
          if (exception.stack) {
            attributes[semantic_conventions_1.SemanticAttributes.EXCEPTION_STACKTRACE] = exception.stack;
          }
        }
        if (attributes[semantic_conventions_1.SemanticAttributes.EXCEPTION_TYPE] || attributes[semantic_conventions_1.SemanticAttributes.EXCEPTION_MESSAGE]) {
          this.addEvent(enums_1.ExceptionEventName, attributes, time);
        } else {
          api.diag.warn(`Failed to record an exception ${exception}`);
        }
      }
      get duration() {
        return this._duration;
      }
      get ended() {
        return this._ended;
      }
      _isSpanEnded() {
        if (this._ended) {
          api.diag.warn(`Can not execute the operation on ended Span {traceId: ${this._spanContext.traceId}, spanId: ${this._spanContext.spanId}}`);
        }
        return this._ended;
      }
      _truncateToLimitUtil(value, limit) {
        if (value.length <= limit) {
          return value;
        }
        return value.substr(0, limit);
      }
      _truncateToSize(value) {
        const limit = this._attributeValueLengthLimit;
        if (limit <= 0) {
          api.diag.warn(`Attribute value limit must be positive, got ${limit}`);
          return value;
        }
        if (typeof value === "string") {
          return this._truncateToLimitUtil(value, limit);
        }
        if (Array.isArray(value)) {
          return value.map((val) => typeof val === "string" ? this._truncateToLimitUtil(val, limit) : val);
        }
        return value;
      }
    };
    exports2.Span = Span;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/config.js
var require_config = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/config.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.buildSamplerFromEnv = exports2.DEFAULT_CONFIG = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    var env = (0, core_1.getEnv)();
    var FALLBACK_OTEL_TRACES_SAMPLER = core_1.TracesSamplerValues.AlwaysOn;
    var DEFAULT_RATIO = 1;
    exports2.DEFAULT_CONFIG = {
      sampler: buildSamplerFromEnv(env),
      forceFlushTimeoutMillis: 3e4,
      generalLimits: {
        attributeValueLengthLimit: (0, core_1.getEnv)().OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT,
        attributeCountLimit: (0, core_1.getEnv)().OTEL_ATTRIBUTE_COUNT_LIMIT
      },
      spanLimits: {
        attributeValueLengthLimit: (0, core_1.getEnv)().OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT,
        attributeCountLimit: (0, core_1.getEnv)().OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT,
        linkCountLimit: (0, core_1.getEnv)().OTEL_SPAN_LINK_COUNT_LIMIT,
        eventCountLimit: (0, core_1.getEnv)().OTEL_SPAN_EVENT_COUNT_LIMIT
      }
    };
    function buildSamplerFromEnv(environment = (0, core_1.getEnv)()) {
      switch (environment.OTEL_TRACES_SAMPLER) {
        case core_1.TracesSamplerValues.AlwaysOn:
          return new core_1.AlwaysOnSampler();
        case core_1.TracesSamplerValues.AlwaysOff:
          return new core_1.AlwaysOffSampler();
        case core_1.TracesSamplerValues.ParentBasedAlwaysOn:
          return new core_1.ParentBasedSampler({
            root: new core_1.AlwaysOnSampler()
          });
        case core_1.TracesSamplerValues.ParentBasedAlwaysOff:
          return new core_1.ParentBasedSampler({
            root: new core_1.AlwaysOffSampler()
          });
        case core_1.TracesSamplerValues.TraceIdRatio:
          return new core_1.TraceIdRatioBasedSampler(getSamplerProbabilityFromEnv(environment));
        case core_1.TracesSamplerValues.ParentBasedTraceIdRatio:
          return new core_1.ParentBasedSampler({
            root: new core_1.TraceIdRatioBasedSampler(getSamplerProbabilityFromEnv(environment))
          });
        default:
          api_1.diag.error(`OTEL_TRACES_SAMPLER value "${environment.OTEL_TRACES_SAMPLER} invalid, defaulting to ${FALLBACK_OTEL_TRACES_SAMPLER}".`);
          return new core_1.AlwaysOnSampler();
      }
    }
    exports2.buildSamplerFromEnv = buildSamplerFromEnv;
    function getSamplerProbabilityFromEnv(environment) {
      if (environment.OTEL_TRACES_SAMPLER_ARG === void 0 || environment.OTEL_TRACES_SAMPLER_ARG === "") {
        api_1.diag.error(`OTEL_TRACES_SAMPLER_ARG is blank, defaulting to ${DEFAULT_RATIO}.`);
        return DEFAULT_RATIO;
      }
      const probability = Number(environment.OTEL_TRACES_SAMPLER_ARG);
      if (isNaN(probability)) {
        api_1.diag.error(`OTEL_TRACES_SAMPLER_ARG=${environment.OTEL_TRACES_SAMPLER_ARG} was given, but it is invalid, defaulting to ${DEFAULT_RATIO}.`);
        return DEFAULT_RATIO;
      }
      if (probability < 0 || probability > 1) {
        api_1.diag.error(`OTEL_TRACES_SAMPLER_ARG=${environment.OTEL_TRACES_SAMPLER_ARG} was given, but it is out of range ([0..1]), defaulting to ${DEFAULT_RATIO}.`);
        return DEFAULT_RATIO;
      }
      return probability;
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/utility.js
var require_utility = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/utility.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.reconfigureLimits = exports2.mergeConfig = void 0;
    var config_1 = require_config();
    function mergeConfig(userConfig) {
      const perInstanceDefaults = {
        sampler: (0, config_1.buildSamplerFromEnv)()
      };
      const target = Object.assign({}, config_1.DEFAULT_CONFIG, perInstanceDefaults, userConfig);
      target.generalLimits = Object.assign({}, config_1.DEFAULT_CONFIG.generalLimits, userConfig.generalLimits || {});
      target.spanLimits = Object.assign({}, config_1.DEFAULT_CONFIG.spanLimits, userConfig.spanLimits || {});
      return target;
    }
    exports2.mergeConfig = mergeConfig;
    function reconfigureLimits(userConfig) {
      var _a, _b;
      const spanLimits = Object.assign({}, userConfig.spanLimits);
      if (spanLimits.attributeCountLimit == null && ((_a = userConfig.generalLimits) === null || _a === void 0 ? void 0 : _a.attributeCountLimit) != null) {
        spanLimits.attributeCountLimit = userConfig.generalLimits.attributeCountLimit;
      }
      if (spanLimits.attributeValueLengthLimit == null && ((_b = userConfig.generalLimits) === null || _b === void 0 ? void 0 : _b.attributeValueLengthLimit) != null) {
        spanLimits.attributeValueLengthLimit = userConfig.generalLimits.attributeValueLengthLimit;
      }
      return Object.assign({}, userConfig, { spanLimits });
    }
    exports2.reconfigureLimits = reconfigureLimits;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/Tracer.js
var require_Tracer = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/Tracer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Tracer = void 0;
    var api = require_src();
    var core_1 = require_src4();
    var Span_1 = require_Span();
    var utility_1 = require_utility();
    var Tracer = class {
      constructor(instrumentationLibrary, config, _tracerProvider) {
        this._tracerProvider = _tracerProvider;
        const localConfig = (0, utility_1.mergeConfig)(config);
        this._sampler = localConfig.sampler;
        this._generalLimits = localConfig.generalLimits;
        this._spanLimits = localConfig.spanLimits;
        this._idGenerator = config.idGenerator || new core_1.RandomIdGenerator();
        this.resource = _tracerProvider.resource;
        this.instrumentationLibrary = instrumentationLibrary;
      }
      startSpan(name, options = {}, context = api.context.active()) {
        var _a, _b;
        if ((0, core_1.isTracingSuppressed)(context)) {
          api.diag.debug("Instrumentation suppressed, returning Noop Span");
          return api.trace.wrapSpanContext(api.INVALID_SPAN_CONTEXT);
        }
        if (options.root) {
          context = api.trace.deleteSpan(context);
        }
        const parentSpanContext = api.trace.getSpanContext(context);
        const spanId = this._idGenerator.generateSpanId();
        let traceId;
        let traceState;
        let parentSpanId;
        if (!parentSpanContext || !api.trace.isSpanContextValid(parentSpanContext)) {
          traceId = this._idGenerator.generateTraceId();
        } else {
          traceId = parentSpanContext.traceId;
          traceState = parentSpanContext.traceState;
          parentSpanId = parentSpanContext.spanId;
        }
        const spanKind = (_a = options.kind) !== null && _a !== void 0 ? _a : api.SpanKind.INTERNAL;
        const links = ((_b = options.links) !== null && _b !== void 0 ? _b : []).map((link) => {
          return {
            context: link.context,
            attributes: (0, core_1.sanitizeAttributes)(link.attributes)
          };
        });
        const attributes = (0, core_1.sanitizeAttributes)(options.attributes);
        const samplingResult = this._sampler.shouldSample(context, traceId, name, spanKind, attributes, links);
        const traceFlags = samplingResult.decision === api.SamplingDecision.RECORD_AND_SAMPLED ? api.TraceFlags.SAMPLED : api.TraceFlags.NONE;
        const spanContext = { traceId, spanId, traceFlags, traceState };
        if (samplingResult.decision === api.SamplingDecision.NOT_RECORD) {
          api.diag.debug("Recording is off, propagating context in a non-recording span");
          return api.trace.wrapSpanContext(spanContext);
        }
        const span = new Span_1.Span(this, context, name, spanContext, spanKind, parentSpanId, links, options.startTime);
        const initAttributes = (0, core_1.sanitizeAttributes)(Object.assign(attributes, samplingResult.attributes));
        span.setAttributes(initAttributes);
        return span;
      }
      startActiveSpan(name, arg2, arg3, arg4) {
        let opts;
        let ctx;
        let fn;
        if (arguments.length < 2) {
          return;
        } else if (arguments.length === 2) {
          fn = arg2;
        } else if (arguments.length === 3) {
          opts = arg2;
          fn = arg3;
        } else {
          opts = arg2;
          ctx = arg3;
          fn = arg4;
        }
        const parentContext = ctx !== null && ctx !== void 0 ? ctx : api.context.active();
        const span = this.startSpan(name, opts, parentContext);
        const contextWithSpanSet = api.trace.setSpan(parentContext, span);
        return api.context.with(contextWithSpanSet, fn, void 0, span);
      }
      getGeneralLimits() {
        return this._generalLimits;
      }
      getSpanLimits() {
        return this._spanLimits;
      }
      getActiveSpanProcessor() {
        return this._tracerProvider.getActiveSpanProcessor();
      }
    };
    exports2.Tracer = Tracer;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/default-service-name.js
var require_default_service_name = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/default-service-name.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.defaultServiceName = void 0;
    function defaultServiceName() {
      return `unknown_service:${process.argv0}`;
    }
    exports2.defaultServiceName = defaultServiceName;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/detect-resources.js
var require_detect_resources = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/detect-resources.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.detectResources = void 0;
    var Resource_1 = require_Resource();
    var api_1 = require_src();
    var util = require("util");
    var detectResources2 = async (config = {}) => {
      const internalConfig = Object.assign(config);
      const resources = await Promise.all((internalConfig.detectors || []).map(async (d) => {
        try {
          const resource = await d.detect(internalConfig);
          api_1.diag.debug(`${d.constructor.name} found resource.`, resource);
          return resource;
        } catch (e) {
          api_1.diag.debug(`${d.constructor.name} failed: ${e.message}`);
          return Resource_1.Resource.empty();
        }
      }));
      logResources(resources);
      return resources.reduce((acc, resource) => acc.merge(resource), Resource_1.Resource.empty());
    };
    exports2.detectResources = detectResources2;
    var logResources = (resources) => {
      resources.forEach((resource) => {
        if (Object.keys(resource.attributes).length > 0) {
          const resourceDebugString = util.inspect(resource.attributes, {
            depth: 2,
            breakLength: Infinity,
            sorted: true,
            compact: false
          });
          api_1.diag.verbose(resourceDebugString);
        }
      });
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/HostDetector.js
var require_HostDetector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/HostDetector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.hostDetector = void 0;
    var semantic_conventions_1 = require_src3();
    var Resource_1 = require_Resource();
    var os_1 = require("os");
    var HostDetector = class {
      async detect(_config) {
        const attributes = {
          [semantic_conventions_1.SemanticResourceAttributes.HOST_NAME]: (0, os_1.hostname)(),
          [semantic_conventions_1.SemanticResourceAttributes.HOST_ARCH]: this._normalizeArch((0, os_1.arch)())
        };
        return new Resource_1.Resource(attributes);
      }
      _normalizeArch(nodeArchString) {
        switch (nodeArchString) {
          case "arm":
            return "arm32";
          case "ppc":
            return "ppc32";
          case "x64":
            return "amd64";
          default:
            return nodeArchString;
        }
      }
    };
    exports2.hostDetector = new HostDetector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/OSDetector.js
var require_OSDetector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/OSDetector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.osDetector = void 0;
    var semantic_conventions_1 = require_src3();
    var Resource_1 = require_Resource();
    var os_1 = require("os");
    var OSDetector = class {
      async detect(_config) {
        const attributes = {
          [semantic_conventions_1.SemanticResourceAttributes.OS_TYPE]: this._normalizeType((0, os_1.platform)()),
          [semantic_conventions_1.SemanticResourceAttributes.OS_VERSION]: (0, os_1.release)()
        };
        return new Resource_1.Resource(attributes);
      }
      _normalizeType(nodePlatform) {
        switch (nodePlatform) {
          case "sunos":
            return "solaris";
          case "win32":
            return "windows";
          default:
            return nodePlatform;
        }
      }
    };
    exports2.osDetector = new OSDetector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/index.js
var require_node3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/node/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_default_service_name(), exports2);
    __exportStar(require_detect_resources(), exports2);
    __exportStar(require_HostDetector(), exports2);
    __exportStar(require_OSDetector(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/index.js
var require_platform3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/platform/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_node3(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/Resource.js
var require_Resource = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/Resource.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Resource = void 0;
    var semantic_conventions_1 = require_src3();
    var core_1 = require_src4();
    var platform_1 = require_platform3();
    var Resource = class {
      constructor(attributes) {
        this.attributes = attributes;
      }
      static empty() {
        return Resource.EMPTY;
      }
      static default() {
        return new Resource({
          [semantic_conventions_1.SemanticResourceAttributes.SERVICE_NAME]: (0, platform_1.defaultServiceName)(),
          [semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_LANGUAGE]: core_1.SDK_INFO[semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_LANGUAGE],
          [semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_NAME]: core_1.SDK_INFO[semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_NAME],
          [semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_VERSION]: core_1.SDK_INFO[semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_VERSION]
        });
      }
      merge(other) {
        if (!other || !Object.keys(other.attributes).length)
          return this;
        const mergedAttributes = Object.assign({}, this.attributes, other.attributes);
        return new Resource(mergedAttributes);
      }
    };
    exports2.Resource = Resource;
    Resource.EMPTY = new Resource({});
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/types.js
var require_types6 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/config.js
var require_config2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/config.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/detectors/BrowserDetector.js
var require_BrowserDetector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/detectors/BrowserDetector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.browserDetector = void 0;
    var api_1 = require_src();
    var semantic_conventions_1 = require_src3();
    var __1 = require_src6();
    var BrowserDetector = class {
      async detect(config) {
        const isBrowser = typeof navigator !== "undefined";
        if (!isBrowser) {
          return __1.Resource.empty();
        }
        const browserResource = {
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_NAME]: "browser",
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_DESCRIPTION]: "Web Browser",
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_VERSION]: navigator.userAgent
        };
        return this._getResourceAttributes(browserResource, config);
      }
      _getResourceAttributes(browserResource, _config) {
        if (browserResource[semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_VERSION] === "") {
          api_1.diag.debug("BrowserDetector failed: Unable to find required browser resources. ");
          return __1.Resource.empty();
        } else {
          return new __1.Resource(Object.assign({}, browserResource));
        }
      }
    };
    exports2.browserDetector = new BrowserDetector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/detectors/EnvDetector.js
var require_EnvDetector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/detectors/EnvDetector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.envDetector = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    var semantic_conventions_1 = require_src3();
    var Resource_1 = require_Resource();
    var EnvDetector = class {
      constructor() {
        this._MAX_LENGTH = 255;
        this._COMMA_SEPARATOR = ",";
        this._LABEL_KEY_VALUE_SPLITTER = "=";
        this._ERROR_MESSAGE_INVALID_CHARS = "should be a ASCII string with a length greater than 0 and not exceed " + this._MAX_LENGTH + " characters.";
        this._ERROR_MESSAGE_INVALID_VALUE = "should be a ASCII string with a length not exceed " + this._MAX_LENGTH + " characters.";
      }
      async detect(_config) {
        const attributes = {};
        const env = (0, core_1.getEnv)();
        const rawAttributes = env.OTEL_RESOURCE_ATTRIBUTES;
        const serviceName = env.OTEL_SERVICE_NAME;
        if (rawAttributes) {
          try {
            const parsedAttributes = this._parseResourceAttributes(rawAttributes);
            Object.assign(attributes, parsedAttributes);
          } catch (e) {
            api_1.diag.debug(`EnvDetector failed: ${e.message}`);
          }
        }
        if (serviceName) {
          attributes[semantic_conventions_1.SemanticResourceAttributes.SERVICE_NAME] = serviceName;
        }
        return new Resource_1.Resource(attributes);
      }
      _parseResourceAttributes(rawEnvAttributes) {
        if (!rawEnvAttributes)
          return {};
        const attributes = {};
        const rawAttributes = rawEnvAttributes.split(this._COMMA_SEPARATOR, -1);
        for (const rawAttribute of rawAttributes) {
          const keyValuePair = rawAttribute.split(this._LABEL_KEY_VALUE_SPLITTER, -1);
          if (keyValuePair.length !== 2) {
            continue;
          }
          let [key, value] = keyValuePair;
          key = key.trim();
          value = value.trim().split('^"|"$').join("");
          if (!this._isValidAndNotEmpty(key)) {
            throw new Error(`Attribute key ${this._ERROR_MESSAGE_INVALID_CHARS}`);
          }
          if (!this._isValid(value)) {
            throw new Error(`Attribute value ${this._ERROR_MESSAGE_INVALID_VALUE}`);
          }
          attributes[key] = value;
        }
        return attributes;
      }
      _isValid(name) {
        return name.length <= this._MAX_LENGTH && this._isPrintableString(name);
      }
      _isPrintableString(str) {
        for (let i = 0; i < str.length; i++) {
          const ch = str.charAt(i);
          if (ch <= " " || ch >= "~") {
            return false;
          }
        }
        return true;
      }
      _isValidAndNotEmpty(str) {
        return str.length > 0 && this._isValid(str);
      }
    };
    exports2.envDetector = new EnvDetector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/detectors/ProcessDetector.js
var require_ProcessDetector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/detectors/ProcessDetector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.processDetector = void 0;
    var api_1 = require_src();
    var semantic_conventions_1 = require_src3();
    var Resource_1 = require_Resource();
    var ProcessDetector = class {
      async detect(config) {
        if (typeof process !== "object") {
          return Resource_1.Resource.empty();
        }
        const processResource = {
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_PID]: process.pid,
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_EXECUTABLE_NAME]: process.title || "",
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_COMMAND]: process.argv[1] || "",
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_COMMAND_LINE]: process.argv.join(" ") || "",
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_VERSION]: process.versions.node,
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_NAME]: "nodejs",
          [semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_DESCRIPTION]: "Node.js"
        };
        return this._getResourceAttributes(processResource, config);
      }
      _getResourceAttributes(processResource, _config) {
        if (processResource[semantic_conventions_1.SemanticResourceAttributes.PROCESS_EXECUTABLE_NAME] === "" || processResource[semantic_conventions_1.SemanticResourceAttributes.PROCESS_EXECUTABLE_PATH] === "" || processResource[semantic_conventions_1.SemanticResourceAttributes.PROCESS_COMMAND] === "" || processResource[semantic_conventions_1.SemanticResourceAttributes.PROCESS_COMMAND_LINE] === "" || processResource[semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_VERSION] === "") {
          api_1.diag.debug("ProcessDetector failed: Unable to find required process resources. ");
          return Resource_1.Resource.empty();
        } else {
          return new Resource_1.Resource(Object.assign({}, processResource));
        }
      }
    };
    exports2.processDetector = new ProcessDetector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/detectors/index.js
var require_detectors = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/detectors/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_BrowserDetector(), exports2);
    __exportStar(require_EnvDetector(), exports2);
    __exportStar(require_ProcessDetector(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/index.js
var require_src6 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resources/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_Resource(), exports2);
    __exportStar(require_platform3(), exports2);
    __exportStar(require_types6(), exports2);
    __exportStar(require_config2(), exports2);
    __exportStar(require_detectors(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/MultiSpanProcessor.js
var require_MultiSpanProcessor = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/MultiSpanProcessor.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MultiSpanProcessor = void 0;
    var core_1 = require_src4();
    var MultiSpanProcessor = class {
      constructor(_spanProcessors) {
        this._spanProcessors = _spanProcessors;
      }
      forceFlush() {
        const promises = [];
        for (const spanProcessor2 of this._spanProcessors) {
          promises.push(spanProcessor2.forceFlush());
        }
        return new Promise((resolve) => {
          Promise.all(promises).then(() => {
            resolve();
          }).catch((error) => {
            (0, core_1.globalErrorHandler)(error || new Error("MultiSpanProcessor: forceFlush failed"));
            resolve();
          });
        });
      }
      onStart(span, context) {
        for (const spanProcessor2 of this._spanProcessors) {
          spanProcessor2.onStart(span, context);
        }
      }
      onEnd(span) {
        for (const spanProcessor2 of this._spanProcessors) {
          spanProcessor2.onEnd(span);
        }
      }
      shutdown() {
        const promises = [];
        for (const spanProcessor2 of this._spanProcessors) {
          promises.push(spanProcessor2.shutdown());
        }
        return new Promise((resolve, reject) => {
          Promise.all(promises).then(() => {
            resolve();
          }, reject);
        });
      }
    };
    exports2.MultiSpanProcessor = MultiSpanProcessor;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/NoopSpanProcessor.js
var require_NoopSpanProcessor = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/NoopSpanProcessor.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NoopSpanProcessor = void 0;
    var NoopSpanProcessor = class {
      onStart(_span, _context) {
      }
      onEnd(_span) {
      }
      shutdown() {
        return Promise.resolve();
      }
      forceFlush() {
        return Promise.resolve();
      }
    };
    exports2.NoopSpanProcessor = NoopSpanProcessor;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/BatchSpanProcessorBase.js
var require_BatchSpanProcessorBase = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/BatchSpanProcessorBase.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BatchSpanProcessorBase = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    var BatchSpanProcessorBase = class {
      constructor(_exporter, config) {
        this._exporter = _exporter;
        this._finishedSpans = [];
        const env = (0, core_1.getEnv)();
        this._maxExportBatchSize = typeof (config === null || config === void 0 ? void 0 : config.maxExportBatchSize) === "number" ? config.maxExportBatchSize : env.OTEL_BSP_MAX_EXPORT_BATCH_SIZE;
        this._maxQueueSize = typeof (config === null || config === void 0 ? void 0 : config.maxQueueSize) === "number" ? config.maxQueueSize : env.OTEL_BSP_MAX_QUEUE_SIZE;
        this._scheduledDelayMillis = typeof (config === null || config === void 0 ? void 0 : config.scheduledDelayMillis) === "number" ? config.scheduledDelayMillis : env.OTEL_BSP_SCHEDULE_DELAY;
        this._exportTimeoutMillis = typeof (config === null || config === void 0 ? void 0 : config.exportTimeoutMillis) === "number" ? config.exportTimeoutMillis : env.OTEL_BSP_EXPORT_TIMEOUT;
        this._shutdownOnce = new core_1.BindOnceFuture(this._shutdown, this);
      }
      forceFlush() {
        if (this._shutdownOnce.isCalled) {
          return this._shutdownOnce.promise;
        }
        return this._flushAll();
      }
      onStart(_span, _parentContext) {
      }
      onEnd(span) {
        if (this._shutdownOnce.isCalled) {
          return;
        }
        if ((span.spanContext().traceFlags & api_1.TraceFlags.SAMPLED) === 0) {
          return;
        }
        this._addToBuffer(span);
      }
      shutdown() {
        return this._shutdownOnce.call();
      }
      _shutdown() {
        return Promise.resolve().then(() => {
          return this.onShutdown();
        }).then(() => {
          return this._flushAll();
        }).then(() => {
          return this._exporter.shutdown();
        });
      }
      _addToBuffer(span) {
        if (this._finishedSpans.length >= this._maxQueueSize) {
          return;
        }
        this._finishedSpans.push(span);
        this._maybeStartTimer();
      }
      _flushAll() {
        return new Promise((resolve, reject) => {
          const promises = [];
          const count = Math.ceil(this._finishedSpans.length / this._maxExportBatchSize);
          for (let i = 0, j = count; i < j; i++) {
            promises.push(this._flushOneBatch());
          }
          Promise.all(promises).then(() => {
            resolve();
          }).catch(reject);
        });
      }
      _flushOneBatch() {
        this._clearTimer();
        if (this._finishedSpans.length === 0) {
          return Promise.resolve();
        }
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Timeout"));
          }, this._exportTimeoutMillis);
          api_1.context.with((0, core_1.suppressTracing)(api_1.context.active()), () => {
            this._exporter.export(this._finishedSpans.splice(0, this._maxExportBatchSize), (result) => {
              var _a;
              clearTimeout(timer);
              if (result.code === core_1.ExportResultCode.SUCCESS) {
                resolve();
              } else {
                reject((_a = result.error) !== null && _a !== void 0 ? _a : new Error("BatchSpanProcessor: span export failed"));
              }
            });
          });
        });
      }
      _maybeStartTimer() {
        if (this._timer !== void 0)
          return;
        this._timer = setTimeout(() => {
          this._flushOneBatch().then(() => {
            if (this._finishedSpans.length > 0) {
              this._clearTimer();
              this._maybeStartTimer();
            }
          }).catch((e) => {
            (0, core_1.globalErrorHandler)(e);
          });
        }, this._scheduledDelayMillis);
        (0, core_1.unrefTimer)(this._timer);
      }
      _clearTimer() {
        if (this._timer !== void 0) {
          clearTimeout(this._timer);
          this._timer = void 0;
        }
      }
    };
    exports2.BatchSpanProcessorBase = BatchSpanProcessorBase;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/platform/node/export/BatchSpanProcessor.js
var require_BatchSpanProcessor = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/platform/node/export/BatchSpanProcessor.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BatchSpanProcessor = void 0;
    var BatchSpanProcessorBase_1 = require_BatchSpanProcessorBase();
    var BatchSpanProcessor = class extends BatchSpanProcessorBase_1.BatchSpanProcessorBase {
      onShutdown() {
      }
    };
    exports2.BatchSpanProcessor = BatchSpanProcessor;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/platform/node/index.js
var require_node4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/platform/node/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_BatchSpanProcessor(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/platform/index.js
var require_platform4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/platform/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_node4(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/BasicTracerProvider.js
var require_BasicTracerProvider = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/BasicTracerProvider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BasicTracerProvider = exports2.ForceFlushState = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    var resources_1 = require_src6();
    var _1 = require_src7();
    var config_1 = require_config();
    var MultiSpanProcessor_1 = require_MultiSpanProcessor();
    var NoopSpanProcessor_1 = require_NoopSpanProcessor();
    var platform_1 = require_platform4();
    var utility_1 = require_utility();
    var ForceFlushState;
    (function(ForceFlushState2) {
      ForceFlushState2[ForceFlushState2["resolved"] = 0] = "resolved";
      ForceFlushState2[ForceFlushState2["timeout"] = 1] = "timeout";
      ForceFlushState2[ForceFlushState2["error"] = 2] = "error";
      ForceFlushState2[ForceFlushState2["unresolved"] = 3] = "unresolved";
    })(ForceFlushState = exports2.ForceFlushState || (exports2.ForceFlushState = {}));
    var BasicTracerProvider = class {
      constructor(config = {}) {
        var _a;
        this._registeredSpanProcessors = [];
        this._tracers = /* @__PURE__ */ new Map();
        const mergedConfig = (0, core_1.merge)({}, config_1.DEFAULT_CONFIG, (0, utility_1.reconfigureLimits)(config));
        this.resource = (_a = mergedConfig.resource) !== null && _a !== void 0 ? _a : resources_1.Resource.empty();
        this.resource = resources_1.Resource.default().merge(this.resource);
        this._config = Object.assign({}, mergedConfig, {
          resource: this.resource
        });
        const defaultExporter = this._buildExporterFromEnv();
        if (defaultExporter !== void 0) {
          const batchProcessor = new platform_1.BatchSpanProcessor(defaultExporter);
          this.activeSpanProcessor = batchProcessor;
        } else {
          this.activeSpanProcessor = new NoopSpanProcessor_1.NoopSpanProcessor();
        }
      }
      getTracer(name, version, options) {
        const key = `${name}@${version || ""}:${(options === null || options === void 0 ? void 0 : options.schemaUrl) || ""}`;
        if (!this._tracers.has(key)) {
          this._tracers.set(key, new _1.Tracer({ name, version, schemaUrl: options === null || options === void 0 ? void 0 : options.schemaUrl }, this._config, this));
        }
        return this._tracers.get(key);
      }
      addSpanProcessor(spanProcessor2) {
        if (this._registeredSpanProcessors.length === 0) {
          this.activeSpanProcessor.shutdown().catch((err) => api_1.diag.error("Error while trying to shutdown current span processor", err));
        }
        this._registeredSpanProcessors.push(spanProcessor2);
        this.activeSpanProcessor = new MultiSpanProcessor_1.MultiSpanProcessor(this._registeredSpanProcessors);
      }
      getActiveSpanProcessor() {
        return this.activeSpanProcessor;
      }
      register(config = {}) {
        api_1.trace.setGlobalTracerProvider(this);
        if (config.propagator === void 0) {
          config.propagator = this._buildPropagatorFromEnv();
        }
        if (config.contextManager) {
          api_1.context.setGlobalContextManager(config.contextManager);
        }
        if (config.propagator) {
          api_1.propagation.setGlobalPropagator(config.propagator);
        }
      }
      forceFlush() {
        const timeout = this._config.forceFlushTimeoutMillis;
        const promises = this._registeredSpanProcessors.map((spanProcessor2) => {
          return new Promise((resolve) => {
            let state;
            const timeoutInterval = setTimeout(() => {
              resolve(new Error(`Span processor did not completed within timeout period of ${timeout} ms`));
              state = ForceFlushState.timeout;
            }, timeout);
            spanProcessor2.forceFlush().then(() => {
              clearTimeout(timeoutInterval);
              if (state !== ForceFlushState.timeout) {
                state = ForceFlushState.resolved;
                resolve(state);
              }
            }).catch((error) => {
              clearTimeout(timeoutInterval);
              state = ForceFlushState.error;
              resolve(error);
            });
          });
        });
        return new Promise((resolve, reject) => {
          Promise.all(promises).then((results) => {
            const errors = results.filter((result) => result !== ForceFlushState.resolved);
            if (errors.length > 0) {
              reject(errors);
            } else {
              resolve();
            }
          }).catch((error) => reject([error]));
        });
      }
      shutdown() {
        return this.activeSpanProcessor.shutdown();
      }
      _getPropagator(name) {
        var _a;
        return (_a = BasicTracerProvider._registeredPropagators.get(name)) === null || _a === void 0 ? void 0 : _a();
      }
      _getSpanExporter(name) {
        var _a;
        return (_a = BasicTracerProvider._registeredExporters.get(name)) === null || _a === void 0 ? void 0 : _a();
      }
      _buildPropagatorFromEnv() {
        const uniquePropagatorNames = Array.from(new Set((0, core_1.getEnv)().OTEL_PROPAGATORS));
        const propagators = uniquePropagatorNames.map((name) => {
          const propagator = this._getPropagator(name);
          if (!propagator) {
            api_1.diag.warn(`Propagator "${name}" requested through environment variable is unavailable.`);
          }
          return propagator;
        });
        const validPropagators = propagators.reduce((list, item) => {
          if (item) {
            list.push(item);
          }
          return list;
        }, []);
        if (validPropagators.length === 0) {
          return;
        } else if (uniquePropagatorNames.length === 1) {
          return validPropagators[0];
        } else {
          return new core_1.CompositePropagator({
            propagators: validPropagators
          });
        }
      }
      _buildExporterFromEnv() {
        const exporterName = (0, core_1.getEnv)().OTEL_TRACES_EXPORTER;
        if (exporterName === "none")
          return;
        const exporter = this._getSpanExporter(exporterName);
        if (!exporter) {
          api_1.diag.error(`Exporter "${exporterName}" requested through environment variable is unavailable.`);
        }
        return exporter;
      }
    };
    exports2.BasicTracerProvider = BasicTracerProvider;
    BasicTracerProvider._registeredPropagators = /* @__PURE__ */ new Map([
      ["tracecontext", () => new core_1.W3CTraceContextPropagator()],
      ["baggage", () => new core_1.W3CBaggagePropagator()]
    ]);
    BasicTracerProvider._registeredExporters = /* @__PURE__ */ new Map();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/ConsoleSpanExporter.js
var require_ConsoleSpanExporter = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/ConsoleSpanExporter.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ConsoleSpanExporter = void 0;
    var core_1 = require_src4();
    var ConsoleSpanExporter = class {
      export(spans, resultCallback) {
        return this._sendSpans(spans, resultCallback);
      }
      shutdown() {
        this._sendSpans([]);
        return Promise.resolve();
      }
      _exportInfo(span) {
        return {
          traceId: span.spanContext().traceId,
          parentId: span.parentSpanId,
          name: span.name,
          id: span.spanContext().spanId,
          kind: span.kind,
          timestamp: (0, core_1.hrTimeToMicroseconds)(span.startTime),
          duration: (0, core_1.hrTimeToMicroseconds)(span.duration),
          attributes: span.attributes,
          status: span.status,
          events: span.events,
          links: span.links
        };
      }
      _sendSpans(spans, done) {
        for (const span of spans) {
          console.dir(this._exportInfo(span), { depth: 3 });
        }
        if (done) {
          return done({ code: core_1.ExportResultCode.SUCCESS });
        }
      }
    };
    exports2.ConsoleSpanExporter = ConsoleSpanExporter;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/InMemorySpanExporter.js
var require_InMemorySpanExporter = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/InMemorySpanExporter.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.InMemorySpanExporter = void 0;
    var core_1 = require_src4();
    var InMemorySpanExporter2 = class {
      constructor() {
        this._finishedSpans = [];
        this._stopped = false;
      }
      export(spans, resultCallback) {
        if (this._stopped)
          return resultCallback({
            code: core_1.ExportResultCode.FAILED,
            error: new Error("Exporter has been stopped")
          });
        this._finishedSpans.push(...spans);
        setTimeout(() => resultCallback({ code: core_1.ExportResultCode.SUCCESS }), 0);
      }
      shutdown() {
        this._stopped = true;
        this._finishedSpans = [];
        return Promise.resolve();
      }
      reset() {
        this._finishedSpans = [];
      }
      getFinishedSpans() {
        return this._finishedSpans;
      }
    };
    exports2.InMemorySpanExporter = InMemorySpanExporter2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/ReadableSpan.js
var require_ReadableSpan = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/ReadableSpan.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/SimpleSpanProcessor.js
var require_SimpleSpanProcessor = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/SimpleSpanProcessor.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SimpleSpanProcessor = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    var SimpleSpanProcessor = class {
      constructor(_exporter) {
        this._exporter = _exporter;
        this._shutdownOnce = new core_1.BindOnceFuture(this._shutdown, this);
      }
      forceFlush() {
        return Promise.resolve();
      }
      onStart(_span, _parentContext) {
      }
      onEnd(span) {
        if (this._shutdownOnce.isCalled) {
          return;
        }
        if ((span.spanContext().traceFlags & api_1.TraceFlags.SAMPLED) === 0) {
          return;
        }
        api_1.context.with((0, core_1.suppressTracing)(api_1.context.active()), () => {
          this._exporter.export([span], (result) => {
            var _a;
            if (result.code !== core_1.ExportResultCode.SUCCESS) {
              (0, core_1.globalErrorHandler)((_a = result.error) !== null && _a !== void 0 ? _a : new Error(`SimpleSpanProcessor: span export failed (status ${result})`));
            }
          });
        });
      }
      shutdown() {
        return this._shutdownOnce.call();
      }
      _shutdown() {
        return this._exporter.shutdown();
      }
    };
    exports2.SimpleSpanProcessor = SimpleSpanProcessor;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/SpanExporter.js
var require_SpanExporter = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/export/SpanExporter.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/SpanProcessor.js
var require_SpanProcessor = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/SpanProcessor.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/TimedEvent.js
var require_TimedEvent = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/TimedEvent.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/types.js
var require_types7 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/index.js
var require_src7 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-base/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_Tracer(), exports2);
    __exportStar(require_BasicTracerProvider(), exports2);
    __exportStar(require_platform4(), exports2);
    __exportStar(require_ConsoleSpanExporter(), exports2);
    __exportStar(require_InMemorySpanExporter(), exports2);
    __exportStar(require_ReadableSpan(), exports2);
    __exportStar(require_SimpleSpanProcessor(), exports2);
    __exportStar(require_SpanExporter(), exports2);
    __exportStar(require_NoopSpanProcessor(), exports2);
    __exportStar(require_Span(), exports2);
    __exportStar(require_SpanProcessor(), exports2);
    __exportStar(require_TimedEvent(), exports2);
    __exportStar(require_types7(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/constants.js
var require_constants3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/constants.js"(exports2, module2) {
    var SEMVER_SPEC_VERSION = "2.0.0";
    var MAX_LENGTH = 256;
    var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;
    var MAX_SAFE_COMPONENT_LENGTH = 16;
    module2.exports = {
      SEMVER_SPEC_VERSION,
      MAX_LENGTH,
      MAX_SAFE_INTEGER,
      MAX_SAFE_COMPONENT_LENGTH
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/debug.js
var require_debug = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/debug.js"(exports2, module2) {
    var debug = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {
    };
    module2.exports = debug;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/re.js
var require_re = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/re.js"(exports2, module2) {
    var { MAX_SAFE_COMPONENT_LENGTH } = require_constants3();
    var debug = require_debug();
    exports2 = module2.exports = {};
    var re = exports2.re = [];
    var src = exports2.src = [];
    var t = exports2.t = {};
    var R = 0;
    var createToken = (name, value, isGlobal) => {
      const index = R++;
      debug(name, index, value);
      t[name] = index;
      src[index] = value;
      re[index] = new RegExp(value, isGlobal ? "g" : void 0);
    };
    createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
    createToken("NUMERICIDENTIFIERLOOSE", "[0-9]+");
    createToken("NONNUMERICIDENTIFIER", "\\d*[a-zA-Z-][a-zA-Z0-9-]*");
    createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
    createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NUMERICIDENTIFIER]}|${src[t.NONNUMERICIDENTIFIER]})`);
    createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NUMERICIDENTIFIERLOOSE]}|${src[t.NONNUMERICIDENTIFIER]})`);
    createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
    createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
    createToken("BUILDIDENTIFIER", "[0-9A-Za-z-]+");
    createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
    createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
    createToken("FULL", `^${src[t.FULLPLAIN]}$`);
    createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
    createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
    createToken("GTLT", "((?:<|>)?=?)");
    createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
    createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
    createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
    createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COERCE", `${"(^|[^\\d])(\\d{1,"}${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:$|[^\\d])`);
    createToken("COERCERTL", src[t.COERCE], true);
    createToken("LONETILDE", "(?:~>?)");
    createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
    exports2.tildeTrimReplace = "$1~";
    createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
    createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("LONECARET", "(?:\\^)");
    createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
    exports2.caretTrimReplace = "$1^";
    createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
    createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
    createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
    createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
    exports2.comparatorTrimReplace = "$1$2$3";
    createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
    createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
    createToken("STAR", "(<|>)?=?\\s*\\*");
    createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
    createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/parse-options.js
var require_parse_options = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/parse-options.js"(exports2, module2) {
    var opts = ["includePrerelease", "loose", "rtl"];
    var parseOptions = (options) => !options ? {} : typeof options !== "object" ? { loose: true } : opts.filter((k) => options[k]).reduce((o, k) => {
      o[k] = true;
      return o;
    }, {});
    module2.exports = parseOptions;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/identifiers.js
var require_identifiers = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/internal/identifiers.js"(exports2, module2) {
    var numeric = /^[0-9]+$/;
    var compareIdentifiers = (a, b) => {
      const anum = numeric.test(a);
      const bnum = numeric.test(b);
      if (anum && bnum) {
        a = +a;
        b = +b;
      }
      return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
    };
    var rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
    module2.exports = {
      compareIdentifiers,
      rcompareIdentifiers
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/classes/semver.js
var require_semver2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/classes/semver.js"(exports2, module2) {
    var debug = require_debug();
    var { MAX_LENGTH, MAX_SAFE_INTEGER } = require_constants3();
    var { re, t } = require_re();
    var parseOptions = require_parse_options();
    var { compareIdentifiers } = require_identifiers();
    var SemVer = class {
      constructor(version, options) {
        options = parseOptions(options);
        if (version instanceof SemVer) {
          if (version.loose === !!options.loose && version.includePrerelease === !!options.includePrerelease) {
            return version;
          } else {
            version = version.version;
          }
        } else if (typeof version !== "string") {
          throw new TypeError(`Invalid Version: ${version}`);
        }
        if (version.length > MAX_LENGTH) {
          throw new TypeError(`version is longer than ${MAX_LENGTH} characters`);
        }
        debug("SemVer", version, options);
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL]);
        if (!m) {
          throw new TypeError(`Invalid Version: ${version}`);
        }
        this.raw = version;
        this.major = +m[1];
        this.minor = +m[2];
        this.patch = +m[3];
        if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
          throw new TypeError("Invalid major version");
        }
        if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
          throw new TypeError("Invalid minor version");
        }
        if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
          throw new TypeError("Invalid patch version");
        }
        if (!m[4]) {
          this.prerelease = [];
        } else {
          this.prerelease = m[4].split(".").map((id) => {
            if (/^[0-9]+$/.test(id)) {
              const num = +id;
              if (num >= 0 && num < MAX_SAFE_INTEGER) {
                return num;
              }
            }
            return id;
          });
        }
        this.build = m[5] ? m[5].split(".") : [];
        this.format();
      }
      format() {
        this.version = `${this.major}.${this.minor}.${this.patch}`;
        if (this.prerelease.length) {
          this.version += `-${this.prerelease.join(".")}`;
        }
        return this.version;
      }
      toString() {
        return this.version;
      }
      compare(other) {
        debug("SemVer.compare", this.version, this.options, other);
        if (!(other instanceof SemVer)) {
          if (typeof other === "string" && other === this.version) {
            return 0;
          }
          other = new SemVer(other, this.options);
        }
        if (other.version === this.version) {
          return 0;
        }
        return this.compareMain(other) || this.comparePre(other);
      }
      compareMain(other) {
        if (!(other instanceof SemVer)) {
          other = new SemVer(other, this.options);
        }
        return compareIdentifiers(this.major, other.major) || compareIdentifiers(this.minor, other.minor) || compareIdentifiers(this.patch, other.patch);
      }
      comparePre(other) {
        if (!(other instanceof SemVer)) {
          other = new SemVer(other, this.options);
        }
        if (this.prerelease.length && !other.prerelease.length) {
          return -1;
        } else if (!this.prerelease.length && other.prerelease.length) {
          return 1;
        } else if (!this.prerelease.length && !other.prerelease.length) {
          return 0;
        }
        let i = 0;
        do {
          const a = this.prerelease[i];
          const b = other.prerelease[i];
          debug("prerelease compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      compareBuild(other) {
        if (!(other instanceof SemVer)) {
          other = new SemVer(other, this.options);
        }
        let i = 0;
        do {
          const a = this.build[i];
          const b = other.build[i];
          debug("prerelease compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      inc(release, identifier) {
        switch (release) {
          case "premajor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor = 0;
            this.major++;
            this.inc("pre", identifier);
            break;
          case "preminor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor++;
            this.inc("pre", identifier);
            break;
          case "prepatch":
            this.prerelease.length = 0;
            this.inc("patch", identifier);
            this.inc("pre", identifier);
            break;
          case "prerelease":
            if (this.prerelease.length === 0) {
              this.inc("patch", identifier);
            }
            this.inc("pre", identifier);
            break;
          case "major":
            if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) {
              this.major++;
            }
            this.minor = 0;
            this.patch = 0;
            this.prerelease = [];
            break;
          case "minor":
            if (this.patch !== 0 || this.prerelease.length === 0) {
              this.minor++;
            }
            this.patch = 0;
            this.prerelease = [];
            break;
          case "patch":
            if (this.prerelease.length === 0) {
              this.patch++;
            }
            this.prerelease = [];
            break;
          case "pre":
            if (this.prerelease.length === 0) {
              this.prerelease = [0];
            } else {
              let i = this.prerelease.length;
              while (--i >= 0) {
                if (typeof this.prerelease[i] === "number") {
                  this.prerelease[i]++;
                  i = -2;
                }
              }
              if (i === -1) {
                this.prerelease.push(0);
              }
            }
            if (identifier) {
              if (compareIdentifiers(this.prerelease[0], identifier) === 0) {
                if (isNaN(this.prerelease[1])) {
                  this.prerelease = [identifier, 0];
                }
              } else {
                this.prerelease = [identifier, 0];
              }
            }
            break;
          default:
            throw new Error(`invalid increment argument: ${release}`);
        }
        this.format();
        this.raw = this.version;
        return this;
      }
    };
    module2.exports = SemVer;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/parse.js
var require_parse = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/parse.js"(exports2, module2) {
    var { MAX_LENGTH } = require_constants3();
    var { re, t } = require_re();
    var SemVer = require_semver2();
    var parseOptions = require_parse_options();
    var parse = (version, options) => {
      options = parseOptions(options);
      if (version instanceof SemVer) {
        return version;
      }
      if (typeof version !== "string") {
        return null;
      }
      if (version.length > MAX_LENGTH) {
        return null;
      }
      const r = options.loose ? re[t.LOOSE] : re[t.FULL];
      if (!r.test(version)) {
        return null;
      }
      try {
        return new SemVer(version, options);
      } catch (er) {
        return null;
      }
    };
    module2.exports = parse;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/valid.js
var require_valid = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/valid.js"(exports2, module2) {
    var parse = require_parse();
    var valid = (version, options) => {
      const v = parse(version, options);
      return v ? v.version : null;
    };
    module2.exports = valid;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/clean.js
var require_clean = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/clean.js"(exports2, module2) {
    var parse = require_parse();
    var clean = (version, options) => {
      const s = parse(version.trim().replace(/^[=v]+/, ""), options);
      return s ? s.version : null;
    };
    module2.exports = clean;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/inc.js
var require_inc = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/inc.js"(exports2, module2) {
    var SemVer = require_semver2();
    var inc = (version, release, options, identifier) => {
      if (typeof options === "string") {
        identifier = options;
        options = void 0;
      }
      try {
        return new SemVer(version instanceof SemVer ? version.version : version, options).inc(release, identifier).version;
      } catch (er) {
        return null;
      }
    };
    module2.exports = inc;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/compare.js
var require_compare = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/compare.js"(exports2, module2) {
    var SemVer = require_semver2();
    var compare = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
    module2.exports = compare;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/eq.js
var require_eq = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/eq.js"(exports2, module2) {
    var compare = require_compare();
    var eq = (a, b, loose) => compare(a, b, loose) === 0;
    module2.exports = eq;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/diff.js
var require_diff = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/diff.js"(exports2, module2) {
    var parse = require_parse();
    var eq = require_eq();
    var diff = (version1, version2) => {
      if (eq(version1, version2)) {
        return null;
      } else {
        const v1 = parse(version1);
        const v2 = parse(version2);
        const hasPre = v1.prerelease.length || v2.prerelease.length;
        const prefix = hasPre ? "pre" : "";
        const defaultResult = hasPre ? "prerelease" : "";
        for (const key in v1) {
          if (key === "major" || key === "minor" || key === "patch") {
            if (v1[key] !== v2[key]) {
              return prefix + key;
            }
          }
        }
        return defaultResult;
      }
    };
    module2.exports = diff;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/major.js
var require_major = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/major.js"(exports2, module2) {
    var SemVer = require_semver2();
    var major = (a, loose) => new SemVer(a, loose).major;
    module2.exports = major;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/minor.js
var require_minor = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/minor.js"(exports2, module2) {
    var SemVer = require_semver2();
    var minor = (a, loose) => new SemVer(a, loose).minor;
    module2.exports = minor;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/patch.js
var require_patch = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/patch.js"(exports2, module2) {
    var SemVer = require_semver2();
    var patch = (a, loose) => new SemVer(a, loose).patch;
    module2.exports = patch;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/prerelease.js
var require_prerelease = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/prerelease.js"(exports2, module2) {
    var parse = require_parse();
    var prerelease = (version, options) => {
      const parsed = parse(version, options);
      return parsed && parsed.prerelease.length ? parsed.prerelease : null;
    };
    module2.exports = prerelease;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/rcompare.js
var require_rcompare = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/rcompare.js"(exports2, module2) {
    var compare = require_compare();
    var rcompare = (a, b, loose) => compare(b, a, loose);
    module2.exports = rcompare;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/compare-loose.js
var require_compare_loose = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/compare-loose.js"(exports2, module2) {
    var compare = require_compare();
    var compareLoose = (a, b) => compare(a, b, true);
    module2.exports = compareLoose;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/compare-build.js
var require_compare_build = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/compare-build.js"(exports2, module2) {
    var SemVer = require_semver2();
    var compareBuild = (a, b, loose) => {
      const versionA = new SemVer(a, loose);
      const versionB = new SemVer(b, loose);
      return versionA.compare(versionB) || versionA.compareBuild(versionB);
    };
    module2.exports = compareBuild;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/sort.js
var require_sort = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/sort.js"(exports2, module2) {
    var compareBuild = require_compare_build();
    var sort = (list, loose) => list.sort((a, b) => compareBuild(a, b, loose));
    module2.exports = sort;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/rsort.js
var require_rsort = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/rsort.js"(exports2, module2) {
    var compareBuild = require_compare_build();
    var rsort = (list, loose) => list.sort((a, b) => compareBuild(b, a, loose));
    module2.exports = rsort;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/gt.js
var require_gt = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/gt.js"(exports2, module2) {
    var compare = require_compare();
    var gt = (a, b, loose) => compare(a, b, loose) > 0;
    module2.exports = gt;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/lt.js
var require_lt = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/lt.js"(exports2, module2) {
    var compare = require_compare();
    var lt = (a, b, loose) => compare(a, b, loose) < 0;
    module2.exports = lt;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/neq.js
var require_neq = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/neq.js"(exports2, module2) {
    var compare = require_compare();
    var neq = (a, b, loose) => compare(a, b, loose) !== 0;
    module2.exports = neq;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/gte.js
var require_gte = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/gte.js"(exports2, module2) {
    var compare = require_compare();
    var gte = (a, b, loose) => compare(a, b, loose) >= 0;
    module2.exports = gte;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/lte.js
var require_lte = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/lte.js"(exports2, module2) {
    var compare = require_compare();
    var lte = (a, b, loose) => compare(a, b, loose) <= 0;
    module2.exports = lte;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/cmp.js
var require_cmp = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/cmp.js"(exports2, module2) {
    var eq = require_eq();
    var neq = require_neq();
    var gt = require_gt();
    var gte = require_gte();
    var lt = require_lt();
    var lte = require_lte();
    var cmp = (a, op, b, loose) => {
      switch (op) {
        case "===":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a === b;
        case "!==":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a !== b;
        case "":
        case "=":
        case "==":
          return eq(a, b, loose);
        case "!=":
          return neq(a, b, loose);
        case ">":
          return gt(a, b, loose);
        case ">=":
          return gte(a, b, loose);
        case "<":
          return lt(a, b, loose);
        case "<=":
          return lte(a, b, loose);
        default:
          throw new TypeError(`Invalid operator: ${op}`);
      }
    };
    module2.exports = cmp;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/coerce.js
var require_coerce = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/coerce.js"(exports2, module2) {
    var SemVer = require_semver2();
    var parse = require_parse();
    var { re, t } = require_re();
    var coerce = (version, options) => {
      if (version instanceof SemVer) {
        return version;
      }
      if (typeof version === "number") {
        version = String(version);
      }
      if (typeof version !== "string") {
        return null;
      }
      options = options || {};
      let match = null;
      if (!options.rtl) {
        match = version.match(re[t.COERCE]);
      } else {
        let next;
        while ((next = re[t.COERCERTL].exec(version)) && (!match || match.index + match[0].length !== version.length)) {
          if (!match || next.index + next[0].length !== match.index + match[0].length) {
            match = next;
          }
          re[t.COERCERTL].lastIndex = next.index + next[1].length + next[2].length;
        }
        re[t.COERCERTL].lastIndex = -1;
      }
      if (match === null) {
        return null;
      }
      return parse(`${match[2]}.${match[3] || "0"}.${match[4] || "0"}`, options);
    };
    module2.exports = coerce;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/yallist/iterator.js
var require_iterator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/yallist/iterator.js"(exports2, module2) {
    "use strict";
    module2.exports = function(Yallist) {
      Yallist.prototype[Symbol.iterator] = function* () {
        for (let walker = this.head; walker; walker = walker.next) {
          yield walker.value;
        }
      };
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/yallist/yallist.js
var require_yallist = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/yallist/yallist.js"(exports2, module2) {
    "use strict";
    module2.exports = Yallist;
    Yallist.Node = Node;
    Yallist.create = Yallist;
    function Yallist(list) {
      var self2 = this;
      if (!(self2 instanceof Yallist)) {
        self2 = new Yallist();
      }
      self2.tail = null;
      self2.head = null;
      self2.length = 0;
      if (list && typeof list.forEach === "function") {
        list.forEach(function(item) {
          self2.push(item);
        });
      } else if (arguments.length > 0) {
        for (var i = 0, l = arguments.length; i < l; i++) {
          self2.push(arguments[i]);
        }
      }
      return self2;
    }
    Yallist.prototype.removeNode = function(node) {
      if (node.list !== this) {
        throw new Error("removing node which does not belong to this list");
      }
      var next = node.next;
      var prev = node.prev;
      if (next) {
        next.prev = prev;
      }
      if (prev) {
        prev.next = next;
      }
      if (node === this.head) {
        this.head = next;
      }
      if (node === this.tail) {
        this.tail = prev;
      }
      node.list.length--;
      node.next = null;
      node.prev = null;
      node.list = null;
      return next;
    };
    Yallist.prototype.unshiftNode = function(node) {
      if (node === this.head) {
        return;
      }
      if (node.list) {
        node.list.removeNode(node);
      }
      var head = this.head;
      node.list = this;
      node.next = head;
      if (head) {
        head.prev = node;
      }
      this.head = node;
      if (!this.tail) {
        this.tail = node;
      }
      this.length++;
    };
    Yallist.prototype.pushNode = function(node) {
      if (node === this.tail) {
        return;
      }
      if (node.list) {
        node.list.removeNode(node);
      }
      var tail = this.tail;
      node.list = this;
      node.prev = tail;
      if (tail) {
        tail.next = node;
      }
      this.tail = node;
      if (!this.head) {
        this.head = node;
      }
      this.length++;
    };
    Yallist.prototype.push = function() {
      for (var i = 0, l = arguments.length; i < l; i++) {
        push(this, arguments[i]);
      }
      return this.length;
    };
    Yallist.prototype.unshift = function() {
      for (var i = 0, l = arguments.length; i < l; i++) {
        unshift(this, arguments[i]);
      }
      return this.length;
    };
    Yallist.prototype.pop = function() {
      if (!this.tail) {
        return void 0;
      }
      var res = this.tail.value;
      this.tail = this.tail.prev;
      if (this.tail) {
        this.tail.next = null;
      } else {
        this.head = null;
      }
      this.length--;
      return res;
    };
    Yallist.prototype.shift = function() {
      if (!this.head) {
        return void 0;
      }
      var res = this.head.value;
      this.head = this.head.next;
      if (this.head) {
        this.head.prev = null;
      } else {
        this.tail = null;
      }
      this.length--;
      return res;
    };
    Yallist.prototype.forEach = function(fn, thisp) {
      thisp = thisp || this;
      for (var walker = this.head, i = 0; walker !== null; i++) {
        fn.call(thisp, walker.value, i, this);
        walker = walker.next;
      }
    };
    Yallist.prototype.forEachReverse = function(fn, thisp) {
      thisp = thisp || this;
      for (var walker = this.tail, i = this.length - 1; walker !== null; i--) {
        fn.call(thisp, walker.value, i, this);
        walker = walker.prev;
      }
    };
    Yallist.prototype.get = function(n) {
      for (var i = 0, walker = this.head; walker !== null && i < n; i++) {
        walker = walker.next;
      }
      if (i === n && walker !== null) {
        return walker.value;
      }
    };
    Yallist.prototype.getReverse = function(n) {
      for (var i = 0, walker = this.tail; walker !== null && i < n; i++) {
        walker = walker.prev;
      }
      if (i === n && walker !== null) {
        return walker.value;
      }
    };
    Yallist.prototype.map = function(fn, thisp) {
      thisp = thisp || this;
      var res = new Yallist();
      for (var walker = this.head; walker !== null; ) {
        res.push(fn.call(thisp, walker.value, this));
        walker = walker.next;
      }
      return res;
    };
    Yallist.prototype.mapReverse = function(fn, thisp) {
      thisp = thisp || this;
      var res = new Yallist();
      for (var walker = this.tail; walker !== null; ) {
        res.push(fn.call(thisp, walker.value, this));
        walker = walker.prev;
      }
      return res;
    };
    Yallist.prototype.reduce = function(fn, initial) {
      var acc;
      var walker = this.head;
      if (arguments.length > 1) {
        acc = initial;
      } else if (this.head) {
        walker = this.head.next;
        acc = this.head.value;
      } else {
        throw new TypeError("Reduce of empty list with no initial value");
      }
      for (var i = 0; walker !== null; i++) {
        acc = fn(acc, walker.value, i);
        walker = walker.next;
      }
      return acc;
    };
    Yallist.prototype.reduceReverse = function(fn, initial) {
      var acc;
      var walker = this.tail;
      if (arguments.length > 1) {
        acc = initial;
      } else if (this.tail) {
        walker = this.tail.prev;
        acc = this.tail.value;
      } else {
        throw new TypeError("Reduce of empty list with no initial value");
      }
      for (var i = this.length - 1; walker !== null; i--) {
        acc = fn(acc, walker.value, i);
        walker = walker.prev;
      }
      return acc;
    };
    Yallist.prototype.toArray = function() {
      var arr = new Array(this.length);
      for (var i = 0, walker = this.head; walker !== null; i++) {
        arr[i] = walker.value;
        walker = walker.next;
      }
      return arr;
    };
    Yallist.prototype.toArrayReverse = function() {
      var arr = new Array(this.length);
      for (var i = 0, walker = this.tail; walker !== null; i++) {
        arr[i] = walker.value;
        walker = walker.prev;
      }
      return arr;
    };
    Yallist.prototype.slice = function(from, to) {
      to = to || this.length;
      if (to < 0) {
        to += this.length;
      }
      from = from || 0;
      if (from < 0) {
        from += this.length;
      }
      var ret = new Yallist();
      if (to < from || to < 0) {
        return ret;
      }
      if (from < 0) {
        from = 0;
      }
      if (to > this.length) {
        to = this.length;
      }
      for (var i = 0, walker = this.head; walker !== null && i < from; i++) {
        walker = walker.next;
      }
      for (; walker !== null && i < to; i++, walker = walker.next) {
        ret.push(walker.value);
      }
      return ret;
    };
    Yallist.prototype.sliceReverse = function(from, to) {
      to = to || this.length;
      if (to < 0) {
        to += this.length;
      }
      from = from || 0;
      if (from < 0) {
        from += this.length;
      }
      var ret = new Yallist();
      if (to < from || to < 0) {
        return ret;
      }
      if (from < 0) {
        from = 0;
      }
      if (to > this.length) {
        to = this.length;
      }
      for (var i = this.length, walker = this.tail; walker !== null && i > to; i--) {
        walker = walker.prev;
      }
      for (; walker !== null && i > from; i--, walker = walker.prev) {
        ret.push(walker.value);
      }
      return ret;
    };
    Yallist.prototype.splice = function(start, deleteCount, ...nodes) {
      if (start > this.length) {
        start = this.length - 1;
      }
      if (start < 0) {
        start = this.length + start;
      }
      for (var i = 0, walker = this.head; walker !== null && i < start; i++) {
        walker = walker.next;
      }
      var ret = [];
      for (var i = 0; walker && i < deleteCount; i++) {
        ret.push(walker.value);
        walker = this.removeNode(walker);
      }
      if (walker === null) {
        walker = this.tail;
      }
      if (walker !== this.head && walker !== this.tail) {
        walker = walker.prev;
      }
      for (var i = 0; i < nodes.length; i++) {
        walker = insert(this, walker, nodes[i]);
      }
      return ret;
    };
    Yallist.prototype.reverse = function() {
      var head = this.head;
      var tail = this.tail;
      for (var walker = head; walker !== null; walker = walker.prev) {
        var p = walker.prev;
        walker.prev = walker.next;
        walker.next = p;
      }
      this.head = tail;
      this.tail = head;
      return this;
    };
    function insert(self2, node, value) {
      var inserted = node === self2.head ? new Node(value, null, node, self2) : new Node(value, node, node.next, self2);
      if (inserted.next === null) {
        self2.tail = inserted;
      }
      if (inserted.prev === null) {
        self2.head = inserted;
      }
      self2.length++;
      return inserted;
    }
    function push(self2, item) {
      self2.tail = new Node(item, self2.tail, null, self2);
      if (!self2.head) {
        self2.head = self2.tail;
      }
      self2.length++;
    }
    function unshift(self2, item) {
      self2.head = new Node(item, null, self2.head, self2);
      if (!self2.tail) {
        self2.tail = self2.head;
      }
      self2.length++;
    }
    function Node(value, prev, next, list) {
      if (!(this instanceof Node)) {
        return new Node(value, prev, next, list);
      }
      this.list = list;
      this.value = value;
      if (prev) {
        prev.next = this;
        this.prev = prev;
      } else {
        this.prev = null;
      }
      if (next) {
        next.prev = this;
        this.next = next;
      } else {
        this.next = null;
      }
    }
    try {
      require_iterator()(Yallist);
    } catch (er) {
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/lru-cache/index.js
var require_lru_cache = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/lru-cache/index.js"(exports2, module2) {
    "use strict";
    var Yallist = require_yallist();
    var MAX = Symbol("max");
    var LENGTH = Symbol("length");
    var LENGTH_CALCULATOR = Symbol("lengthCalculator");
    var ALLOW_STALE = Symbol("allowStale");
    var MAX_AGE = Symbol("maxAge");
    var DISPOSE = Symbol("dispose");
    var NO_DISPOSE_ON_SET = Symbol("noDisposeOnSet");
    var LRU_LIST = Symbol("lruList");
    var CACHE = Symbol("cache");
    var UPDATE_AGE_ON_GET = Symbol("updateAgeOnGet");
    var naiveLength = () => 1;
    var LRUCache = class {
      constructor(options) {
        if (typeof options === "number")
          options = { max: options };
        if (!options)
          options = {};
        if (options.max && (typeof options.max !== "number" || options.max < 0))
          throw new TypeError("max must be a non-negative number");
        const max = this[MAX] = options.max || Infinity;
        const lc = options.length || naiveLength;
        this[LENGTH_CALCULATOR] = typeof lc !== "function" ? naiveLength : lc;
        this[ALLOW_STALE] = options.stale || false;
        if (options.maxAge && typeof options.maxAge !== "number")
          throw new TypeError("maxAge must be a number");
        this[MAX_AGE] = options.maxAge || 0;
        this[DISPOSE] = options.dispose;
        this[NO_DISPOSE_ON_SET] = options.noDisposeOnSet || false;
        this[UPDATE_AGE_ON_GET] = options.updateAgeOnGet || false;
        this.reset();
      }
      set max(mL) {
        if (typeof mL !== "number" || mL < 0)
          throw new TypeError("max must be a non-negative number");
        this[MAX] = mL || Infinity;
        trim(this);
      }
      get max() {
        return this[MAX];
      }
      set allowStale(allowStale) {
        this[ALLOW_STALE] = !!allowStale;
      }
      get allowStale() {
        return this[ALLOW_STALE];
      }
      set maxAge(mA) {
        if (typeof mA !== "number")
          throw new TypeError("maxAge must be a non-negative number");
        this[MAX_AGE] = mA;
        trim(this);
      }
      get maxAge() {
        return this[MAX_AGE];
      }
      set lengthCalculator(lC) {
        if (typeof lC !== "function")
          lC = naiveLength;
        if (lC !== this[LENGTH_CALCULATOR]) {
          this[LENGTH_CALCULATOR] = lC;
          this[LENGTH] = 0;
          this[LRU_LIST].forEach((hit) => {
            hit.length = this[LENGTH_CALCULATOR](hit.value, hit.key);
            this[LENGTH] += hit.length;
          });
        }
        trim(this);
      }
      get lengthCalculator() {
        return this[LENGTH_CALCULATOR];
      }
      get length() {
        return this[LENGTH];
      }
      get itemCount() {
        return this[LRU_LIST].length;
      }
      rforEach(fn, thisp) {
        thisp = thisp || this;
        for (let walker = this[LRU_LIST].tail; walker !== null; ) {
          const prev = walker.prev;
          forEachStep(this, fn, walker, thisp);
          walker = prev;
        }
      }
      forEach(fn, thisp) {
        thisp = thisp || this;
        for (let walker = this[LRU_LIST].head; walker !== null; ) {
          const next = walker.next;
          forEachStep(this, fn, walker, thisp);
          walker = next;
        }
      }
      keys() {
        return this[LRU_LIST].toArray().map((k) => k.key);
      }
      values() {
        return this[LRU_LIST].toArray().map((k) => k.value);
      }
      reset() {
        if (this[DISPOSE] && this[LRU_LIST] && this[LRU_LIST].length) {
          this[LRU_LIST].forEach((hit) => this[DISPOSE](hit.key, hit.value));
        }
        this[CACHE] = /* @__PURE__ */ new Map();
        this[LRU_LIST] = new Yallist();
        this[LENGTH] = 0;
      }
      dump() {
        return this[LRU_LIST].map((hit) => isStale(this, hit) ? false : {
          k: hit.key,
          v: hit.value,
          e: hit.now + (hit.maxAge || 0)
        }).toArray().filter((h) => h);
      }
      dumpLru() {
        return this[LRU_LIST];
      }
      set(key, value, maxAge) {
        maxAge = maxAge || this[MAX_AGE];
        if (maxAge && typeof maxAge !== "number")
          throw new TypeError("maxAge must be a number");
        const now = maxAge ? Date.now() : 0;
        const len = this[LENGTH_CALCULATOR](value, key);
        if (this[CACHE].has(key)) {
          if (len > this[MAX]) {
            del(this, this[CACHE].get(key));
            return false;
          }
          const node = this[CACHE].get(key);
          const item = node.value;
          if (this[DISPOSE]) {
            if (!this[NO_DISPOSE_ON_SET])
              this[DISPOSE](key, item.value);
          }
          item.now = now;
          item.maxAge = maxAge;
          item.value = value;
          this[LENGTH] += len - item.length;
          item.length = len;
          this.get(key);
          trim(this);
          return true;
        }
        const hit = new Entry(key, value, len, now, maxAge);
        if (hit.length > this[MAX]) {
          if (this[DISPOSE])
            this[DISPOSE](key, value);
          return false;
        }
        this[LENGTH] += hit.length;
        this[LRU_LIST].unshift(hit);
        this[CACHE].set(key, this[LRU_LIST].head);
        trim(this);
        return true;
      }
      has(key) {
        if (!this[CACHE].has(key))
          return false;
        const hit = this[CACHE].get(key).value;
        return !isStale(this, hit);
      }
      get(key) {
        return get(this, key, true);
      }
      peek(key) {
        return get(this, key, false);
      }
      pop() {
        const node = this[LRU_LIST].tail;
        if (!node)
          return null;
        del(this, node);
        return node.value;
      }
      del(key) {
        del(this, this[CACHE].get(key));
      }
      load(arr) {
        this.reset();
        const now = Date.now();
        for (let l = arr.length - 1; l >= 0; l--) {
          const hit = arr[l];
          const expiresAt = hit.e || 0;
          if (expiresAt === 0)
            this.set(hit.k, hit.v);
          else {
            const maxAge = expiresAt - now;
            if (maxAge > 0) {
              this.set(hit.k, hit.v, maxAge);
            }
          }
        }
      }
      prune() {
        this[CACHE].forEach((value, key) => get(this, key, false));
      }
    };
    var get = (self2, key, doUse) => {
      const node = self2[CACHE].get(key);
      if (node) {
        const hit = node.value;
        if (isStale(self2, hit)) {
          del(self2, node);
          if (!self2[ALLOW_STALE])
            return void 0;
        } else {
          if (doUse) {
            if (self2[UPDATE_AGE_ON_GET])
              node.value.now = Date.now();
            self2[LRU_LIST].unshiftNode(node);
          }
        }
        return hit.value;
      }
    };
    var isStale = (self2, hit) => {
      if (!hit || !hit.maxAge && !self2[MAX_AGE])
        return false;
      const diff = Date.now() - hit.now;
      return hit.maxAge ? diff > hit.maxAge : self2[MAX_AGE] && diff > self2[MAX_AGE];
    };
    var trim = (self2) => {
      if (self2[LENGTH] > self2[MAX]) {
        for (let walker = self2[LRU_LIST].tail; self2[LENGTH] > self2[MAX] && walker !== null; ) {
          const prev = walker.prev;
          del(self2, walker);
          walker = prev;
        }
      }
    };
    var del = (self2, node) => {
      if (node) {
        const hit = node.value;
        if (self2[DISPOSE])
          self2[DISPOSE](hit.key, hit.value);
        self2[LENGTH] -= hit.length;
        self2[CACHE].delete(hit.key);
        self2[LRU_LIST].removeNode(node);
      }
    };
    var Entry = class {
      constructor(key, value, length, now, maxAge) {
        this.key = key;
        this.value = value;
        this.length = length;
        this.now = now;
        this.maxAge = maxAge || 0;
      }
    };
    var forEachStep = (self2, fn, node, thisp) => {
      let hit = node.value;
      if (isStale(self2, hit)) {
        del(self2, node);
        if (!self2[ALLOW_STALE])
          hit = void 0;
      }
      if (hit)
        fn.call(thisp, hit.value, hit.key, self2);
    };
    module2.exports = LRUCache;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/classes/range.js
var require_range = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/classes/range.js"(exports2, module2) {
    var Range = class {
      constructor(range, options) {
        options = parseOptions(options);
        if (range instanceof Range) {
          if (range.loose === !!options.loose && range.includePrerelease === !!options.includePrerelease) {
            return range;
          } else {
            return new Range(range.raw, options);
          }
        }
        if (range instanceof Comparator) {
          this.raw = range.value;
          this.set = [[range]];
          this.format();
          return this;
        }
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        this.raw = range;
        this.set = range.split("||").map((r) => this.parseRange(r.trim())).filter((c) => c.length);
        if (!this.set.length) {
          throw new TypeError(`Invalid SemVer Range: ${range}`);
        }
        if (this.set.length > 1) {
          const first = this.set[0];
          this.set = this.set.filter((c) => !isNullSet(c[0]));
          if (this.set.length === 0) {
            this.set = [first];
          } else if (this.set.length > 1) {
            for (const c of this.set) {
              if (c.length === 1 && isAny(c[0])) {
                this.set = [c];
                break;
              }
            }
          }
        }
        this.format();
      }
      format() {
        this.range = this.set.map((comps) => {
          return comps.join(" ").trim();
        }).join("||").trim();
        return this.range;
      }
      toString() {
        return this.range;
      }
      parseRange(range) {
        range = range.trim();
        const memoOpts = Object.keys(this.options).join(",");
        const memoKey = `parseRange:${memoOpts}:${range}`;
        const cached = cache.get(memoKey);
        if (cached) {
          return cached;
        }
        const loose = this.options.loose;
        const hr = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE];
        range = range.replace(hr, hyphenReplace(this.options.includePrerelease));
        debug("hyphen replace", range);
        range = range.replace(re[t.COMPARATORTRIM], comparatorTrimReplace);
        debug("comparator trim", range);
        range = range.replace(re[t.TILDETRIM], tildeTrimReplace);
        range = range.replace(re[t.CARETTRIM], caretTrimReplace);
        range = range.split(/\s+/).join(" ");
        let rangeList = range.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options));
        if (loose) {
          rangeList = rangeList.filter((comp) => {
            debug("loose invalid filter", comp, this.options);
            return !!comp.match(re[t.COMPARATORLOOSE]);
          });
        }
        debug("range list", rangeList);
        const rangeMap = /* @__PURE__ */ new Map();
        const comparators = rangeList.map((comp) => new Comparator(comp, this.options));
        for (const comp of comparators) {
          if (isNullSet(comp)) {
            return [comp];
          }
          rangeMap.set(comp.value, comp);
        }
        if (rangeMap.size > 1 && rangeMap.has("")) {
          rangeMap.delete("");
        }
        const result = [...rangeMap.values()];
        cache.set(memoKey, result);
        return result;
      }
      intersects(range, options) {
        if (!(range instanceof Range)) {
          throw new TypeError("a Range is required");
        }
        return this.set.some((thisComparators) => {
          return isSatisfiable(thisComparators, options) && range.set.some((rangeComparators) => {
            return isSatisfiable(rangeComparators, options) && thisComparators.every((thisComparator) => {
              return rangeComparators.every((rangeComparator) => {
                return thisComparator.intersects(rangeComparator, options);
              });
            });
          });
        });
      }
      test(version) {
        if (!version) {
          return false;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        for (let i = 0; i < this.set.length; i++) {
          if (testSet(this.set[i], version, this.options)) {
            return true;
          }
        }
        return false;
      }
    };
    module2.exports = Range;
    var LRU = require_lru_cache();
    var cache = new LRU({ max: 1e3 });
    var parseOptions = require_parse_options();
    var Comparator = require_comparator();
    var debug = require_debug();
    var SemVer = require_semver2();
    var {
      re,
      t,
      comparatorTrimReplace,
      tildeTrimReplace,
      caretTrimReplace
    } = require_re();
    var isNullSet = (c) => c.value === "<0.0.0-0";
    var isAny = (c) => c.value === "";
    var isSatisfiable = (comparators, options) => {
      let result = true;
      const remainingComparators = comparators.slice();
      let testComparator = remainingComparators.pop();
      while (result && remainingComparators.length) {
        result = remainingComparators.every((otherComparator) => {
          return testComparator.intersects(otherComparator, options);
        });
        testComparator = remainingComparators.pop();
      }
      return result;
    };
    var parseComparator = (comp, options) => {
      debug("comp", comp, options);
      comp = replaceCarets(comp, options);
      debug("caret", comp);
      comp = replaceTildes(comp, options);
      debug("tildes", comp);
      comp = replaceXRanges(comp, options);
      debug("xrange", comp);
      comp = replaceStars(comp, options);
      debug("stars", comp);
      return comp;
    };
    var isX = (id) => !id || id.toLowerCase() === "x" || id === "*";
    var replaceTildes = (comp, options) => comp.trim().split(/\s+/).map((c) => {
      return replaceTilde(c, options);
    }).join(" ");
    var replaceTilde = (comp, options) => {
      const r = options.loose ? re[t.TILDELOOSE] : re[t.TILDE];
      return comp.replace(r, (_, M, m, p, pr) => {
        debug("tilde", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0 <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          ret = `>=${M}.${m}.0 <${M}.${+m + 1}.0-0`;
        } else if (pr) {
          debug("replaceTilde pr", pr);
          ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
        } else {
          ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
        }
        debug("tilde return", ret);
        return ret;
      });
    };
    var replaceCarets = (comp, options) => comp.trim().split(/\s+/).map((c) => {
      return replaceCaret(c, options);
    }).join(" ");
    var replaceCaret = (comp, options) => {
      debug("caret", comp, options);
      const r = options.loose ? re[t.CARETLOOSE] : re[t.CARET];
      const z = options.includePrerelease ? "-0" : "";
      return comp.replace(r, (_, M, m, p, pr) => {
        debug("caret", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          if (M === "0") {
            ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
          } else {
            ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
          }
        } else if (pr) {
          debug("replaceCaret pr", pr);
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
          }
        } else {
          debug("no pr");
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p}${z} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p}${z} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
          }
        }
        debug("caret return", ret);
        return ret;
      });
    };
    var replaceXRanges = (comp, options) => {
      debug("replaceXRanges", comp, options);
      return comp.split(/\s+/).map((c) => {
        return replaceXRange(c, options);
      }).join(" ");
    };
    var replaceXRange = (comp, options) => {
      comp = comp.trim();
      const r = options.loose ? re[t.XRANGELOOSE] : re[t.XRANGE];
      return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
        debug("xRange", comp, ret, gtlt, M, m, p, pr);
        const xM = isX(M);
        const xm = xM || isX(m);
        const xp = xm || isX(p);
        const anyX = xp;
        if (gtlt === "=" && anyX) {
          gtlt = "";
        }
        pr = options.includePrerelease ? "-0" : "";
        if (xM) {
          if (gtlt === ">" || gtlt === "<") {
            ret = "<0.0.0-0";
          } else {
            ret = "*";
          }
        } else if (gtlt && anyX) {
          if (xm) {
            m = 0;
          }
          p = 0;
          if (gtlt === ">") {
            gtlt = ">=";
            if (xm) {
              M = +M + 1;
              m = 0;
              p = 0;
            } else {
              m = +m + 1;
              p = 0;
            }
          } else if (gtlt === "<=") {
            gtlt = "<";
            if (xm) {
              M = +M + 1;
            } else {
              m = +m + 1;
            }
          }
          if (gtlt === "<") {
            pr = "-0";
          }
          ret = `${gtlt + M}.${m}.${p}${pr}`;
        } else if (xm) {
          ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
        } else if (xp) {
          ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
        }
        debug("xRange return", ret);
        return ret;
      });
    };
    var replaceStars = (comp, options) => {
      debug("replaceStars", comp, options);
      return comp.trim().replace(re[t.STAR], "");
    };
    var replaceGTE0 = (comp, options) => {
      debug("replaceGTE0", comp, options);
      return comp.trim().replace(re[options.includePrerelease ? t.GTE0PRE : t.GTE0], "");
    };
    var hyphenReplace = (incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr, tb) => {
      if (isX(fM)) {
        from = "";
      } else if (isX(fm)) {
        from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
      } else if (isX(fp)) {
        from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
      } else if (fpr) {
        from = `>=${from}`;
      } else {
        from = `>=${from}${incPr ? "-0" : ""}`;
      }
      if (isX(tM)) {
        to = "";
      } else if (isX(tm)) {
        to = `<${+tM + 1}.0.0-0`;
      } else if (isX(tp)) {
        to = `<${tM}.${+tm + 1}.0-0`;
      } else if (tpr) {
        to = `<=${tM}.${tm}.${tp}-${tpr}`;
      } else if (incPr) {
        to = `<${tM}.${tm}.${+tp + 1}-0`;
      } else {
        to = `<=${to}`;
      }
      return `${from} ${to}`.trim();
    };
    var testSet = (set, version, options) => {
      for (let i = 0; i < set.length; i++) {
        if (!set[i].test(version)) {
          return false;
        }
      }
      if (version.prerelease.length && !options.includePrerelease) {
        for (let i = 0; i < set.length; i++) {
          debug(set[i].semver);
          if (set[i].semver === Comparator.ANY) {
            continue;
          }
          if (set[i].semver.prerelease.length > 0) {
            const allowed = set[i].semver;
            if (allowed.major === version.major && allowed.minor === version.minor && allowed.patch === version.patch) {
              return true;
            }
          }
        }
        return false;
      }
      return true;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/classes/comparator.js
var require_comparator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/classes/comparator.js"(exports2, module2) {
    var ANY = Symbol("SemVer ANY");
    var Comparator = class {
      static get ANY() {
        return ANY;
      }
      constructor(comp, options) {
        options = parseOptions(options);
        if (comp instanceof Comparator) {
          if (comp.loose === !!options.loose) {
            return comp;
          } else {
            comp = comp.value;
          }
        }
        debug("comparator", comp, options);
        this.options = options;
        this.loose = !!options.loose;
        this.parse(comp);
        if (this.semver === ANY) {
          this.value = "";
        } else {
          this.value = this.operator + this.semver.version;
        }
        debug("comp", this);
      }
      parse(comp) {
        const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
        const m = comp.match(r);
        if (!m) {
          throw new TypeError(`Invalid comparator: ${comp}`);
        }
        this.operator = m[1] !== void 0 ? m[1] : "";
        if (this.operator === "=") {
          this.operator = "";
        }
        if (!m[2]) {
          this.semver = ANY;
        } else {
          this.semver = new SemVer(m[2], this.options.loose);
        }
      }
      toString() {
        return this.value;
      }
      test(version) {
        debug("Comparator.test", version, this.options.loose);
        if (this.semver === ANY || version === ANY) {
          return true;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        return cmp(version, this.operator, this.semver, this.options);
      }
      intersects(comp, options) {
        if (!(comp instanceof Comparator)) {
          throw new TypeError("a Comparator is required");
        }
        if (!options || typeof options !== "object") {
          options = {
            loose: !!options,
            includePrerelease: false
          };
        }
        if (this.operator === "") {
          if (this.value === "") {
            return true;
          }
          return new Range(comp.value, options).test(this.value);
        } else if (comp.operator === "") {
          if (comp.value === "") {
            return true;
          }
          return new Range(this.value, options).test(comp.semver);
        }
        const sameDirectionIncreasing = (this.operator === ">=" || this.operator === ">") && (comp.operator === ">=" || comp.operator === ">");
        const sameDirectionDecreasing = (this.operator === "<=" || this.operator === "<") && (comp.operator === "<=" || comp.operator === "<");
        const sameSemVer = this.semver.version === comp.semver.version;
        const differentDirectionsInclusive = (this.operator === ">=" || this.operator === "<=") && (comp.operator === ">=" || comp.operator === "<=");
        const oppositeDirectionsLessThan = cmp(this.semver, "<", comp.semver, options) && (this.operator === ">=" || this.operator === ">") && (comp.operator === "<=" || comp.operator === "<");
        const oppositeDirectionsGreaterThan = cmp(this.semver, ">", comp.semver, options) && (this.operator === "<=" || this.operator === "<") && (comp.operator === ">=" || comp.operator === ">");
        return sameDirectionIncreasing || sameDirectionDecreasing || sameSemVer && differentDirectionsInclusive || oppositeDirectionsLessThan || oppositeDirectionsGreaterThan;
      }
    };
    module2.exports = Comparator;
    var parseOptions = require_parse_options();
    var { re, t } = require_re();
    var cmp = require_cmp();
    var debug = require_debug();
    var SemVer = require_semver2();
    var Range = require_range();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/satisfies.js
var require_satisfies = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/functions/satisfies.js"(exports2, module2) {
    var Range = require_range();
    var satisfies = (version, range, options) => {
      try {
        range = new Range(range, options);
      } catch (er) {
        return false;
      }
      return range.test(version);
    };
    module2.exports = satisfies;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/to-comparators.js
var require_to_comparators = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/to-comparators.js"(exports2, module2) {
    var Range = require_range();
    var toComparators = (range, options) => new Range(range, options).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" "));
    module2.exports = toComparators;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/max-satisfying.js
var require_max_satisfying = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/max-satisfying.js"(exports2, module2) {
    var SemVer = require_semver2();
    var Range = require_range();
    var maxSatisfying = (versions, range, options) => {
      let max = null;
      let maxSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!max || maxSV.compare(v) === -1) {
            max = v;
            maxSV = new SemVer(max, options);
          }
        }
      });
      return max;
    };
    module2.exports = maxSatisfying;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/min-satisfying.js
var require_min_satisfying = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/min-satisfying.js"(exports2, module2) {
    var SemVer = require_semver2();
    var Range = require_range();
    var minSatisfying = (versions, range, options) => {
      let min = null;
      let minSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!min || minSV.compare(v) === 1) {
            min = v;
            minSV = new SemVer(min, options);
          }
        }
      });
      return min;
    };
    module2.exports = minSatisfying;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/min-version.js
var require_min_version = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/min-version.js"(exports2, module2) {
    var SemVer = require_semver2();
    var Range = require_range();
    var gt = require_gt();
    var minVersion = (range, loose) => {
      range = new Range(range, loose);
      let minver = new SemVer("0.0.0");
      if (range.test(minver)) {
        return minver;
      }
      minver = new SemVer("0.0.0-0");
      if (range.test(minver)) {
        return minver;
      }
      minver = null;
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let setMin = null;
        comparators.forEach((comparator) => {
          const compver = new SemVer(comparator.semver.version);
          switch (comparator.operator) {
            case ">":
              if (compver.prerelease.length === 0) {
                compver.patch++;
              } else {
                compver.prerelease.push(0);
              }
              compver.raw = compver.format();
            case "":
            case ">=":
              if (!setMin || gt(compver, setMin)) {
                setMin = compver;
              }
              break;
            case "<":
            case "<=":
              break;
            default:
              throw new Error(`Unexpected operation: ${comparator.operator}`);
          }
        });
        if (setMin && (!minver || gt(minver, setMin))) {
          minver = setMin;
        }
      }
      if (minver && range.test(minver)) {
        return minver;
      }
      return null;
    };
    module2.exports = minVersion;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/valid.js
var require_valid2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/valid.js"(exports2, module2) {
    var Range = require_range();
    var validRange = (range, options) => {
      try {
        return new Range(range, options).range || "*";
      } catch (er) {
        return null;
      }
    };
    module2.exports = validRange;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/outside.js
var require_outside = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/outside.js"(exports2, module2) {
    var SemVer = require_semver2();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var Range = require_range();
    var satisfies = require_satisfies();
    var gt = require_gt();
    var lt = require_lt();
    var lte = require_lte();
    var gte = require_gte();
    var outside = (version, range, hilo, options) => {
      version = new SemVer(version, options);
      range = new Range(range, options);
      let gtfn, ltefn, ltfn, comp, ecomp;
      switch (hilo) {
        case ">":
          gtfn = gt;
          ltefn = lte;
          ltfn = lt;
          comp = ">";
          ecomp = ">=";
          break;
        case "<":
          gtfn = lt;
          ltefn = gte;
          ltfn = gt;
          comp = "<";
          ecomp = "<=";
          break;
        default:
          throw new TypeError('Must provide a hilo val of "<" or ">"');
      }
      if (satisfies(version, range, options)) {
        return false;
      }
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let high = null;
        let low = null;
        comparators.forEach((comparator) => {
          if (comparator.semver === ANY) {
            comparator = new Comparator(">=0.0.0");
          }
          high = high || comparator;
          low = low || comparator;
          if (gtfn(comparator.semver, high.semver, options)) {
            high = comparator;
          } else if (ltfn(comparator.semver, low.semver, options)) {
            low = comparator;
          }
        });
        if (high.operator === comp || high.operator === ecomp) {
          return false;
        }
        if ((!low.operator || low.operator === comp) && ltefn(version, low.semver)) {
          return false;
        } else if (low.operator === ecomp && ltfn(version, low.semver)) {
          return false;
        }
      }
      return true;
    };
    module2.exports = outside;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/gtr.js
var require_gtr = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/gtr.js"(exports2, module2) {
    var outside = require_outside();
    var gtr = (version, range, options) => outside(version, range, ">", options);
    module2.exports = gtr;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/ltr.js
var require_ltr = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/ltr.js"(exports2, module2) {
    var outside = require_outside();
    var ltr = (version, range, options) => outside(version, range, "<", options);
    module2.exports = ltr;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/intersects.js
var require_intersects = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/intersects.js"(exports2, module2) {
    var Range = require_range();
    var intersects = (r1, r2, options) => {
      r1 = new Range(r1, options);
      r2 = new Range(r2, options);
      return r1.intersects(r2);
    };
    module2.exports = intersects;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/simplify.js
var require_simplify = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/simplify.js"(exports2, module2) {
    var satisfies = require_satisfies();
    var compare = require_compare();
    module2.exports = (versions, range, options) => {
      const set = [];
      let first = null;
      let prev = null;
      const v = versions.sort((a, b) => compare(a, b, options));
      for (const version of v) {
        const included = satisfies(version, range, options);
        if (included) {
          prev = version;
          if (!first) {
            first = version;
          }
        } else {
          if (prev) {
            set.push([first, prev]);
          }
          prev = null;
          first = null;
        }
      }
      if (first) {
        set.push([first, null]);
      }
      const ranges = [];
      for (const [min, max] of set) {
        if (min === max) {
          ranges.push(min);
        } else if (!max && min === v[0]) {
          ranges.push("*");
        } else if (!max) {
          ranges.push(`>=${min}`);
        } else if (min === v[0]) {
          ranges.push(`<=${max}`);
        } else {
          ranges.push(`${min} - ${max}`);
        }
      }
      const simplified = ranges.join(" || ");
      const original = typeof range.raw === "string" ? range.raw : String(range);
      return simplified.length < original.length ? simplified : range;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/subset.js
var require_subset = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/ranges/subset.js"(exports2, module2) {
    var Range = require_range();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var satisfies = require_satisfies();
    var compare = require_compare();
    var subset = (sub, dom, options = {}) => {
      if (sub === dom) {
        return true;
      }
      sub = new Range(sub, options);
      dom = new Range(dom, options);
      let sawNonNull = false;
      OUTER:
        for (const simpleSub of sub.set) {
          for (const simpleDom of dom.set) {
            const isSub = simpleSubset(simpleSub, simpleDom, options);
            sawNonNull = sawNonNull || isSub !== null;
            if (isSub) {
              continue OUTER;
            }
          }
          if (sawNonNull) {
            return false;
          }
        }
      return true;
    };
    var simpleSubset = (sub, dom, options) => {
      if (sub === dom) {
        return true;
      }
      if (sub.length === 1 && sub[0].semver === ANY) {
        if (dom.length === 1 && dom[0].semver === ANY) {
          return true;
        } else if (options.includePrerelease) {
          sub = [new Comparator(">=0.0.0-0")];
        } else {
          sub = [new Comparator(">=0.0.0")];
        }
      }
      if (dom.length === 1 && dom[0].semver === ANY) {
        if (options.includePrerelease) {
          return true;
        } else {
          dom = [new Comparator(">=0.0.0")];
        }
      }
      const eqSet = /* @__PURE__ */ new Set();
      let gt, lt;
      for (const c of sub) {
        if (c.operator === ">" || c.operator === ">=") {
          gt = higherGT(gt, c, options);
        } else if (c.operator === "<" || c.operator === "<=") {
          lt = lowerLT(lt, c, options);
        } else {
          eqSet.add(c.semver);
        }
      }
      if (eqSet.size > 1) {
        return null;
      }
      let gtltComp;
      if (gt && lt) {
        gtltComp = compare(gt.semver, lt.semver, options);
        if (gtltComp > 0) {
          return null;
        } else if (gtltComp === 0 && (gt.operator !== ">=" || lt.operator !== "<=")) {
          return null;
        }
      }
      for (const eq of eqSet) {
        if (gt && !satisfies(eq, String(gt), options)) {
          return null;
        }
        if (lt && !satisfies(eq, String(lt), options)) {
          return null;
        }
        for (const c of dom) {
          if (!satisfies(eq, String(c), options)) {
            return false;
          }
        }
        return true;
      }
      let higher, lower;
      let hasDomLT, hasDomGT;
      let needDomLTPre = lt && !options.includePrerelease && lt.semver.prerelease.length ? lt.semver : false;
      let needDomGTPre = gt && !options.includePrerelease && gt.semver.prerelease.length ? gt.semver : false;
      if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt.operator === "<" && needDomLTPre.prerelease[0] === 0) {
        needDomLTPre = false;
      }
      for (const c of dom) {
        hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
        hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
        if (gt) {
          if (needDomGTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) {
              needDomGTPre = false;
            }
          }
          if (c.operator === ">" || c.operator === ">=") {
            higher = higherGT(gt, c, options);
            if (higher === c && higher !== gt) {
              return false;
            }
          } else if (gt.operator === ">=" && !satisfies(gt.semver, String(c), options)) {
            return false;
          }
        }
        if (lt) {
          if (needDomLTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) {
              needDomLTPre = false;
            }
          }
          if (c.operator === "<" || c.operator === "<=") {
            lower = lowerLT(lt, c, options);
            if (lower === c && lower !== lt) {
              return false;
            }
          } else if (lt.operator === "<=" && !satisfies(lt.semver, String(c), options)) {
            return false;
          }
        }
        if (!c.operator && (lt || gt) && gtltComp !== 0) {
          return false;
        }
      }
      if (gt && hasDomLT && !lt && gtltComp !== 0) {
        return false;
      }
      if (lt && hasDomGT && !gt && gtltComp !== 0) {
        return false;
      }
      if (needDomGTPre || needDomLTPre) {
        return false;
      }
      return true;
    };
    var higherGT = (a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare(a.semver, b.semver, options);
      return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
    };
    var lowerLT = (a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare(a.semver, b.semver, options);
      return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
    };
    module2.exports = subset;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/index.js
var require_semver3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/semver/index.js"(exports2, module2) {
    var internalRe = require_re();
    module2.exports = {
      re: internalRe.re,
      src: internalRe.src,
      tokens: internalRe.t,
      SEMVER_SPEC_VERSION: require_constants3().SEMVER_SPEC_VERSION,
      SemVer: require_semver2(),
      compareIdentifiers: require_identifiers().compareIdentifiers,
      rcompareIdentifiers: require_identifiers().rcompareIdentifiers,
      parse: require_parse(),
      valid: require_valid(),
      clean: require_clean(),
      inc: require_inc(),
      diff: require_diff(),
      major: require_major(),
      minor: require_minor(),
      patch: require_patch(),
      prerelease: require_prerelease(),
      compare: require_compare(),
      rcompare: require_rcompare(),
      compareLoose: require_compare_loose(),
      compareBuild: require_compare_build(),
      sort: require_sort(),
      rsort: require_rsort(),
      gt: require_gt(),
      lt: require_lt(),
      eq: require_eq(),
      neq: require_neq(),
      gte: require_gte(),
      lte: require_lte(),
      cmp: require_cmp(),
      coerce: require_coerce(),
      Comparator: require_comparator(),
      Range: require_range(),
      satisfies: require_satisfies(),
      toComparators: require_to_comparators(),
      maxSatisfying: require_max_satisfying(),
      minSatisfying: require_min_satisfying(),
      minVersion: require_min_version(),
      validRange: require_valid2(),
      outside: require_outside(),
      gtr: require_gtr(),
      ltr: require_ltr(),
      intersects: require_intersects(),
      simplifyRange: require_simplify(),
      subset: require_subset()
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-jaeger/build/src/JaegerPropagator.js
var require_JaegerPropagator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-jaeger/build/src/JaegerPropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.JaegerPropagator = exports2.UBER_BAGGAGE_HEADER_PREFIX = exports2.UBER_TRACE_ID_HEADER = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    exports2.UBER_TRACE_ID_HEADER = "uber-trace-id";
    exports2.UBER_BAGGAGE_HEADER_PREFIX = "uberctx";
    var JaegerPropagator = class {
      constructor(config) {
        if (typeof config === "string") {
          this._jaegerTraceHeader = config;
          this._jaegerBaggageHeaderPrefix = exports2.UBER_BAGGAGE_HEADER_PREFIX;
        } else {
          this._jaegerTraceHeader = (config === null || config === void 0 ? void 0 : config.customTraceHeader) || exports2.UBER_TRACE_ID_HEADER;
          this._jaegerBaggageHeaderPrefix = (config === null || config === void 0 ? void 0 : config.customBaggageHeaderPrefix) || exports2.UBER_BAGGAGE_HEADER_PREFIX;
        }
      }
      inject(context, carrier, setter) {
        const spanContext = api_1.trace.getSpanContext(context);
        const baggage = api_1.propagation.getBaggage(context);
        if (spanContext && (0, core_1.isTracingSuppressed)(context) === false) {
          const traceFlags = `0${(spanContext.traceFlags || api_1.TraceFlags.NONE).toString(16)}`;
          setter.set(carrier, this._jaegerTraceHeader, `${spanContext.traceId}:${spanContext.spanId}:0:${traceFlags}`);
        }
        if (baggage) {
          for (const [key, entry] of baggage.getAllEntries()) {
            setter.set(carrier, `${this._jaegerBaggageHeaderPrefix}-${key}`, encodeURIComponent(entry.value));
          }
        }
      }
      extract(context, carrier, getter) {
        var _a;
        const uberTraceIdHeader = getter.get(carrier, this._jaegerTraceHeader);
        const uberTraceId = Array.isArray(uberTraceIdHeader) ? uberTraceIdHeader[0] : uberTraceIdHeader;
        const baggageValues = getter.keys(carrier).filter((key) => key.startsWith(`${this._jaegerBaggageHeaderPrefix}-`)).map((key) => {
          const value = getter.get(carrier, key);
          return {
            key: key.substring(this._jaegerBaggageHeaderPrefix.length + 1),
            value: Array.isArray(value) ? value[0] : value
          };
        });
        let newContext = context;
        if (typeof uberTraceId === "string") {
          const spanContext = deserializeSpanContext(uberTraceId);
          if (spanContext) {
            newContext = api_1.trace.setSpanContext(newContext, spanContext);
          }
        }
        if (baggageValues.length === 0)
          return newContext;
        let currentBaggage = (_a = api_1.propagation.getBaggage(context)) !== null && _a !== void 0 ? _a : api_1.propagation.createBaggage();
        for (const baggageEntry of baggageValues) {
          if (baggageEntry.value === void 0)
            continue;
          currentBaggage = currentBaggage.setEntry(baggageEntry.key, {
            value: decodeURIComponent(baggageEntry.value)
          });
        }
        newContext = api_1.propagation.setBaggage(newContext, currentBaggage);
        return newContext;
      }
      fields() {
        return [this._jaegerTraceHeader];
      }
    };
    exports2.JaegerPropagator = JaegerPropagator;
    function deserializeSpanContext(serializedString) {
      const headers = decodeURIComponent(serializedString).split(":");
      if (headers.length !== 4) {
        return null;
      }
      const [_traceId, _spanId, , flags] = headers;
      const traceId = _traceId.padStart(32, "0");
      const spanId = _spanId.padStart(16, "0");
      const traceFlags = flags.match(/^[0-9a-f]{1,2}$/i) ? parseInt(flags, 16) & 1 : 1;
      return { traceId, spanId, isRemote: true, traceFlags };
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-jaeger/build/src/index.js
var require_src8 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-jaeger/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_JaegerPropagator(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-node/build/src/NodeTracerProvider.js
var require_NodeTracerProvider = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-node/build/src/NodeTracerProvider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NodeTracerProvider = void 0;
    var context_async_hooks_1 = require_src2();
    var propagator_b3_1 = require_src5();
    var sdk_trace_base_1 = require_src7();
    var semver = require_semver3();
    var propagator_jaeger_1 = require_src8();
    var NodeTracerProvider2 = class extends sdk_trace_base_1.BasicTracerProvider {
      constructor(config = {}) {
        super(config);
      }
      register(config = {}) {
        if (config.contextManager === void 0) {
          const ContextManager = semver.gte(process.version, "14.8.0") ? context_async_hooks_1.AsyncLocalStorageContextManager : context_async_hooks_1.AsyncHooksContextManager;
          config.contextManager = new ContextManager();
          config.contextManager.enable();
        }
        super.register(config);
      }
      _getPropagator(name) {
        var _a;
        return super._getPropagator(name) || ((_a = NodeTracerProvider2._registeredPropagators.get(name)) === null || _a === void 0 ? void 0 : _a());
      }
    };
    exports2.NodeTracerProvider = NodeTracerProvider2;
    NodeTracerProvider2._registeredPropagators = /* @__PURE__ */ new Map([
      [
        "b3",
        () => new propagator_b3_1.B3Propagator({ injectEncoding: propagator_b3_1.B3InjectEncoding.SINGLE_HEADER })
      ],
      [
        "b3multi",
        () => new propagator_b3_1.B3Propagator({ injectEncoding: propagator_b3_1.B3InjectEncoding.MULTI_HEADER })
      ],
      ["jaeger", () => new propagator_jaeger_1.JaegerPropagator()]
    ]);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-node/build/src/index.js
var require_src9 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/sdk-trace-node/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_NodeTracerProvider(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/NoopMeter.js
var require_NoopMeter = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/NoopMeter.js"(exports2) {
    "use strict";
    var __extends = exports2 && exports2.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
          d2.__proto__ = b2;
        } || function(d2, b2) {
          for (var p in b2)
            if (Object.prototype.hasOwnProperty.call(b2, p))
              d2[p] = b2[p];
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        if (typeof b !== "function" && b !== null)
          throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = exports2.NOOP_OBSERVABLE_GAUGE_METRIC = exports2.NOOP_OBSERVABLE_COUNTER_METRIC = exports2.NOOP_UP_DOWN_COUNTER_METRIC = exports2.NOOP_HISTOGRAM_METRIC = exports2.NOOP_COUNTER_METRIC = exports2.NOOP_METER = exports2.NoopObservableBaseMetric = exports2.NoopHistogramMetric = exports2.NoopUpDownCounterMetric = exports2.NoopCounterMetric = exports2.NoopMetric = exports2.NoopMeter = void 0;
    var NoopMeter = function() {
      function NoopMeter2() {
      }
      NoopMeter2.prototype.createHistogram = function(_name, _options) {
        return exports2.NOOP_HISTOGRAM_METRIC;
      };
      NoopMeter2.prototype.createCounter = function(_name, _options) {
        return exports2.NOOP_COUNTER_METRIC;
      };
      NoopMeter2.prototype.createUpDownCounter = function(_name, _options) {
        return exports2.NOOP_UP_DOWN_COUNTER_METRIC;
      };
      NoopMeter2.prototype.createObservableGauge = function(_name, _options, _callback) {
        return exports2.NOOP_OBSERVABLE_GAUGE_METRIC;
      };
      NoopMeter2.prototype.createObservableCounter = function(_name, _options, _callback) {
        return exports2.NOOP_OBSERVABLE_COUNTER_METRIC;
      };
      NoopMeter2.prototype.createObservableUpDownCounter = function(_name, _options, _callback) {
        return exports2.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC;
      };
      return NoopMeter2;
    }();
    exports2.NoopMeter = NoopMeter;
    var NoopMetric = function() {
      function NoopMetric2() {
      }
      return NoopMetric2;
    }();
    exports2.NoopMetric = NoopMetric;
    var NoopCounterMetric = function(_super) {
      __extends(NoopCounterMetric2, _super);
      function NoopCounterMetric2() {
        return _super !== null && _super.apply(this, arguments) || this;
      }
      NoopCounterMetric2.prototype.add = function(_value, _attributes) {
      };
      return NoopCounterMetric2;
    }(NoopMetric);
    exports2.NoopCounterMetric = NoopCounterMetric;
    var NoopUpDownCounterMetric = function(_super) {
      __extends(NoopUpDownCounterMetric2, _super);
      function NoopUpDownCounterMetric2() {
        return _super !== null && _super.apply(this, arguments) || this;
      }
      NoopUpDownCounterMetric2.prototype.add = function(_value, _attributes) {
      };
      return NoopUpDownCounterMetric2;
    }(NoopMetric);
    exports2.NoopUpDownCounterMetric = NoopUpDownCounterMetric;
    var NoopHistogramMetric = function(_super) {
      __extends(NoopHistogramMetric2, _super);
      function NoopHistogramMetric2() {
        return _super !== null && _super.apply(this, arguments) || this;
      }
      NoopHistogramMetric2.prototype.record = function(_value, _attributes) {
      };
      return NoopHistogramMetric2;
    }(NoopMetric);
    exports2.NoopHistogramMetric = NoopHistogramMetric;
    var NoopObservableBaseMetric = function(_super) {
      __extends(NoopObservableBaseMetric2, _super);
      function NoopObservableBaseMetric2() {
        return _super !== null && _super.apply(this, arguments) || this;
      }
      NoopObservableBaseMetric2.prototype.observation = function() {
        return {
          observable: this,
          value: 0
        };
      };
      return NoopObservableBaseMetric2;
    }(NoopMetric);
    exports2.NoopObservableBaseMetric = NoopObservableBaseMetric;
    exports2.NOOP_METER = new NoopMeter();
    exports2.NOOP_COUNTER_METRIC = new NoopCounterMetric();
    exports2.NOOP_HISTOGRAM_METRIC = new NoopHistogramMetric();
    exports2.NOOP_UP_DOWN_COUNTER_METRIC = new NoopUpDownCounterMetric();
    exports2.NOOP_OBSERVABLE_COUNTER_METRIC = new NoopObservableBaseMetric();
    exports2.NOOP_OBSERVABLE_GAUGE_METRIC = new NoopObservableBaseMetric();
    exports2.NOOP_OBSERVABLE_UP_DOWN_COUNTER_METRIC = new NoopObservableBaseMetric();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/NoopMeterProvider.js
var require_NoopMeterProvider = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/NoopMeterProvider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NOOP_METER_PROVIDER = exports2.NoopMeterProvider = void 0;
    var NoopMeter_1 = require_NoopMeter();
    var NoopMeterProvider = function() {
      function NoopMeterProvider2() {
      }
      NoopMeterProvider2.prototype.getMeter = function(_name, _version, _options) {
        return NoopMeter_1.NOOP_METER;
      };
      return NoopMeterProvider2;
    }();
    exports2.NoopMeterProvider = NoopMeterProvider;
    exports2.NOOP_METER_PROVIDER = new NoopMeterProvider();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/Meter.js
var require_Meter = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/Meter.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/MeterProvider.js
var require_MeterProvider = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/MeterProvider.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/Metric.js
var require_Metric = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/Metric.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AggregationTemporality = exports2.ValueType = void 0;
    var ValueType;
    (function(ValueType2) {
      ValueType2[ValueType2["INT"] = 0] = "INT";
      ValueType2[ValueType2["DOUBLE"] = 1] = "DOUBLE";
    })(ValueType = exports2.ValueType || (exports2.ValueType = {}));
    var AggregationTemporality;
    (function(AggregationTemporality2) {
      AggregationTemporality2[AggregationTemporality2["AGGREGATION_TEMPORALITY_UNSPECIFIED"] = 0] = "AGGREGATION_TEMPORALITY_UNSPECIFIED";
      AggregationTemporality2[AggregationTemporality2["AGGREGATION_TEMPORALITY_DELTA"] = 1] = "AGGREGATION_TEMPORALITY_DELTA";
      AggregationTemporality2[AggregationTemporality2["AGGREGATION_TEMPORALITY_CUMULATIVE"] = 2] = "AGGREGATION_TEMPORALITY_CUMULATIVE";
    })(AggregationTemporality = exports2.AggregationTemporality || (exports2.AggregationTemporality = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/Observation.js
var require_Observation = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/Observation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/ObservableResult.js
var require_ObservableResult = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/types/ObservableResult.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/platform/node/globalThis.js
var require_globalThis3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/platform/node/globalThis.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2._globalThis = void 0;
    exports2._globalThis = typeof globalThis === "object" ? globalThis : global;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/platform/node/index.js
var require_node5 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/platform/node/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_globalThis3(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/platform/index.js
var require_platform5 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/platform/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_node5(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/api/global-utils.js
var require_global_utils2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/api/global-utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.API_BACKWARDS_COMPATIBILITY_VERSION = exports2.makeGetter = exports2._global = exports2.GLOBAL_METRICS_API_KEY = void 0;
    var platform_1 = require_platform5();
    exports2.GLOBAL_METRICS_API_KEY = Symbol.for("io.opentelemetry.js.api.metrics");
    exports2._global = platform_1._globalThis;
    function makeGetter(requiredVersion, instance, fallback) {
      return function(version) {
        return version === requiredVersion ? instance : fallback;
      };
    }
    exports2.makeGetter = makeGetter;
    exports2.API_BACKWARDS_COMPATIBILITY_VERSION = 4;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/api/metrics.js
var require_metrics = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/api/metrics.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MetricsAPI = void 0;
    var NoopMeterProvider_1 = require_NoopMeterProvider();
    var global_utils_1 = require_global_utils2();
    var MetricsAPI = function() {
      function MetricsAPI2() {
      }
      MetricsAPI2.getInstance = function() {
        if (!this._instance) {
          this._instance = new MetricsAPI2();
        }
        return this._instance;
      };
      MetricsAPI2.prototype.setGlobalMeterProvider = function(provider) {
        if (global_utils_1._global[global_utils_1.GLOBAL_METRICS_API_KEY]) {
          return this.getMeterProvider();
        }
        global_utils_1._global[global_utils_1.GLOBAL_METRICS_API_KEY] = global_utils_1.makeGetter(global_utils_1.API_BACKWARDS_COMPATIBILITY_VERSION, provider, NoopMeterProvider_1.NOOP_METER_PROVIDER);
        return provider;
      };
      MetricsAPI2.prototype.getMeterProvider = function() {
        var _a, _b;
        return (_b = (_a = global_utils_1._global[global_utils_1.GLOBAL_METRICS_API_KEY]) === null || _a === void 0 ? void 0 : _a.call(global_utils_1._global, global_utils_1.API_BACKWARDS_COMPATIBILITY_VERSION)) !== null && _b !== void 0 ? _b : NoopMeterProvider_1.NOOP_METER_PROVIDER;
      };
      MetricsAPI2.prototype.getMeter = function(name, version, options) {
        return this.getMeterProvider().getMeter(name, version, options);
      };
      MetricsAPI2.prototype.disable = function() {
        delete global_utils_1._global[global_utils_1.GLOBAL_METRICS_API_KEY];
      };
      return MetricsAPI2;
    }();
    exports2.MetricsAPI = MetricsAPI;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/index.js
var require_src10 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/api-metrics/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.metrics = void 0;
    __exportStar(require_NoopMeter(), exports2);
    __exportStar(require_NoopMeterProvider(), exports2);
    __exportStar(require_Meter(), exports2);
    __exportStar(require_MeterProvider(), exports2);
    __exportStar(require_Metric(), exports2);
    __exportStar(require_Observation(), exports2);
    __exportStar(require_ObservableResult(), exports2);
    var metrics_1 = require_metrics();
    exports2.metrics = metrics_1.MetricsAPI.getInstance();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/autoLoaderUtils.js
var require_autoLoaderUtils = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/autoLoaderUtils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.disableInstrumentations = exports2.enableInstrumentations = exports2.parseInstrumentationOptions = void 0;
    function parseInstrumentationOptions(options = []) {
      let instrumentations = [];
      for (let i = 0, j = options.length; i < j; i++) {
        const option = options[i];
        if (Array.isArray(option)) {
          const results = parseInstrumentationOptions(option);
          instrumentations = instrumentations.concat(results.instrumentations);
        } else if (typeof option === "function") {
          instrumentations.push(new option());
        } else if (option.instrumentationName) {
          instrumentations.push(option);
        }
      }
      return { instrumentations };
    }
    exports2.parseInstrumentationOptions = parseInstrumentationOptions;
    function enableInstrumentations(instrumentations, tracerProvider2, meterProvider) {
      for (let i = 0, j = instrumentations.length; i < j; i++) {
        const instrumentation = instrumentations[i];
        if (tracerProvider2) {
          instrumentation.setTracerProvider(tracerProvider2);
        }
        if (meterProvider) {
          instrumentation.setMeterProvider(meterProvider);
        }
        if (!instrumentation.getConfig().enabled) {
          instrumentation.enable();
        }
      }
    }
    exports2.enableInstrumentations = enableInstrumentations;
    function disableInstrumentations(instrumentations) {
      instrumentations.forEach((instrumentation) => instrumentation.disable());
    }
    exports2.disableInstrumentations = disableInstrumentations;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/autoLoader.js
var require_autoLoader = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/autoLoader.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.registerInstrumentations = void 0;
    var api_1 = require_src();
    var api_metrics_1 = require_src10();
    var autoLoaderUtils_1 = require_autoLoaderUtils();
    function registerInstrumentations2(options) {
      const { instrumentations } = autoLoaderUtils_1.parseInstrumentationOptions(options.instrumentations);
      const tracerProvider2 = options.tracerProvider || api_1.trace.getTracerProvider();
      const meterProvider = options.meterProvider || api_metrics_1.metrics.getMeterProvider();
      autoLoaderUtils_1.enableInstrumentations(instrumentations, tracerProvider2, meterProvider);
      return () => {
        autoLoaderUtils_1.disableInstrumentations(instrumentations);
      };
    }
    exports2.registerInstrumentations = registerInstrumentations2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/homedir.js
var require_homedir = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/homedir.js"(exports2, module2) {
    "use strict";
    var os = require("os");
    module2.exports = os.homedir || function homedir() {
      var home = process.env.HOME;
      var user = process.env.LOGNAME || process.env.USER || process.env.LNAME || process.env.USERNAME;
      if (process.platform === "win32") {
        return process.env.USERPROFILE || process.env.HOMEDRIVE + process.env.HOMEPATH || home || null;
      }
      if (process.platform === "darwin") {
        return home || (user ? "/Users/" + user : null);
      }
      if (process.platform === "linux") {
        return home || (process.getuid() === 0 ? "/root" : user ? "/home/" + user : null);
      }
      return home || null;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/caller.js
var require_caller = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/caller.js"(exports2, module2) {
    module2.exports = function() {
      var origPrepareStackTrace = Error.prepareStackTrace;
      Error.prepareStackTrace = function(_, stack2) {
        return stack2;
      };
      var stack = new Error().stack;
      Error.prepareStackTrace = origPrepareStackTrace;
      return stack[2].getFileName();
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/path-parse/index.js
var require_path_parse = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/path-parse/index.js"(exports2, module2) {
    "use strict";
    var isWindows = process.platform === "win32";
    var splitWindowsRe = /^(((?:[a-zA-Z]:|[\\\/]{2}[^\\\/]+[\\\/]+[^\\\/]+)?[\\\/]?)(?:[^\\\/]*[\\\/])*)((\.{1,2}|[^\\\/]+?|)(\.[^.\/\\]*|))[\\\/]*$/;
    var win32 = {};
    function win32SplitPath(filename) {
      return splitWindowsRe.exec(filename).slice(1);
    }
    win32.parse = function(pathString) {
      if (typeof pathString !== "string") {
        throw new TypeError("Parameter 'pathString' must be a string, not " + typeof pathString);
      }
      var allParts = win32SplitPath(pathString);
      if (!allParts || allParts.length !== 5) {
        throw new TypeError("Invalid path '" + pathString + "'");
      }
      return {
        root: allParts[1],
        dir: allParts[0] === allParts[1] ? allParts[0] : allParts[0].slice(0, -1),
        base: allParts[2],
        ext: allParts[4],
        name: allParts[3]
      };
    };
    var splitPathRe = /^((\/?)(?:[^\/]*\/)*)((\.{1,2}|[^\/]+?|)(\.[^.\/]*|))[\/]*$/;
    var posix = {};
    function posixSplitPath(filename) {
      return splitPathRe.exec(filename).slice(1);
    }
    posix.parse = function(pathString) {
      if (typeof pathString !== "string") {
        throw new TypeError("Parameter 'pathString' must be a string, not " + typeof pathString);
      }
      var allParts = posixSplitPath(pathString);
      if (!allParts || allParts.length !== 5) {
        throw new TypeError("Invalid path '" + pathString + "'");
      }
      return {
        root: allParts[1],
        dir: allParts[0].slice(0, -1),
        base: allParts[2],
        ext: allParts[4],
        name: allParts[3]
      };
    };
    if (isWindows)
      module2.exports = win32.parse;
    else
      module2.exports = posix.parse;
    module2.exports.posix = posix.parse;
    module2.exports.win32 = win32.parse;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/node-modules-paths.js
var require_node_modules_paths = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/node-modules-paths.js"(exports2, module2) {
    var path = require("path");
    var parse = path.parse || require_path_parse();
    var getNodeModulesDirs = function getNodeModulesDirs2(absoluteStart, modules) {
      var prefix = "/";
      if (/^([A-Za-z]:)/.test(absoluteStart)) {
        prefix = "";
      } else if (/^\\\\/.test(absoluteStart)) {
        prefix = "\\\\";
      }
      var paths = [absoluteStart];
      var parsed = parse(absoluteStart);
      while (parsed.dir !== paths[paths.length - 1]) {
        paths.push(parsed.dir);
        parsed = parse(parsed.dir);
      }
      return paths.reduce(function(dirs, aPath) {
        return dirs.concat(modules.map(function(moduleDir) {
          return path.resolve(prefix, aPath, moduleDir);
        }));
      }, []);
    };
    module2.exports = function nodeModulesPaths(start, opts, request) {
      var modules = opts && opts.moduleDirectory ? [].concat(opts.moduleDirectory) : ["node_modules"];
      if (opts && typeof opts.paths === "function") {
        return opts.paths(request, start, function() {
          return getNodeModulesDirs(start, modules);
        }, opts);
      }
      var dirs = getNodeModulesDirs(start, modules);
      return opts && opts.paths ? dirs.concat(opts.paths) : dirs;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/normalize-options.js
var require_normalize_options = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/normalize-options.js"(exports2, module2) {
    module2.exports = function(x, opts) {
      return opts || {};
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/function-bind/implementation.js
var require_implementation = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/function-bind/implementation.js"(exports2, module2) {
    "use strict";
    var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
    var slice = Array.prototype.slice;
    var toStr = Object.prototype.toString;
    var funcType = "[object Function]";
    module2.exports = function bind(that) {
      var target = this;
      if (typeof target !== "function" || toStr.call(target) !== funcType) {
        throw new TypeError(ERROR_MESSAGE + target);
      }
      var args = slice.call(arguments, 1);
      var bound;
      var binder = function() {
        if (this instanceof bound) {
          var result = target.apply(this, args.concat(slice.call(arguments)));
          if (Object(result) === result) {
            return result;
          }
          return this;
        } else {
          return target.apply(that, args.concat(slice.call(arguments)));
        }
      };
      var boundLength = Math.max(0, target.length - args.length);
      var boundArgs = [];
      for (var i = 0; i < boundLength; i++) {
        boundArgs.push("$" + i);
      }
      bound = Function("binder", "return function (" + boundArgs.join(",") + "){ return binder.apply(this,arguments); }")(binder);
      if (target.prototype) {
        var Empty = function Empty2() {
        };
        Empty.prototype = target.prototype;
        bound.prototype = new Empty();
        Empty.prototype = null;
      }
      return bound;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/function-bind/index.js
var require_function_bind = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/function-bind/index.js"(exports2, module2) {
    "use strict";
    var implementation = require_implementation();
    module2.exports = Function.prototype.bind || implementation;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/has/src/index.js
var require_src11 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/has/src/index.js"(exports2, module2) {
    "use strict";
    var bind = require_function_bind();
    module2.exports = bind.call(Function.call, Object.prototype.hasOwnProperty);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/is-core-module/core.json
var require_core = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/is-core-module/core.json"(exports2, module2) {
    module2.exports = {
      assert: true,
      "node:assert": [">= 14.18 && < 15", ">= 16"],
      "assert/strict": ">= 15",
      "node:assert/strict": ">= 16",
      async_hooks: ">= 8",
      "node:async_hooks": [">= 14.18 && < 15", ">= 16"],
      buffer_ieee754: ">= 0.5 && < 0.9.7",
      buffer: true,
      "node:buffer": [">= 14.18 && < 15", ">= 16"],
      child_process: true,
      "node:child_process": [">= 14.18 && < 15", ">= 16"],
      cluster: ">= 0.5",
      "node:cluster": [">= 14.18 && < 15", ">= 16"],
      console: true,
      "node:console": [">= 14.18 && < 15", ">= 16"],
      constants: true,
      "node:constants": [">= 14.18 && < 15", ">= 16"],
      crypto: true,
      "node:crypto": [">= 14.18 && < 15", ">= 16"],
      _debug_agent: ">= 1 && < 8",
      _debugger: "< 8",
      dgram: true,
      "node:dgram": [">= 14.18 && < 15", ">= 16"],
      diagnostics_channel: [">= 14.17 && < 15", ">= 15.1"],
      "node:diagnostics_channel": [">= 14.18 && < 15", ">= 16"],
      dns: true,
      "node:dns": [">= 14.18 && < 15", ">= 16"],
      "dns/promises": ">= 15",
      "node:dns/promises": ">= 16",
      domain: ">= 0.7.12",
      "node:domain": [">= 14.18 && < 15", ">= 16"],
      events: true,
      "node:events": [">= 14.18 && < 15", ">= 16"],
      freelist: "< 6",
      fs: true,
      "node:fs": [">= 14.18 && < 15", ">= 16"],
      "fs/promises": [">= 10 && < 10.1", ">= 14"],
      "node:fs/promises": [">= 14.18 && < 15", ">= 16"],
      _http_agent: ">= 0.11.1",
      "node:_http_agent": [">= 14.18 && < 15", ">= 16"],
      _http_client: ">= 0.11.1",
      "node:_http_client": [">= 14.18 && < 15", ">= 16"],
      _http_common: ">= 0.11.1",
      "node:_http_common": [">= 14.18 && < 15", ">= 16"],
      _http_incoming: ">= 0.11.1",
      "node:_http_incoming": [">= 14.18 && < 15", ">= 16"],
      _http_outgoing: ">= 0.11.1",
      "node:_http_outgoing": [">= 14.18 && < 15", ">= 16"],
      _http_server: ">= 0.11.1",
      "node:_http_server": [">= 14.18 && < 15", ">= 16"],
      http: true,
      "node:http": [">= 14.18 && < 15", ">= 16"],
      http2: ">= 8.8",
      "node:http2": [">= 14.18 && < 15", ">= 16"],
      https: true,
      "node:https": [">= 14.18 && < 15", ">= 16"],
      inspector: ">= 8",
      "node:inspector": [">= 14.18 && < 15", ">= 16"],
      _linklist: "< 8",
      module: true,
      "node:module": [">= 14.18 && < 15", ">= 16"],
      net: true,
      "node:net": [">= 14.18 && < 15", ">= 16"],
      "node-inspect/lib/_inspect": ">= 7.6 && < 12",
      "node-inspect/lib/internal/inspect_client": ">= 7.6 && < 12",
      "node-inspect/lib/internal/inspect_repl": ">= 7.6 && < 12",
      os: true,
      "node:os": [">= 14.18 && < 15", ">= 16"],
      path: true,
      "node:path": [">= 14.18 && < 15", ">= 16"],
      "path/posix": ">= 15.3",
      "node:path/posix": ">= 16",
      "path/win32": ">= 15.3",
      "node:path/win32": ">= 16",
      perf_hooks: ">= 8.5",
      "node:perf_hooks": [">= 14.18 && < 15", ">= 16"],
      process: ">= 1",
      "node:process": [">= 14.18 && < 15", ">= 16"],
      punycode: ">= 0.5",
      "node:punycode": [">= 14.18 && < 15", ">= 16"],
      querystring: true,
      "node:querystring": [">= 14.18 && < 15", ">= 16"],
      readline: true,
      "node:readline": [">= 14.18 && < 15", ">= 16"],
      "readline/promises": ">= 17",
      "node:readline/promises": ">= 17",
      repl: true,
      "node:repl": [">= 14.18 && < 15", ">= 16"],
      smalloc: ">= 0.11.5 && < 3",
      _stream_duplex: ">= 0.9.4",
      "node:_stream_duplex": [">= 14.18 && < 15", ">= 16"],
      _stream_transform: ">= 0.9.4",
      "node:_stream_transform": [">= 14.18 && < 15", ">= 16"],
      _stream_wrap: ">= 1.4.1",
      "node:_stream_wrap": [">= 14.18 && < 15", ">= 16"],
      _stream_passthrough: ">= 0.9.4",
      "node:_stream_passthrough": [">= 14.18 && < 15", ">= 16"],
      _stream_readable: ">= 0.9.4",
      "node:_stream_readable": [">= 14.18 && < 15", ">= 16"],
      _stream_writable: ">= 0.9.4",
      "node:_stream_writable": [">= 14.18 && < 15", ">= 16"],
      stream: true,
      "node:stream": [">= 14.18 && < 15", ">= 16"],
      "stream/consumers": ">= 16.7",
      "node:stream/consumers": ">= 16.7",
      "stream/promises": ">= 15",
      "node:stream/promises": ">= 16",
      "stream/web": ">= 16.5",
      "node:stream/web": ">= 16.5",
      string_decoder: true,
      "node:string_decoder": [">= 14.18 && < 15", ">= 16"],
      sys: [">= 0.4 && < 0.7", ">= 0.8"],
      "node:sys": [">= 14.18 && < 15", ">= 16"],
      "node:test": ">= 18",
      timers: true,
      "node:timers": [">= 14.18 && < 15", ">= 16"],
      "timers/promises": ">= 15",
      "node:timers/promises": ">= 16",
      _tls_common: ">= 0.11.13",
      "node:_tls_common": [">= 14.18 && < 15", ">= 16"],
      _tls_legacy: ">= 0.11.3 && < 10",
      _tls_wrap: ">= 0.11.3",
      "node:_tls_wrap": [">= 14.18 && < 15", ">= 16"],
      tls: true,
      "node:tls": [">= 14.18 && < 15", ">= 16"],
      trace_events: ">= 10",
      "node:trace_events": [">= 14.18 && < 15", ">= 16"],
      tty: true,
      "node:tty": [">= 14.18 && < 15", ">= 16"],
      url: true,
      "node:url": [">= 14.18 && < 15", ">= 16"],
      util: true,
      "node:util": [">= 14.18 && < 15", ">= 16"],
      "util/types": ">= 15.3",
      "node:util/types": ">= 16",
      "v8/tools/arguments": ">= 10 && < 12",
      "v8/tools/codemap": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/consarray": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/csvparser": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/logreader": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/profile_view": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/splaytree": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      v8: ">= 1",
      "node:v8": [">= 14.18 && < 15", ">= 16"],
      vm: true,
      "node:vm": [">= 14.18 && < 15", ">= 16"],
      wasi: ">= 13.4 && < 13.5",
      worker_threads: ">= 11.7",
      "node:worker_threads": [">= 14.18 && < 15", ">= 16"],
      zlib: ">= 0.5",
      "node:zlib": [">= 14.18 && < 15", ">= 16"]
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/is-core-module/index.js
var require_is_core_module = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/is-core-module/index.js"(exports2, module2) {
    "use strict";
    var has = require_src11();
    function specifierIncluded(current, specifier) {
      var nodeParts = current.split(".");
      var parts = specifier.split(" ");
      var op = parts.length > 1 ? parts[0] : "=";
      var versionParts = (parts.length > 1 ? parts[1] : parts[0]).split(".");
      for (var i = 0; i < 3; ++i) {
        var cur = parseInt(nodeParts[i] || 0, 10);
        var ver = parseInt(versionParts[i] || 0, 10);
        if (cur === ver) {
          continue;
        }
        if (op === "<") {
          return cur < ver;
        }
        if (op === ">=") {
          return cur >= ver;
        }
        return false;
      }
      return op === ">=";
    }
    function matchesRange(current, range) {
      var specifiers = range.split(/ ?&& ?/);
      if (specifiers.length === 0) {
        return false;
      }
      for (var i = 0; i < specifiers.length; ++i) {
        if (!specifierIncluded(current, specifiers[i])) {
          return false;
        }
      }
      return true;
    }
    function versionIncluded(nodeVersion, specifierValue) {
      if (typeof specifierValue === "boolean") {
        return specifierValue;
      }
      var current = typeof nodeVersion === "undefined" ? process.versions && process.versions.node : nodeVersion;
      if (typeof current !== "string") {
        throw new TypeError(typeof nodeVersion === "undefined" ? "Unable to determine current node version" : "If provided, a valid node version is required");
      }
      if (specifierValue && typeof specifierValue === "object") {
        for (var i = 0; i < specifierValue.length; ++i) {
          if (matchesRange(current, specifierValue[i])) {
            return true;
          }
        }
        return false;
      }
      return matchesRange(current, specifierValue);
    }
    var data = require_core();
    module2.exports = function isCore(x, nodeVersion) {
      return has(data, x) && versionIncluded(nodeVersion, data[x]);
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/async.js
var require_async = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/async.js"(exports2, module2) {
    var fs = require("fs");
    var getHomedir = require_homedir();
    var path = require("path");
    var caller = require_caller();
    var nodeModulesPaths = require_node_modules_paths();
    var normalizeOptions = require_normalize_options();
    var isCore = require_is_core_module();
    var realpathFS = process.platform !== "win32" && fs.realpath && typeof fs.realpath.native === "function" ? fs.realpath.native : fs.realpath;
    var homedir = getHomedir();
    var defaultPaths = function() {
      return [
        path.join(homedir, ".node_modules"),
        path.join(homedir, ".node_libraries")
      ];
    };
    var defaultIsFile = function isFile(file, cb) {
      fs.stat(file, function(err, stat) {
        if (!err) {
          return cb(null, stat.isFile() || stat.isFIFO());
        }
        if (err.code === "ENOENT" || err.code === "ENOTDIR")
          return cb(null, false);
        return cb(err);
      });
    };
    var defaultIsDir = function isDirectory(dir, cb) {
      fs.stat(dir, function(err, stat) {
        if (!err) {
          return cb(null, stat.isDirectory());
        }
        if (err.code === "ENOENT" || err.code === "ENOTDIR")
          return cb(null, false);
        return cb(err);
      });
    };
    var defaultRealpath = function realpath(x, cb) {
      realpathFS(x, function(realpathErr, realPath) {
        if (realpathErr && realpathErr.code !== "ENOENT")
          cb(realpathErr);
        else
          cb(null, realpathErr ? x : realPath);
      });
    };
    var maybeRealpath = function maybeRealpath2(realpath, x, opts, cb) {
      if (opts && opts.preserveSymlinks === false) {
        realpath(x, cb);
      } else {
        cb(null, x);
      }
    };
    var defaultReadPackage = function defaultReadPackage2(readFile, pkgfile, cb) {
      readFile(pkgfile, function(readFileErr, body) {
        if (readFileErr)
          cb(readFileErr);
        else {
          try {
            var pkg = JSON.parse(body);
            cb(null, pkg);
          } catch (jsonErr) {
            cb(null);
          }
        }
      });
    };
    var getPackageCandidates = function getPackageCandidates2(x, start, opts) {
      var dirs = nodeModulesPaths(start, opts, x);
      for (var i = 0; i < dirs.length; i++) {
        dirs[i] = path.join(dirs[i], x);
      }
      return dirs;
    };
    module2.exports = function resolve(x, options, callback) {
      var cb = callback;
      var opts = options;
      if (typeof options === "function") {
        cb = opts;
        opts = {};
      }
      if (typeof x !== "string") {
        var err = new TypeError("Path must be a string.");
        return process.nextTick(function() {
          cb(err);
        });
      }
      opts = normalizeOptions(x, opts);
      var isFile = opts.isFile || defaultIsFile;
      var isDirectory = opts.isDirectory || defaultIsDir;
      var readFile = opts.readFile || fs.readFile;
      var realpath = opts.realpath || defaultRealpath;
      var readPackage = opts.readPackage || defaultReadPackage;
      if (opts.readFile && opts.readPackage) {
        var conflictErr = new TypeError("`readFile` and `readPackage` are mutually exclusive.");
        return process.nextTick(function() {
          cb(conflictErr);
        });
      }
      var packageIterator = opts.packageIterator;
      var extensions = opts.extensions || [".js"];
      var includeCoreModules = opts.includeCoreModules !== false;
      var basedir = opts.basedir || path.dirname(caller());
      var parent = opts.filename || basedir;
      opts.paths = opts.paths || defaultPaths();
      var absoluteStart = path.resolve(basedir);
      maybeRealpath(realpath, absoluteStart, opts, function(err2, realStart) {
        if (err2)
          cb(err2);
        else
          init(realStart);
      });
      var res;
      function init(basedir2) {
        if (/^(?:\.\.?(?:\/|$)|\/|([A-Za-z]:)?[/\\])/.test(x)) {
          res = path.resolve(basedir2, x);
          if (x === "." || x === ".." || x.slice(-1) === "/")
            res += "/";
          if (/\/$/.test(x) && res === basedir2) {
            loadAsDirectory(res, opts.package, onfile);
          } else
            loadAsFile(res, opts.package, onfile);
        } else if (includeCoreModules && isCore(x)) {
          return cb(null, x);
        } else
          loadNodeModules(x, basedir2, function(err2, n, pkg) {
            if (err2)
              cb(err2);
            else if (n) {
              return maybeRealpath(realpath, n, opts, function(err3, realN) {
                if (err3) {
                  cb(err3);
                } else {
                  cb(null, realN, pkg);
                }
              });
            } else {
              var moduleError = new Error("Cannot find module '" + x + "' from '" + parent + "'");
              moduleError.code = "MODULE_NOT_FOUND";
              cb(moduleError);
            }
          });
      }
      function onfile(err2, m, pkg) {
        if (err2)
          cb(err2);
        else if (m)
          cb(null, m, pkg);
        else
          loadAsDirectory(res, function(err3, d, pkg2) {
            if (err3)
              cb(err3);
            else if (d) {
              maybeRealpath(realpath, d, opts, function(err4, realD) {
                if (err4) {
                  cb(err4);
                } else {
                  cb(null, realD, pkg2);
                }
              });
            } else {
              var moduleError = new Error("Cannot find module '" + x + "' from '" + parent + "'");
              moduleError.code = "MODULE_NOT_FOUND";
              cb(moduleError);
            }
          });
      }
      function loadAsFile(x2, thePackage, callback2) {
        var loadAsFilePackage = thePackage;
        var cb2 = callback2;
        if (typeof loadAsFilePackage === "function") {
          cb2 = loadAsFilePackage;
          loadAsFilePackage = void 0;
        }
        var exts = [""].concat(extensions);
        load(exts, x2, loadAsFilePackage);
        function load(exts2, x3, loadPackage) {
          if (exts2.length === 0)
            return cb2(null, void 0, loadPackage);
          var file = x3 + exts2[0];
          var pkg = loadPackage;
          if (pkg)
            onpkg(null, pkg);
          else
            loadpkg(path.dirname(file), onpkg);
          function onpkg(err2, pkg_, dir) {
            pkg = pkg_;
            if (err2)
              return cb2(err2);
            if (dir && pkg && opts.pathFilter) {
              var rfile = path.relative(dir, file);
              var rel = rfile.slice(0, rfile.length - exts2[0].length);
              var r = opts.pathFilter(pkg, x3, rel);
              if (r)
                return load([""].concat(extensions.slice()), path.resolve(dir, r), pkg);
            }
            isFile(file, onex);
          }
          function onex(err2, ex) {
            if (err2)
              return cb2(err2);
            if (ex)
              return cb2(null, file, pkg);
            load(exts2.slice(1), x3, pkg);
          }
        }
      }
      function loadpkg(dir, cb2) {
        if (dir === "" || dir === "/")
          return cb2(null);
        if (process.platform === "win32" && /^\w:[/\\]*$/.test(dir)) {
          return cb2(null);
        }
        if (/[/\\]node_modules[/\\]*$/.test(dir))
          return cb2(null);
        maybeRealpath(realpath, dir, opts, function(unwrapErr, pkgdir) {
          if (unwrapErr)
            return loadpkg(path.dirname(dir), cb2);
          var pkgfile = path.join(pkgdir, "package.json");
          isFile(pkgfile, function(err2, ex) {
            if (!ex)
              return loadpkg(path.dirname(dir), cb2);
            readPackage(readFile, pkgfile, function(err3, pkgParam) {
              if (err3)
                cb2(err3);
              var pkg = pkgParam;
              if (pkg && opts.packageFilter) {
                pkg = opts.packageFilter(pkg, pkgfile);
              }
              cb2(null, pkg, dir);
            });
          });
        });
      }
      function loadAsDirectory(x2, loadAsDirectoryPackage, callback2) {
        var cb2 = callback2;
        var fpkg = loadAsDirectoryPackage;
        if (typeof fpkg === "function") {
          cb2 = fpkg;
          fpkg = opts.package;
        }
        maybeRealpath(realpath, x2, opts, function(unwrapErr, pkgdir) {
          if (unwrapErr)
            return cb2(unwrapErr);
          var pkgfile = path.join(pkgdir, "package.json");
          isFile(pkgfile, function(err2, ex) {
            if (err2)
              return cb2(err2);
            if (!ex)
              return loadAsFile(path.join(x2, "index"), fpkg, cb2);
            readPackage(readFile, pkgfile, function(err3, pkgParam) {
              if (err3)
                return cb2(err3);
              var pkg = pkgParam;
              if (pkg && opts.packageFilter) {
                pkg = opts.packageFilter(pkg, pkgfile);
              }
              if (pkg && pkg.main) {
                if (typeof pkg.main !== "string") {
                  var mainError = new TypeError("package \u201C" + pkg.name + "\u201D `main` must be a string");
                  mainError.code = "INVALID_PACKAGE_MAIN";
                  return cb2(mainError);
                }
                if (pkg.main === "." || pkg.main === "./") {
                  pkg.main = "index";
                }
                loadAsFile(path.resolve(x2, pkg.main), pkg, function(err4, m, pkg2) {
                  if (err4)
                    return cb2(err4);
                  if (m)
                    return cb2(null, m, pkg2);
                  if (!pkg2)
                    return loadAsFile(path.join(x2, "index"), pkg2, cb2);
                  var dir = path.resolve(x2, pkg2.main);
                  loadAsDirectory(dir, pkg2, function(err5, n, pkg3) {
                    if (err5)
                      return cb2(err5);
                    if (n)
                      return cb2(null, n, pkg3);
                    loadAsFile(path.join(x2, "index"), pkg3, cb2);
                  });
                });
                return;
              }
              loadAsFile(path.join(x2, "/index"), pkg, cb2);
            });
          });
        });
      }
      function processDirs(cb2, dirs) {
        if (dirs.length === 0)
          return cb2(null, void 0);
        var dir = dirs[0];
        isDirectory(path.dirname(dir), isdir);
        function isdir(err2, isdir2) {
          if (err2)
            return cb2(err2);
          if (!isdir2)
            return processDirs(cb2, dirs.slice(1));
          loadAsFile(dir, opts.package, onfile2);
        }
        function onfile2(err2, m, pkg) {
          if (err2)
            return cb2(err2);
          if (m)
            return cb2(null, m, pkg);
          loadAsDirectory(dir, opts.package, ondir);
        }
        function ondir(err2, n, pkg) {
          if (err2)
            return cb2(err2);
          if (n)
            return cb2(null, n, pkg);
          processDirs(cb2, dirs.slice(1));
        }
      }
      function loadNodeModules(x2, start, cb2) {
        var thunk = function() {
          return getPackageCandidates(x2, start, opts);
        };
        processDirs(cb2, packageIterator ? packageIterator(x2, start, thunk, opts) : thunk());
      }
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/core.json
var require_core2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/core.json"(exports2, module2) {
    module2.exports = {
      assert: true,
      "node:assert": [">= 14.18 && < 15", ">= 16"],
      "assert/strict": ">= 15",
      "node:assert/strict": ">= 16",
      async_hooks: ">= 8",
      "node:async_hooks": [">= 14.18 && < 15", ">= 16"],
      buffer_ieee754: ">= 0.5 && < 0.9.7",
      buffer: true,
      "node:buffer": [">= 14.18 && < 15", ">= 16"],
      child_process: true,
      "node:child_process": [">= 14.18 && < 15", ">= 16"],
      cluster: ">= 0.5",
      "node:cluster": [">= 14.18 && < 15", ">= 16"],
      console: true,
      "node:console": [">= 14.18 && < 15", ">= 16"],
      constants: true,
      "node:constants": [">= 14.18 && < 15", ">= 16"],
      crypto: true,
      "node:crypto": [">= 14.18 && < 15", ">= 16"],
      _debug_agent: ">= 1 && < 8",
      _debugger: "< 8",
      dgram: true,
      "node:dgram": [">= 14.18 && < 15", ">= 16"],
      diagnostics_channel: [">= 14.17 && < 15", ">= 15.1"],
      "node:diagnostics_channel": [">= 14.18 && < 15", ">= 16"],
      dns: true,
      "node:dns": [">= 14.18 && < 15", ">= 16"],
      "dns/promises": ">= 15",
      "node:dns/promises": ">= 16",
      domain: ">= 0.7.12",
      "node:domain": [">= 14.18 && < 15", ">= 16"],
      events: true,
      "node:events": [">= 14.18 && < 15", ">= 16"],
      freelist: "< 6",
      fs: true,
      "node:fs": [">= 14.18 && < 15", ">= 16"],
      "fs/promises": [">= 10 && < 10.1", ">= 14"],
      "node:fs/promises": [">= 14.18 && < 15", ">= 16"],
      _http_agent: ">= 0.11.1",
      "node:_http_agent": [">= 14.18 && < 15", ">= 16"],
      _http_client: ">= 0.11.1",
      "node:_http_client": [">= 14.18 && < 15", ">= 16"],
      _http_common: ">= 0.11.1",
      "node:_http_common": [">= 14.18 && < 15", ">= 16"],
      _http_incoming: ">= 0.11.1",
      "node:_http_incoming": [">= 14.18 && < 15", ">= 16"],
      _http_outgoing: ">= 0.11.1",
      "node:_http_outgoing": [">= 14.18 && < 15", ">= 16"],
      _http_server: ">= 0.11.1",
      "node:_http_server": [">= 14.18 && < 15", ">= 16"],
      http: true,
      "node:http": [">= 14.18 && < 15", ">= 16"],
      http2: ">= 8.8",
      "node:http2": [">= 14.18 && < 15", ">= 16"],
      https: true,
      "node:https": [">= 14.18 && < 15", ">= 16"],
      inspector: ">= 8",
      "node:inspector": [">= 14.18 && < 15", ">= 16"],
      _linklist: "< 8",
      module: true,
      "node:module": [">= 14.18 && < 15", ">= 16"],
      net: true,
      "node:net": [">= 14.18 && < 15", ">= 16"],
      "node-inspect/lib/_inspect": ">= 7.6 && < 12",
      "node-inspect/lib/internal/inspect_client": ">= 7.6 && < 12",
      "node-inspect/lib/internal/inspect_repl": ">= 7.6 && < 12",
      os: true,
      "node:os": [">= 14.18 && < 15", ">= 16"],
      path: true,
      "node:path": [">= 14.18 && < 15", ">= 16"],
      "path/posix": ">= 15.3",
      "node:path/posix": ">= 16",
      "path/win32": ">= 15.3",
      "node:path/win32": ">= 16",
      perf_hooks: ">= 8.5",
      "node:perf_hooks": [">= 14.18 && < 15", ">= 16"],
      process: ">= 1",
      "node:process": [">= 14.18 && < 15", ">= 16"],
      punycode: ">= 0.5",
      "node:punycode": [">= 14.18 && < 15", ">= 16"],
      querystring: true,
      "node:querystring": [">= 14.18 && < 15", ">= 16"],
      readline: true,
      "node:readline": [">= 14.18 && < 15", ">= 16"],
      "readline/promises": ">= 17",
      "node:readline/promises": ">= 17",
      repl: true,
      "node:repl": [">= 14.18 && < 15", ">= 16"],
      smalloc: ">= 0.11.5 && < 3",
      _stream_duplex: ">= 0.9.4",
      "node:_stream_duplex": [">= 14.18 && < 15", ">= 16"],
      _stream_transform: ">= 0.9.4",
      "node:_stream_transform": [">= 14.18 && < 15", ">= 16"],
      _stream_wrap: ">= 1.4.1",
      "node:_stream_wrap": [">= 14.18 && < 15", ">= 16"],
      _stream_passthrough: ">= 0.9.4",
      "node:_stream_passthrough": [">= 14.18 && < 15", ">= 16"],
      _stream_readable: ">= 0.9.4",
      "node:_stream_readable": [">= 14.18 && < 15", ">= 16"],
      _stream_writable: ">= 0.9.4",
      "node:_stream_writable": [">= 14.18 && < 15", ">= 16"],
      stream: true,
      "node:stream": [">= 14.18 && < 15", ">= 16"],
      "stream/consumers": ">= 16.7",
      "node:stream/consumers": ">= 16.7",
      "stream/promises": ">= 15",
      "node:stream/promises": ">= 16",
      "stream/web": ">= 16.5",
      "node:stream/web": ">= 16.5",
      string_decoder: true,
      "node:string_decoder": [">= 14.18 && < 15", ">= 16"],
      sys: [">= 0.4 && < 0.7", ">= 0.8"],
      "node:sys": [">= 14.18 && < 15", ">= 16"],
      "node:test": ">= 18",
      timers: true,
      "node:timers": [">= 14.18 && < 15", ">= 16"],
      "timers/promises": ">= 15",
      "node:timers/promises": ">= 16",
      _tls_common: ">= 0.11.13",
      "node:_tls_common": [">= 14.18 && < 15", ">= 16"],
      _tls_legacy: ">= 0.11.3 && < 10",
      _tls_wrap: ">= 0.11.3",
      "node:_tls_wrap": [">= 14.18 && < 15", ">= 16"],
      tls: true,
      "node:tls": [">= 14.18 && < 15", ">= 16"],
      trace_events: ">= 10",
      "node:trace_events": [">= 14.18 && < 15", ">= 16"],
      tty: true,
      "node:tty": [">= 14.18 && < 15", ">= 16"],
      url: true,
      "node:url": [">= 14.18 && < 15", ">= 16"],
      util: true,
      "node:util": [">= 14.18 && < 15", ">= 16"],
      "util/types": ">= 15.3",
      "node:util/types": ">= 16",
      "v8/tools/arguments": ">= 10 && < 12",
      "v8/tools/codemap": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/consarray": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/csvparser": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/logreader": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/profile_view": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      "v8/tools/splaytree": [">= 4.4 && < 5", ">= 5.2 && < 12"],
      v8: ">= 1",
      "node:v8": [">= 14.18 && < 15", ">= 16"],
      vm: true,
      "node:vm": [">= 14.18 && < 15", ">= 16"],
      wasi: ">= 13.4 && < 13.5",
      worker_threads: ">= 11.7",
      "node:worker_threads": [">= 14.18 && < 15", ">= 16"],
      zlib: ">= 0.5",
      "node:zlib": [">= 14.18 && < 15", ">= 16"]
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/core.js
var require_core3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/core.js"(exports2, module2) {
    var current = process.versions && process.versions.node && process.versions.node.split(".") || [];
    function specifierIncluded(specifier) {
      var parts = specifier.split(" ");
      var op = parts.length > 1 ? parts[0] : "=";
      var versionParts = (parts.length > 1 ? parts[1] : parts[0]).split(".");
      for (var i = 0; i < 3; ++i) {
        var cur = parseInt(current[i] || 0, 10);
        var ver = parseInt(versionParts[i] || 0, 10);
        if (cur === ver) {
          continue;
        }
        if (op === "<") {
          return cur < ver;
        } else if (op === ">=") {
          return cur >= ver;
        }
        return false;
      }
      return op === ">=";
    }
    function matchesRange(range) {
      var specifiers = range.split(/ ?&& ?/);
      if (specifiers.length === 0) {
        return false;
      }
      for (var i = 0; i < specifiers.length; ++i) {
        if (!specifierIncluded(specifiers[i])) {
          return false;
        }
      }
      return true;
    }
    function versionIncluded(specifierValue) {
      if (typeof specifierValue === "boolean") {
        return specifierValue;
      }
      if (specifierValue && typeof specifierValue === "object") {
        for (var i = 0; i < specifierValue.length; ++i) {
          if (matchesRange(specifierValue[i])) {
            return true;
          }
        }
        return false;
      }
      return matchesRange(specifierValue);
    }
    var data = require_core2();
    var core = {};
    for (mod in data) {
      if (Object.prototype.hasOwnProperty.call(data, mod)) {
        core[mod] = versionIncluded(data[mod]);
      }
    }
    var mod;
    module2.exports = core;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/is-core.js
var require_is_core = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/is-core.js"(exports2, module2) {
    var isCoreModule = require_is_core_module();
    module2.exports = function isCore(x) {
      return isCoreModule(x);
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/sync.js
var require_sync = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/lib/sync.js"(exports2, module2) {
    var isCore = require_is_core_module();
    var fs = require("fs");
    var path = require("path");
    var getHomedir = require_homedir();
    var caller = require_caller();
    var nodeModulesPaths = require_node_modules_paths();
    var normalizeOptions = require_normalize_options();
    var realpathFS = process.platform !== "win32" && fs.realpathSync && typeof fs.realpathSync.native === "function" ? fs.realpathSync.native : fs.realpathSync;
    var homedir = getHomedir();
    var defaultPaths = function() {
      return [
        path.join(homedir, ".node_modules"),
        path.join(homedir, ".node_libraries")
      ];
    };
    var defaultIsFile = function isFile(file) {
      try {
        var stat = fs.statSync(file, { throwIfNoEntry: false });
      } catch (e) {
        if (e && (e.code === "ENOENT" || e.code === "ENOTDIR"))
          return false;
        throw e;
      }
      return !!stat && (stat.isFile() || stat.isFIFO());
    };
    var defaultIsDir = function isDirectory(dir) {
      try {
        var stat = fs.statSync(dir, { throwIfNoEntry: false });
      } catch (e) {
        if (e && (e.code === "ENOENT" || e.code === "ENOTDIR"))
          return false;
        throw e;
      }
      return !!stat && stat.isDirectory();
    };
    var defaultRealpathSync = function realpathSync(x) {
      try {
        return realpathFS(x);
      } catch (realpathErr) {
        if (realpathErr.code !== "ENOENT") {
          throw realpathErr;
        }
      }
      return x;
    };
    var maybeRealpathSync = function maybeRealpathSync2(realpathSync, x, opts) {
      if (opts && opts.preserveSymlinks === false) {
        return realpathSync(x);
      }
      return x;
    };
    var defaultReadPackageSync = function defaultReadPackageSync2(readFileSync, pkgfile) {
      var body = readFileSync(pkgfile);
      try {
        var pkg = JSON.parse(body);
        return pkg;
      } catch (jsonErr) {
      }
    };
    var getPackageCandidates = function getPackageCandidates2(x, start, opts) {
      var dirs = nodeModulesPaths(start, opts, x);
      for (var i = 0; i < dirs.length; i++) {
        dirs[i] = path.join(dirs[i], x);
      }
      return dirs;
    };
    module2.exports = function resolveSync(x, options) {
      if (typeof x !== "string") {
        throw new TypeError("Path must be a string.");
      }
      var opts = normalizeOptions(x, options);
      var isFile = opts.isFile || defaultIsFile;
      var readFileSync = opts.readFileSync || fs.readFileSync;
      var isDirectory = opts.isDirectory || defaultIsDir;
      var realpathSync = opts.realpathSync || defaultRealpathSync;
      var readPackageSync = opts.readPackageSync || defaultReadPackageSync;
      if (opts.readFileSync && opts.readPackageSync) {
        throw new TypeError("`readFileSync` and `readPackageSync` are mutually exclusive.");
      }
      var packageIterator = opts.packageIterator;
      var extensions = opts.extensions || [".js"];
      var includeCoreModules = opts.includeCoreModules !== false;
      var basedir = opts.basedir || path.dirname(caller());
      var parent = opts.filename || basedir;
      opts.paths = opts.paths || defaultPaths();
      var absoluteStart = maybeRealpathSync(realpathSync, path.resolve(basedir), opts);
      if (/^(?:\.\.?(?:\/|$)|\/|([A-Za-z]:)?[/\\])/.test(x)) {
        var res = path.resolve(absoluteStart, x);
        if (x === "." || x === ".." || x.slice(-1) === "/")
          res += "/";
        var m = loadAsFileSync(res) || loadAsDirectorySync(res);
        if (m)
          return maybeRealpathSync(realpathSync, m, opts);
      } else if (includeCoreModules && isCore(x)) {
        return x;
      } else {
        var n = loadNodeModulesSync(x, absoluteStart);
        if (n)
          return maybeRealpathSync(realpathSync, n, opts);
      }
      var err = new Error("Cannot find module '" + x + "' from '" + parent + "'");
      err.code = "MODULE_NOT_FOUND";
      throw err;
      function loadAsFileSync(x2) {
        var pkg = loadpkg(path.dirname(x2));
        if (pkg && pkg.dir && pkg.pkg && opts.pathFilter) {
          var rfile = path.relative(pkg.dir, x2);
          var r = opts.pathFilter(pkg.pkg, x2, rfile);
          if (r) {
            x2 = path.resolve(pkg.dir, r);
          }
        }
        if (isFile(x2)) {
          return x2;
        }
        for (var i = 0; i < extensions.length; i++) {
          var file = x2 + extensions[i];
          if (isFile(file)) {
            return file;
          }
        }
      }
      function loadpkg(dir) {
        if (dir === "" || dir === "/")
          return;
        if (process.platform === "win32" && /^\w:[/\\]*$/.test(dir)) {
          return;
        }
        if (/[/\\]node_modules[/\\]*$/.test(dir))
          return;
        var pkgfile = path.join(maybeRealpathSync(realpathSync, dir, opts), "package.json");
        if (!isFile(pkgfile)) {
          return loadpkg(path.dirname(dir));
        }
        var pkg = readPackageSync(readFileSync, pkgfile);
        if (pkg && opts.packageFilter) {
          pkg = opts.packageFilter(pkg, dir);
        }
        return { pkg, dir };
      }
      function loadAsDirectorySync(x2) {
        var pkgfile = path.join(maybeRealpathSync(realpathSync, x2, opts), "/package.json");
        if (isFile(pkgfile)) {
          try {
            var pkg = readPackageSync(readFileSync, pkgfile);
          } catch (e) {
          }
          if (pkg && opts.packageFilter) {
            pkg = opts.packageFilter(pkg, x2);
          }
          if (pkg && pkg.main) {
            if (typeof pkg.main !== "string") {
              var mainError = new TypeError("package \u201C" + pkg.name + "\u201D `main` must be a string");
              mainError.code = "INVALID_PACKAGE_MAIN";
              throw mainError;
            }
            if (pkg.main === "." || pkg.main === "./") {
              pkg.main = "index";
            }
            try {
              var m2 = loadAsFileSync(path.resolve(x2, pkg.main));
              if (m2)
                return m2;
              var n2 = loadAsDirectorySync(path.resolve(x2, pkg.main));
              if (n2)
                return n2;
            } catch (e) {
            }
          }
        }
        return loadAsFileSync(path.join(x2, "/index"));
      }
      function loadNodeModulesSync(x2, start) {
        var thunk = function() {
          return getPackageCandidates(x2, start, opts);
        };
        var dirs = packageIterator ? packageIterator(x2, start, thunk, opts) : thunk();
        for (var i = 0; i < dirs.length; i++) {
          var dir = dirs[i];
          if (isDirectory(path.dirname(dir))) {
            var m2 = loadAsFileSync(dir);
            if (m2)
              return m2;
            var n2 = loadAsDirectorySync(dir);
            if (n2)
              return n2;
          }
        }
      }
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/index.js
var require_resolve = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/resolve/index.js"(exports2, module2) {
    var async = require_async();
    async.core = require_core3();
    async.isCore = require_is_core();
    async.sync = require_sync();
    module2.exports = async;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/ms/index.js
var require_ms = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/ms/index.js"(exports2, module2) {
    var s = 1e3;
    var m = s * 60;
    var h = m * 60;
    var d = h * 24;
    var w = d * 7;
    var y = d * 365.25;
    module2.exports = function(val, options) {
      options = options || {};
      var type = typeof val;
      if (type === "string" && val.length > 0) {
        return parse(val);
      } else if (type === "number" && isFinite(val)) {
        return options.long ? fmtLong(val) : fmtShort(val);
      }
      throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(val));
    };
    function parse(str) {
      str = String(str);
      if (str.length > 100) {
        return;
      }
      var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(str);
      if (!match) {
        return;
      }
      var n = parseFloat(match[1]);
      var type = (match[2] || "ms").toLowerCase();
      switch (type) {
        case "years":
        case "year":
        case "yrs":
        case "yr":
        case "y":
          return n * y;
        case "weeks":
        case "week":
        case "w":
          return n * w;
        case "days":
        case "day":
        case "d":
          return n * d;
        case "hours":
        case "hour":
        case "hrs":
        case "hr":
        case "h":
          return n * h;
        case "minutes":
        case "minute":
        case "mins":
        case "min":
        case "m":
          return n * m;
        case "seconds":
        case "second":
        case "secs":
        case "sec":
        case "s":
          return n * s;
        case "milliseconds":
        case "millisecond":
        case "msecs":
        case "msec":
        case "ms":
          return n;
        default:
          return void 0;
      }
    }
    function fmtShort(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return Math.round(ms / d) + "d";
      }
      if (msAbs >= h) {
        return Math.round(ms / h) + "h";
      }
      if (msAbs >= m) {
        return Math.round(ms / m) + "m";
      }
      if (msAbs >= s) {
        return Math.round(ms / s) + "s";
      }
      return ms + "ms";
    }
    function fmtLong(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return plural(ms, msAbs, d, "day");
      }
      if (msAbs >= h) {
        return plural(ms, msAbs, h, "hour");
      }
      if (msAbs >= m) {
        return plural(ms, msAbs, m, "minute");
      }
      if (msAbs >= s) {
        return plural(ms, msAbs, s, "second");
      }
      return ms + " ms";
    }
    function plural(ms, msAbs, n, name) {
      var isPlural = msAbs >= n * 1.5;
      return Math.round(ms / n) + " " + name + (isPlural ? "s" : "");
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/debug/src/common.js
var require_common2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/debug/src/common.js"(exports2, module2) {
    function setup(env) {
      createDebug.debug = createDebug;
      createDebug.default = createDebug;
      createDebug.coerce = coerce;
      createDebug.disable = disable;
      createDebug.enable = enable;
      createDebug.enabled = enabled;
      createDebug.humanize = require_ms();
      createDebug.destroy = destroy;
      Object.keys(env).forEach((key) => {
        createDebug[key] = env[key];
      });
      createDebug.names = [];
      createDebug.skips = [];
      createDebug.formatters = {};
      function selectColor(namespace) {
        let hash = 0;
        for (let i = 0; i < namespace.length; i++) {
          hash = (hash << 5) - hash + namespace.charCodeAt(i);
          hash |= 0;
        }
        return createDebug.colors[Math.abs(hash) % createDebug.colors.length];
      }
      createDebug.selectColor = selectColor;
      function createDebug(namespace) {
        let prevTime;
        let enableOverride = null;
        let namespacesCache;
        let enabledCache;
        function debug(...args) {
          if (!debug.enabled) {
            return;
          }
          const self2 = debug;
          const curr = Number(new Date());
          const ms = curr - (prevTime || curr);
          self2.diff = ms;
          self2.prev = prevTime;
          self2.curr = curr;
          prevTime = curr;
          args[0] = createDebug.coerce(args[0]);
          if (typeof args[0] !== "string") {
            args.unshift("%O");
          }
          let index = 0;
          args[0] = args[0].replace(/%([a-zA-Z%])/g, (match, format) => {
            if (match === "%%") {
              return "%";
            }
            index++;
            const formatter = createDebug.formatters[format];
            if (typeof formatter === "function") {
              const val = args[index];
              match = formatter.call(self2, val);
              args.splice(index, 1);
              index--;
            }
            return match;
          });
          createDebug.formatArgs.call(self2, args);
          const logFn = self2.log || createDebug.log;
          logFn.apply(self2, args);
        }
        debug.namespace = namespace;
        debug.useColors = createDebug.useColors();
        debug.color = createDebug.selectColor(namespace);
        debug.extend = extend;
        debug.destroy = createDebug.destroy;
        Object.defineProperty(debug, "enabled", {
          enumerable: true,
          configurable: false,
          get: () => {
            if (enableOverride !== null) {
              return enableOverride;
            }
            if (namespacesCache !== createDebug.namespaces) {
              namespacesCache = createDebug.namespaces;
              enabledCache = createDebug.enabled(namespace);
            }
            return enabledCache;
          },
          set: (v) => {
            enableOverride = v;
          }
        });
        if (typeof createDebug.init === "function") {
          createDebug.init(debug);
        }
        return debug;
      }
      function extend(namespace, delimiter) {
        const newDebug = createDebug(this.namespace + (typeof delimiter === "undefined" ? ":" : delimiter) + namespace);
        newDebug.log = this.log;
        return newDebug;
      }
      function enable(namespaces) {
        createDebug.save(namespaces);
        createDebug.namespaces = namespaces;
        createDebug.names = [];
        createDebug.skips = [];
        let i;
        const split = (typeof namespaces === "string" ? namespaces : "").split(/[\s,]+/);
        const len = split.length;
        for (i = 0; i < len; i++) {
          if (!split[i]) {
            continue;
          }
          namespaces = split[i].replace(/\*/g, ".*?");
          if (namespaces[0] === "-") {
            createDebug.skips.push(new RegExp("^" + namespaces.slice(1) + "$"));
          } else {
            createDebug.names.push(new RegExp("^" + namespaces + "$"));
          }
        }
      }
      function disable() {
        const namespaces = [
          ...createDebug.names.map(toNamespace),
          ...createDebug.skips.map(toNamespace).map((namespace) => "-" + namespace)
        ].join(",");
        createDebug.enable("");
        return namespaces;
      }
      function enabled(name) {
        if (name[name.length - 1] === "*") {
          return true;
        }
        let i;
        let len;
        for (i = 0, len = createDebug.skips.length; i < len; i++) {
          if (createDebug.skips[i].test(name)) {
            return false;
          }
        }
        for (i = 0, len = createDebug.names.length; i < len; i++) {
          if (createDebug.names[i].test(name)) {
            return true;
          }
        }
        return false;
      }
      function toNamespace(regexp) {
        return regexp.toString().substring(2, regexp.toString().length - 2).replace(/\.\*\?$/, "*");
      }
      function coerce(val) {
        if (val instanceof Error) {
          return val.stack || val.message;
        }
        return val;
      }
      function destroy() {
        console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
      }
      createDebug.enable(createDebug.load());
      return createDebug;
    }
    module2.exports = setup;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/debug/src/browser.js
var require_browser = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/debug/src/browser.js"(exports2, module2) {
    exports2.formatArgs = formatArgs;
    exports2.save = save;
    exports2.load = load;
    exports2.useColors = useColors;
    exports2.storage = localstorage();
    exports2.destroy = (() => {
      let warned = false;
      return () => {
        if (!warned) {
          warned = true;
          console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
        }
      };
    })();
    exports2.colors = [
      "#0000CC",
      "#0000FF",
      "#0033CC",
      "#0033FF",
      "#0066CC",
      "#0066FF",
      "#0099CC",
      "#0099FF",
      "#00CC00",
      "#00CC33",
      "#00CC66",
      "#00CC99",
      "#00CCCC",
      "#00CCFF",
      "#3300CC",
      "#3300FF",
      "#3333CC",
      "#3333FF",
      "#3366CC",
      "#3366FF",
      "#3399CC",
      "#3399FF",
      "#33CC00",
      "#33CC33",
      "#33CC66",
      "#33CC99",
      "#33CCCC",
      "#33CCFF",
      "#6600CC",
      "#6600FF",
      "#6633CC",
      "#6633FF",
      "#66CC00",
      "#66CC33",
      "#9900CC",
      "#9900FF",
      "#9933CC",
      "#9933FF",
      "#99CC00",
      "#99CC33",
      "#CC0000",
      "#CC0033",
      "#CC0066",
      "#CC0099",
      "#CC00CC",
      "#CC00FF",
      "#CC3300",
      "#CC3333",
      "#CC3366",
      "#CC3399",
      "#CC33CC",
      "#CC33FF",
      "#CC6600",
      "#CC6633",
      "#CC9900",
      "#CC9933",
      "#CCCC00",
      "#CCCC33",
      "#FF0000",
      "#FF0033",
      "#FF0066",
      "#FF0099",
      "#FF00CC",
      "#FF00FF",
      "#FF3300",
      "#FF3333",
      "#FF3366",
      "#FF3399",
      "#FF33CC",
      "#FF33FF",
      "#FF6600",
      "#FF6633",
      "#FF9900",
      "#FF9933",
      "#FFCC00",
      "#FFCC33"
    ];
    function useColors() {
      if (typeof window !== "undefined" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) {
        return true;
      }
      if (typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) {
        return false;
      }
      return typeof document !== "undefined" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || typeof window !== "undefined" && window.console && (window.console.firebug || window.console.exception && window.console.table) || typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31 || typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
    }
    function formatArgs(args) {
      args[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + args[0] + (this.useColors ? "%c " : " ") + "+" + module2.exports.humanize(this.diff);
      if (!this.useColors) {
        return;
      }
      const c = "color: " + this.color;
      args.splice(1, 0, c, "color: inherit");
      let index = 0;
      let lastC = 0;
      args[0].replace(/%[a-zA-Z%]/g, (match) => {
        if (match === "%%") {
          return;
        }
        index++;
        if (match === "%c") {
          lastC = index;
        }
      });
      args.splice(lastC, 0, c);
    }
    exports2.log = console.debug || console.log || (() => {
    });
    function save(namespaces) {
      try {
        if (namespaces) {
          exports2.storage.setItem("debug", namespaces);
        } else {
          exports2.storage.removeItem("debug");
        }
      } catch (error) {
      }
    }
    function load() {
      let r;
      try {
        r = exports2.storage.getItem("debug");
      } catch (error) {
      }
      if (!r && typeof process !== "undefined" && "env" in process) {
        r = process.env.DEBUG;
      }
      return r;
    }
    function localstorage() {
      try {
        return localStorage;
      } catch (error) {
      }
    }
    module2.exports = require_common2()(exports2);
    var { formatters } = module2.exports;
    formatters.j = function(v) {
      try {
        return JSON.stringify(v);
      } catch (error) {
        return "[UnexpectedJSONParseError]: " + error.message;
      }
    };
  }
});

// ../../node_modules/has-flag/index.js
var require_has_flag = __commonJS({
  "../../node_modules/has-flag/index.js"(exports2, module2) {
    "use strict";
    module2.exports = (flag, argv = process.argv) => {
      const prefix = flag.startsWith("-") ? "" : flag.length === 1 ? "-" : "--";
      const position = argv.indexOf(prefix + flag);
      const terminatorPosition = argv.indexOf("--");
      return position !== -1 && (terminatorPosition === -1 || position < terminatorPosition);
    };
  }
});

// ../../node_modules/supports-color/index.js
var require_supports_color = __commonJS({
  "../../node_modules/supports-color/index.js"(exports2, module2) {
    "use strict";
    var os = require("os");
    var tty = require("tty");
    var hasFlag = require_has_flag();
    var { env } = process;
    var flagForceColor;
    if (hasFlag("no-color") || hasFlag("no-colors") || hasFlag("color=false") || hasFlag("color=never")) {
      flagForceColor = 0;
    } else if (hasFlag("color") || hasFlag("colors") || hasFlag("color=true") || hasFlag("color=always")) {
      flagForceColor = 1;
    }
    function envForceColor() {
      if ("FORCE_COLOR" in env) {
        if (env.FORCE_COLOR === "true") {
          return 1;
        }
        if (env.FORCE_COLOR === "false") {
          return 0;
        }
        return env.FORCE_COLOR.length === 0 ? 1 : Math.min(Number.parseInt(env.FORCE_COLOR, 10), 3);
      }
    }
    function translateLevel(level) {
      if (level === 0) {
        return false;
      }
      return {
        level,
        hasBasic: true,
        has256: level >= 2,
        has16m: level >= 3
      };
    }
    function supportsColor(haveStream, { streamIsTTY, sniffFlags = true } = {}) {
      const noFlagForceColor = envForceColor();
      if (noFlagForceColor !== void 0) {
        flagForceColor = noFlagForceColor;
      }
      const forceColor = sniffFlags ? flagForceColor : noFlagForceColor;
      if (forceColor === 0) {
        return 0;
      }
      if (sniffFlags) {
        if (hasFlag("color=16m") || hasFlag("color=full") || hasFlag("color=truecolor")) {
          return 3;
        }
        if (hasFlag("color=256")) {
          return 2;
        }
      }
      if (haveStream && !streamIsTTY && forceColor === void 0) {
        return 0;
      }
      const min = forceColor || 0;
      if (env.TERM === "dumb") {
        return min;
      }
      if (process.platform === "win32") {
        const osRelease = os.release().split(".");
        if (Number(osRelease[0]) >= 10 && Number(osRelease[2]) >= 10586) {
          return Number(osRelease[2]) >= 14931 ? 3 : 2;
        }
        return 1;
      }
      if ("CI" in env) {
        if (["TRAVIS", "CIRCLECI", "APPVEYOR", "GITLAB_CI", "GITHUB_ACTIONS", "BUILDKITE", "DRONE"].some((sign) => sign in env) || env.CI_NAME === "codeship") {
          return 1;
        }
        return min;
      }
      if ("TEAMCITY_VERSION" in env) {
        return /^(9\.(0*[1-9]\d*)\.|\d{2,}\.)/.test(env.TEAMCITY_VERSION) ? 1 : 0;
      }
      if (env.COLORTERM === "truecolor") {
        return 3;
      }
      if ("TERM_PROGRAM" in env) {
        const version = Number.parseInt((env.TERM_PROGRAM_VERSION || "").split(".")[0], 10);
        switch (env.TERM_PROGRAM) {
          case "iTerm.app":
            return version >= 3 ? 3 : 2;
          case "Apple_Terminal":
            return 2;
        }
      }
      if (/-256(color)?$/i.test(env.TERM)) {
        return 2;
      }
      if (/^screen|^xterm|^vt100|^vt220|^rxvt|color|ansi|cygwin|linux/i.test(env.TERM)) {
        return 1;
      }
      if ("COLORTERM" in env) {
        return 1;
      }
      return min;
    }
    function getSupportLevel(stream, options = {}) {
      const level = supportsColor(stream, {
        streamIsTTY: stream && stream.isTTY,
        ...options
      });
      return translateLevel(level);
    }
    module2.exports = {
      supportsColor: getSupportLevel,
      stdout: getSupportLevel({ isTTY: tty.isatty(1) }),
      stderr: getSupportLevel({ isTTY: tty.isatty(2) })
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/debug/src/node.js
var require_node6 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/debug/src/node.js"(exports2, module2) {
    var tty = require("tty");
    var util = require("util");
    exports2.init = init;
    exports2.log = log;
    exports2.formatArgs = formatArgs;
    exports2.save = save;
    exports2.load = load;
    exports2.useColors = useColors;
    exports2.destroy = util.deprecate(() => {
    }, "Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
    exports2.colors = [6, 2, 3, 4, 5, 1];
    try {
      const supportsColor = require_supports_color();
      if (supportsColor && (supportsColor.stderr || supportsColor).level >= 2) {
        exports2.colors = [
          20,
          21,
          26,
          27,
          32,
          33,
          38,
          39,
          40,
          41,
          42,
          43,
          44,
          45,
          56,
          57,
          62,
          63,
          68,
          69,
          74,
          75,
          76,
          77,
          78,
          79,
          80,
          81,
          92,
          93,
          98,
          99,
          112,
          113,
          128,
          129,
          134,
          135,
          148,
          149,
          160,
          161,
          162,
          163,
          164,
          165,
          166,
          167,
          168,
          169,
          170,
          171,
          172,
          173,
          178,
          179,
          184,
          185,
          196,
          197,
          198,
          199,
          200,
          201,
          202,
          203,
          204,
          205,
          206,
          207,
          208,
          209,
          214,
          215,
          220,
          221
        ];
      }
    } catch (error) {
    }
    exports2.inspectOpts = Object.keys(process.env).filter((key) => {
      return /^debug_/i.test(key);
    }).reduce((obj, key) => {
      const prop = key.substring(6).toLowerCase().replace(/_([a-z])/g, (_, k) => {
        return k.toUpperCase();
      });
      let val = process.env[key];
      if (/^(yes|on|true|enabled)$/i.test(val)) {
        val = true;
      } else if (/^(no|off|false|disabled)$/i.test(val)) {
        val = false;
      } else if (val === "null") {
        val = null;
      } else {
        val = Number(val);
      }
      obj[prop] = val;
      return obj;
    }, {});
    function useColors() {
      return "colors" in exports2.inspectOpts ? Boolean(exports2.inspectOpts.colors) : tty.isatty(process.stderr.fd);
    }
    function formatArgs(args) {
      const { namespace: name, useColors: useColors2 } = this;
      if (useColors2) {
        const c = this.color;
        const colorCode = "\x1B[3" + (c < 8 ? c : "8;5;" + c);
        const prefix = `  ${colorCode};1m${name} \x1B[0m`;
        args[0] = prefix + args[0].split("\n").join("\n" + prefix);
        args.push(colorCode + "m+" + module2.exports.humanize(this.diff) + "\x1B[0m");
      } else {
        args[0] = getDate() + name + " " + args[0];
      }
    }
    function getDate() {
      if (exports2.inspectOpts.hideDate) {
        return "";
      }
      return new Date().toISOString() + " ";
    }
    function log(...args) {
      return process.stderr.write(util.format(...args) + "\n");
    }
    function save(namespaces) {
      if (namespaces) {
        process.env.DEBUG = namespaces;
      } else {
        delete process.env.DEBUG;
      }
    }
    function load() {
      return process.env.DEBUG;
    }
    function init(debug) {
      debug.inspectOpts = {};
      const keys = Object.keys(exports2.inspectOpts);
      for (let i = 0; i < keys.length; i++) {
        debug.inspectOpts[keys[i]] = exports2.inspectOpts[keys[i]];
      }
    }
    module2.exports = require_common2()(exports2);
    var { formatters } = module2.exports;
    formatters.o = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts).split("\n").map((str) => str.trim()).join(" ");
    };
    formatters.O = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts);
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/debug/src/index.js
var require_src12 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/debug/src/index.js"(exports2, module2) {
    if (typeof process === "undefined" || process.type === "renderer" || process.browser === true || process.__nwjs) {
      module2.exports = require_browser();
    } else {
      module2.exports = require_node6();
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/module-details-from-path/index.js
var require_module_details_from_path = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/module-details-from-path/index.js"(exports2, module2) {
    "use strict";
    var path = require("path");
    module2.exports = function(file) {
      var segments = file.split(path.sep);
      var index = segments.lastIndexOf("node_modules");
      if (index === -1)
        return;
      if (!segments[index + 1])
        return;
      var scoped = segments[index + 1][0] === "@";
      var name = scoped ? segments[index + 1] + "/" + segments[index + 2] : segments[index + 1];
      var offset = scoped ? 3 : 2;
      return {
        name,
        basedir: segments.slice(0, index + offset).join(path.sep),
        path: segments.slice(index + offset).join(path.sep)
      };
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/require-in-the-middle/package.json
var require_package = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/require-in-the-middle/package.json"(exports2, module2) {
    module2.exports = {
      name: "require-in-the-middle",
      version: "5.1.0",
      description: "Module to hook into the Node.js require function",
      main: "index.js",
      dependencies: {
        debug: "^4.1.1",
        "module-details-from-path": "^1.0.3",
        resolve: "^1.12.0"
      },
      devDependencies: {
        "@babel/core": "^7.9.0",
        "@babel/preset-env": "^7.9.5",
        "@babel/preset-typescript": "^7.9.0",
        "@babel/register": "^7.9.0",
        "ipp-printer": "^1.0.0",
        patterns: "^1.0.3",
        roundround: "^0.2.0",
        semver: "^6.3.0",
        standard: "^14.3.1",
        tape: "^4.11.0"
      },
      scripts: {
        test: "npm run test:lint && npm run test:tape && npm run test:babel",
        "test:lint": "standard",
        "test:tape": "tape test/*.js",
        "test:babel": "node test/babel/babel-register.js"
      },
      repository: {
        type: "git",
        url: "git+https://github.com/elastic/require-in-the-middle.git"
      },
      keywords: [
        "require",
        "hook",
        "shim",
        "shimmer",
        "shimming",
        "patch",
        "monkey",
        "monkeypatch",
        "module",
        "load"
      ],
      author: "Thomas Watson Steen <w@tson.dk> (https://twitter.com/wa7son)",
      license: "MIT",
      bugs: {
        url: "https://github.com/elastic/require-in-the-middle/issues"
      },
      homepage: "https://github.com/elastic/require-in-the-middle#readme",
      coordinates: [
        56.009779,
        11.962099
      ]
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/require-in-the-middle/index.js
var require_require_in_the_middle = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/require-in-the-middle/index.js"(exports2, module2) {
    "use strict";
    var path = require("path");
    var Module = require("module");
    var resolve = require_resolve();
    var debug = require_src12()("require-in-the-middle");
    var parse = require_module_details_from_path();
    module2.exports = Hook;
    var builtins = Module.builtinModules;
    var isCore = builtins ? (filename) => builtins.includes(filename) : (filename) => filename.includes(path.sep) === false;
    var normalize = /([/\\]index)?(\.js)?$/;
    function Hook(modules, options, onrequire) {
      if (this instanceof Hook === false)
        return new Hook(modules, options, onrequire);
      if (typeof modules === "function") {
        onrequire = modules;
        modules = null;
        options = null;
      } else if (typeof options === "function") {
        onrequire = options;
        options = null;
      }
      if (typeof Module._resolveFilename !== "function") {
        console.error("Error: Expected Module._resolveFilename to be a function (was: %s) - aborting!", typeof Module._resolveFilename);
        console.error("Please report this error as an issue related to Node.js %s at %s", process.version, require_package().bugs.url);
        return;
      }
      this.cache = /* @__PURE__ */ new Map();
      this._unhooked = false;
      this._origRequire = Module.prototype.require;
      const self2 = this;
      const patching = /* @__PURE__ */ new Set();
      const internals = options ? options.internals === true : false;
      const hasWhitelist = Array.isArray(modules);
      debug("registering require hook");
      this._require = Module.prototype.require = function(id) {
        if (self2._unhooked === true) {
          debug("ignoring require call - module is soft-unhooked");
          return self2._origRequire.apply(this, arguments);
        }
        const filename = Module._resolveFilename(id, this);
        const core = isCore(filename);
        let moduleName, basedir;
        debug("processing %s module require('%s'): %s", core === true ? "core" : "non-core", id, filename);
        if (self2.cache.has(filename) === true) {
          debug("returning already patched cached module: %s", filename);
          return self2.cache.get(filename);
        }
        const isPatching = patching.has(filename);
        if (isPatching === false) {
          patching.add(filename);
        }
        const exports3 = self2._origRequire.apply(this, arguments);
        if (isPatching === true) {
          debug("module is in the process of being patched already - ignoring: %s", filename);
          return exports3;
        }
        patching.delete(filename);
        if (core === true) {
          if (hasWhitelist === true && modules.includes(filename) === false) {
            debug("ignoring core module not on whitelist: %s", filename);
            return exports3;
          }
          moduleName = filename;
        } else if (hasWhitelist === true && modules.includes(filename)) {
          const parsedPath = path.parse(filename);
          moduleName = parsedPath.name;
          basedir = parsedPath.dir;
        } else {
          const stat = parse(filename);
          if (stat === void 0) {
            debug("could not parse filename: %s", filename);
            return exports3;
          }
          moduleName = stat.name;
          basedir = stat.basedir;
          const fullModuleName = resolveModuleName(stat);
          debug("resolved filename to module: %s (id: %s, resolved: %s, basedir: %s)", moduleName, id, fullModuleName, basedir);
          if (hasWhitelist === true && modules.includes(moduleName) === false) {
            if (modules.includes(fullModuleName) === false)
              return exports3;
            moduleName = fullModuleName;
          } else {
            let res;
            try {
              res = resolve.sync(moduleName, { basedir });
            } catch (e) {
              debug("could not resolve module: %s", moduleName);
              return exports3;
            }
            if (res !== filename) {
              if (internals === true) {
                moduleName = moduleName + path.sep + path.relative(basedir, filename);
                debug("preparing to process require of internal file: %s", moduleName);
              } else {
                debug("ignoring require of non-main module file: %s", res);
                return exports3;
              }
            }
          }
        }
        if (self2.cache.has(filename) === false) {
          self2.cache.set(filename, exports3);
          debug("calling require hook: %s", moduleName);
          self2.cache.set(filename, onrequire(exports3, moduleName, basedir));
        }
        debug("returning module: %s", moduleName);
        return self2.cache.get(filename);
      };
    }
    Hook.prototype.unhook = function() {
      this._unhooked = true;
      if (this._require === Module.prototype.require) {
        Module.prototype.require = this._origRequire;
        debug("unhook successful");
      } else {
        debug("unhook unsuccessful");
      }
    };
    function resolveModuleName(stat) {
      const normalizedPath = path.sep !== "/" ? stat.path.split(path.sep).join("/") : stat.path;
      return path.posix.join(stat.name, normalizedPath).replace(normalize, "");
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/shimmer/index.js
var require_shimmer = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/shimmer/index.js"(exports2, module2) {
    "use strict";
    function isFunction(funktion) {
      return typeof funktion === "function";
    }
    var logger = console.error.bind(console);
    function defineProperty(obj, name, value) {
      var enumerable = !!obj[name] && obj.propertyIsEnumerable(name);
      Object.defineProperty(obj, name, {
        configurable: true,
        enumerable,
        writable: true,
        value
      });
    }
    function shimmer(options) {
      if (options && options.logger) {
        if (!isFunction(options.logger))
          logger("new logger isn't a function, not replacing");
        else
          logger = options.logger;
      }
    }
    function wrap(nodule, name, wrapper) {
      if (!nodule || !nodule[name]) {
        logger("no original function " + name + " to wrap");
        return;
      }
      if (!wrapper) {
        logger("no wrapper function");
        logger(new Error().stack);
        return;
      }
      if (!isFunction(nodule[name]) || !isFunction(wrapper)) {
        logger("original object and wrapper must be functions");
        return;
      }
      var original = nodule[name];
      var wrapped = wrapper(original, name);
      defineProperty(wrapped, "__original", original);
      defineProperty(wrapped, "__unwrap", function() {
        if (nodule[name] === wrapped)
          defineProperty(nodule, name, original);
      });
      defineProperty(wrapped, "__wrapped", true);
      defineProperty(nodule, name, wrapped);
      return wrapped;
    }
    function massWrap(nodules, names, wrapper) {
      if (!nodules) {
        logger("must provide one or more modules to patch");
        logger(new Error().stack);
        return;
      } else if (!Array.isArray(nodules)) {
        nodules = [nodules];
      }
      if (!(names && Array.isArray(names))) {
        logger("must provide one or more functions to wrap on modules");
        return;
      }
      nodules.forEach(function(nodule) {
        names.forEach(function(name) {
          wrap(nodule, name, wrapper);
        });
      });
    }
    function unwrap(nodule, name) {
      if (!nodule || !nodule[name]) {
        logger("no function to unwrap.");
        logger(new Error().stack);
        return;
      }
      if (!nodule[name].__unwrap) {
        logger("no original to unwrap to -- has " + name + " already been unwrapped?");
      } else {
        return nodule[name].__unwrap();
      }
    }
    function massUnwrap(nodules, names) {
      if (!nodules) {
        logger("must provide one or more modules to patch");
        logger(new Error().stack);
        return;
      } else if (!Array.isArray(nodules)) {
        nodules = [nodules];
      }
      if (!(names && Array.isArray(names))) {
        logger("must provide one or more functions to unwrap on modules");
        return;
      }
      nodules.forEach(function(nodule) {
        names.forEach(function(name) {
          unwrap(nodule, name);
        });
      });
    }
    shimmer.wrap = wrap;
    shimmer.massWrap = massWrap;
    shimmer.unwrap = unwrap;
    shimmer.massUnwrap = massUnwrap;
    module2.exports = shimmer;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/instrumentation.js
var require_instrumentation = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.InstrumentationAbstract = void 0;
    var api_1 = require_src();
    var api_metrics_1 = require_src10();
    var shimmer = require_shimmer();
    var InstrumentationAbstract = class {
      constructor(instrumentationName, instrumentationVersion, config = {}) {
        this.instrumentationName = instrumentationName;
        this.instrumentationVersion = instrumentationVersion;
        this._wrap = shimmer.wrap;
        this._unwrap = shimmer.unwrap;
        this._massWrap = shimmer.massWrap;
        this._massUnwrap = shimmer.massUnwrap;
        this._config = Object.assign({ enabled: true }, config);
        this._diag = api_1.diag.createComponentLogger({
          namespace: instrumentationName
        });
        this._tracer = api_1.trace.getTracer(instrumentationName, instrumentationVersion);
        this._meter = api_metrics_1.metrics.getMeter(instrumentationName, instrumentationVersion);
      }
      get meter() {
        return this._meter;
      }
      setMeterProvider(meterProvider) {
        this._meter = meterProvider.getMeter(this.instrumentationName, this.instrumentationVersion);
      }
      getConfig() {
        return this._config;
      }
      setConfig(config = {}) {
        this._config = Object.assign({}, config);
      }
      setTracerProvider(tracerProvider2) {
        this._tracer = tracerProvider2.getTracer(this.instrumentationName, this.instrumentationVersion);
      }
      get tracer() {
        return this._tracer;
      }
    };
    exports2.InstrumentationAbstract = InstrumentationAbstract;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/instrumentation.js
var require_instrumentation2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.InstrumentationBase = void 0;
    var path = require("path");
    var RequireInTheMiddle = require_require_in_the_middle();
    var semver_1 = require_semver3();
    var instrumentation_1 = require_instrumentation();
    var api_1 = require_src();
    var InstrumentationBase = class extends instrumentation_1.InstrumentationAbstract {
      constructor(instrumentationName, instrumentationVersion, config = {}) {
        super(instrumentationName, instrumentationVersion, config);
        this._hooks = [];
        this._enabled = false;
        let modules = this.init();
        if (modules && !Array.isArray(modules)) {
          modules = [modules];
        }
        this._modules = modules || [];
        if (this._modules.length === 0) {
          api_1.diag.warn("No modules instrumentation has been defined, nothing will be patched");
        }
        if (this._config.enabled) {
          this.enable();
        }
      }
      _extractPackageVersion(baseDir) {
        try {
          const version = require(path.join(baseDir, "package.json")).version;
          return typeof version === "string" ? version : void 0;
        } catch (error) {
          api_1.diag.warn("Failed extracting version", baseDir);
        }
        return void 0;
      }
      _onRequire(module3, exports3, name, baseDir) {
        var _a;
        if (!baseDir) {
          if (typeof module3.patch === "function") {
            module3.moduleExports = exports3;
            return module3.patch(exports3);
          }
          return exports3;
        }
        const version = this._extractPackageVersion(baseDir);
        module3.moduleVersion = version;
        if (module3.name === name) {
          if (isSupported(module3.supportedVersions, version, module3.includePrerelease)) {
            if (typeof module3.patch === "function") {
              module3.moduleExports = exports3;
              if (this._enabled) {
                return module3.patch(exports3, module3.moduleVersion);
              }
            }
          }
        } else {
          const files = (_a = module3.files) !== null && _a !== void 0 ? _a : [];
          const file = files.find((f) => f.name === name);
          if (file && isSupported(file.supportedVersions, version, module3.includePrerelease)) {
            file.moduleExports = exports3;
            if (this._enabled) {
              return file.patch(exports3, module3.moduleVersion);
            }
          }
        }
        return exports3;
      }
      enable() {
        if (this._enabled) {
          return;
        }
        this._enabled = true;
        if (this._hooks.length > 0) {
          for (const module3 of this._modules) {
            if (typeof module3.patch === "function" && module3.moduleExports) {
              module3.patch(module3.moduleExports, module3.moduleVersion);
            }
            for (const file of module3.files) {
              if (file.moduleExports) {
                file.patch(file.moduleExports, module3.moduleVersion);
              }
            }
          }
          return;
        }
        for (const module3 of this._modules) {
          this._hooks.push(RequireInTheMiddle([module3.name], { internals: true }, (exports3, name, baseDir) => {
            return this._onRequire(module3, exports3, name, baseDir);
          }));
        }
      }
      disable() {
        if (!this._enabled) {
          return;
        }
        this._enabled = false;
        for (const module3 of this._modules) {
          if (typeof module3.unpatch === "function" && module3.moduleExports) {
            module3.unpatch(module3.moduleExports, module3.moduleVersion);
          }
          for (const file of module3.files) {
            if (file.moduleExports) {
              file.unpatch(file.moduleExports, module3.moduleVersion);
            }
          }
        }
      }
      isEnabled() {
        return this._enabled;
      }
    };
    exports2.InstrumentationBase = InstrumentationBase;
    function isSupported(supportedVersions, version, includePrerelease) {
      if (typeof version === "undefined") {
        return supportedVersions.includes("*");
      }
      return supportedVersions.some((supportedVersion) => {
        return semver_1.satisfies(version, supportedVersion, { includePrerelease });
      });
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/instrumentationNodeModuleDefinition.js
var require_instrumentationNodeModuleDefinition = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/instrumentationNodeModuleDefinition.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.InstrumentationNodeModuleDefinition = void 0;
    var InstrumentationNodeModuleDefinition = class {
      constructor(name, supportedVersions, patch, unpatch, files) {
        this.name = name;
        this.supportedVersions = supportedVersions;
        this.patch = patch;
        this.unpatch = unpatch;
        this.files = files || [];
      }
    };
    exports2.InstrumentationNodeModuleDefinition = InstrumentationNodeModuleDefinition;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/instrumentationNodeModuleFile.js
var require_instrumentationNodeModuleFile = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/instrumentationNodeModuleFile.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.InstrumentationNodeModuleFile = void 0;
    var path_1 = require("path");
    var InstrumentationNodeModuleFile = class {
      constructor(name, supportedVersions, patch, unpatch) {
        this.supportedVersions = supportedVersions;
        this.patch = patch;
        this.unpatch = unpatch;
        this.name = path_1.normalize(name);
      }
    };
    exports2.InstrumentationNodeModuleFile = InstrumentationNodeModuleFile;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/types.js
var require_types8 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/index.js
var require_node7 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/node/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation2(), exports2);
    __exportStar(require_instrumentationNodeModuleDefinition(), exports2);
    __exportStar(require_instrumentationNodeModuleFile(), exports2);
    __exportStar(require_types8(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/index.js
var require_platform6 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/platform/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_node7(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/types.js
var require_types9 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/types_internal.js
var require_types_internal = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/types_internal.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/utils.js
var require_utils3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isWrapped = exports2.safeExecuteInTheMiddleAsync = exports2.safeExecuteInTheMiddle = void 0;
    function safeExecuteInTheMiddle(execute, onFinish, preventThrowingError) {
      let error;
      let result;
      try {
        result = execute();
      } catch (e) {
        error = e;
      } finally {
        onFinish(error, result);
        if (error && !preventThrowingError) {
          throw error;
        }
        return result;
      }
    }
    exports2.safeExecuteInTheMiddle = safeExecuteInTheMiddle;
    async function safeExecuteInTheMiddleAsync(execute, onFinish, preventThrowingError) {
      let error;
      let result;
      try {
        result = await execute();
      } catch (e) {
        error = e;
      } finally {
        onFinish(error, result);
        if (error && !preventThrowingError) {
          throw error;
        }
        return result;
      }
    }
    exports2.safeExecuteInTheMiddleAsync = safeExecuteInTheMiddleAsync;
    function isWrapped(func) {
      return typeof func === "function" && typeof func.__original === "function" && typeof func.__unwrap === "function" && func.__wrapped === true;
    }
    exports2.isWrapped = isWrapped;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/index.js
var require_src13 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_autoLoader(), exports2);
    __exportStar(require_platform6(), exports2);
    __exportStar(require_types9(), exports2);
    __exportStar(require_types_internal(), exports2);
    __exportStar(require_utils3(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/enums.js
var require_enums2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/enums.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["AWS_ERROR"] = "aws.error";
      AttributeNames2["AWS_OPERATION"] = "aws.operation";
      AttributeNames2["AWS_REGION"] = "aws.region";
      AttributeNames2["AWS_SERVICE_API"] = "aws.service.api";
      AttributeNames2["AWS_SERVICE_NAME"] = "aws.service.name";
      AttributeNames2["AWS_SERVICE_IDENTIFIER"] = "aws.service.identifier";
      AttributeNames2["AWS_REQUEST_ID"] = "aws.request.id";
      AttributeNames2["AWS_REQUEST_EXTENDED_ID"] = "aws.request.extended_id";
      AttributeNames2["AWS_SIGNATURE_VERSION"] = "aws.signature.version";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagation-utils/build/src/pubsub-propagation.js
var require_pubsub_propagation = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagation-utils/build/src/pubsub-propagation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var api_1 = require_src();
    var START_SPAN_FUNCTION = Symbol("opentelemetry.pubsub-propagation.start_span");
    var END_SPAN_FUNCTION = Symbol("opentelemetry.pubsub-propagation.end_span");
    var patchArrayFilter = (messages, tracer, loopContext) => {
      const origFunc = messages.filter;
      const patchedFunc = function(...args) {
        const newArray = origFunc.apply(this, args);
        patchArrayForProcessSpans(newArray, tracer, loopContext);
        return newArray;
      };
      Object.defineProperty(messages, "filter", {
        enumerable: false,
        value: patchedFunc
      });
    };
    var patchArrayFunction = (messages, functionName, tracer, loopContext) => {
      const origFunc = messages[functionName];
      const patchedFunc = function(...arrFuncArgs) {
        const callback = arrFuncArgs[0];
        const wrappedCallback = function(...callbackArgs) {
          var _a;
          const message = callbackArgs[0];
          const messageSpan = (_a = message === null || message === void 0 ? void 0 : message[START_SPAN_FUNCTION]) === null || _a === void 0 ? void 0 : _a.call(message);
          if (!messageSpan)
            return callback.apply(this, callbackArgs);
          const res = api_1.context.with(api_1.trace.setSpan(loopContext, messageSpan), () => {
            var _a2;
            try {
              return callback.apply(this, callbackArgs);
            } finally {
              (_a2 = message[END_SPAN_FUNCTION]) === null || _a2 === void 0 ? void 0 : _a2.call(message);
            }
          });
          if (typeof res === "object") {
            const startSpanFunction = Object.getOwnPropertyDescriptor(message, START_SPAN_FUNCTION);
            startSpanFunction && Object.defineProperty(res, START_SPAN_FUNCTION, startSpanFunction);
            const endSpanFunction = Object.getOwnPropertyDescriptor(message, END_SPAN_FUNCTION);
            endSpanFunction && Object.defineProperty(res, END_SPAN_FUNCTION, endSpanFunction);
          }
          return res;
        };
        arrFuncArgs[0] = wrappedCallback;
        const funcResult = origFunc.apply(this, arrFuncArgs);
        if (Array.isArray(funcResult))
          patchArrayForProcessSpans(funcResult, tracer, loopContext);
        return funcResult;
      };
      Object.defineProperty(messages, functionName, {
        enumerable: false,
        value: patchedFunc
      });
    };
    var patchArrayForProcessSpans = (messages, tracer, loopContext = api_1.context.active()) => {
      patchArrayFunction(messages, "forEach", tracer, loopContext);
      patchArrayFunction(messages, "map", tracer, loopContext);
      patchArrayFilter(messages, tracer, loopContext);
    };
    var startMessagingProcessSpan = (message, name, attributes, parentContext, propagatedContext, tracer, processHook) => {
      const links = [];
      const spanContext = api_1.trace.getSpanContext(propagatedContext);
      if (spanContext) {
        links.push({
          context: spanContext
        });
      }
      const spanName = `${name} process`;
      const processSpan = tracer.startSpan(spanName, {
        kind: api_1.SpanKind.CONSUMER,
        attributes: Object.assign(Object.assign({}, attributes), { ["messaging.operation"]: "process" }),
        links
      }, parentContext);
      Object.defineProperty(message, START_SPAN_FUNCTION, {
        enumerable: false,
        writable: true,
        value: () => processSpan
      });
      Object.defineProperty(message, END_SPAN_FUNCTION, {
        enumerable: false,
        writable: true,
        value: () => {
          processSpan.end();
          Object.defineProperty(message, END_SPAN_FUNCTION, {
            enumerable: false,
            writable: true,
            value: () => {
            }
          });
        }
      });
      try {
        processHook === null || processHook === void 0 ? void 0 : processHook(processSpan, message);
      } catch (err) {
        api_1.diag.error("opentelemetry-pubsub-propagation: process hook error", err);
      }
      return processSpan;
    };
    var patchMessagesArrayToStartProcessSpans = ({ messages, tracer, parentContext, messageToSpanDetails, processHook }) => {
      messages.forEach((message) => {
        const { attributes, name, parentContext: propagatedContext } = messageToSpanDetails(message);
        Object.defineProperty(message, START_SPAN_FUNCTION, {
          enumerable: false,
          writable: true,
          value: () => startMessagingProcessSpan(message, name, attributes, parentContext, propagatedContext, tracer, processHook)
        });
      });
    };
    exports2.default = {
      patchMessagesArrayToStartProcessSpans,
      patchArrayForProcessSpans
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagation-utils/build/src/index.js
var require_src14 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagation-utils/build/src/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.pubsubPropagation = void 0;
    var pubsub_propagation_1 = require_pubsub_propagation();
    Object.defineProperty(exports2, "pubsubPropagation", { enumerable: true, get: function() {
      return pubsub_propagation_1.default;
    } });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/MessageAttributes.js
var require_MessageAttributes = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/MessageAttributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.extractPropagationContext = exports2.injectPropagationContext = exports2.contextGetter = exports2.contextSetter = exports2.MAX_MESSAGE_ATTRIBUTES = void 0;
    var api_1 = require_src();
    exports2.MAX_MESSAGE_ATTRIBUTES = 10;
    var ContextSetter = class {
      set(carrier, key, value) {
        carrier[key] = {
          DataType: "String",
          StringValue: value
        };
      }
    };
    exports2.contextSetter = new ContextSetter();
    var ContextGetter = class {
      keys(carrier) {
        return Object.keys(carrier);
      }
      get(carrier, key) {
        var _a, _b;
        return ((_a = carrier === null || carrier === void 0 ? void 0 : carrier[key]) === null || _a === void 0 ? void 0 : _a.StringValue) || ((_b = carrier === null || carrier === void 0 ? void 0 : carrier[key]) === null || _b === void 0 ? void 0 : _b.Value);
      }
    };
    exports2.contextGetter = new ContextGetter();
    var injectPropagationContext = (attributesMap) => {
      const attributes = attributesMap !== null && attributesMap !== void 0 ? attributesMap : {};
      if (Object.keys(attributes).length + api_1.propagation.fields().length <= exports2.MAX_MESSAGE_ATTRIBUTES) {
        api_1.propagation.inject(api_1.context.active(), attributes, exports2.contextSetter);
      } else {
        api_1.diag.warn("aws-sdk instrumentation: cannot set context propagation on SQS/SNS message due to maximum amount of MessageAttributes");
      }
      return attributes;
    };
    exports2.injectPropagationContext = injectPropagationContext;
    var extractPropagationContext = (message, sqsExtractContextPropagationFromPayload) => {
      const propagationFields = api_1.propagation.fields();
      const hasPropagationFields = Object.keys(message.MessageAttributes || []).some((attr) => propagationFields.includes(attr));
      if (hasPropagationFields) {
        return message.MessageAttributes;
      } else if (sqsExtractContextPropagationFromPayload && message.Body) {
        try {
          const payload = JSON.parse(message.Body);
          return payload.MessageAttributes;
        } catch (_a) {
          api_1.diag.debug("failed to parse SQS payload to extract context propagation, trace might be incomplete.");
        }
      }
      return void 0;
    };
    exports2.extractPropagationContext = extractPropagationContext;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/sqs.js
var require_sqs = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/sqs.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SqsServiceExtension = void 0;
    var api_1 = require_src();
    var propagation_utils_1 = require_src14();
    var semantic_conventions_1 = require_src3();
    var MessageAttributes_1 = require_MessageAttributes();
    var SqsServiceExtension = class {
      constructor() {
        this.requestPostSpanHook = (request) => {
          var _a, _b, _c;
          switch (request.commandName) {
            case "SendMessage":
              {
                const origMessageAttributes = (_a = request.commandInput["MessageAttributes"]) !== null && _a !== void 0 ? _a : {};
                if (origMessageAttributes) {
                  request.commandInput["MessageAttributes"] = MessageAttributes_1.injectPropagationContext(origMessageAttributes);
                }
              }
              break;
            case "SendMessageBatch":
              {
                (_c = (_b = request.commandInput) === null || _b === void 0 ? void 0 : _b.Entries) === null || _c === void 0 ? void 0 : _c.forEach((messageParams) => {
                  var _a2;
                  messageParams.MessageAttributes = MessageAttributes_1.injectPropagationContext((_a2 = messageParams.MessageAttributes) !== null && _a2 !== void 0 ? _a2 : {});
                });
              }
              break;
          }
        };
        this.responseHook = (response, span, tracer, config) => {
          var _a;
          const messages = (_a = response === null || response === void 0 ? void 0 : response.data) === null || _a === void 0 ? void 0 : _a.Messages;
          if (messages) {
            const queueUrl = this.extractQueueUrl(response.request.commandInput);
            const queueName = this.extractQueueNameFromUrl(queueUrl);
            propagation_utils_1.pubsubPropagation.patchMessagesArrayToStartProcessSpans({
              messages,
              parentContext: api_1.trace.setSpan(api_1.context.active(), span),
              tracer,
              messageToSpanDetails: (message) => ({
                name: queueName !== null && queueName !== void 0 ? queueName : "unknown",
                parentContext: api_1.propagation.extract(api_1.ROOT_CONTEXT, MessageAttributes_1.extractPropagationContext(message, config.sqsExtractContextPropagationFromPayload), MessageAttributes_1.contextGetter),
                attributes: {
                  [semantic_conventions_1.SemanticAttributes.MESSAGING_SYSTEM]: "aws.sqs",
                  [semantic_conventions_1.SemanticAttributes.MESSAGING_DESTINATION]: queueName,
                  [semantic_conventions_1.SemanticAttributes.MESSAGING_DESTINATION_KIND]: semantic_conventions_1.MessagingDestinationKindValues.QUEUE,
                  [semantic_conventions_1.SemanticAttributes.MESSAGING_MESSAGE_ID]: message.MessageId,
                  [semantic_conventions_1.SemanticAttributes.MESSAGING_URL]: queueUrl,
                  [semantic_conventions_1.SemanticAttributes.MESSAGING_OPERATION]: semantic_conventions_1.MessagingOperationValues.PROCESS
                }
              }),
              processHook: (span2, message) => {
                var _a2;
                return (_a2 = config.sqsProcessHook) === null || _a2 === void 0 ? void 0 : _a2.call(config, span2, { message });
              }
            });
            propagation_utils_1.pubsubPropagation.patchArrayForProcessSpans(messages, tracer, api_1.context.active());
          }
        };
        this.extractQueueUrl = (commandInput) => {
          return commandInput === null || commandInput === void 0 ? void 0 : commandInput.QueueUrl;
        };
        this.extractQueueNameFromUrl = (queueUrl) => {
          if (!queueUrl)
            return void 0;
          const segments = queueUrl.split("/");
          if (segments.length === 0)
            return void 0;
          return segments[segments.length - 1];
        };
      }
      requestPreSpanHook(request) {
        var _a;
        const queueUrl = this.extractQueueUrl(request.commandInput);
        const queueName = this.extractQueueNameFromUrl(queueUrl);
        let spanKind = api_1.SpanKind.CLIENT;
        let spanName;
        const spanAttributes = {
          [semantic_conventions_1.SemanticAttributes.MESSAGING_SYSTEM]: "aws.sqs",
          [semantic_conventions_1.SemanticAttributes.MESSAGING_DESTINATION_KIND]: semantic_conventions_1.MessagingDestinationKindValues.QUEUE,
          [semantic_conventions_1.SemanticAttributes.MESSAGING_DESTINATION]: queueName,
          [semantic_conventions_1.SemanticAttributes.MESSAGING_URL]: queueUrl
        };
        let isIncoming = false;
        switch (request.commandName) {
          case "ReceiveMessage":
            {
              isIncoming = true;
              spanKind = api_1.SpanKind.CONSUMER;
              spanName = `${queueName} receive`;
              spanAttributes[semantic_conventions_1.SemanticAttributes.MESSAGING_OPERATION] = semantic_conventions_1.MessagingOperationValues.RECEIVE;
              request.commandInput.MessageAttributeNames = ((_a = request.commandInput.MessageAttributeNames) !== null && _a !== void 0 ? _a : []).concat(api_1.propagation.fields());
            }
            break;
          case "SendMessage":
          case "SendMessageBatch":
            spanKind = api_1.SpanKind.PRODUCER;
            spanName = `${queueName} send`;
            break;
        }
        return {
          isIncoming,
          spanAttributes,
          spanKind,
          spanName
        };
      }
    };
    exports2.SqsServiceExtension = SqsServiceExtension;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/dynamodb.js
var require_dynamodb = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/dynamodb.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DynamodbServiceExtension = void 0;
    var api_1 = require_src();
    var semantic_conventions_1 = require_src3();
    var DynamodbServiceExtension = class {
      requestPreSpanHook(normalizedRequest) {
        var _a;
        const spanKind = api_1.SpanKind.CLIENT;
        let spanName;
        const isIncoming = false;
        const operation = normalizedRequest.commandName;
        const spanAttributes = {
          [semantic_conventions_1.SemanticAttributes.DB_SYSTEM]: semantic_conventions_1.DbSystemValues.DYNAMODB,
          [semantic_conventions_1.SemanticAttributes.DB_NAME]: (_a = normalizedRequest.commandInput) === null || _a === void 0 ? void 0 : _a.TableName,
          [semantic_conventions_1.SemanticAttributes.DB_OPERATION]: operation,
          [semantic_conventions_1.SemanticAttributes.DB_STATEMENT]: JSON.stringify(normalizedRequest.commandInput)
        };
        if (operation == "BatchGetItem") {
          spanAttributes[semantic_conventions_1.SemanticAttributes.AWS_DYNAMODB_TABLE_NAMES] = Object.keys(normalizedRequest.commandInput.RequestItems);
        }
        return {
          isIncoming,
          spanAttributes,
          spanKind,
          spanName
        };
      }
      responseHook(response, span, tracer, config) {
        var _a;
        const operation = response.request.commandName;
        if (operation === "BatchGetItem") {
          if (Array.isArray((_a = response.data) === null || _a === void 0 ? void 0 : _a.ConsumedCapacity)) {
            span.setAttribute(semantic_conventions_1.SemanticAttributes.AWS_DYNAMODB_CONSUMED_CAPACITY, response.data.ConsumedCapacity.map((x) => JSON.stringify(x)));
          }
        }
      }
    };
    exports2.DynamodbServiceExtension = DynamodbServiceExtension;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/sns.js
var require_sns = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/sns.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SnsServiceExtension = void 0;
    var api_1 = require_src();
    var semantic_conventions_1 = require_src3();
    var MessageAttributes_1 = require_MessageAttributes();
    var SnsServiceExtension = class {
      requestPreSpanHook(request) {
        let spanKind = api_1.SpanKind.CLIENT;
        let spanName = `SNS ${request.commandName}`;
        const spanAttributes = {
          [semantic_conventions_1.SemanticAttributes.MESSAGING_SYSTEM]: "aws.sns"
        };
        if (request.commandName === "Publish") {
          spanKind = api_1.SpanKind.PRODUCER;
          spanAttributes[semantic_conventions_1.SemanticAttributes.MESSAGING_DESTINATION_KIND] = semantic_conventions_1.MessagingDestinationKindValues.TOPIC;
          const { TopicArn, TargetArn, PhoneNumber } = request.commandInput;
          spanAttributes[semantic_conventions_1.SemanticAttributes.MESSAGING_DESTINATION] = this.extractDestinationName(TopicArn, TargetArn, PhoneNumber);
          spanName = `${PhoneNumber ? "phone_number" : spanAttributes[semantic_conventions_1.SemanticAttributes.MESSAGING_DESTINATION]} send`;
        }
        return {
          isIncoming: false,
          spanAttributes,
          spanKind,
          spanName
        };
      }
      requestPostSpanHook(request) {
        var _a;
        if (request.commandName === "Publish") {
          const origMessageAttributes = (_a = request.commandInput["MessageAttributes"]) !== null && _a !== void 0 ? _a : {};
          if (origMessageAttributes) {
            request.commandInput["MessageAttributes"] = MessageAttributes_1.injectPropagationContext(origMessageAttributes);
          }
        }
      }
      responseHook(response, span, tracer, config) {
      }
      extractDestinationName(topicArn, targetArn, phoneNumber) {
        if (topicArn || targetArn) {
          const arn = topicArn !== null && topicArn !== void 0 ? topicArn : targetArn;
          try {
            return arn.substr(arn.lastIndexOf(":") + 1);
          } catch (err) {
            return arn;
          }
        } else if (phoneNumber) {
          return phoneNumber;
        } else {
          return "unknown";
        }
      }
    };
    exports2.SnsServiceExtension = SnsServiceExtension;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/ServicesExtensions.js
var require_ServicesExtensions = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/ServicesExtensions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ServicesExtensions = void 0;
    var sqs_1 = require_sqs();
    var dynamodb_1 = require_dynamodb();
    var sns_1 = require_sns();
    var ServicesExtensions = class {
      constructor() {
        this.services = /* @__PURE__ */ new Map();
        this.services.set("SQS", new sqs_1.SqsServiceExtension());
        this.services.set("SNS", new sns_1.SnsServiceExtension());
        this.services.set("DynamoDB", new dynamodb_1.DynamodbServiceExtension());
      }
      requestPreSpanHook(request) {
        const serviceExtension = this.services.get(request.serviceName);
        if (!serviceExtension)
          return {
            isIncoming: false
          };
        return serviceExtension.requestPreSpanHook(request);
      }
      requestPostSpanHook(request) {
        const serviceExtension = this.services.get(request.serviceName);
        if (!(serviceExtension === null || serviceExtension === void 0 ? void 0 : serviceExtension.requestPostSpanHook))
          return;
        return serviceExtension.requestPostSpanHook(request);
      }
      responseHook(response, span, tracer, config) {
        var _a;
        const serviceExtension = this.services.get(response.request.serviceName);
        (_a = serviceExtension === null || serviceExtension === void 0 ? void 0 : serviceExtension.responseHook) === null || _a === void 0 ? void 0 : _a.call(serviceExtension, response, span, tracer, config);
      }
    };
    exports2.ServicesExtensions = ServicesExtensions;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/index.js
var require_services = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/services/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ServicesExtensions = void 0;
    var ServicesExtensions_1 = require_ServicesExtensions();
    Object.defineProperty(exports2, "ServicesExtensions", { enumerable: true, get: function() {
      return ServicesExtensions_1.ServicesExtensions;
    } });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/version.js
var require_version3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.5.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/utils.js
var require_utils4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.bindPromise = exports2.extractAttributesFromNormalizedRequest = exports2.normalizeV3Request = exports2.normalizeV2Request = exports2.removeSuffixFromStringIfExists = void 0;
    var api_1 = require_src();
    var semantic_conventions_1 = require_src3();
    var enums_1 = require_enums2();
    var toPascalCase = (str) => typeof str === "string" ? str.charAt(0).toUpperCase() + str.slice(1) : str;
    var removeSuffixFromStringIfExists = (str, suffixToRemove) => {
      const suffixLength = suffixToRemove.length;
      return (str === null || str === void 0 ? void 0 : str.slice(-suffixLength)) === suffixToRemove ? str.slice(0, str.length - suffixLength) : str;
    };
    exports2.removeSuffixFromStringIfExists = removeSuffixFromStringIfExists;
    var normalizeV2Request = (awsV2Request) => {
      var _a, _b, _c, _d, _e;
      const service = (_a = awsV2Request) === null || _a === void 0 ? void 0 : _a.service;
      return {
        serviceName: (_c = (_b = service === null || service === void 0 ? void 0 : service.api) === null || _b === void 0 ? void 0 : _b.serviceId) === null || _c === void 0 ? void 0 : _c.replace(/\s+/g, ""),
        commandName: toPascalCase((_d = awsV2Request) === null || _d === void 0 ? void 0 : _d.operation),
        commandInput: awsV2Request.params,
        region: (_e = service === null || service === void 0 ? void 0 : service.config) === null || _e === void 0 ? void 0 : _e.region
      };
    };
    exports2.normalizeV2Request = normalizeV2Request;
    var normalizeV3Request = (serviceName, commandNameWithSuffix, commandInput, region) => {
      return {
        serviceName: serviceName === null || serviceName === void 0 ? void 0 : serviceName.replace(/\s+/g, ""),
        commandName: exports2.removeSuffixFromStringIfExists(commandNameWithSuffix, "Command"),
        commandInput,
        region
      };
    };
    exports2.normalizeV3Request = normalizeV3Request;
    var extractAttributesFromNormalizedRequest = (normalizedRequest) => {
      return {
        [semantic_conventions_1.SemanticAttributes.RPC_SYSTEM]: "aws-api",
        [semantic_conventions_1.SemanticAttributes.RPC_METHOD]: normalizedRequest.commandName,
        [semantic_conventions_1.SemanticAttributes.RPC_SERVICE]: normalizedRequest.serviceName,
        [enums_1.AttributeNames.AWS_REGION]: normalizedRequest.region
      };
    };
    exports2.extractAttributesFromNormalizedRequest = extractAttributesFromNormalizedRequest;
    var bindPromise = (target, contextForCallbacks, rebindCount = 1) => {
      const origThen = target.then;
      target.then = function(onFulfilled, onRejected) {
        const newOnFulfilled = api_1.context.bind(contextForCallbacks, onFulfilled);
        const newOnRejected = api_1.context.bind(contextForCallbacks, onRejected);
        const patchedPromise = origThen.call(this, newOnFulfilled, newOnRejected);
        return rebindCount > 1 ? exports2.bindPromise(patchedPromise, contextForCallbacks, rebindCount - 1) : patchedPromise;
      };
      return target;
    };
    exports2.bindPromise = bindPromise;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/aws-sdk.js
var require_aws_sdk = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/aws-sdk.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AwsInstrumentation = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    var enums_1 = require_enums2();
    var services_1 = require_services();
    var version_1 = require_version3();
    var instrumentation_1 = require_src13();
    var utils_1 = require_utils4();
    var semantic_conventions_1 = require_src3();
    var V3_CLIENT_CONFIG_KEY = Symbol("opentelemetry.instrumentation.aws-sdk.client.config");
    var REQUEST_SPAN_KEY = Symbol("opentelemetry.instrumentation.aws-sdk.span");
    var AwsInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(config = {}) {
        super("@opentelemetry/instrumentation-aws-sdk", version_1.VERSION, Object.assign({}, config));
        this.servicesExtensions = new services_1.ServicesExtensions();
      }
      setConfig(config = {}) {
        this._config = Object.assign({}, config);
      }
      init() {
        const v3MiddlewareStackFileOldVersions = new instrumentation_1.InstrumentationNodeModuleFile("@aws-sdk/middleware-stack/dist/cjs/MiddlewareStack.js", [">=3.1.0 <3.35.0"], this.patchV3ConstructStack.bind(this), this.unpatchV3ConstructStack.bind(this));
        const v3MiddlewareStackFileNewVersions = new instrumentation_1.InstrumentationNodeModuleFile("@aws-sdk/middleware-stack/dist-cjs/MiddlewareStack.js", [">=3.35.0"], this.patchV3ConstructStack.bind(this), this.unpatchV3ConstructStack.bind(this));
        const v3MiddlewareStack = new instrumentation_1.InstrumentationNodeModuleDefinition("@aws-sdk/middleware-stack", ["^3.1.0"], void 0, void 0, [
          v3MiddlewareStackFileOldVersions,
          v3MiddlewareStackFileNewVersions
        ]);
        const v3SmithyClient = new instrumentation_1.InstrumentationNodeModuleDefinition("@aws-sdk/smithy-client", ["^3.1.0"], this.patchV3SmithyClient.bind(this), this.unpatchV3SmithyClient.bind(this));
        const v2Request = new instrumentation_1.InstrumentationNodeModuleFile("aws-sdk/lib/core.js", ["^2.308.0"], this.patchV2.bind(this), this.unpatchV2.bind(this));
        const v2Module = new instrumentation_1.InstrumentationNodeModuleDefinition("aws-sdk", ["^2.308.0"], void 0, void 0, [v2Request]);
        return [v2Module, v3MiddlewareStack, v3SmithyClient];
      }
      patchV3ConstructStack(moduleExports, moduleVersion) {
        api_1.diag.debug("aws-sdk instrumentation: applying patch to aws-sdk v3 constructStack");
        this._wrap(moduleExports, "constructStack", this._getV3ConstructStackPatch.bind(this, moduleVersion));
        return moduleExports;
      }
      unpatchV3ConstructStack(moduleExports) {
        api_1.diag.debug("aws-sdk instrumentation: applying unpatch to aws-sdk v3 constructStack");
        this._unwrap(moduleExports, "constructStack");
        return moduleExports;
      }
      patchV3SmithyClient(moduleExports) {
        api_1.diag.debug("aws-sdk instrumentation: applying patch to aws-sdk v3 client send");
        this._wrap(moduleExports.Client.prototype, "send", this._getV3SmithyClientSendPatch.bind(this));
        return moduleExports;
      }
      unpatchV3SmithyClient(moduleExports) {
        api_1.diag.debug("aws-sdk instrumentation: applying patch to aws-sdk v3 constructStack");
        this._unwrap(moduleExports.Client.prototype, "send");
        return moduleExports;
      }
      patchV2(moduleExports, moduleVersion) {
        api_1.diag.debug(`aws-sdk instrumentation: applying patch to ${AwsInstrumentation2.component}`);
        this.unpatchV2(moduleExports);
        this._wrap(moduleExports === null || moduleExports === void 0 ? void 0 : moduleExports.Request.prototype, "send", this._getRequestSendPatch.bind(this, moduleVersion));
        this._wrap(moduleExports === null || moduleExports === void 0 ? void 0 : moduleExports.Request.prototype, "promise", this._getRequestPromisePatch.bind(this, moduleVersion));
        return moduleExports;
      }
      unpatchV2(moduleExports) {
        if (instrumentation_1.isWrapped(moduleExports === null || moduleExports === void 0 ? void 0 : moduleExports.Request.prototype.send)) {
          this._unwrap(moduleExports.Request.prototype, "send");
        }
        if (instrumentation_1.isWrapped(moduleExports === null || moduleExports === void 0 ? void 0 : moduleExports.Request.prototype.promise)) {
          this._unwrap(moduleExports.Request.prototype, "promise");
        }
      }
      _startAwsV3Span(normalizedRequest, metadata) {
        var _a;
        const name = (_a = metadata.spanName) !== null && _a !== void 0 ? _a : `${normalizedRequest.serviceName}.${normalizedRequest.commandName}`;
        const newSpan = this.tracer.startSpan(name, {
          kind: metadata.spanKind,
          attributes: Object.assign(Object.assign({}, utils_1.extractAttributesFromNormalizedRequest(normalizedRequest)), metadata.spanAttributes)
        });
        return newSpan;
      }
      _startAwsV2Span(request, metadata, normalizedRequest) {
        var _a, _b, _c, _d, _e;
        const operation = request.operation;
        const service = request.service;
        const serviceIdentifier = service === null || service === void 0 ? void 0 : service.serviceIdentifier;
        const name = (_a = metadata.spanName) !== null && _a !== void 0 ? _a : `${normalizedRequest.serviceName}.${normalizedRequest.commandName}`;
        const newSpan = this.tracer.startSpan(name, {
          kind: (_b = metadata.spanKind) !== null && _b !== void 0 ? _b : api_1.SpanKind.CLIENT,
          attributes: Object.assign(Object.assign({ [enums_1.AttributeNames.AWS_OPERATION]: operation, [enums_1.AttributeNames.AWS_SIGNATURE_VERSION]: (_c = service === null || service === void 0 ? void 0 : service.config) === null || _c === void 0 ? void 0 : _c.signatureVersion, [enums_1.AttributeNames.AWS_SERVICE_API]: (_d = service === null || service === void 0 ? void 0 : service.api) === null || _d === void 0 ? void 0 : _d.className, [enums_1.AttributeNames.AWS_SERVICE_IDENTIFIER]: serviceIdentifier, [enums_1.AttributeNames.AWS_SERVICE_NAME]: (_e = service === null || service === void 0 ? void 0 : service.api) === null || _e === void 0 ? void 0 : _e.abbreviation }, utils_1.extractAttributesFromNormalizedRequest(normalizedRequest)), metadata.spanAttributes)
        });
        return newSpan;
      }
      _callUserPreRequestHook(span, request, moduleVersion) {
        var _a;
        if ((_a = this._config) === null || _a === void 0 ? void 0 : _a.preRequestHook) {
          const requestInfo = {
            moduleVersion,
            request
          };
          instrumentation_1.safeExecuteInTheMiddle(() => this._config.preRequestHook(span, requestInfo), (e) => {
            if (e)
              api_1.diag.error(`${AwsInstrumentation2.component} instrumentation: preRequestHook error`, e);
          }, true);
        }
      }
      _callUserResponseHook(span, response) {
        var _a;
        const responseHook = (_a = this._config) === null || _a === void 0 ? void 0 : _a.responseHook;
        if (!responseHook)
          return;
        const responseInfo = {
          response
        };
        instrumentation_1.safeExecuteInTheMiddle(() => responseHook(span, responseInfo), (e) => {
          if (e)
            api_1.diag.error(`${AwsInstrumentation2.component} instrumentation: responseHook error`, e);
        }, true);
      }
      _registerV2CompletedEvent(span, v2Request, normalizedRequest, completedEventContext) {
        const self2 = this;
        v2Request.on("complete", (response) => {
          api_1.context.with(completedEventContext, () => {
            var _a;
            if (!v2Request[REQUEST_SPAN_KEY]) {
              return;
            }
            delete v2Request[REQUEST_SPAN_KEY];
            const normalizedResponse = {
              data: response.data,
              request: normalizedRequest
            };
            self2._callUserResponseHook(span, normalizedResponse);
            if (response.error) {
              span.setAttribute(enums_1.AttributeNames.AWS_ERROR, response.error);
            } else {
              this.servicesExtensions.responseHook(normalizedResponse, span, self2.tracer, self2._config);
            }
            span.setAttribute(enums_1.AttributeNames.AWS_REQUEST_ID, response.requestId);
            const httpStatusCode = (_a = response.httpResponse) === null || _a === void 0 ? void 0 : _a.statusCode;
            if (httpStatusCode) {
              span.setAttribute(semantic_conventions_1.SemanticAttributes.HTTP_STATUS_CODE, httpStatusCode);
            }
            span.end();
          });
        });
      }
      _getV3ConstructStackPatch(moduleVersion, original) {
        const self2 = this;
        return function constructStack(...args) {
          const stack = original.apply(this, args);
          self2.patchV3MiddlewareStack(moduleVersion, stack);
          return stack;
        };
      }
      _getV3SmithyClientSendPatch(original) {
        return function send(command, ...args) {
          command[V3_CLIENT_CONFIG_KEY] = this.config;
          return original.apply(this, [command, ...args]);
        };
      }
      patchV3MiddlewareStack(moduleVersion, middlewareStackToPatch) {
        if (!instrumentation_1.isWrapped(middlewareStackToPatch.resolve)) {
          this._wrap(middlewareStackToPatch, "resolve", this._getV3MiddlewareStackResolvePatch.bind(this, moduleVersion));
        }
        this._wrap(middlewareStackToPatch, "clone", this._getV3MiddlewareStackClonePatch.bind(this, moduleVersion));
        this._wrap(middlewareStackToPatch, "concat", this._getV3MiddlewareStackClonePatch.bind(this, moduleVersion));
      }
      _getV3MiddlewareStackClonePatch(moduleVersion, original) {
        const self2 = this;
        return function(...args) {
          const newStack = original.apply(this, args);
          self2.patchV3MiddlewareStack(moduleVersion, newStack);
          return newStack;
        };
      }
      _getV3MiddlewareStackResolvePatch(moduleVersion, original) {
        const self2 = this;
        return function(_handler, awsExecutionContext) {
          const origHandler = original.call(this, _handler, awsExecutionContext);
          const patchedHandler = function(command) {
            var _a, _b, _c, _d;
            const clientConfig = command[V3_CLIENT_CONFIG_KEY];
            const regionPromise = (_a = clientConfig === null || clientConfig === void 0 ? void 0 : clientConfig.region) === null || _a === void 0 ? void 0 : _a.call(clientConfig);
            const serviceName = (_b = clientConfig === null || clientConfig === void 0 ? void 0 : clientConfig.serviceId) !== null && _b !== void 0 ? _b : utils_1.removeSuffixFromStringIfExists(awsExecutionContext.clientName, "Client");
            const commandName = (_c = awsExecutionContext.commandName) !== null && _c !== void 0 ? _c : (_d = command.constructor) === null || _d === void 0 ? void 0 : _d.name;
            const normalizedRequest = utils_1.normalizeV3Request(serviceName, commandName, command.input, void 0);
            const requestMetadata = self2.servicesExtensions.requestPreSpanHook(normalizedRequest);
            const span = self2._startAwsV3Span(normalizedRequest, requestMetadata);
            const activeContextWithSpan = api_1.trace.setSpan(api_1.context.active(), span);
            const handlerPromise = new Promise((resolve, reject) => {
              Promise.resolve(regionPromise).then((resolvedRegion) => {
                normalizedRequest.region = resolvedRegion;
                span.setAttribute(enums_1.AttributeNames.AWS_REGION, resolvedRegion);
              }).catch((e) => {
                api_1.diag.debug(`${AwsInstrumentation2.component} instrumentation: failed to extract region from async function`, e);
              }).finally(() => {
                self2._callUserPreRequestHook(span, normalizedRequest, moduleVersion);
                const resultPromise = api_1.context.with(activeContextWithSpan, () => {
                  self2.servicesExtensions.requestPostSpanHook(normalizedRequest);
                  return self2._callOriginalFunction(() => origHandler.call(this, command));
                });
                const promiseWithResponseLogic = resultPromise.then((response) => {
                  var _a2, _b2, _c2, _d2, _e, _f;
                  const requestId = (_b2 = (_a2 = response.output) === null || _a2 === void 0 ? void 0 : _a2.$metadata) === null || _b2 === void 0 ? void 0 : _b2.requestId;
                  if (requestId) {
                    span.setAttribute(enums_1.AttributeNames.AWS_REQUEST_ID, requestId);
                  }
                  const httpStatusCode = (_d2 = (_c2 = response.output) === null || _c2 === void 0 ? void 0 : _c2.$metadata) === null || _d2 === void 0 ? void 0 : _d2.httpStatusCode;
                  if (httpStatusCode) {
                    span.setAttribute(semantic_conventions_1.SemanticAttributes.HTTP_STATUS_CODE, httpStatusCode);
                  }
                  const extendedRequestId = (_f = (_e = response.output) === null || _e === void 0 ? void 0 : _e.$metadata) === null || _f === void 0 ? void 0 : _f.extendedRequestId;
                  if (extendedRequestId) {
                    span.setAttribute(enums_1.AttributeNames.AWS_REQUEST_EXTENDED_ID, extendedRequestId);
                  }
                  const normalizedResponse = {
                    data: response.output,
                    request: normalizedRequest
                  };
                  self2.servicesExtensions.responseHook(normalizedResponse, span, self2.tracer, self2._config);
                  self2._callUserResponseHook(span, normalizedResponse);
                  return response;
                }).catch((err) => {
                  const requestId = err === null || err === void 0 ? void 0 : err.RequestId;
                  if (requestId) {
                    span.setAttribute(enums_1.AttributeNames.AWS_REQUEST_ID, requestId);
                  }
                  const extendedRequestId = err === null || err === void 0 ? void 0 : err.extendedRequestId;
                  if (extendedRequestId) {
                    span.setAttribute(enums_1.AttributeNames.AWS_REQUEST_EXTENDED_ID, extendedRequestId);
                  }
                  span.setStatus({
                    code: api_1.SpanStatusCode.ERROR,
                    message: err.message
                  });
                  span.recordException(err);
                  throw err;
                }).finally(() => {
                  span.end();
                });
                promiseWithResponseLogic.then((res) => {
                  resolve(res);
                }).catch((err) => reject(err));
              });
            });
            return requestMetadata.isIncoming ? utils_1.bindPromise(handlerPromise, activeContextWithSpan, 2) : handlerPromise;
          };
          return patchedHandler;
        };
      }
      _getRequestSendPatch(moduleVersion, original) {
        const self2 = this;
        return function(callback) {
          if (this[REQUEST_SPAN_KEY]) {
            return original.call(this, callback);
          }
          const normalizedRequest = utils_1.normalizeV2Request(this);
          const requestMetadata = self2.servicesExtensions.requestPreSpanHook(normalizedRequest);
          const span = self2._startAwsV2Span(this, requestMetadata, normalizedRequest);
          this[REQUEST_SPAN_KEY] = span;
          const activeContextWithSpan = api_1.trace.setSpan(api_1.context.active(), span);
          const callbackWithContext = api_1.context.bind(activeContextWithSpan, callback);
          self2._callUserPreRequestHook(span, normalizedRequest, moduleVersion);
          self2._registerV2CompletedEvent(span, this, normalizedRequest, activeContextWithSpan);
          return api_1.context.with(activeContextWithSpan, () => {
            self2.servicesExtensions.requestPostSpanHook(normalizedRequest);
            return self2._callOriginalFunction(() => original.call(this, callbackWithContext));
          });
        };
      }
      _getRequestPromisePatch(moduleVersion, original) {
        const self2 = this;
        return function(...args) {
          if (this[REQUEST_SPAN_KEY]) {
            return original.apply(this, args);
          }
          const normalizedRequest = utils_1.normalizeV2Request(this);
          const requestMetadata = self2.servicesExtensions.requestPreSpanHook(normalizedRequest);
          const span = self2._startAwsV2Span(this, requestMetadata, normalizedRequest);
          this[REQUEST_SPAN_KEY] = span;
          const activeContextWithSpan = api_1.trace.setSpan(api_1.context.active(), span);
          self2._callUserPreRequestHook(span, normalizedRequest, moduleVersion);
          self2._registerV2CompletedEvent(span, this, normalizedRequest, activeContextWithSpan);
          const origPromise = api_1.context.with(activeContextWithSpan, () => {
            self2.servicesExtensions.requestPostSpanHook(normalizedRequest);
            return self2._callOriginalFunction(() => original.call(this, arguments));
          });
          return requestMetadata.isIncoming ? utils_1.bindPromise(origPromise, activeContextWithSpan) : origPromise;
        };
      }
      _callOriginalFunction(originalFunction) {
        var _a;
        if ((_a = this._config) === null || _a === void 0 ? void 0 : _a.suppressInternalInstrumentation) {
          return api_1.context.with(core_1.suppressTracing(api_1.context.active()), originalFunction);
        } else {
          return originalFunction();
        }
      }
    };
    exports2.AwsInstrumentation = AwsInstrumentation2;
    AwsInstrumentation2.component = "aws-sdk";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/types.js
var require_types10 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/index.js
var require_src15 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-sdk/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_aws_sdk(), exports2);
    __exportStar(require_types10(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsEc2Detector.js
var require_AwsEc2Detector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsEc2Detector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.awsEc2Detector = void 0;
    var resources_1 = require_src6();
    var semantic_conventions_1 = require_src3();
    var http2 = require("http");
    var AwsEc2Detector = class {
      constructor() {
        this.AWS_IDMS_ENDPOINT = "169.254.169.254";
        this.AWS_INSTANCE_TOKEN_DOCUMENT_PATH = "/latest/api/token";
        this.AWS_INSTANCE_IDENTITY_DOCUMENT_PATH = "/latest/dynamic/instance-identity/document";
        this.AWS_INSTANCE_HOST_DOCUMENT_PATH = "/latest/meta-data/hostname";
        this.AWS_METADATA_TTL_HEADER = "X-aws-ec2-metadata-token-ttl-seconds";
        this.AWS_METADATA_TOKEN_HEADER = "X-aws-ec2-metadata-token";
        this.MILLISECOND_TIME_OUT = 5e3;
      }
      async detect(_config) {
        const token = await this._fetchToken();
        const { accountId, instanceId, instanceType, region, availabilityZone } = await this._fetchIdentity(token);
        const hostname = await this._fetchHost(token);
        return new resources_1.Resource({
          [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PROVIDER]: semantic_conventions_1.CloudProviderValues.AWS,
          [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PLATFORM]: semantic_conventions_1.CloudPlatformValues.AWS_EC2,
          [semantic_conventions_1.SemanticResourceAttributes.CLOUD_ACCOUNT_ID]: accountId,
          [semantic_conventions_1.SemanticResourceAttributes.CLOUD_REGION]: region,
          [semantic_conventions_1.SemanticResourceAttributes.CLOUD_AVAILABILITY_ZONE]: availabilityZone,
          [semantic_conventions_1.SemanticResourceAttributes.HOST_ID]: instanceId,
          [semantic_conventions_1.SemanticResourceAttributes.HOST_TYPE]: instanceType,
          [semantic_conventions_1.SemanticResourceAttributes.HOST_NAME]: hostname
        });
      }
      async _fetchToken() {
        const options = {
          host: this.AWS_IDMS_ENDPOINT,
          path: this.AWS_INSTANCE_TOKEN_DOCUMENT_PATH,
          method: "PUT",
          timeout: this.MILLISECOND_TIME_OUT,
          headers: {
            [this.AWS_METADATA_TTL_HEADER]: "60"
          }
        };
        return await this._fetchString(options);
      }
      async _fetchIdentity(token) {
        const options = {
          host: this.AWS_IDMS_ENDPOINT,
          path: this.AWS_INSTANCE_IDENTITY_DOCUMENT_PATH,
          method: "GET",
          timeout: this.MILLISECOND_TIME_OUT,
          headers: {
            [this.AWS_METADATA_TOKEN_HEADER]: token
          }
        };
        const identity = await this._fetchString(options);
        return JSON.parse(identity);
      }
      async _fetchHost(token) {
        const options = {
          host: this.AWS_IDMS_ENDPOINT,
          path: this.AWS_INSTANCE_HOST_DOCUMENT_PATH,
          method: "GET",
          timeout: this.MILLISECOND_TIME_OUT,
          headers: {
            [this.AWS_METADATA_TOKEN_HEADER]: token
          }
        };
        return await this._fetchString(options);
      }
      async _fetchString(options) {
        return new Promise((resolve, reject) => {
          const timeoutId = setTimeout(() => {
            req.abort();
            reject(new Error("EC2 metadata api request timed out."));
          }, 1e3);
          const req = http2.request(options, (res) => {
            clearTimeout(timeoutId);
            const { statusCode } = res;
            res.setEncoding("utf8");
            let rawData = "";
            res.on("data", (chunk) => rawData += chunk);
            res.on("end", () => {
              if (statusCode && statusCode >= 200 && statusCode < 300) {
                try {
                  resolve(rawData);
                } catch (e) {
                  reject(e);
                }
              } else {
                reject(new Error("Failed to load page, status code: " + statusCode));
              }
            });
          });
          req.on("error", (err) => {
            clearTimeout(timeoutId);
            reject(err);
          });
          req.end();
        });
      }
    };
    exports2.awsEc2Detector = new AwsEc2Detector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsBeanstalkDetector.js
var require_AwsBeanstalkDetector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsBeanstalkDetector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.awsBeanstalkDetector = exports2.AwsBeanstalkDetector = void 0;
    var api_1 = require_src();
    var resources_1 = require_src6();
    var semantic_conventions_1 = require_src3();
    var fs = require("fs");
    var util = require("util");
    var DEFAULT_BEANSTALK_CONF_PATH = "/var/elasticbeanstalk/xray/environment.conf";
    var WIN_OS_BEANSTALK_CONF_PATH = "C:\\Program Files\\Amazon\\XRay\\environment.conf";
    var AwsBeanstalkDetector = class {
      constructor() {
        if (process.platform === "win32") {
          this.BEANSTALK_CONF_PATH = WIN_OS_BEANSTALK_CONF_PATH;
        } else {
          this.BEANSTALK_CONF_PATH = DEFAULT_BEANSTALK_CONF_PATH;
        }
      }
      async detect(_config) {
        try {
          await AwsBeanstalkDetector.fileAccessAsync(this.BEANSTALK_CONF_PATH, fs.constants.R_OK);
          const rawData = await AwsBeanstalkDetector.readFileAsync(this.BEANSTALK_CONF_PATH, "utf8");
          const parsedData = JSON.parse(rawData);
          return new resources_1.Resource({
            [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PROVIDER]: semantic_conventions_1.CloudProviderValues.AWS,
            [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PLATFORM]: semantic_conventions_1.CloudPlatformValues.AWS_ELASTIC_BEANSTALK,
            [semantic_conventions_1.SemanticResourceAttributes.SERVICE_NAME]: semantic_conventions_1.CloudPlatformValues.AWS_ELASTIC_BEANSTALK,
            [semantic_conventions_1.SemanticResourceAttributes.SERVICE_NAMESPACE]: parsedData.environment_name,
            [semantic_conventions_1.SemanticResourceAttributes.SERVICE_VERSION]: parsedData.version_label,
            [semantic_conventions_1.SemanticResourceAttributes.SERVICE_INSTANCE_ID]: parsedData.deployment_id
          });
        } catch (e) {
          api_1.diag.debug(`AwsBeanstalkDetector failed: ${e.message}`);
          return resources_1.Resource.empty();
        }
      }
    };
    exports2.AwsBeanstalkDetector = AwsBeanstalkDetector;
    AwsBeanstalkDetector.readFileAsync = util.promisify(fs.readFile);
    AwsBeanstalkDetector.fileAccessAsync = util.promisify(fs.access);
    exports2.awsBeanstalkDetector = new AwsBeanstalkDetector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsEcsDetector.js
var require_AwsEcsDetector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsEcsDetector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.awsEcsDetector = exports2.AwsEcsDetector = void 0;
    var api_1 = require_src();
    var resources_1 = require_src6();
    var semantic_conventions_1 = require_src3();
    var util = require("util");
    var fs = require("fs");
    var os = require("os");
    var core_1 = require_src4();
    var AwsEcsDetector = class {
      constructor() {
        this.CONTAINER_ID_LENGTH = 64;
        this.DEFAULT_CGROUP_PATH = "/proc/self/cgroup";
      }
      async detect(_config) {
        const env = core_1.getEnv();
        if (!env.ECS_CONTAINER_METADATA_URI_V4 && !env.ECS_CONTAINER_METADATA_URI) {
          api_1.diag.debug("AwsEcsDetector failed: Process is not on ECS");
          return resources_1.Resource.empty();
        }
        const hostName = os.hostname();
        const containerId = await this._getContainerId();
        return !hostName && !containerId ? resources_1.Resource.empty() : new resources_1.Resource({
          [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PROVIDER]: semantic_conventions_1.CloudProviderValues.AWS,
          [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PLATFORM]: semantic_conventions_1.CloudPlatformValues.AWS_ECS,
          [semantic_conventions_1.SemanticResourceAttributes.CONTAINER_NAME]: hostName || "",
          [semantic_conventions_1.SemanticResourceAttributes.CONTAINER_ID]: containerId || ""
        });
      }
      async _getContainerId() {
        try {
          const rawData = await AwsEcsDetector.readFileAsync(this.DEFAULT_CGROUP_PATH, "utf8");
          const splitData = rawData.trim().split("\n");
          for (const str of splitData) {
            if (str.length > this.CONTAINER_ID_LENGTH) {
              return str.substring(str.length - this.CONTAINER_ID_LENGTH);
            }
          }
        } catch (e) {
          api_1.diag.warn(`AwsEcsDetector failed to read container ID: ${e.message}`);
        }
        return void 0;
      }
    };
    exports2.AwsEcsDetector = AwsEcsDetector;
    AwsEcsDetector.readFileAsync = util.promisify(fs.readFile);
    exports2.awsEcsDetector = new AwsEcsDetector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsEksDetector.js
var require_AwsEksDetector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsEksDetector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.awsEksDetector = exports2.AwsEksDetector = void 0;
    var resources_1 = require_src6();
    var semantic_conventions_1 = require_src3();
    var https = require("https");
    var fs = require("fs");
    var util = require("util");
    var api_1 = require_src();
    var AwsEksDetector = class {
      constructor() {
        this.K8S_SVC_URL = "kubernetes.default.svc";
        this.K8S_TOKEN_PATH = "/var/run/secrets/kubernetes.io/serviceaccount/token";
        this.K8S_CERT_PATH = "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt";
        this.AUTH_CONFIGMAP_PATH = "/api/v1/namespaces/kube-system/configmaps/aws-auth";
        this.CW_CONFIGMAP_PATH = "/api/v1/namespaces/amazon-cloudwatch/configmaps/cluster-info";
        this.CONTAINER_ID_LENGTH = 64;
        this.DEFAULT_CGROUP_PATH = "/proc/self/cgroup";
        this.TIMEOUT_MS = 2e3;
        this.UTF8_UNICODE = "utf8";
      }
      async detect(_config) {
        try {
          await AwsEksDetector.fileAccessAsync(this.K8S_TOKEN_PATH);
          const k8scert = await AwsEksDetector.readFileAsync(this.K8S_CERT_PATH);
          if (!await this._isEks(k8scert)) {
            return resources_1.Resource.empty();
          }
          const containerId = await this._getContainerId();
          const clusterName = await this._getClusterName(k8scert);
          return !containerId && !clusterName ? resources_1.Resource.empty() : new resources_1.Resource({
            [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PROVIDER]: semantic_conventions_1.CloudProviderValues.AWS,
            [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PLATFORM]: semantic_conventions_1.CloudPlatformValues.AWS_EKS,
            [semantic_conventions_1.SemanticResourceAttributes.K8S_CLUSTER_NAME]: clusterName || "",
            [semantic_conventions_1.SemanticResourceAttributes.CONTAINER_ID]: containerId || ""
          });
        } catch (e) {
          api_1.diag.warn("Process is not running on K8S", e);
          return resources_1.Resource.empty();
        }
      }
      async _isEks(cert) {
        const options = {
          ca: cert,
          headers: {
            Authorization: await this._getK8sCredHeader()
          },
          hostname: this.K8S_SVC_URL,
          method: "GET",
          path: this.AUTH_CONFIGMAP_PATH,
          timeout: this.TIMEOUT_MS
        };
        return !!await this._fetchString(options);
      }
      async _getClusterName(cert) {
        const options = {
          ca: cert,
          headers: {
            Authorization: await this._getK8sCredHeader()
          },
          host: this.K8S_SVC_URL,
          method: "GET",
          path: this.CW_CONFIGMAP_PATH,
          timeout: this.TIMEOUT_MS
        };
        const response = await this._fetchString(options);
        try {
          return JSON.parse(response).data["cluster.name"];
        } catch (e) {
          api_1.diag.warn("Cannot get cluster name on EKS", e);
        }
        return "";
      }
      async _getK8sCredHeader() {
        try {
          const content = await AwsEksDetector.readFileAsync(this.K8S_TOKEN_PATH, this.UTF8_UNICODE);
          return "Bearer " + content;
        } catch (e) {
          api_1.diag.warn("Unable to read Kubernetes client token.", e);
        }
        return "";
      }
      async _getContainerId() {
        try {
          const rawData = await AwsEksDetector.readFileAsync(this.DEFAULT_CGROUP_PATH, this.UTF8_UNICODE);
          const splitData = rawData.trim().split("\n");
          for (const str of splitData) {
            if (str.length > this.CONTAINER_ID_LENGTH) {
              return str.substring(str.length - this.CONTAINER_ID_LENGTH);
            }
          }
        } catch (e) {
          api_1.diag.warn(`AwsEksDetector failed to read container ID: ${e.message}`);
        }
        return void 0;
      }
      async _fetchString(options) {
        return await new Promise((resolve, reject) => {
          const timeoutId = setTimeout(() => {
            req.abort();
            reject(new Error("EKS metadata api request timed out."));
          }, 2e3);
          const req = https.request(options, (res) => {
            clearTimeout(timeoutId);
            const { statusCode } = res;
            res.setEncoding(this.UTF8_UNICODE);
            let rawData = "";
            res.on("data", (chunk) => rawData += chunk);
            res.on("end", () => {
              if (statusCode && statusCode >= 200 && statusCode < 300) {
                try {
                  resolve(rawData);
                } catch (e) {
                  reject(e);
                }
              } else {
                reject(new Error("Failed to load page, status code: " + statusCode));
              }
            });
          });
          req.on("error", (err) => {
            clearTimeout(timeoutId);
            reject(err);
          });
          req.end();
        });
      }
    };
    exports2.AwsEksDetector = AwsEksDetector;
    AwsEksDetector.readFileAsync = util.promisify(fs.readFile);
    AwsEksDetector.fileAccessAsync = util.promisify(fs.access);
    exports2.awsEksDetector = new AwsEksDetector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsLambdaDetector.js
var require_AwsLambdaDetector = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/AwsLambdaDetector.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.awsLambdaDetector = exports2.AwsLambdaDetector = void 0;
    var resources_1 = require_src6();
    var semantic_conventions_1 = require_src3();
    var AwsLambdaDetector = class {
      async detect(_config) {
        const functionName = process.env.AWS_LAMBDA_FUNCTION_NAME;
        if (!functionName) {
          return resources_1.Resource.empty();
        }
        const functionVersion = process.env.AWS_LAMBDA_FUNCTION_VERSION;
        const region = process.env.AWS_REGION;
        const attributes = {
          [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PROVIDER]: String(semantic_conventions_1.CloudProviderValues.AWS),
          [semantic_conventions_1.SemanticResourceAttributes.CLOUD_PLATFORM]: String(semantic_conventions_1.CloudPlatformValues.AWS_LAMBDA)
        };
        if (region) {
          attributes[semantic_conventions_1.SemanticResourceAttributes.CLOUD_REGION] = region;
        }
        if (functionName) {
          attributes[semantic_conventions_1.SemanticResourceAttributes.FAAS_NAME] = functionName;
        }
        if (functionVersion) {
          attributes[semantic_conventions_1.SemanticResourceAttributes.FAAS_VERSION] = functionVersion;
        }
        return new resources_1.Resource(attributes);
      }
    };
    exports2.AwsLambdaDetector = AwsLambdaDetector;
    exports2.awsLambdaDetector = new AwsLambdaDetector();
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/index.js
var require_detectors2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/detectors/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_AwsEc2Detector(), exports2);
    __exportStar(require_AwsBeanstalkDetector(), exports2);
    __exportStar(require_AwsEcsDetector(), exports2);
    __exportStar(require_AwsEksDetector(), exports2);
    __exportStar(require_AwsLambdaDetector(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/index.js
var require_src16 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/resource-detector-aws/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_detectors2(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/enums/AttributeNames.js
var require_AttributeNames = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/enums/AttributeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["DNS_ERROR_CODE"] = "dns.error_code";
      AttributeNames2["DNS_ERROR_NAME"] = "dns.error_name";
      AttributeNames2["DNS_ERROR_MESSAGE"] = "dns.error_message";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/utils.js
var require_utils5 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isIgnored = exports2.satisfiesPattern = exports2.setLookupAttributes = exports2.getOperationName = exports2.getFamilyAttribute = exports2.setError = void 0;
    var api_1 = require_src();
    var AttributeNames_1 = require_AttributeNames();
    var setError = (err, span, nodeVersion) => {
      const { code, message, name } = err;
      const attributes = {
        [AttributeNames_1.AttributeNames.DNS_ERROR_MESSAGE]: message,
        [AttributeNames_1.AttributeNames.DNS_ERROR_NAME]: name
      };
      if (nodeVersion.startsWith("v12")) {
        attributes[AttributeNames_1.AttributeNames.DNS_ERROR_CODE] = code;
      }
      span.setAttributes(attributes);
      span.setStatus({
        code: api_1.SpanStatusCode.ERROR,
        message
      });
    };
    exports2.setError = setError;
    var getFamilyAttribute = (family, index) => {
      return index ? `peer[${index}].ipv${family}` : `peer.ipv${family}`;
    };
    exports2.getFamilyAttribute = getFamilyAttribute;
    var getOperationName = (funcName, service) => {
      return service ? `dns.${service}/${funcName}` : `dns.${funcName}`;
    };
    exports2.getOperationName = getOperationName;
    var setLookupAttributes = (span, address, family) => {
      const attributes = {};
      const isObject = typeof address === "object";
      let addresses = address;
      if (!isObject) {
        addresses = [{ address, family }];
      } else if (!(addresses instanceof Array)) {
        addresses = [
          {
            address: address.address,
            family: address.family
          }
        ];
      }
      addresses.forEach((_, i) => {
        const peerAttrFormat = exports2.getFamilyAttribute(_.family, i);
        attributes[peerAttrFormat] = _.address;
      });
      span.setAttributes(attributes);
    };
    exports2.setLookupAttributes = setLookupAttributes;
    var satisfiesPattern = (constant, pattern) => {
      if (typeof pattern === "string") {
        return pattern === constant;
      } else if (pattern instanceof RegExp) {
        return pattern.test(constant);
      } else if (typeof pattern === "function") {
        return pattern(constant);
      } else {
        throw new TypeError("Pattern is in unsupported datatype");
      }
    };
    exports2.satisfiesPattern = satisfiesPattern;
    var isIgnored = (constant, list, onException) => {
      if (!list) {
        return false;
      }
      try {
        for (const pattern of list) {
          if (exports2.satisfiesPattern(constant, pattern)) {
            return true;
          }
        }
      } catch (e) {
        if (onException) {
          onException(e);
        }
      }
      return false;
    };
    exports2.isIgnored = isIgnored;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/version.js
var require_version4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.27.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/instrumentation.js
var require_instrumentation3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DnsInstrumentation = void 0;
    var api_1 = require_src();
    var instrumentation_1 = require_src13();
    var semver = require_semver3();
    var utils = require_utils5();
    var version_1 = require_version4();
    var DnsInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(_config = {}) {
        super("@opentelemetry/instrumentation-dns", version_1.VERSION, _config);
        this._config = _config;
      }
      init() {
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("dns", ["*"], (moduleExports) => {
            api_1.diag.debug("Applying patch for dns");
            if (instrumentation_1.isWrapped(moduleExports.lookup)) {
              this._unwrap(moduleExports, "lookup");
            }
            this._wrap(moduleExports, "lookup", this._getLookup());
            if (semver.gte(process.version, "10.6.0")) {
              this._wrap(moduleExports.promises, "lookup", this._getLookup());
            }
            return moduleExports;
          }, (moduleExports) => {
            if (moduleExports === void 0)
              return;
            api_1.diag.debug("Removing patch for dns");
            this._unwrap(moduleExports, "lookup");
            if (semver.gte(process.version, "10.6.0")) {
              this._unwrap(moduleExports.promises, "lookup");
            }
          })
        ];
      }
      _getLookup() {
        return (original) => {
          return this._getPatchLookupFunction(original);
        };
      }
      _getPatchLookupFunction(original) {
        api_1.diag.debug("patch lookup function");
        const plugin = this;
        return function patchedLookup(hostname, ...args) {
          if (utils.isIgnored(hostname, plugin._config.ignoreHostnames, (e) => api_1.diag.error("caught ignoreHostname error: ", e))) {
            return original.apply(this, [hostname, ...args]);
          }
          const argsCount = args.length;
          api_1.diag.debug("wrap lookup callback function and starts span");
          const name = utils.getOperationName("lookup");
          const span = plugin.tracer.startSpan(name, {
            kind: api_1.SpanKind.CLIENT
          });
          const originalCallback = args[argsCount - 1];
          if (typeof originalCallback === "function") {
            args[argsCount - 1] = plugin._wrapLookupCallback(originalCallback, span);
            return instrumentation_1.safeExecuteInTheMiddle(() => original.apply(this, [hostname, ...args]), (error) => {
              if (error != null) {
                utils.setError(error, span, process.version);
                span.end();
              }
            });
          } else {
            const promise = instrumentation_1.safeExecuteInTheMiddle(() => original.apply(this, [
              hostname,
              ...args
            ]), (error) => {
              if (error != null) {
                utils.setError(error, span, process.version);
                span.end();
              }
            });
            promise.then((result) => {
              utils.setLookupAttributes(span, result);
              span.end();
            }, (e) => {
              utils.setError(e, span, process.version);
              span.end();
            });
            return promise;
          }
        };
      }
      _wrapLookupCallback(original, span) {
        return function wrappedLookupCallback(err, address, family) {
          api_1.diag.debug("executing wrapped lookup callback function");
          if (err !== null) {
            utils.setError(err, span, process.version);
          } else {
            utils.setLookupAttributes(span, address, family);
          }
          span.end();
          api_1.diag.debug("executing original lookup callback function");
          return original.apply(this, arguments);
        };
      }
    };
    exports2.DnsInstrumentation = DnsInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/index.js
var require_src17 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-dns/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation3(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/types.js
var require_types11 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2._LAYERS_STORE_PROPERTY = void 0;
    var _1 = require_src18();
    exports2._LAYERS_STORE_PROPERTY = "__ot_middlewares";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/enums/ExpressLayerType.js
var require_ExpressLayerType = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/enums/ExpressLayerType.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ExpressLayerType = void 0;
    var ExpressLayerType;
    (function(ExpressLayerType2) {
      ExpressLayerType2["ROUTER"] = "router";
      ExpressLayerType2["MIDDLEWARE"] = "middleware";
      ExpressLayerType2["REQUEST_HANDLER"] = "request_handler";
    })(ExpressLayerType = exports2.ExpressLayerType || (exports2.ExpressLayerType = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/enums/AttributeNames.js
var require_AttributeNames2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/enums/AttributeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["EXPRESS_TYPE"] = "express.type";
      AttributeNames2["EXPRESS_NAME"] = "express.name";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/utils.js
var require_utils6 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isLayerIgnored = exports2.getLayerMetadata = exports2.storeLayerPath = void 0;
    var types_1 = require_types11();
    var ExpressLayerType_1 = require_ExpressLayerType();
    var AttributeNames_1 = require_AttributeNames2();
    var storeLayerPath = (request, value) => {
      if (Array.isArray(request[types_1._LAYERS_STORE_PROPERTY]) === false) {
        Object.defineProperty(request, types_1._LAYERS_STORE_PROPERTY, {
          enumerable: false,
          value: []
        });
      }
      if (value === void 0)
        return;
      request[types_1._LAYERS_STORE_PROPERTY].push(value);
    };
    exports2.storeLayerPath = storeLayerPath;
    var getLayerMetadata = (layer, layerPath) => {
      if (layer.name === "router") {
        return {
          attributes: {
            [AttributeNames_1.AttributeNames.EXPRESS_NAME]: layerPath,
            [AttributeNames_1.AttributeNames.EXPRESS_TYPE]: ExpressLayerType_1.ExpressLayerType.ROUTER
          },
          name: `router - ${layerPath}`
        };
      } else if (layer.name === "bound dispatch") {
        return {
          attributes: {
            [AttributeNames_1.AttributeNames.EXPRESS_NAME]: layerPath !== null && layerPath !== void 0 ? layerPath : "request handler",
            [AttributeNames_1.AttributeNames.EXPRESS_TYPE]: ExpressLayerType_1.ExpressLayerType.REQUEST_HANDLER
          },
          name: `request handler${layer.path ? ` - ${layerPath}` : ""}`
        };
      } else {
        return {
          attributes: {
            [AttributeNames_1.AttributeNames.EXPRESS_NAME]: layer.name,
            [AttributeNames_1.AttributeNames.EXPRESS_TYPE]: ExpressLayerType_1.ExpressLayerType.MIDDLEWARE
          },
          name: `middleware - ${layer.name}`
        };
      }
    };
    exports2.getLayerMetadata = getLayerMetadata;
    var satisfiesPattern = (constant, pattern) => {
      if (typeof pattern === "string") {
        return pattern === constant;
      } else if (pattern instanceof RegExp) {
        return pattern.test(constant);
      } else if (typeof pattern === "function") {
        return pattern(constant);
      } else {
        throw new TypeError("Pattern is in unsupported datatype");
      }
    };
    var isLayerIgnored = (name, type, config) => {
      var _a;
      if (Array.isArray(config === null || config === void 0 ? void 0 : config.ignoreLayersType) && ((_a = config === null || config === void 0 ? void 0 : config.ignoreLayersType) === null || _a === void 0 ? void 0 : _a.includes(type))) {
        return true;
      }
      if (Array.isArray(config === null || config === void 0 ? void 0 : config.ignoreLayers) === false)
        return false;
      try {
        for (const pattern of config.ignoreLayers) {
          if (satisfiesPattern(name, pattern)) {
            return true;
          }
        }
      } catch (e) {
      }
      return false;
    };
    exports2.isLayerIgnored = isLayerIgnored;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/version.js
var require_version5 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.27.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/instrumentation.js
var require_instrumentation4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ExpressInstrumentation = exports2.kLayerPatched = void 0;
    var core_1 = require_src4();
    var api_1 = require_src();
    var types_1 = require_types11();
    var ExpressLayerType_1 = require_ExpressLayerType();
    var AttributeNames_1 = require_AttributeNames2();
    var utils_1 = require_utils6();
    var version_1 = require_version5();
    var instrumentation_1 = require_src13();
    var semantic_conventions_1 = require_src3();
    exports2.kLayerPatched = Symbol("express-layer-patched");
    var ExpressInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(config = {}) {
        super("@opentelemetry/instrumentation-express", version_1.VERSION, Object.assign({}, config));
      }
      init() {
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("express", ["^4.0.0"], (moduleExports, moduleVersion) => {
            api_1.diag.debug(`Applying patch for express@${moduleVersion}`);
            const routerProto = moduleExports.Router;
            if (instrumentation_1.isWrapped(routerProto.route)) {
              this._unwrap(routerProto, "route");
            }
            this._wrap(routerProto, "route", this._getRoutePatch());
            if (instrumentation_1.isWrapped(routerProto.use)) {
              this._unwrap(routerProto, "use");
            }
            this._wrap(routerProto, "use", this._getRouterUsePatch());
            if (instrumentation_1.isWrapped(moduleExports.application.use)) {
              this._unwrap(moduleExports.application, "use");
            }
            this._wrap(moduleExports.application, "use", this._getAppUsePatch());
            return moduleExports;
          }, (moduleExports, moduleVersion) => {
            if (moduleExports === void 0)
              return;
            api_1.diag.debug(`Removing patch for express@${moduleVersion}`);
            this._unwrap(moduleExports.Router.prototype, "route");
            this._unwrap(moduleExports.Router.prototype, "use");
            this._unwrap(moduleExports.application.prototype, "use");
          })
        ];
      }
      _getRoutePatch() {
        const instrumentation = this;
        return function(original) {
          return function route_trace(...args) {
            const route = original.apply(this, args);
            const layer = this.stack[this.stack.length - 1];
            instrumentation._applyPatch(layer, typeof args[0] === "string" ? args[0] : void 0);
            return route;
          };
        };
      }
      _getRouterUsePatch() {
        const instrumentation = this;
        return function(original) {
          return function use(...args) {
            const route = original.apply(this, args);
            const layer = this.stack[this.stack.length - 1];
            instrumentation._applyPatch(layer, typeof args[0] === "string" ? args[0] : void 0);
            return route;
          };
        };
      }
      _getAppUsePatch() {
        const instrumentation = this;
        return function(original) {
          return function use(...args) {
            const route = original.apply(this, args);
            const layer = this._router.stack[this._router.stack.length - 1];
            instrumentation._applyPatch.call(instrumentation, layer, typeof args[0] === "string" ? args[0] : void 0);
            return route;
          };
        };
      }
      _applyPatch(layer, layerPath) {
        const instrumentation = this;
        if (layer[exports2.kLayerPatched] === true)
          return;
        layer[exports2.kLayerPatched] = true;
        this._wrap(layer, "handle", (original) => {
          if (original.length === 4)
            return original;
          return function(req, res) {
            utils_1.storeLayerPath(req, layerPath);
            const route = req[types_1._LAYERS_STORE_PROPERTY].filter((path) => path !== "/" && path !== "/*").join("");
            const attributes = {
              [semantic_conventions_1.SemanticAttributes.HTTP_ROUTE]: route.length > 0 ? route : "/"
            };
            const metadata = utils_1.getLayerMetadata(layer, layerPath);
            const type = metadata.attributes[AttributeNames_1.AttributeNames.EXPRESS_TYPE];
            const rpcMetadata = core_1.getRPCMetadata(api_1.context.active());
            if (metadata.attributes[AttributeNames_1.AttributeNames.EXPRESS_TYPE] === ExpressLayerType_1.ExpressLayerType.REQUEST_HANDLER && (rpcMetadata === null || rpcMetadata === void 0 ? void 0 : rpcMetadata.type) === core_1.RPCType.HTTP) {
              rpcMetadata.span.updateName(`${req.method} ${route.length > 0 ? route : "/"}`);
            }
            if (utils_1.isLayerIgnored(metadata.name, type, instrumentation._config)) {
              if (type === ExpressLayerType_1.ExpressLayerType.MIDDLEWARE) {
                req[types_1._LAYERS_STORE_PROPERTY].pop();
              }
              return original.apply(this, arguments);
            }
            if (api_1.trace.getSpan(api_1.context.active()) === void 0) {
              return original.apply(this, arguments);
            }
            const span = instrumentation.tracer.startSpan(metadata.name, {
              attributes: Object.assign(attributes, metadata.attributes)
            });
            const startTime = core_1.hrTime();
            let spanHasEnded = false;
            if (metadata.attributes[AttributeNames_1.AttributeNames.EXPRESS_TYPE] !== ExpressLayerType_1.ExpressLayerType.MIDDLEWARE) {
              span.end(startTime);
              spanHasEnded = true;
            }
            const onResponseFinish = () => {
              if (spanHasEnded === false) {
                spanHasEnded = true;
                span.end(startTime);
              }
            };
            const args = Array.from(arguments);
            const callbackIdx = args.findIndex((arg) => typeof arg === "function");
            const newContext = (rpcMetadata === null || rpcMetadata === void 0 ? void 0 : rpcMetadata.type) === core_1.RPCType.HTTP ? core_1.setRPCMetadata(api_1.context.active(), Object.assign(rpcMetadata, { route })) : api_1.context.active();
            if (callbackIdx >= 0) {
              arguments[callbackIdx] = function() {
                var _a;
                if (spanHasEnded === false) {
                  spanHasEnded = true;
                  (_a = req.res) === null || _a === void 0 ? void 0 : _a.removeListener("finish", onResponseFinish);
                  span.end();
                }
                if (!(req.route && arguments[0] instanceof Error)) {
                  req[types_1._LAYERS_STORE_PROPERTY].pop();
                }
                const callback = args[callbackIdx];
                return api_1.context.bind(newContext, callback).apply(this, arguments);
              };
            }
            const result = original.apply(this, arguments);
            if (!spanHasEnded) {
              res.once("finish", onResponseFinish);
            }
            return result;
          };
        });
      }
    };
    exports2.ExpressInstrumentation = ExpressInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/index.js
var require_src18 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-express/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ExpressLayerType = void 0;
    __exportStar(require_instrumentation4(), exports2);
    var ExpressLayerType_1 = require_ExpressLayerType();
    Object.defineProperty(exports2, "ExpressLayerType", { enumerable: true, get: function() {
      return ExpressLayerType_1.ExpressLayerType;
    } });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/enum.js
var require_enum = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/enum.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SpanNames = exports2.TokenKind = exports2.AllowedOperationTypes = void 0;
    var AllowedOperationTypes;
    (function(AllowedOperationTypes2) {
      AllowedOperationTypes2["QUERY"] = "query";
      AllowedOperationTypes2["MUTATION"] = "mutation";
      AllowedOperationTypes2["SUBSCRIPTION"] = "subscription";
    })(AllowedOperationTypes = exports2.AllowedOperationTypes || (exports2.AllowedOperationTypes = {}));
    var TokenKind;
    (function(TokenKind2) {
      TokenKind2["SOF"] = "<SOF>";
      TokenKind2["EOF"] = "<EOF>";
      TokenKind2["BANG"] = "!";
      TokenKind2["DOLLAR"] = "$";
      TokenKind2["AMP"] = "&";
      TokenKind2["PAREN_L"] = "(";
      TokenKind2["PAREN_R"] = ")";
      TokenKind2["SPREAD"] = "...";
      TokenKind2["COLON"] = ":";
      TokenKind2["EQUALS"] = "=";
      TokenKind2["AT"] = "@";
      TokenKind2["BRACKET_L"] = "[";
      TokenKind2["BRACKET_R"] = "]";
      TokenKind2["BRACE_L"] = "{";
      TokenKind2["PIPE"] = "|";
      TokenKind2["BRACE_R"] = "}";
      TokenKind2["NAME"] = "Name";
      TokenKind2["INT"] = "Int";
      TokenKind2["FLOAT"] = "Float";
      TokenKind2["STRING"] = "String";
      TokenKind2["BLOCK_STRING"] = "BlockString";
      TokenKind2["COMMENT"] = "Comment";
    })(TokenKind = exports2.TokenKind || (exports2.TokenKind = {}));
    var SpanNames;
    (function(SpanNames2) {
      SpanNames2["EXECUTE"] = "graphql.execute";
      SpanNames2["PARSE"] = "graphql.parse";
      SpanNames2["RESOLVE"] = "graphql.resolve";
      SpanNames2["VALIDATE"] = "graphql.validate";
      SpanNames2["SCHEMA_VALIDATE"] = "graphql.validateSchema";
      SpanNames2["SCHEMA_PARSE"] = "graphql.parseSchema";
    })(SpanNames = exports2.SpanNames || (exports2.SpanNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/enums/AttributeNames.js
var require_AttributeNames3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/enums/AttributeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["COMPONENT"] = "graphql";
      AttributeNames2["SOURCE"] = "graphql.source";
      AttributeNames2["FIELD_NAME"] = "graphql.field.name";
      AttributeNames2["FIELD_PATH"] = "graphql.field.path";
      AttributeNames2["FIELD_TYPE"] = "graphql.field.type";
      AttributeNames2["OPERATION_TYPE"] = "graphql.operation.type";
      AttributeNames2["OPERATION_NAME"] = "graphql.operation.name";
      AttributeNames2["VARIABLES"] = "graphql.variables.";
      AttributeNames2["ERROR_VALIDATION_NAME"] = "graphql.validation.error";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/symbols.js
var require_symbols = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/symbols.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.OTEL_GRAPHQL_DATA_SYMBOL = exports2.OTEL_PATCHED_SYMBOL = void 0;
    exports2.OTEL_PATCHED_SYMBOL = Symbol.for("opentelemetry.patched");
    exports2.OTEL_GRAPHQL_DATA_SYMBOL = Symbol.for("opentelemetry.graphql_data");
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/types.js
var require_types12 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.OPERATION_NOT_SUPPORTED = void 0;
    var symbols_1 = require_symbols();
    exports2.OPERATION_NOT_SUPPORTED = "Operation$operationName$not supported";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/utils.js
var require_utils7 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.wrapFieldResolver = exports2.wrapFields = exports2.getSourceFromLocation = exports2.getOperation = exports2.endSpan = exports2.addSpanSource = exports2.addInputVariableAttributes = void 0;
    var api = require_src();
    var enum_1 = require_enum();
    var AttributeNames_1 = require_AttributeNames3();
    var symbols_1 = require_symbols();
    var OPERATION_VALUES = Object.values(enum_1.AllowedOperationTypes);
    function addInputVariableAttribute(span, key, variable) {
      if (Array.isArray(variable)) {
        variable.forEach((value, idx) => {
          addInputVariableAttribute(span, `${key}.${idx}`, value);
        });
      } else if (variable instanceof Object) {
        Object.entries(variable).forEach(([nestedKey, value]) => {
          addInputVariableAttribute(span, `${key}.${nestedKey}`, value);
        });
      } else {
        span.setAttribute(`${AttributeNames_1.AttributeNames.VARIABLES}${String(key)}`, variable);
      }
    }
    function addInputVariableAttributes(span, variableValues) {
      Object.entries(variableValues).forEach(([key, value]) => {
        addInputVariableAttribute(span, key, value);
      });
    }
    exports2.addInputVariableAttributes = addInputVariableAttributes;
    function addSpanSource(span, loc, allowValues, start, end) {
      const source = getSourceFromLocation(loc, allowValues, start, end);
      span.setAttribute(AttributeNames_1.AttributeNames.SOURCE, source);
    }
    exports2.addSpanSource = addSpanSource;
    function createFieldIfNotExists(tracer, getConfig, contextValue, info, path) {
      let field = getField(contextValue, path);
      let spanAdded = false;
      if (!field) {
        spanAdded = true;
        const parent = getParentField(contextValue, path);
        field = {
          parent,
          span: createResolverSpan(tracer, getConfig, contextValue, info, path, parent.span),
          error: null
        };
        addField(contextValue, path, field);
      }
      return { spanAdded, field };
    }
    function createResolverSpan(tracer, getConfig, contextValue, info, path, parentSpan) {
      var _a, _b;
      const attributes = {
        [AttributeNames_1.AttributeNames.FIELD_NAME]: info.fieldName,
        [AttributeNames_1.AttributeNames.FIELD_PATH]: path.join("."),
        [AttributeNames_1.AttributeNames.FIELD_TYPE]: info.returnType.toString()
      };
      const span = tracer.startSpan(enum_1.SpanNames.RESOLVE, {
        attributes
      }, parentSpan ? api.trace.setSpan(api.context.active(), parentSpan) : void 0);
      const document2 = contextValue[symbols_1.OTEL_GRAPHQL_DATA_SYMBOL].source;
      const fieldNode = info.fieldNodes.find((fieldNode2) => fieldNode2.kind === "Field");
      if (fieldNode) {
        addSpanSource(span, document2.loc, getConfig().allowValues, (_a = fieldNode.loc) === null || _a === void 0 ? void 0 : _a.start, (_b = fieldNode.loc) === null || _b === void 0 ? void 0 : _b.end);
      }
      return span;
    }
    function endSpan(span, error) {
      if (error) {
        span.recordException(error);
      }
      span.end();
    }
    exports2.endSpan = endSpan;
    function getOperation(document2, operationName) {
      if (!document2 || !Array.isArray(document2.definitions)) {
        return void 0;
      }
      if (operationName) {
        return document2.definitions.filter((definition) => {
          var _a;
          return OPERATION_VALUES.indexOf((_a = definition) === null || _a === void 0 ? void 0 : _a.operation) !== -1;
        }).find((definition) => {
          var _a, _b;
          return operationName === ((_b = (_a = definition) === null || _a === void 0 ? void 0 : _a.name) === null || _b === void 0 ? void 0 : _b.value);
        });
      } else {
        return document2.definitions.find((definition) => {
          var _a;
          return OPERATION_VALUES.indexOf((_a = definition) === null || _a === void 0 ? void 0 : _a.operation) !== -1;
        });
      }
    }
    exports2.getOperation = getOperation;
    function addField(contextValue, path, field) {
      return contextValue[symbols_1.OTEL_GRAPHQL_DATA_SYMBOL].fields[path.join(".")] = field;
    }
    function getField(contextValue, path) {
      return contextValue[symbols_1.OTEL_GRAPHQL_DATA_SYMBOL].fields[path.join(".")];
    }
    function getParentField(contextValue, path) {
      for (let i = path.length - 1; i > 0; i--) {
        const field = getField(contextValue, path.slice(0, i));
        if (field) {
          return field;
        }
      }
      return {
        span: contextValue[symbols_1.OTEL_GRAPHQL_DATA_SYMBOL].span
      };
    }
    function pathToArray(mergeItems, path) {
      const flattened = [];
      let curr = path;
      while (curr) {
        let key = curr.key;
        if (mergeItems && typeof key === "number") {
          key = "*";
        }
        flattened.push(String(key));
        curr = curr.prev;
      }
      return flattened.reverse();
    }
    function repeatBreak(i) {
      return repeatChar("\n", i);
    }
    function repeatSpace(i) {
      return repeatChar(" ", i);
    }
    function repeatChar(char, to) {
      let text = "";
      for (let i = 0; i < to; i++) {
        text += char;
      }
      return text;
    }
    var KindsToBeRemoved = [
      enum_1.TokenKind.FLOAT,
      enum_1.TokenKind.STRING,
      enum_1.TokenKind.INT,
      enum_1.TokenKind.BLOCK_STRING
    ];
    function getSourceFromLocation(loc, allowValues = false, inputStart, inputEnd) {
      var _a, _b;
      let source = "";
      if (loc === null || loc === void 0 ? void 0 : loc.startToken) {
        const start = typeof inputStart === "number" ? inputStart : loc.start;
        const end = typeof inputEnd === "number" ? inputEnd : loc.end;
        let next = loc.startToken.next;
        let previousLine = 1;
        while (next) {
          if (next.start < start) {
            next = next.next;
            previousLine = next === null || next === void 0 ? void 0 : next.line;
            continue;
          }
          if (next.end > end) {
            next = next.next;
            previousLine = next === null || next === void 0 ? void 0 : next.line;
            continue;
          }
          let value = next.value || next.kind;
          let space = "";
          if (!allowValues && KindsToBeRemoved.indexOf(next.kind) >= 0) {
            value = "*";
          }
          if (next.kind === enum_1.TokenKind.STRING) {
            value = `"${value}"`;
          }
          if (next.kind === enum_1.TokenKind.EOF) {
            value = "";
          }
          if (next.line > previousLine) {
            source += repeatBreak(next.line - previousLine);
            previousLine = next.line;
            space = repeatSpace(next.column - 1);
          } else {
            if (next.line === ((_a = next.prev) === null || _a === void 0 ? void 0 : _a.line)) {
              space = repeatSpace(next.start - (((_b = next.prev) === null || _b === void 0 ? void 0 : _b.end) || 0));
            }
          }
          source += space + value;
          if (next) {
            next = next.next;
          }
        }
      }
      return source;
    }
    exports2.getSourceFromLocation = getSourceFromLocation;
    function wrapFields(type, tracer, getConfig) {
      if (!type || typeof type.getFields !== "function" || type[symbols_1.OTEL_PATCHED_SYMBOL]) {
        return;
      }
      const fields = type.getFields();
      type[symbols_1.OTEL_PATCHED_SYMBOL] = true;
      Object.keys(fields).forEach((key) => {
        const field = fields[key];
        if (!field) {
          return;
        }
        if (field.resolve) {
          field.resolve = wrapFieldResolver(tracer, getConfig, field.resolve);
        }
        if (field.type) {
          let unwrappedType = field.type;
          while (unwrappedType.ofType) {
            unwrappedType = unwrappedType.ofType;
          }
          wrapFields(unwrappedType, tracer, getConfig);
        }
      });
    }
    exports2.wrapFields = wrapFields;
    function wrapFieldResolver(tracer, getConfig, fieldResolver) {
      if (wrappedFieldResolver[symbols_1.OTEL_PATCHED_SYMBOL] || typeof fieldResolver !== "function") {
        return fieldResolver;
      }
      function wrappedFieldResolver(source, args, contextValue, info) {
        if (!fieldResolver) {
          return void 0;
        }
        const config = getConfig();
        if (!contextValue[symbols_1.OTEL_GRAPHQL_DATA_SYMBOL]) {
          return fieldResolver.call(this, source, args, contextValue, info);
        }
        const path = pathToArray(config.mergeItems, info && info.path);
        const depth = path.filter((item) => typeof item === "string").length;
        let field;
        let shouldEndSpan = false;
        if (config.depth >= 0 && config.depth < depth) {
          field = getParentField(contextValue, path);
        } else {
          const newField = createFieldIfNotExists(tracer, getConfig, contextValue, info, path);
          field = newField.field;
          shouldEndSpan = newField.spanAdded;
        }
        return api.context.with(api.trace.setSpan(api.context.active(), field.span), () => {
          return safeExecuteInTheMiddleAsync(() => {
            return fieldResolver.call(this, source, args, contextValue, info);
          }, (err) => {
            if (shouldEndSpan) {
              endSpan(field.span, err);
            }
          });
        });
      }
      wrappedFieldResolver[symbols_1.OTEL_PATCHED_SYMBOL] = true;
      return wrappedFieldResolver;
    }
    exports2.wrapFieldResolver = wrapFieldResolver;
    async function safeExecuteInTheMiddleAsync(execute, onFinish, preventThrowingError) {
      let error;
      let result;
      try {
        result = await execute();
      } catch (e) {
        error = e;
      } finally {
        onFinish(error, result);
        if (error && !preventThrowingError) {
          throw error;
        }
        return result;
      }
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/version.js
var require_version6 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.27.4";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/instrumentation.js
var require_instrumentation5 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.GraphQLInstrumentation = void 0;
    var api_1 = require_src();
    var instrumentation_1 = require_src13();
    var enum_1 = require_enum();
    var AttributeNames_1 = require_AttributeNames3();
    var symbols_1 = require_symbols();
    var types_1 = require_types12();
    var utils_1 = require_utils7();
    var version_1 = require_version6();
    var api = require_src();
    var DEFAULT_CONFIG = {
      mergeItems: false,
      depth: -1,
      allowValues: false
    };
    var supportedVersions = [">=14"];
    var GraphQLInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(config = {}) {
        super("@opentelemetry/instrumentation-graphql", version_1.VERSION, Object.assign({}, DEFAULT_CONFIG, config));
      }
      _getConfig() {
        return this._config;
      }
      setConfig(config = {}) {
        this._config = Object.assign({}, DEFAULT_CONFIG, config);
      }
      init() {
        const module3 = new instrumentation_1.InstrumentationNodeModuleDefinition("graphql", supportedVersions);
        module3.files.push(this._addPatchingExecute());
        module3.files.push(this._addPatchingParser());
        module3.files.push(this._addPatchingValidate());
        return module3;
      }
      _addPatchingExecute() {
        return new instrumentation_1.InstrumentationNodeModuleFile("graphql/execution/execute.js", supportedVersions, (moduleExports) => {
          if (instrumentation_1.isWrapped(moduleExports.execute)) {
            this._unwrap(moduleExports, "execute");
          }
          this._wrap(moduleExports, "execute", this._patchExecute(moduleExports.defaultFieldResolver));
          return moduleExports;
        }, (moduleExports) => {
          if (moduleExports) {
            this._unwrap(moduleExports, "execute");
          }
        });
      }
      _addPatchingParser() {
        return new instrumentation_1.InstrumentationNodeModuleFile("graphql/language/parser.js", supportedVersions, (moduleExports) => {
          if (instrumentation_1.isWrapped(moduleExports.execute)) {
            this._unwrap(moduleExports, "parse");
          }
          this._wrap(moduleExports, "parse", this._patchParse());
          return moduleExports;
        }, (moduleExports) => {
          if (moduleExports) {
            this._unwrap(moduleExports, "parse");
          }
        });
      }
      _addPatchingValidate() {
        return new instrumentation_1.InstrumentationNodeModuleFile("graphql/validation/validate.js", supportedVersions, (moduleExports) => {
          if (instrumentation_1.isWrapped(moduleExports.execute)) {
            this._unwrap(moduleExports, "validate");
          }
          this._wrap(moduleExports, "validate", this._patchValidate());
          return moduleExports;
        }, (moduleExports) => {
          if (moduleExports) {
            this._unwrap(moduleExports, "validate");
          }
        });
      }
      _patchExecute(defaultFieldResolved) {
        const instrumentation = this;
        return function execute(original) {
          return function patchExecute() {
            let processedArgs;
            if (arguments.length >= 2) {
              const args = arguments;
              processedArgs = instrumentation._wrapExecuteArgs(args[0], args[1], args[2], args[3], args[4], args[5], args[6] || defaultFieldResolved, args[7]);
            } else {
              const args = arguments[0];
              processedArgs = instrumentation._wrapExecuteArgs(args.schema, args.document, args.rootValue, args.contextValue, args.variableValues, args.operationName, args.fieldResolver || defaultFieldResolved, args.typeResolver);
            }
            const operation = utils_1.getOperation(processedArgs.document, processedArgs.operationName);
            const span = instrumentation._createExecuteSpan(operation, processedArgs);
            processedArgs.contextValue[symbols_1.OTEL_GRAPHQL_DATA_SYMBOL] = {
              source: processedArgs.document ? processedArgs.document || processedArgs.document[symbols_1.OTEL_GRAPHQL_DATA_SYMBOL] : void 0,
              span,
              fields: {}
            };
            return api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => {
              return instrumentation_1.safeExecuteInTheMiddle(() => {
                return original.apply(this, [
                  processedArgs
                ]);
              }, (err, result) => {
                instrumentation._handleExecutionResult(span, err, result);
              });
            });
          };
        };
      }
      _handleExecutionResult(span, err, result) {
        const config = this._getConfig();
        if (result === void 0 || err) {
          utils_1.endSpan(span, err);
          return;
        }
        if (result.constructor.name === "Promise") {
          result.then((resultData) => {
            if (typeof config.responseHook !== "function") {
              utils_1.endSpan(span);
              return;
            }
            this._executeResponseHook(span, resultData);
          });
        } else {
          if (typeof config.responseHook !== "function") {
            utils_1.endSpan(span);
            return;
          }
          this._executeResponseHook(span, result);
        }
      }
      _executeResponseHook(span, result) {
        const config = this._getConfig();
        instrumentation_1.safeExecuteInTheMiddle(() => {
          config.responseHook(span, result);
        }, (err) => {
          if (err) {
            api.diag.error("Error running response hook", err);
          }
          utils_1.endSpan(span, void 0);
        }, true);
      }
      _patchParse() {
        const instrumentation = this;
        return function parse(original) {
          return function patchParse(source, options) {
            return instrumentation._parse(this, original, source, options);
          };
        };
      }
      _patchValidate() {
        const instrumentation = this;
        return function validate(original) {
          return function patchValidate(schema, documentAST, rules, typeInfo, options) {
            return instrumentation._validate(this, original, schema, documentAST, rules, typeInfo, options);
          };
        };
      }
      _parse(obj, original, source, options) {
        const config = this._getConfig();
        const span = this.tracer.startSpan(enum_1.SpanNames.PARSE);
        return api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => {
          return instrumentation_1.safeExecuteInTheMiddle(() => {
            return original.call(obj, source, options);
          }, (err, result) => {
            if (result) {
              const operation = utils_1.getOperation(result);
              if (!operation) {
                span.updateName(enum_1.SpanNames.SCHEMA_PARSE);
              } else if (result.loc) {
                utils_1.addSpanSource(span, result.loc, config.allowValues);
              }
            }
            utils_1.endSpan(span, err);
          });
        });
      }
      _validate(obj, original, schema, documentAST, rules, typeInfo, options) {
        const span = this.tracer.startSpan(enum_1.SpanNames.VALIDATE, {});
        return api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => {
          return instrumentation_1.safeExecuteInTheMiddle(() => {
            return original.call(obj, schema, documentAST, rules, typeInfo, options);
          }, (err, errors) => {
            if (!documentAST.loc) {
              span.updateName(enum_1.SpanNames.SCHEMA_VALIDATE);
            }
            if (errors && errors.length) {
              span.recordException({
                name: AttributeNames_1.AttributeNames.ERROR_VALIDATION_NAME,
                message: JSON.stringify(errors)
              });
            }
            utils_1.endSpan(span, err);
          });
        });
      }
      _createExecuteSpan(operation, processedArgs) {
        var _a;
        const config = this._getConfig();
        const span = this.tracer.startSpan(enum_1.SpanNames.EXECUTE, {});
        if (operation) {
          const operationDefinition = operation;
          span.setAttribute(AttributeNames_1.AttributeNames.OPERATION_TYPE, operationDefinition.operation);
          if (operationDefinition.name) {
            span.setAttribute(AttributeNames_1.AttributeNames.OPERATION_NAME, operationDefinition.name.value);
          }
        } else {
          let operationName = " ";
          if (processedArgs.operationName) {
            operationName = ` "${processedArgs.operationName}" `;
          }
          operationName = types_1.OPERATION_NOT_SUPPORTED.replace("$operationName$", operationName);
          span.setAttribute(AttributeNames_1.AttributeNames.OPERATION_NAME, operationName);
        }
        if ((_a = processedArgs.document) === null || _a === void 0 ? void 0 : _a.loc) {
          utils_1.addSpanSource(span, processedArgs.document.loc, config.allowValues);
        }
        if (processedArgs.variableValues && config.allowValues) {
          utils_1.addInputVariableAttributes(span, processedArgs.variableValues);
        }
        return span;
      }
      _wrapExecuteArgs(schema, document2, rootValue, contextValue, variableValues, operationName, fieldResolver, typeResolver) {
        if (!contextValue) {
          contextValue = {};
        }
        if (contextValue[symbols_1.OTEL_GRAPHQL_DATA_SYMBOL]) {
          return {
            schema,
            document: document2,
            rootValue,
            contextValue,
            variableValues,
            operationName,
            fieldResolver,
            typeResolver
          };
        }
        fieldResolver = utils_1.wrapFieldResolver(this.tracer, this._getConfig.bind(this), fieldResolver);
        if (schema) {
          utils_1.wrapFields(schema.getQueryType(), this.tracer, this._getConfig.bind(this));
          utils_1.wrapFields(schema.getMutationType(), this.tracer, this._getConfig.bind(this));
        }
        return {
          schema,
          document: document2,
          rootValue,
          contextValue,
          variableValues,
          operationName,
          fieldResolver,
          typeResolver
        };
      }
    };
    exports2.GraphQLInstrumentation = GraphQLInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/index.js
var require_src19 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-graphql/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation5(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/version.js
var require_version7 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.27.0";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/utils.js
var require_utils8 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2._methodIsIgnored = exports2._grpcStatusCodeToSpanStatus = exports2._grpcStatusCodeToOpenTelemetryStatusCode = exports2.findIndex = void 0;
    var api_1 = require_src();
    var findIndex = (args, fn) => {
      let index = -1;
      for (const arg of args) {
        index++;
        if (fn(arg)) {
          return index;
        }
      }
      return -1;
    };
    exports2.findIndex = findIndex;
    var _grpcStatusCodeToOpenTelemetryStatusCode = (status) => {
      if (status !== void 0 && status === 0) {
        return api_1.SpanStatusCode.UNSET;
      }
      return api_1.SpanStatusCode.ERROR;
    };
    exports2._grpcStatusCodeToOpenTelemetryStatusCode = _grpcStatusCodeToOpenTelemetryStatusCode;
    var _grpcStatusCodeToSpanStatus = (status) => {
      return { code: exports2._grpcStatusCodeToOpenTelemetryStatusCode(status) };
    };
    exports2._grpcStatusCodeToSpanStatus = _grpcStatusCodeToSpanStatus;
    var _satisfiesPattern = (methodName, pattern) => {
      if (typeof pattern === "string") {
        return pattern.toLowerCase() === methodName.toLowerCase();
      } else if (pattern instanceof RegExp) {
        return pattern.test(methodName);
      } else if (typeof pattern === "function") {
        return pattern(methodName);
      } else {
        return false;
      }
    };
    var _methodIsIgnored = (methodName, ignoredMethods) => {
      if (!ignoredMethods) {
        return false;
      }
      for (const pattern of ignoredMethods) {
        if (_satisfiesPattern(methodName, pattern)) {
          return true;
        }
      }
      return false;
    };
    exports2._methodIsIgnored = _methodIsIgnored;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/enums/AttributeNames.js
var require_AttributeNames4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/enums/AttributeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["GRPC_KIND"] = "grpc.kind";
      AttributeNames2["GRPC_METHOD"] = "grpc.method";
      AttributeNames2["GRPC_ERROR_NAME"] = "grpc.error_name";
      AttributeNames2["GRPC_ERROR_MESSAGE"] = "grpc.error_message";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/trace/SemanticAttributes.js
var require_SemanticAttributes2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/trace/SemanticAttributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MessageTypeValues = exports2.RpcGrpcStatusCodeValues = exports2.MessagingOperationValues = exports2.MessagingDestinationKindValues = exports2.HttpFlavorValues = exports2.NetHostConnectionSubtypeValues = exports2.NetHostConnectionTypeValues = exports2.NetTransportValues = exports2.FaasInvokedProviderValues = exports2.FaasDocumentOperationValues = exports2.FaasTriggerValues = exports2.DbCassandraConsistencyLevelValues = exports2.DbSystemValues = exports2.SemanticAttributes = void 0;
    exports2.SemanticAttributes = {
      AWS_LAMBDA_INVOKED_ARN: "aws.lambda.invoked_arn",
      DB_SYSTEM: "db.system",
      DB_CONNECTION_STRING: "db.connection_string",
      DB_USER: "db.user",
      DB_JDBC_DRIVER_CLASSNAME: "db.jdbc.driver_classname",
      DB_NAME: "db.name",
      DB_STATEMENT: "db.statement",
      DB_OPERATION: "db.operation",
      DB_MSSQL_INSTANCE_NAME: "db.mssql.instance_name",
      DB_CASSANDRA_KEYSPACE: "db.cassandra.keyspace",
      DB_CASSANDRA_PAGE_SIZE: "db.cassandra.page_size",
      DB_CASSANDRA_CONSISTENCY_LEVEL: "db.cassandra.consistency_level",
      DB_CASSANDRA_TABLE: "db.cassandra.table",
      DB_CASSANDRA_IDEMPOTENCE: "db.cassandra.idempotence",
      DB_CASSANDRA_SPECULATIVE_EXECUTION_COUNT: "db.cassandra.speculative_execution_count",
      DB_CASSANDRA_COORDINATOR_ID: "db.cassandra.coordinator.id",
      DB_CASSANDRA_COORDINATOR_DC: "db.cassandra.coordinator.dc",
      DB_HBASE_NAMESPACE: "db.hbase.namespace",
      DB_REDIS_DATABASE_INDEX: "db.redis.database_index",
      DB_MONGODB_COLLECTION: "db.mongodb.collection",
      DB_SQL_TABLE: "db.sql.table",
      EXCEPTION_TYPE: "exception.type",
      EXCEPTION_MESSAGE: "exception.message",
      EXCEPTION_STACKTRACE: "exception.stacktrace",
      EXCEPTION_ESCAPED: "exception.escaped",
      FAAS_TRIGGER: "faas.trigger",
      FAAS_EXECUTION: "faas.execution",
      FAAS_DOCUMENT_COLLECTION: "faas.document.collection",
      FAAS_DOCUMENT_OPERATION: "faas.document.operation",
      FAAS_DOCUMENT_TIME: "faas.document.time",
      FAAS_DOCUMENT_NAME: "faas.document.name",
      FAAS_TIME: "faas.time",
      FAAS_CRON: "faas.cron",
      FAAS_COLDSTART: "faas.coldstart",
      FAAS_INVOKED_NAME: "faas.invoked_name",
      FAAS_INVOKED_PROVIDER: "faas.invoked_provider",
      FAAS_INVOKED_REGION: "faas.invoked_region",
      NET_TRANSPORT: "net.transport",
      NET_PEER_IP: "net.peer.ip",
      NET_PEER_PORT: "net.peer.port",
      NET_PEER_NAME: "net.peer.name",
      NET_HOST_IP: "net.host.ip",
      NET_HOST_PORT: "net.host.port",
      NET_HOST_NAME: "net.host.name",
      NET_HOST_CONNECTION_TYPE: "net.host.connection.type",
      NET_HOST_CONNECTION_SUBTYPE: "net.host.connection.subtype",
      NET_HOST_CARRIER_NAME: "net.host.carrier.name",
      NET_HOST_CARRIER_MCC: "net.host.carrier.mcc",
      NET_HOST_CARRIER_MNC: "net.host.carrier.mnc",
      NET_HOST_CARRIER_ICC: "net.host.carrier.icc",
      PEER_SERVICE: "peer.service",
      ENDUSER_ID: "enduser.id",
      ENDUSER_ROLE: "enduser.role",
      ENDUSER_SCOPE: "enduser.scope",
      THREAD_ID: "thread.id",
      THREAD_NAME: "thread.name",
      CODE_FUNCTION: "code.function",
      CODE_NAMESPACE: "code.namespace",
      CODE_FILEPATH: "code.filepath",
      CODE_LINENO: "code.lineno",
      HTTP_METHOD: "http.method",
      HTTP_URL: "http.url",
      HTTP_TARGET: "http.target",
      HTTP_HOST: "http.host",
      HTTP_SCHEME: "http.scheme",
      HTTP_STATUS_CODE: "http.status_code",
      HTTP_FLAVOR: "http.flavor",
      HTTP_USER_AGENT: "http.user_agent",
      HTTP_REQUEST_CONTENT_LENGTH: "http.request_content_length",
      HTTP_REQUEST_CONTENT_LENGTH_UNCOMPRESSED: "http.request_content_length_uncompressed",
      HTTP_RESPONSE_CONTENT_LENGTH: "http.response_content_length",
      HTTP_RESPONSE_CONTENT_LENGTH_UNCOMPRESSED: "http.response_content_length_uncompressed",
      HTTP_SERVER_NAME: "http.server_name",
      HTTP_ROUTE: "http.route",
      HTTP_CLIENT_IP: "http.client_ip",
      AWS_DYNAMODB_TABLE_NAMES: "aws.dynamodb.table_names",
      AWS_DYNAMODB_CONSUMED_CAPACITY: "aws.dynamodb.consumed_capacity",
      AWS_DYNAMODB_ITEM_COLLECTION_METRICS: "aws.dynamodb.item_collection_metrics",
      AWS_DYNAMODB_PROVISIONED_READ_CAPACITY: "aws.dynamodb.provisioned_read_capacity",
      AWS_DYNAMODB_PROVISIONED_WRITE_CAPACITY: "aws.dynamodb.provisioned_write_capacity",
      AWS_DYNAMODB_CONSISTENT_READ: "aws.dynamodb.consistent_read",
      AWS_DYNAMODB_PROJECTION: "aws.dynamodb.projection",
      AWS_DYNAMODB_LIMIT: "aws.dynamodb.limit",
      AWS_DYNAMODB_ATTRIBUTES_TO_GET: "aws.dynamodb.attributes_to_get",
      AWS_DYNAMODB_INDEX_NAME: "aws.dynamodb.index_name",
      AWS_DYNAMODB_SELECT: "aws.dynamodb.select",
      AWS_DYNAMODB_GLOBAL_SECONDARY_INDEXES: "aws.dynamodb.global_secondary_indexes",
      AWS_DYNAMODB_LOCAL_SECONDARY_INDEXES: "aws.dynamodb.local_secondary_indexes",
      AWS_DYNAMODB_EXCLUSIVE_START_TABLE: "aws.dynamodb.exclusive_start_table",
      AWS_DYNAMODB_TABLE_COUNT: "aws.dynamodb.table_count",
      AWS_DYNAMODB_SCAN_FORWARD: "aws.dynamodb.scan_forward",
      AWS_DYNAMODB_SEGMENT: "aws.dynamodb.segment",
      AWS_DYNAMODB_TOTAL_SEGMENTS: "aws.dynamodb.total_segments",
      AWS_DYNAMODB_COUNT: "aws.dynamodb.count",
      AWS_DYNAMODB_SCANNED_COUNT: "aws.dynamodb.scanned_count",
      AWS_DYNAMODB_ATTRIBUTE_DEFINITIONS: "aws.dynamodb.attribute_definitions",
      AWS_DYNAMODB_GLOBAL_SECONDARY_INDEX_UPDATES: "aws.dynamodb.global_secondary_index_updates",
      MESSAGING_SYSTEM: "messaging.system",
      MESSAGING_DESTINATION: "messaging.destination",
      MESSAGING_DESTINATION_KIND: "messaging.destination_kind",
      MESSAGING_TEMP_DESTINATION: "messaging.temp_destination",
      MESSAGING_PROTOCOL: "messaging.protocol",
      MESSAGING_PROTOCOL_VERSION: "messaging.protocol_version",
      MESSAGING_URL: "messaging.url",
      MESSAGING_MESSAGE_ID: "messaging.message_id",
      MESSAGING_CONVERSATION_ID: "messaging.conversation_id",
      MESSAGING_MESSAGE_PAYLOAD_SIZE_BYTES: "messaging.message_payload_size_bytes",
      MESSAGING_MESSAGE_PAYLOAD_COMPRESSED_SIZE_BYTES: "messaging.message_payload_compressed_size_bytes",
      MESSAGING_OPERATION: "messaging.operation",
      MESSAGING_CONSUMER_ID: "messaging.consumer_id",
      MESSAGING_RABBITMQ_ROUTING_KEY: "messaging.rabbitmq.routing_key",
      MESSAGING_KAFKA_MESSAGE_KEY: "messaging.kafka.message_key",
      MESSAGING_KAFKA_CONSUMER_GROUP: "messaging.kafka.consumer_group",
      MESSAGING_KAFKA_CLIENT_ID: "messaging.kafka.client_id",
      MESSAGING_KAFKA_PARTITION: "messaging.kafka.partition",
      MESSAGING_KAFKA_TOMBSTONE: "messaging.kafka.tombstone",
      RPC_SYSTEM: "rpc.system",
      RPC_SERVICE: "rpc.service",
      RPC_METHOD: "rpc.method",
      RPC_GRPC_STATUS_CODE: "rpc.grpc.status_code",
      RPC_JSONRPC_VERSION: "rpc.jsonrpc.version",
      RPC_JSONRPC_REQUEST_ID: "rpc.jsonrpc.request_id",
      RPC_JSONRPC_ERROR_CODE: "rpc.jsonrpc.error_code",
      RPC_JSONRPC_ERROR_MESSAGE: "rpc.jsonrpc.error_message",
      MESSAGE_TYPE: "message.type",
      MESSAGE_ID: "message.id",
      MESSAGE_COMPRESSED_SIZE: "message.compressed_size",
      MESSAGE_UNCOMPRESSED_SIZE: "message.uncompressed_size"
    };
    exports2.DbSystemValues = {
      OTHER_SQL: "other_sql",
      MSSQL: "mssql",
      MYSQL: "mysql",
      ORACLE: "oracle",
      DB2: "db2",
      POSTGRESQL: "postgresql",
      REDSHIFT: "redshift",
      HIVE: "hive",
      CLOUDSCAPE: "cloudscape",
      HSQLDB: "hsqldb",
      PROGRESS: "progress",
      MAXDB: "maxdb",
      HANADB: "hanadb",
      INGRES: "ingres",
      FIRSTSQL: "firstsql",
      EDB: "edb",
      CACHE: "cache",
      ADABAS: "adabas",
      FIREBIRD: "firebird",
      DERBY: "derby",
      FILEMAKER: "filemaker",
      INFORMIX: "informix",
      INSTANTDB: "instantdb",
      INTERBASE: "interbase",
      MARIADB: "mariadb",
      NETEZZA: "netezza",
      PERVASIVE: "pervasive",
      POINTBASE: "pointbase",
      SQLITE: "sqlite",
      SYBASE: "sybase",
      TERADATA: "teradata",
      VERTICA: "vertica",
      H2: "h2",
      COLDFUSION: "coldfusion",
      CASSANDRA: "cassandra",
      HBASE: "hbase",
      MONGODB: "mongodb",
      REDIS: "redis",
      COUCHBASE: "couchbase",
      COUCHDB: "couchdb",
      COSMOSDB: "cosmosdb",
      DYNAMODB: "dynamodb",
      NEO4J: "neo4j",
      GEODE: "geode",
      ELASTICSEARCH: "elasticsearch",
      MEMCACHED: "memcached",
      COCKROACHDB: "cockroachdb"
    };
    exports2.DbCassandraConsistencyLevelValues = {
      ALL: "all",
      EACH_QUORUM: "each_quorum",
      QUORUM: "quorum",
      LOCAL_QUORUM: "local_quorum",
      ONE: "one",
      TWO: "two",
      THREE: "three",
      LOCAL_ONE: "local_one",
      ANY: "any",
      SERIAL: "serial",
      LOCAL_SERIAL: "local_serial"
    };
    exports2.FaasTriggerValues = {
      DATASOURCE: "datasource",
      HTTP: "http",
      PUBSUB: "pubsub",
      TIMER: "timer",
      OTHER: "other"
    };
    exports2.FaasDocumentOperationValues = {
      INSERT: "insert",
      EDIT: "edit",
      DELETE: "delete"
    };
    exports2.FaasInvokedProviderValues = {
      ALIBABA_CLOUD: "alibaba_cloud",
      AWS: "aws",
      AZURE: "azure",
      GCP: "gcp"
    };
    exports2.NetTransportValues = {
      IP_TCP: "ip_tcp",
      IP_UDP: "ip_udp",
      IP: "ip",
      UNIX: "unix",
      PIPE: "pipe",
      INPROC: "inproc",
      OTHER: "other"
    };
    exports2.NetHostConnectionTypeValues = {
      WIFI: "wifi",
      WIRED: "wired",
      CELL: "cell",
      UNAVAILABLE: "unavailable",
      UNKNOWN: "unknown"
    };
    exports2.NetHostConnectionSubtypeValues = {
      GPRS: "gprs",
      EDGE: "edge",
      UMTS: "umts",
      CDMA: "cdma",
      EVDO_0: "evdo_0",
      EVDO_A: "evdo_a",
      CDMA2000_1XRTT: "cdma2000_1xrtt",
      HSDPA: "hsdpa",
      HSUPA: "hsupa",
      HSPA: "hspa",
      IDEN: "iden",
      EVDO_B: "evdo_b",
      LTE: "lte",
      EHRPD: "ehrpd",
      HSPAP: "hspap",
      GSM: "gsm",
      TD_SCDMA: "td_scdma",
      IWLAN: "iwlan",
      NR: "nr",
      NRNSA: "nrnsa",
      LTE_CA: "lte_ca"
    };
    exports2.HttpFlavorValues = {
      HTTP_1_0: "1.0",
      HTTP_1_1: "1.1",
      HTTP_2_0: "2.0",
      SPDY: "SPDY",
      QUIC: "QUIC"
    };
    exports2.MessagingDestinationKindValues = {
      QUEUE: "queue",
      TOPIC: "topic"
    };
    exports2.MessagingOperationValues = {
      RECEIVE: "receive",
      PROCESS: "process"
    };
    exports2.RpcGrpcStatusCodeValues = {
      OK: 0,
      CANCELLED: 1,
      UNKNOWN: 2,
      INVALID_ARGUMENT: 3,
      DEADLINE_EXCEEDED: 4,
      NOT_FOUND: 5,
      ALREADY_EXISTS: 6,
      PERMISSION_DENIED: 7,
      RESOURCE_EXHAUSTED: 8,
      FAILED_PRECONDITION: 9,
      ABORTED: 10,
      OUT_OF_RANGE: 11,
      UNIMPLEMENTED: 12,
      INTERNAL: 13,
      UNAVAILABLE: 14,
      DATA_LOSS: 15,
      UNAUTHENTICATED: 16
    };
    exports2.MessageTypeValues = {
      SENT: "SENT",
      RECEIVED: "RECEIVED"
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/trace/index.js
var require_trace3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/trace/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_SemanticAttributes2(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/resource/SemanticResourceAttributes.js
var require_SemanticResourceAttributes2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/resource/SemanticResourceAttributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TelemetrySdkLanguageValues = exports2.OsTypeValues = exports2.HostArchValues = exports2.AwsEcsLaunchtypeValues = exports2.CloudPlatformValues = exports2.CloudProviderValues = exports2.SemanticResourceAttributes = void 0;
    exports2.SemanticResourceAttributes = {
      CLOUD_PROVIDER: "cloud.provider",
      CLOUD_ACCOUNT_ID: "cloud.account.id",
      CLOUD_REGION: "cloud.region",
      CLOUD_AVAILABILITY_ZONE: "cloud.availability_zone",
      CLOUD_PLATFORM: "cloud.platform",
      AWS_ECS_CONTAINER_ARN: "aws.ecs.container.arn",
      AWS_ECS_CLUSTER_ARN: "aws.ecs.cluster.arn",
      AWS_ECS_LAUNCHTYPE: "aws.ecs.launchtype",
      AWS_ECS_TASK_ARN: "aws.ecs.task.arn",
      AWS_ECS_TASK_FAMILY: "aws.ecs.task.family",
      AWS_ECS_TASK_REVISION: "aws.ecs.task.revision",
      AWS_EKS_CLUSTER_ARN: "aws.eks.cluster.arn",
      AWS_LOG_GROUP_NAMES: "aws.log.group.names",
      AWS_LOG_GROUP_ARNS: "aws.log.group.arns",
      AWS_LOG_STREAM_NAMES: "aws.log.stream.names",
      AWS_LOG_STREAM_ARNS: "aws.log.stream.arns",
      CONTAINER_NAME: "container.name",
      CONTAINER_ID: "container.id",
      CONTAINER_RUNTIME: "container.runtime",
      CONTAINER_IMAGE_NAME: "container.image.name",
      CONTAINER_IMAGE_TAG: "container.image.tag",
      DEPLOYMENT_ENVIRONMENT: "deployment.environment",
      DEVICE_ID: "device.id",
      DEVICE_MODEL_IDENTIFIER: "device.model.identifier",
      DEVICE_MODEL_NAME: "device.model.name",
      FAAS_NAME: "faas.name",
      FAAS_ID: "faas.id",
      FAAS_VERSION: "faas.version",
      FAAS_INSTANCE: "faas.instance",
      FAAS_MAX_MEMORY: "faas.max_memory",
      HOST_ID: "host.id",
      HOST_NAME: "host.name",
      HOST_TYPE: "host.type",
      HOST_ARCH: "host.arch",
      HOST_IMAGE_NAME: "host.image.name",
      HOST_IMAGE_ID: "host.image.id",
      HOST_IMAGE_VERSION: "host.image.version",
      K8S_CLUSTER_NAME: "k8s.cluster.name",
      K8S_NODE_NAME: "k8s.node.name",
      K8S_NODE_UID: "k8s.node.uid",
      K8S_NAMESPACE_NAME: "k8s.namespace.name",
      K8S_POD_UID: "k8s.pod.uid",
      K8S_POD_NAME: "k8s.pod.name",
      K8S_CONTAINER_NAME: "k8s.container.name",
      K8S_REPLICASET_UID: "k8s.replicaset.uid",
      K8S_REPLICASET_NAME: "k8s.replicaset.name",
      K8S_DEPLOYMENT_UID: "k8s.deployment.uid",
      K8S_DEPLOYMENT_NAME: "k8s.deployment.name",
      K8S_STATEFULSET_UID: "k8s.statefulset.uid",
      K8S_STATEFULSET_NAME: "k8s.statefulset.name",
      K8S_DAEMONSET_UID: "k8s.daemonset.uid",
      K8S_DAEMONSET_NAME: "k8s.daemonset.name",
      K8S_JOB_UID: "k8s.job.uid",
      K8S_JOB_NAME: "k8s.job.name",
      K8S_CRONJOB_UID: "k8s.cronjob.uid",
      K8S_CRONJOB_NAME: "k8s.cronjob.name",
      OS_TYPE: "os.type",
      OS_DESCRIPTION: "os.description",
      OS_NAME: "os.name",
      OS_VERSION: "os.version",
      PROCESS_PID: "process.pid",
      PROCESS_EXECUTABLE_NAME: "process.executable.name",
      PROCESS_EXECUTABLE_PATH: "process.executable.path",
      PROCESS_COMMAND: "process.command",
      PROCESS_COMMAND_LINE: "process.command_line",
      PROCESS_COMMAND_ARGS: "process.command_args",
      PROCESS_OWNER: "process.owner",
      PROCESS_RUNTIME_NAME: "process.runtime.name",
      PROCESS_RUNTIME_VERSION: "process.runtime.version",
      PROCESS_RUNTIME_DESCRIPTION: "process.runtime.description",
      SERVICE_NAME: "service.name",
      SERVICE_NAMESPACE: "service.namespace",
      SERVICE_INSTANCE_ID: "service.instance.id",
      SERVICE_VERSION: "service.version",
      TELEMETRY_SDK_NAME: "telemetry.sdk.name",
      TELEMETRY_SDK_LANGUAGE: "telemetry.sdk.language",
      TELEMETRY_SDK_VERSION: "telemetry.sdk.version",
      TELEMETRY_AUTO_VERSION: "telemetry.auto.version",
      WEBENGINE_NAME: "webengine.name",
      WEBENGINE_VERSION: "webengine.version",
      WEBENGINE_DESCRIPTION: "webengine.description"
    };
    exports2.CloudProviderValues = {
      ALIBABA_CLOUD: "alibaba_cloud",
      AWS: "aws",
      AZURE: "azure",
      GCP: "gcp"
    };
    exports2.CloudPlatformValues = {
      ALIBABA_CLOUD_ECS: "alibaba_cloud_ecs",
      ALIBABA_CLOUD_FC: "alibaba_cloud_fc",
      AWS_EC2: "aws_ec2",
      AWS_ECS: "aws_ecs",
      AWS_EKS: "aws_eks",
      AWS_LAMBDA: "aws_lambda",
      AWS_ELASTIC_BEANSTALK: "aws_elastic_beanstalk",
      AZURE_VM: "azure_vm",
      AZURE_CONTAINER_INSTANCES: "azure_container_instances",
      AZURE_AKS: "azure_aks",
      AZURE_FUNCTIONS: "azure_functions",
      AZURE_APP_SERVICE: "azure_app_service",
      GCP_COMPUTE_ENGINE: "gcp_compute_engine",
      GCP_CLOUD_RUN: "gcp_cloud_run",
      GCP_KUBERNETES_ENGINE: "gcp_kubernetes_engine",
      GCP_CLOUD_FUNCTIONS: "gcp_cloud_functions",
      GCP_APP_ENGINE: "gcp_app_engine"
    };
    exports2.AwsEcsLaunchtypeValues = {
      EC2: "ec2",
      FARGATE: "fargate"
    };
    exports2.HostArchValues = {
      AMD64: "amd64",
      ARM32: "arm32",
      ARM64: "arm64",
      IA64: "ia64",
      PPC32: "ppc32",
      PPC64: "ppc64",
      X86: "x86"
    };
    exports2.OsTypeValues = {
      WINDOWS: "windows",
      LINUX: "linux",
      DARWIN: "darwin",
      FREEBSD: "freebsd",
      NETBSD: "netbsd",
      OPENBSD: "openbsd",
      DRAGONFLYBSD: "dragonflybsd",
      HPUX: "hpux",
      AIX: "aix",
      SOLARIS: "solaris",
      Z_OS: "z_os"
    };
    exports2.TelemetrySdkLanguageValues = {
      CPP: "cpp",
      DOTNET: "dotnet",
      ERLANG: "erlang",
      GO: "go",
      JAVA: "java",
      NODEJS: "nodejs",
      PHP: "php",
      PYTHON: "python",
      RUBY: "ruby",
      WEBJS: "webjs"
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/resource/index.js
var require_resource2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/resource/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_SemanticResourceAttributes2(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/index.js
var require_src20 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/node_modules/@opentelemetry/semantic-conventions/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_trace3(), exports2);
    __exportStar(require_resource2(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc/serverUtils.js
var require_serverUtils = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc/serverUtils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.shouldNotTraceServerCall = exports2.serverStreamAndBidiHandler = exports2.clientStreamAndUnaryHandler = void 0;
    var api_1 = require_src();
    var utils_1 = require_utils8();
    var AttributeNames_1 = require_AttributeNames4();
    var semantic_conventions_1 = require_src20();
    var clientStreamAndUnaryHandler = function(grpcClient, span, call, callback, original, self2) {
      function patchedCallback(err, value, trailer, flags) {
        if (err) {
          if (err.code) {
            span.setStatus({
              code: utils_1._grpcStatusCodeToOpenTelemetryStatusCode(err.code),
              message: err.message
            });
            span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, err.code.toString());
          }
          span.setAttributes({
            [AttributeNames_1.AttributeNames.GRPC_ERROR_NAME]: err.name,
            [AttributeNames_1.AttributeNames.GRPC_ERROR_MESSAGE]: err.message
          });
        } else {
          span.setStatus({ code: api_1.SpanStatusCode.UNSET });
          span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, grpcClient.status.OK.toString());
        }
        span.addEvent("received");
        span.end();
        return callback(err, value, trailer, flags);
      }
      api_1.context.bind(api_1.context.active(), call);
      return original.call(self2, call, patchedCallback);
    };
    exports2.clientStreamAndUnaryHandler = clientStreamAndUnaryHandler;
    var serverStreamAndBidiHandler = function(span, call, original, self2) {
      let spanEnded = false;
      const endSpan = () => {
        if (!spanEnded) {
          spanEnded = true;
          span.end();
        }
      };
      api_1.context.bind(api_1.context.active(), call);
      call.on("finish", () => {
        span.setStatus(utils_1._grpcStatusCodeToSpanStatus(call.status.code));
        span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, call.status.code.toString());
        if (call.status.code === 0) {
          span.addEvent("finished");
          endSpan();
        }
      });
      call.on("error", (err) => {
        span.setStatus({
          code: utils_1._grpcStatusCodeToOpenTelemetryStatusCode(err.code),
          message: err.message
        });
        span.addEvent("finished with error");
        span.setAttributes({
          [AttributeNames_1.AttributeNames.GRPC_ERROR_NAME]: err.name,
          [AttributeNames_1.AttributeNames.GRPC_ERROR_MESSAGE]: err.message
        });
        endSpan();
      });
      return original.call(self2, call);
    };
    exports2.serverStreamAndBidiHandler = serverStreamAndBidiHandler;
    var shouldNotTraceServerCall = function(call, name) {
      const parsedName = name.split("/");
      return utils_1._methodIsIgnored(parsedName[parsedName.length - 1] || name, this.getConfig().ignoreGrpcMethods);
    };
    exports2.shouldNotTraceServerCall = shouldNotTraceServerCall;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc/clientUtils.js
var require_clientUtils = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc/clientUtils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getMetadata = exports2.makeGrpcClientRemoteCall = void 0;
    var semantic_conventions_1 = require_src20();
    var api_1 = require_src();
    var utils_1 = require_utils8();
    var AttributeNames_1 = require_AttributeNames4();
    var makeGrpcClientRemoteCall = function(grpcClient, original, args, metadata, self2) {
      function patchedCallback(span, callback, _metadata) {
        const wrappedFn = (err, res) => {
          if (err) {
            if (err.code) {
              span.setStatus(utils_1._grpcStatusCodeToSpanStatus(err.code));
              span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, err.code.toString());
            }
            span.setAttributes({
              [AttributeNames_1.AttributeNames.GRPC_ERROR_NAME]: err.name,
              [AttributeNames_1.AttributeNames.GRPC_ERROR_MESSAGE]: err.message
            });
          } else {
            span.setStatus({ code: api_1.SpanStatusCode.UNSET });
            span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, grpcClient.status.OK.toString());
          }
          span.end();
          callback(err, res);
        };
        return api_1.context.bind(api_1.context.active(), wrappedFn);
      }
      return (span) => {
        if (!span) {
          return original.apply(self2, args);
        }
        if (!original.responseStream) {
          const callbackFuncIndex = utils_1.findIndex(args, (arg) => {
            return typeof arg === "function";
          });
          if (callbackFuncIndex !== -1) {
            args[callbackFuncIndex] = patchedCallback(span, args[callbackFuncIndex], metadata);
          }
        }
        span.addEvent("sent");
        span.setAttributes({
          [AttributeNames_1.AttributeNames.GRPC_METHOD]: original.path,
          [AttributeNames_1.AttributeNames.GRPC_KIND]: api_1.SpanKind.CLIENT
        });
        setSpanContext(metadata);
        const call = original.apply(self2, args);
        if (original.responseStream) {
          let spanEnded = false;
          const endSpan = () => {
            if (!spanEnded) {
              span.end();
              spanEnded = true;
            }
          };
          api_1.context.bind(api_1.context.active(), call);
          call.on("error", (err) => {
            span.setStatus({
              code: utils_1._grpcStatusCodeToOpenTelemetryStatusCode(err.code),
              message: err.message
            });
            span.setAttributes({
              [AttributeNames_1.AttributeNames.GRPC_ERROR_NAME]: err.name,
              [AttributeNames_1.AttributeNames.GRPC_ERROR_MESSAGE]: err.message
            });
            endSpan();
          });
          call.on("status", (status) => {
            span.setStatus({ code: api_1.SpanStatusCode.UNSET });
            span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, status.code.toString());
            endSpan();
          });
        }
        return call;
      };
    };
    exports2.makeGrpcClientRemoteCall = makeGrpcClientRemoteCall;
    var getMetadata = function(grpcClient, original, args) {
      let metadata;
      let metadataIndex = utils_1.findIndex(args, (arg) => {
        return arg && typeof arg === "object" && arg._internal_repr && typeof arg.getMap === "function";
      });
      if (metadataIndex === -1) {
        metadata = new grpcClient.Metadata();
        if (!original.requestStream) {
          if (args.length === 0) {
            args.push(void 0);
          }
          metadataIndex = 1;
        } else {
          metadataIndex = 0;
        }
        args.splice(metadataIndex, 0, metadata);
      } else {
        metadata = args[metadataIndex];
      }
      return metadata;
    };
    exports2.getMetadata = getMetadata;
    var setSpanContext = function(metadata) {
      api_1.propagation.inject(api_1.context.active(), metadata, {
        set: (metadata2, k, v) => metadata2.set(k, v)
      });
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc/index.js
var require_grpc = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.GrpcNativeInstrumentation = void 0;
    var instrumentation_1 = require_src13();
    var api_1 = require_src();
    var serverUtils_1 = require_serverUtils();
    var clientUtils_1 = require_clientUtils();
    var utils_1 = require_utils8();
    var AttributeNames_1 = require_AttributeNames4();
    var grpcClient;
    var GrpcNativeInstrumentation = class extends instrumentation_1.InstrumentationBase {
      constructor(name, version, config) {
        super(name, version, config);
      }
      init() {
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("grpc", ["1.*"], (moduleExports, version) => {
            this._diag.debug(`Applying patch for grpc@${version}`);
            grpcClient = moduleExports;
            if (instrumentation_1.isWrapped(moduleExports.Server.prototype.register)) {
              this._unwrap(moduleExports.Server.prototype, "register");
            }
            this._wrap(moduleExports.Server.prototype, "register", this._patchServer(moduleExports));
            if (instrumentation_1.isWrapped(moduleExports.makeGenericClientConstructor)) {
              this._unwrap(moduleExports, "makeGenericClientConstructor");
            }
            this._wrap(moduleExports, "makeGenericClientConstructor", this._patchClient());
            return moduleExports;
          }, (moduleExports, version) => {
            if (moduleExports === void 0)
              return;
            this._diag.debug(`Removing patch for grpc@${version}`);
            this._unwrap(moduleExports.Server.prototype, "register");
          }, this._getInternalPatchs())
        ];
      }
      getConfig() {
        return super.getConfig();
      }
      _getInternalPatchs() {
        const onPatch = (moduleExports, version) => {
          this._diag.debug(`Applying internal patch for grpc@${version}`);
          if (instrumentation_1.isWrapped(moduleExports.makeClientConstructor)) {
            this._unwrap(moduleExports, "makeClientConstructor");
          }
          this._wrap(moduleExports, "makeClientConstructor", this._patchClient());
          return moduleExports;
        };
        const onUnPatch = (moduleExports, version) => {
          if (moduleExports === void 0)
            return;
          this._diag.debug(`Removing internal patch for grpc@${version}`);
          this._unwrap(moduleExports, "makeClientConstructor");
        };
        return [
          new instrumentation_1.InstrumentationNodeModuleFile("grpc/src/node/src/client.js", ["0.13 - 1.6"], onPatch, onUnPatch),
          new instrumentation_1.InstrumentationNodeModuleFile("grpc/src/client.js", ["^1.7"], onPatch, onUnPatch)
        ];
      }
      _patchServer(grpcModule) {
        const instrumentation = this;
        return (originalRegister) => {
          instrumentation._diag.debug("patched gRPC server");
          return function register(name, handler, serialize, deserialize, type) {
            const originalResult = originalRegister.apply(this, arguments);
            const handlerSet = this.handlers[name];
            instrumentation._wrap(handlerSet, "func", (originalFunc) => {
              return function func(call, callback) {
                const self2 = this;
                if (serverUtils_1.shouldNotTraceServerCall.call(instrumentation, call, name)) {
                  switch (type) {
                    case "unary":
                    case "client_stream":
                      return originalFunc.call(self2, call, callback);
                    case "server_stream":
                    case "bidi":
                      return originalFunc.call(self2, call);
                    default:
                      return originalResult;
                  }
                }
                const spanName = `grpc.${name.replace("/", "")}`;
                const spanOptions = {
                  kind: api_1.SpanKind.SERVER
                };
                instrumentation._diag.debug(`patch func: ${JSON.stringify(spanOptions)}`);
                api_1.context.with(api_1.propagation.extract(api_1.context.active(), call.metadata, {
                  get: (metadata, key) => metadata.get(key).map(String),
                  keys: (metadata) => Object.keys(metadata.getMap())
                }), () => {
                  const span = instrumentation.tracer.startSpan(spanName, spanOptions).setAttributes({
                    [AttributeNames_1.AttributeNames.GRPC_KIND]: spanOptions.kind
                  });
                  api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => {
                    switch (type) {
                      case "unary":
                      case "client_stream":
                        return serverUtils_1.clientStreamAndUnaryHandler(grpcModule, span, call, callback, originalFunc, self2);
                      case "server_stream":
                      case "bidi":
                        return serverUtils_1.serverStreamAndBidiHandler(span, call, originalFunc, self2);
                      default:
                        break;
                    }
                  });
                });
              };
            });
            return originalResult;
          };
        };
      }
      _patchClient() {
        const instrumentation = this;
        return (original) => {
          instrumentation._diag.debug("patching client");
          return function makeClientConstructor(methods, _serviceName, _options) {
            const client = original.apply(this, arguments);
            instrumentation._massWrap(client.prototype, instrumentation._getMethodsToWrap(client, methods), instrumentation._getPatchedClientMethods());
            return client;
          };
        };
      }
      _getMethodsToWrap(client, methods) {
        const methodList = [];
        Object.entries(methods).forEach(([name, { originalName }]) => {
          if (!utils_1._methodIsIgnored(name, this.getConfig().ignoreGrpcMethods)) {
            methodList.push(name);
            if (originalName && client.prototype.hasOwnProperty(originalName) && name !== originalName) {
              methodList.push(originalName);
            }
          }
        });
        return methodList;
      }
      _getPatchedClientMethods() {
        const instrumentation = this;
        return (original) => {
          instrumentation._diag.debug("patch all client methods");
          return function clientMethodTrace() {
            var _a;
            const name = `grpc.${(_a = original.path) === null || _a === void 0 ? void 0 : _a.replace("/", "")}`;
            const args = Array.prototype.slice.call(arguments);
            const metadata = clientUtils_1.getMetadata(grpcClient, original, args);
            const span = instrumentation.tracer.startSpan(name, {
              kind: api_1.SpanKind.CLIENT
            });
            return api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => clientUtils_1.makeGrpcClientRemoteCall(grpcClient, original, args, metadata, this)(span));
          };
        };
      }
    };
    exports2.GrpcNativeInstrumentation = GrpcNativeInstrumentation;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc-js/serverUtils.js
var require_serverUtils2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc-js/serverUtils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.shouldNotTraceServerCall = exports2.handleUntracedServerFunction = exports2.handleServerFunction = exports2.CALL_SPAN_ENDED = void 0;
    var api_1 = require_src();
    var utils_1 = require_utils8();
    var AttributeNames_1 = require_AttributeNames4();
    var semantic_conventions_1 = require_src20();
    exports2.CALL_SPAN_ENDED = Symbol("opentelemetry call span ended");
    function serverStreamAndBidiHandler(span, call, original) {
      let spanEnded = false;
      const endSpan = () => {
        if (!spanEnded) {
          spanEnded = true;
          span.end();
        }
      };
      api_1.context.bind(api_1.context.active(), call);
      call.on("finish", () => {
        if (call[exports2.CALL_SPAN_ENDED]) {
          return;
        }
        call[exports2.CALL_SPAN_ENDED] = true;
        span.setStatus({
          code: api_1.SpanStatusCode.UNSET
        });
        span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, api_1.SpanStatusCode.OK.toString());
        endSpan();
      });
      call.on("error", (err) => {
        if (call[exports2.CALL_SPAN_ENDED]) {
          return;
        }
        call[exports2.CALL_SPAN_ENDED] = true;
        span.setStatus({
          code: utils_1._grpcStatusCodeToOpenTelemetryStatusCode(err.code),
          message: err.message
        });
        span.setAttributes({
          [AttributeNames_1.AttributeNames.GRPC_ERROR_NAME]: err.name,
          [AttributeNames_1.AttributeNames.GRPC_ERROR_MESSAGE]: err.message
        });
        endSpan();
      });
      return original.call({}, call);
    }
    function clientStreamAndUnaryHandler(span, call, callback, original) {
      const patchedCallback = (err, value) => {
        if (err) {
          if (err.code) {
            span.setStatus({
              code: utils_1._grpcStatusCodeToOpenTelemetryStatusCode(err.code),
              message: err.message
            });
            span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, err.code.toString());
          }
          span.setAttributes({
            [AttributeNames_1.AttributeNames.GRPC_ERROR_NAME]: err.name,
            [AttributeNames_1.AttributeNames.GRPC_ERROR_MESSAGE]: err.message
          });
        } else {
          span.setStatus({ code: api_1.SpanStatusCode.UNSET });
          span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, api_1.SpanStatusCode.OK.toString());
        }
        span.end();
        return callback(err, value);
      };
      api_1.context.bind(api_1.context.active(), call);
      return original.call({}, call, patchedCallback);
    }
    function handleServerFunction(span, type, originalFunc, call, callback) {
      switch (type) {
        case "unary":
        case "clientStream":
        case "client_stream":
          return clientStreamAndUnaryHandler(span, call, callback, originalFunc);
        case "serverStream":
        case "server_stream":
        case "bidi":
          return serverStreamAndBidiHandler(span, call, originalFunc);
        default:
          break;
      }
    }
    exports2.handleServerFunction = handleServerFunction;
    function handleUntracedServerFunction(type, originalFunc, call, callback) {
      switch (type) {
        case "unary":
        case "clientStream":
        case "client_stream":
          return originalFunc.call({}, call, callback);
        case "serverStream":
        case "server_stream":
        case "bidi":
          return originalFunc.call({}, call);
        default:
          break;
      }
    }
    exports2.handleUntracedServerFunction = handleUntracedServerFunction;
    function shouldNotTraceServerCall(metadata, methodName, ignoreGrpcMethods) {
      const parsedName = methodName.split("/");
      return utils_1._methodIsIgnored(parsedName[parsedName.length - 1] || methodName, ignoreGrpcMethods);
    }
    exports2.shouldNotTraceServerCall = shouldNotTraceServerCall;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc-js/clientUtils.js
var require_clientUtils2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc-js/clientUtils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.setSpanContext = exports2.getMetadata = exports2.makeGrpcClientRemoteCall = exports2.getMethodsToWrap = void 0;
    var api_1 = require_src();
    var utils_1 = require_utils8();
    var serverUtils_1 = require_serverUtils2();
    var AttributeNames_1 = require_AttributeNames4();
    var semantic_conventions_1 = require_src20();
    function getMethodsToWrap(client, methods) {
      const methodList = [];
      Object.entries(methods).forEach(([name, { originalName }]) => {
        if (!utils_1._methodIsIgnored(name, this.getConfig().ignoreGrpcMethods)) {
          methodList.push(name);
          if (originalName && client.prototype.hasOwnProperty(originalName) && name !== originalName) {
            methodList.push(originalName);
          }
        }
      });
      return methodList;
    }
    exports2.getMethodsToWrap = getMethodsToWrap;
    function makeGrpcClientRemoteCall(original, args, metadata, self2) {
      function patchedCallback(span, callback) {
        const wrappedFn = (err, res) => {
          if (err) {
            if (err.code) {
              span.setStatus(utils_1._grpcStatusCodeToSpanStatus(err.code));
              span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, err.code.toString());
            }
            span.setAttributes({
              [AttributeNames_1.AttributeNames.GRPC_ERROR_NAME]: err.name,
              [AttributeNames_1.AttributeNames.GRPC_ERROR_MESSAGE]: err.message
            });
          } else {
            span.setStatus({ code: api_1.SpanStatusCode.UNSET });
            span.setAttribute(semantic_conventions_1.SemanticAttributes.RPC_GRPC_STATUS_CODE, api_1.SpanStatusCode.UNSET.toString());
          }
          span.end();
          callback(err, res);
        };
        return api_1.context.bind(api_1.context.active(), wrappedFn);
      }
      return (span) => {
        if (!original.responseStream) {
          const callbackFuncIndex = args.findIndex((arg) => {
            return typeof arg === "function";
          });
          if (callbackFuncIndex !== -1) {
            args[callbackFuncIndex] = patchedCallback(span, args[callbackFuncIndex]);
          }
        }
        span.setAttributes({
          [AttributeNames_1.AttributeNames.GRPC_METHOD]: original.path,
          [AttributeNames_1.AttributeNames.GRPC_KIND]: api_1.SpanKind.CLIENT
        });
        setSpanContext(metadata);
        const call = original.apply(self2, args);
        if (original.responseStream) {
          let spanEnded = false;
          const endSpan = () => {
            if (!spanEnded) {
              span.end();
              spanEnded = true;
            }
          };
          api_1.context.bind(api_1.context.active(), call);
          call.on("error", (err) => {
            if (call[serverUtils_1.CALL_SPAN_ENDED]) {
              return;
            }
            call[serverUtils_1.CALL_SPAN_ENDED] = true;
            span.setStatus({
              code: utils_1._grpcStatusCodeToOpenTelemetryStatusCode(err.code),
              message: err.message
            });
            span.setAttributes({
              [AttributeNames_1.AttributeNames.GRPC_ERROR_NAME]: err.name,
              [AttributeNames_1.AttributeNames.GRPC_ERROR_MESSAGE]: err.message
            });
            endSpan();
          });
          call.on("status", (status) => {
            if (call[serverUtils_1.CALL_SPAN_ENDED]) {
              return;
            }
            call[serverUtils_1.CALL_SPAN_ENDED] = true;
            span.setStatus(utils_1._grpcStatusCodeToSpanStatus(status.code));
            endSpan();
          });
        }
        return call;
      };
    }
    exports2.makeGrpcClientRemoteCall = makeGrpcClientRemoteCall;
    function getMetadata(grpcClient, original, args) {
      let metadata;
      let metadataIndex = args.findIndex((arg) => {
        return arg && typeof arg === "object" && arg["internalRepr"] && typeof arg.getMap === "function";
      });
      if (metadataIndex === -1) {
        metadata = new grpcClient.Metadata();
        if (!original.requestStream) {
          metadataIndex = 1;
        } else {
          metadataIndex = 0;
        }
        args.splice(metadataIndex, 0, metadata);
      } else {
        metadata = args[metadataIndex];
      }
      return metadata;
    }
    exports2.getMetadata = getMetadata;
    function setSpanContext(metadata) {
      api_1.propagation.inject(api_1.context.active(), metadata, {
        set: (metadata2, k, v) => metadata2.set(k, v)
      });
    }
    exports2.setSpanContext = setSpanContext;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc-js/index.js
var require_grpc_js = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/grpc-js/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.GrpcJsInstrumentation = void 0;
    var instrumentation_1 = require_src13();
    var instrumentation_2 = require_src13();
    var api_1 = require_src();
    var serverUtils_1 = require_serverUtils2();
    var clientUtils_1 = require_clientUtils2();
    var AttributeNames_1 = require_AttributeNames4();
    var GrpcJsInstrumentation = class extends instrumentation_2.InstrumentationBase {
      constructor(name, version, config) {
        super(name, version, config);
      }
      init() {
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("@grpc/grpc-js", ["1.*"], (moduleExports, version) => {
            this._diag.debug(`Applying patch for @grpc/grpc-js@${version}`);
            if (instrumentation_1.isWrapped(moduleExports.Server.prototype.register)) {
              this._unwrap(moduleExports.Server.prototype, "register");
            }
            this._wrap(moduleExports.Server.prototype, "register", this._patchServer());
            if (instrumentation_1.isWrapped(moduleExports.makeGenericClientConstructor)) {
              this._unwrap(moduleExports, "makeGenericClientConstructor");
            }
            this._wrap(moduleExports, "makeGenericClientConstructor", this._patchClient(moduleExports));
            if (instrumentation_1.isWrapped(moduleExports.makeClientConstructor)) {
              this._unwrap(moduleExports, "makeClientConstructor");
            }
            this._wrap(moduleExports, "makeClientConstructor", this._patchClient(moduleExports));
            if (instrumentation_1.isWrapped(moduleExports.loadPackageDefinition)) {
              this._unwrap(moduleExports, "loadPackageDefinition");
            }
            this._wrap(moduleExports, "loadPackageDefinition", this._patchLoadPackageDefinition(moduleExports));
            return moduleExports;
          }, (moduleExports, version) => {
            if (moduleExports === void 0)
              return;
            this._diag.debug(`Removing patch for @grpc/grpc-js@${version}`);
            this._unwrap(moduleExports.Server.prototype, "register");
            this._unwrap(moduleExports, "makeClientConstructor");
            this._unwrap(moduleExports, "makeGenericClientConstructor");
            this._unwrap(moduleExports, "loadPackageDefinition");
          })
        ];
      }
      getConfig() {
        return super.getConfig();
      }
      _patchServer() {
        const instrumentation = this;
        return (originalRegister) => {
          const config = this.getConfig();
          instrumentation._diag.debug("patched gRPC server");
          return function register(name, handler, serialize, deserialize, type) {
            const originalRegisterResult = originalRegister.call(this, name, handler, serialize, deserialize, type);
            const handlerSet = this["handlers"].get(name);
            instrumentation._wrap(handlerSet, "func", (originalFunc) => {
              return function func(call, callback) {
                const self2 = this;
                if (serverUtils_1.shouldNotTraceServerCall(call.metadata, name, config.ignoreGrpcMethods)) {
                  return serverUtils_1.handleUntracedServerFunction(type, originalFunc, call, callback);
                }
                const spanName = `grpc.${name.replace("/", "")}`;
                const spanOptions = {
                  kind: api_1.SpanKind.SERVER
                };
                instrumentation._diag.debug(`patch func: ${JSON.stringify(spanOptions)}`);
                api_1.context.with(api_1.propagation.extract(api_1.ROOT_CONTEXT, call.metadata, {
                  get: (carrier, key) => carrier.get(key).map(String),
                  keys: (carrier) => Object.keys(carrier.getMap())
                }), () => {
                  const span = instrumentation.tracer.startSpan(spanName, spanOptions).setAttributes({
                    [AttributeNames_1.AttributeNames.GRPC_KIND]: spanOptions.kind
                  });
                  api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => {
                    serverUtils_1.handleServerFunction.call(self2, span, type, originalFunc, call, callback);
                  });
                });
              };
            });
            return originalRegisterResult;
          };
        };
      }
      _patchClient(grpcClient) {
        const instrumentation = this;
        return (original) => {
          instrumentation._diag.debug("patching client");
          return function makeClientConstructor(methods, serviceName, options) {
            const client = original.call(this, methods, serviceName, options);
            instrumentation._massWrap(client.prototype, clientUtils_1.getMethodsToWrap.call(instrumentation, client, methods), instrumentation._getPatchedClientMethods(grpcClient));
            return client;
          };
        };
      }
      _patchLoadPackageDefinition(grpcClient) {
        const instrumentation = this;
        instrumentation._diag.debug("patching loadPackageDefinition");
        return (original) => {
          return function patchedLoadPackageDefinition(packageDef) {
            const result = original.call(this, packageDef);
            instrumentation._patchLoadedPackage(grpcClient, result);
            return result;
          };
        };
      }
      _getPatchedClientMethods(grpcClient) {
        const instrumentation = this;
        return (original) => {
          instrumentation._diag.debug("patch all client methods");
          return function clientMethodTrace() {
            const name = `grpc.${original.path.replace("/", "")}`;
            const args = [...arguments];
            const metadata = clientUtils_1.getMetadata.call(instrumentation, grpcClient, original, args);
            const span = instrumentation.tracer.startSpan(name, {
              kind: api_1.SpanKind.CLIENT
            });
            return api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => clientUtils_1.makeGrpcClientRemoteCall(original, args, metadata, this)(span));
          };
        };
      }
      _patchLoadedPackage(grpcClient, result) {
        Object.values(result).forEach((service) => {
          if (typeof service === "function") {
            this._massWrap(service.prototype, clientUtils_1.getMethodsToWrap.call(this, service, service.service), this._getPatchedClientMethods.call(this, grpcClient));
          } else if (typeof service.format !== "string") {
            this._patchLoadedPackage.call(this, grpcClient, service);
          }
        });
      }
    };
    exports2.GrpcJsInstrumentation = GrpcJsInstrumentation;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/instrumentation.js
var require_instrumentation6 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.GrpcInstrumentation = exports2.GRPC_TRACE_KEY = void 0;
    var version_1 = require_version7();
    var grpc_1 = require_grpc();
    var grpc_js_1 = require_grpc_js();
    exports2.GRPC_TRACE_KEY = "grpc-trace-bin";
    var GrpcInstrumentation2 = class {
      constructor(config) {
        this.instrumentationName = "@opentelemetry/instrumentation-grpc";
        this.instrumentationVersion = version_1.VERSION;
        this._grpcJsInstrumentation = new grpc_js_1.GrpcJsInstrumentation(this.instrumentationName, this.instrumentationVersion, config);
        this._grpcNativeInstrumentation = new grpc_1.GrpcNativeInstrumentation(this.instrumentationName, this.instrumentationVersion, config);
      }
      setConfig(config) {
        this._grpcJsInstrumentation.setConfig(config);
        this._grpcNativeInstrumentation.setConfig(config);
      }
      getConfig() {
        return this._grpcJsInstrumentation.getConfig();
      }
      init() {
        return;
      }
      enable() {
        this._grpcJsInstrumentation.enable();
        this._grpcNativeInstrumentation.enable();
      }
      disable() {
        this._grpcJsInstrumentation.disable();
        this._grpcNativeInstrumentation.disable();
      }
      setMeterProvider(meterProvider) {
        this._grpcJsInstrumentation.setMeterProvider(meterProvider);
        this._grpcNativeInstrumentation.setMeterProvider(meterProvider);
      }
      setTracerProvider(tracerProvider2) {
        this._grpcJsInstrumentation.setTracerProvider(tracerProvider2);
        this._grpcNativeInstrumentation.setTracerProvider(tracerProvider2);
      }
    };
    exports2.GrpcInstrumentation = GrpcInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/index.js
var require_src21 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-grpc/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation6(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/version.js
var require_version8 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.27.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/types.js
var require_types13 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.HapiLifecycleMethodNames = exports2.HapiLayerType = exports2.handlerPatched = exports2.HapiComponentName = void 0;
    exports2.HapiComponentName = "@hapi/hapi";
    exports2.handlerPatched = Symbol("hapi-handler-patched");
    exports2.HapiLayerType = {
      ROUTER: "router",
      PLUGIN: "plugin",
      EXT: "server.ext"
    };
    exports2.HapiLifecycleMethodNames = /* @__PURE__ */ new Set([
      "onPreAuth",
      "onCredentials",
      "onPostAuth",
      "onPreHandler",
      "onPostHandler",
      "onPreResponse",
      "onRequest"
    ]);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/enums/AttributeNames.js
var require_AttributeNames5 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/enums/AttributeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["HAPI_TYPE"] = "hapi.type";
      AttributeNames2["PLUGIN_NAME"] = "hapi.plugin.name";
      AttributeNames2["EXT_TYPE"] = "server.ext.type";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/utils.js
var require_utils9 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getExtMetadata = exports2.getRootSpanMetadata = exports2.getRouteMetadata = exports2.isPatchableExtMethod = exports2.isDirectExtInput = exports2.isLifecycleExtEventObj = exports2.isLifecycleExtType = exports2.getPluginName = void 0;
    var semantic_conventions_1 = require_src3();
    var types_1 = require_types13();
    var AttributeNames_1 = require_AttributeNames5();
    function getPluginName(plugin) {
      if (plugin.name) {
        return plugin.name;
      } else {
        return plugin.pkg.name;
      }
    }
    exports2.getPluginName = getPluginName;
    var isLifecycleExtType = (variableToCheck) => {
      return typeof variableToCheck === "string" && types_1.HapiLifecycleMethodNames.has(variableToCheck);
    };
    exports2.isLifecycleExtType = isLifecycleExtType;
    var isLifecycleExtEventObj = (variableToCheck) => {
      var _a;
      const event = (_a = variableToCheck) === null || _a === void 0 ? void 0 : _a.type;
      return event !== void 0 && exports2.isLifecycleExtType(event);
    };
    exports2.isLifecycleExtEventObj = isLifecycleExtEventObj;
    var isDirectExtInput = (variableToCheck) => {
      return Array.isArray(variableToCheck) && variableToCheck.length <= 3 && exports2.isLifecycleExtType(variableToCheck[0]) && typeof variableToCheck[1] === "function";
    };
    exports2.isDirectExtInput = isDirectExtInput;
    var isPatchableExtMethod = (variableToCheck) => {
      return !Array.isArray(variableToCheck);
    };
    exports2.isPatchableExtMethod = isPatchableExtMethod;
    var getRouteMetadata = (route, pluginName) => {
      if (pluginName) {
        return {
          attributes: {
            [semantic_conventions_1.SemanticAttributes.HTTP_ROUTE]: route.path,
            [semantic_conventions_1.SemanticAttributes.HTTP_METHOD]: route.method,
            [AttributeNames_1.AttributeNames.HAPI_TYPE]: types_1.HapiLayerType.PLUGIN,
            [AttributeNames_1.AttributeNames.PLUGIN_NAME]: pluginName
          },
          name: `${pluginName}: route - ${route.path}`
        };
      }
      return {
        attributes: {
          [semantic_conventions_1.SemanticAttributes.HTTP_ROUTE]: route.path,
          [semantic_conventions_1.SemanticAttributes.HTTP_METHOD]: route.method,
          [AttributeNames_1.AttributeNames.HAPI_TYPE]: types_1.HapiLayerType.ROUTER
        },
        name: `route - ${route.path}`
      };
    };
    exports2.getRouteMetadata = getRouteMetadata;
    var getRootSpanMetadata = (route) => {
      return {
        attributes: {
          [semantic_conventions_1.SemanticAttributes.HTTP_ROUTE]: route.path
        },
        name: `${route.method} ${route.path}`
      };
    };
    exports2.getRootSpanMetadata = getRootSpanMetadata;
    var getExtMetadata = (extPoint, pluginName) => {
      if (pluginName) {
        return {
          attributes: {
            [AttributeNames_1.AttributeNames.EXT_TYPE]: extPoint,
            [AttributeNames_1.AttributeNames.HAPI_TYPE]: types_1.HapiLayerType.EXT,
            [AttributeNames_1.AttributeNames.PLUGIN_NAME]: pluginName
          },
          name: `${pluginName}: ext - ${extPoint}`
        };
      }
      return {
        attributes: {
          [AttributeNames_1.AttributeNames.EXT_TYPE]: extPoint,
          [AttributeNames_1.AttributeNames.HAPI_TYPE]: types_1.HapiLayerType.EXT
        },
        name: `ext - ${extPoint}`
      };
    };
    exports2.getExtMetadata = getExtMetadata;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/instrumentation.js
var require_instrumentation7 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.HapiInstrumentation = void 0;
    var api = require_src();
    var core_1 = require_src4();
    var instrumentation_1 = require_src13();
    var version_1 = require_version8();
    var types_1 = require_types13();
    var utils_1 = require_utils9();
    var HapiInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(config) {
        super("@opentelemetry/instrumentation-hapi", version_1.VERSION, config);
      }
      init() {
        return new instrumentation_1.InstrumentationNodeModuleDefinition(types_1.HapiComponentName, [">=17.0.0"], (moduleExports) => {
          if (!instrumentation_1.isWrapped(moduleExports.server)) {
            api.diag.debug("Patching Hapi.server");
            this._wrap(moduleExports, "server", this._getServerPatch.bind(this));
          }
          if (!instrumentation_1.isWrapped(moduleExports.Server)) {
            api.diag.debug("Patching Hapi.Server");
            this._wrap(moduleExports, "Server", this._getServerPatch.bind(this));
          }
          return moduleExports;
        }, (moduleExports) => {
          api.diag.debug("Unpatching Hapi");
          this._massUnwrap([moduleExports], ["server", "Server"]);
        });
      }
      _getServerPatch(original) {
        const instrumentation = this;
        const self2 = this;
        return function server(opts) {
          const newServer = original.apply(this, [opts]);
          self2._wrap(newServer, "route", (originalRouter) => {
            return instrumentation._getServerRoutePatch.bind(instrumentation)(originalRouter);
          });
          self2._wrap(newServer, "ext", (originalExtHandler) => {
            return instrumentation._getServerExtPatch.bind(instrumentation)(originalExtHandler);
          });
          self2._wrap(newServer, "register", instrumentation._getServerRegisterPatch.bind(instrumentation));
          return newServer;
        };
      }
      _getServerRegisterPatch(original) {
        const instrumentation = this;
        api.diag.debug("Patching Hapi.Server register function");
        return function register(pluginInput, options) {
          var _a, _b, _c, _d;
          if (Array.isArray(pluginInput)) {
            for (const pluginObj of pluginInput) {
              instrumentation._wrapRegisterHandler((_b = (_a = pluginObj.plugin) === null || _a === void 0 ? void 0 : _a.plugin) !== null && _b !== void 0 ? _b : pluginObj.plugin);
            }
          } else {
            instrumentation._wrapRegisterHandler((_d = (_c = pluginInput.plugin) === null || _c === void 0 ? void 0 : _c.plugin) !== null && _d !== void 0 ? _d : pluginInput.plugin);
          }
          return original.apply(this, [pluginInput, options]);
        };
      }
      _getServerExtPatch(original, pluginName) {
        const instrumentation = this;
        api.diag.debug("Patching Hapi.Server ext function");
        return function ext(...args) {
          if (Array.isArray(args[0])) {
            const eventsList = args[0];
            for (let i = 0; i < eventsList.length; i++) {
              const eventObj = eventsList[i];
              if (utils_1.isLifecycleExtType(eventObj.type)) {
                const lifecycleEventObj = eventObj;
                const handler = instrumentation._wrapExtMethods(lifecycleEventObj.method, eventObj.type, pluginName);
                lifecycleEventObj.method = handler;
                eventsList[i] = lifecycleEventObj;
              }
            }
            return original.apply(this, args);
          } else if (utils_1.isDirectExtInput(args)) {
            const extInput = args;
            const method = extInput[1];
            const handler = instrumentation._wrapExtMethods(method, extInput[0], pluginName);
            return original.apply(this, [extInput[0], handler, extInput[2]]);
          } else if (utils_1.isLifecycleExtEventObj(args[0])) {
            const lifecycleEventObj = args[0];
            const handler = instrumentation._wrapExtMethods(lifecycleEventObj.method, lifecycleEventObj.type, pluginName);
            lifecycleEventObj.method = handler;
            return original.call(this, lifecycleEventObj);
          }
          return original.apply(this, args);
        };
      }
      _getServerRoutePatch(original, pluginName) {
        const instrumentation = this;
        api.diag.debug("Patching Hapi.Server route function");
        return function route(route) {
          if (Array.isArray(route)) {
            for (let i = 0; i < route.length; i++) {
              const newRoute = instrumentation._wrapRouteHandler.call(instrumentation, route[i], pluginName);
              route[i] = newRoute;
            }
          } else {
            route = instrumentation._wrapRouteHandler.call(instrumentation, route, pluginName);
          }
          return original.apply(this, [route]);
        };
      }
      _wrapRegisterHandler(plugin) {
        const instrumentation = this;
        const pluginName = utils_1.getPluginName(plugin);
        const oldHandler = plugin.register;
        const self2 = this;
        const newRegisterHandler = function(server, options) {
          self2._wrap(server, "route", (original) => {
            return instrumentation._getServerRoutePatch.bind(instrumentation)(original, pluginName);
          });
          self2._wrap(server, "ext", (originalExtHandler) => {
            return instrumentation._getServerExtPatch.bind(instrumentation)(originalExtHandler, pluginName);
          });
          return oldHandler(server, options);
        };
        plugin.register = newRegisterHandler;
      }
      _wrapExtMethods(method, extPoint, pluginName) {
        const instrumentation = this;
        if (method instanceof Array) {
          for (let i = 0; i < method.length; i++) {
            method[i] = instrumentation._wrapExtMethods(method[i], extPoint);
          }
          return method;
        } else if (utils_1.isPatchableExtMethod(method)) {
          if (method[types_1.handlerPatched] === true)
            return method;
          method[types_1.handlerPatched] = true;
          const newHandler = async function(...params) {
            if (api.trace.getSpan(api.context.active()) === void 0) {
              return await method(...params);
            }
            const metadata = utils_1.getExtMetadata(extPoint, pluginName);
            const span = instrumentation.tracer.startSpan(metadata.name, {
              attributes: metadata.attributes
            });
            try {
              return await api.context.with(api.trace.setSpan(api.context.active(), span), method, void 0, ...params);
            } catch (err) {
              span.recordException(err);
              span.setStatus({
                code: api.SpanStatusCode.ERROR,
                message: err.message
              });
              throw err;
            } finally {
              span.end();
            }
          };
          return newHandler;
        }
        return method;
      }
      _wrapRouteHandler(route, pluginName) {
        var _a, _b, _c;
        const instrumentation = this;
        if (route[types_1.handlerPatched] === true)
          return route;
        route[types_1.handlerPatched] = true;
        const oldHandler = (_b = (_a = route.options) === null || _a === void 0 ? void 0 : _a.handler) !== null && _b !== void 0 ? _b : route.handler;
        if (typeof oldHandler === "function") {
          const newHandler = async function(request, h, err) {
            if (api.trace.getSpan(api.context.active()) === void 0) {
              return await oldHandler(request, h, err);
            }
            const rpcMetadata = core_1.getRPCMetadata(api.context.active());
            if ((rpcMetadata === null || rpcMetadata === void 0 ? void 0 : rpcMetadata.type) === core_1.RPCType.HTTP) {
              const rootSpanMetadata = utils_1.getRootSpanMetadata(route);
              rpcMetadata.span.updateName(rootSpanMetadata.name);
              rpcMetadata.span.setAttributes(rootSpanMetadata.attributes);
            }
            const metadata = utils_1.getRouteMetadata(route, pluginName);
            const span = instrumentation.tracer.startSpan(metadata.name, {
              attributes: metadata.attributes
            });
            try {
              return await oldHandler(request, h, err);
            } catch (err2) {
              span.recordException(err2);
              span.setStatus({
                code: api.SpanStatusCode.ERROR,
                message: err2.message
              });
              throw err2;
            } finally {
              span.end();
            }
          };
          if ((_c = route.options) === null || _c === void 0 ? void 0 : _c.handler) {
            route.options.handler = newHandler;
          } else {
            route.handler = newHandler;
          }
        }
        return route;
      }
    };
    exports2.HapiInstrumentation = HapiInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/index.js
var require_src22 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-hapi/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation7(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/suppress-tracing.js
var require_suppress_tracing2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/suppress-tracing.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isTracingSuppressed = exports2.unsuppressTracing = exports2.suppressTracing = void 0;
    var api_1 = require_src();
    var SUPPRESS_TRACING_KEY = api_1.createContextKey("OpenTelemetry SDK Context Key SUPPRESS_TRACING");
    function suppressTracing(context) {
      return context.setValue(SUPPRESS_TRACING_KEY, true);
    }
    exports2.suppressTracing = suppressTracing;
    function unsuppressTracing(context) {
      return context.deleteValue(SUPPRESS_TRACING_KEY);
    }
    exports2.unsuppressTracing = unsuppressTracing;
    function isTracingSuppressed(context) {
      return context.getValue(SUPPRESS_TRACING_KEY) === true;
    }
    exports2.isTracingSuppressed = isTracingSuppressed;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/baggage/constants.js
var require_constants4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/baggage/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BAGGAGE_MAX_TOTAL_LENGTH = exports2.BAGGAGE_MAX_PER_NAME_VALUE_PAIRS = exports2.BAGGAGE_MAX_NAME_VALUE_PAIRS = exports2.BAGGAGE_HEADER = exports2.BAGGAGE_ITEMS_SEPARATOR = exports2.BAGGAGE_PROPERTIES_SEPARATOR = exports2.BAGGAGE_KEY_PAIR_SEPARATOR = void 0;
    exports2.BAGGAGE_KEY_PAIR_SEPARATOR = "=";
    exports2.BAGGAGE_PROPERTIES_SEPARATOR = ";";
    exports2.BAGGAGE_ITEMS_SEPARATOR = ",";
    exports2.BAGGAGE_HEADER = "baggage";
    exports2.BAGGAGE_MAX_NAME_VALUE_PAIRS = 180;
    exports2.BAGGAGE_MAX_PER_NAME_VALUE_PAIRS = 4096;
    exports2.BAGGAGE_MAX_TOTAL_LENGTH = 8192;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/baggage/utils.js
var require_utils10 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/baggage/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.parseKeyPairsIntoRecord = exports2.parsePairKeyValue = exports2.getKeyPairs = exports2.serializeKeyPairs = void 0;
    var api_1 = require_src();
    var constants_1 = require_constants4();
    function serializeKeyPairs(keyPairs) {
      return keyPairs.reduce((hValue, current) => {
        const value = `${hValue}${hValue !== "" ? constants_1.BAGGAGE_ITEMS_SEPARATOR : ""}${current}`;
        return value.length > constants_1.BAGGAGE_MAX_TOTAL_LENGTH ? hValue : value;
      }, "");
    }
    exports2.serializeKeyPairs = serializeKeyPairs;
    function getKeyPairs(baggage) {
      return baggage.getAllEntries().map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value.value)}`);
    }
    exports2.getKeyPairs = getKeyPairs;
    function parsePairKeyValue(entry) {
      const valueProps = entry.split(constants_1.BAGGAGE_PROPERTIES_SEPARATOR);
      if (valueProps.length <= 0)
        return;
      const keyPairPart = valueProps.shift();
      if (!keyPairPart)
        return;
      const keyPair = keyPairPart.split(constants_1.BAGGAGE_KEY_PAIR_SEPARATOR);
      if (keyPair.length !== 2)
        return;
      const key = decodeURIComponent(keyPair[0].trim());
      const value = decodeURIComponent(keyPair[1].trim());
      let metadata;
      if (valueProps.length > 0) {
        metadata = api_1.baggageEntryMetadataFromString(valueProps.join(constants_1.BAGGAGE_PROPERTIES_SEPARATOR));
      }
      return { key, value, metadata };
    }
    exports2.parsePairKeyValue = parsePairKeyValue;
    function parseKeyPairsIntoRecord(value) {
      if (typeof value !== "string" || value.length === 0)
        return {};
      return value.split(constants_1.BAGGAGE_ITEMS_SEPARATOR).map((entry) => {
        return parsePairKeyValue(entry);
      }).filter((keyPair) => keyPair !== void 0 && keyPair.value.length > 0).reduce((headers, keyPair) => {
        headers[keyPair.key] = keyPair.value;
        return headers;
      }, {});
    }
    exports2.parseKeyPairsIntoRecord = parseKeyPairsIntoRecord;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/baggage/propagation/W3CBaggagePropagator.js
var require_W3CBaggagePropagator2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/baggage/propagation/W3CBaggagePropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.W3CBaggagePropagator = void 0;
    var api_1 = require_src();
    var suppress_tracing_1 = require_suppress_tracing2();
    var constants_1 = require_constants4();
    var utils_1 = require_utils10();
    var W3CBaggagePropagator = class {
      inject(context, carrier, setter) {
        const baggage = api_1.propagation.getBaggage(context);
        if (!baggage || suppress_tracing_1.isTracingSuppressed(context))
          return;
        const keyPairs = utils_1.getKeyPairs(baggage).filter((pair) => {
          return pair.length <= constants_1.BAGGAGE_MAX_PER_NAME_VALUE_PAIRS;
        }).slice(0, constants_1.BAGGAGE_MAX_NAME_VALUE_PAIRS);
        const headerValue = utils_1.serializeKeyPairs(keyPairs);
        if (headerValue.length > 0) {
          setter.set(carrier, constants_1.BAGGAGE_HEADER, headerValue);
        }
      }
      extract(context, carrier, getter) {
        const headerValue = getter.get(carrier, constants_1.BAGGAGE_HEADER);
        if (!headerValue)
          return context;
        const baggage = {};
        if (headerValue.length === 0) {
          return context;
        }
        const pairs = headerValue.split(constants_1.BAGGAGE_ITEMS_SEPARATOR);
        pairs.forEach((entry) => {
          const keyPair = utils_1.parsePairKeyValue(entry);
          if (keyPair) {
            const baggageEntry = { value: keyPair.value };
            if (keyPair.metadata) {
              baggageEntry.metadata = keyPair.metadata;
            }
            baggage[keyPair.key] = baggageEntry;
          }
        });
        if (Object.entries(baggage).length === 0) {
          return context;
        }
        return api_1.propagation.setBaggage(context, api_1.propagation.createBaggage(baggage));
      }
      fields() {
        return [constants_1.BAGGAGE_HEADER];
      }
    };
    exports2.W3CBaggagePropagator = W3CBaggagePropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/attributes.js
var require_attributes3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/attributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isAttributeValue = exports2.sanitizeAttributes = void 0;
    function sanitizeAttributes(attributes) {
      const out = {};
      if (attributes == null || typeof attributes !== "object") {
        return out;
      }
      for (const [k, v] of Object.entries(attributes)) {
        if (isAttributeValue(v)) {
          if (Array.isArray(v)) {
            out[k] = v.slice();
          } else {
            out[k] = v;
          }
        }
      }
      return out;
    }
    exports2.sanitizeAttributes = sanitizeAttributes;
    function isAttributeValue(val) {
      if (val == null) {
        return true;
      }
      if (Array.isArray(val)) {
        return isHomogeneousAttributeValueArray(val);
      }
      return isValidPrimitiveAttributeValue(val);
    }
    exports2.isAttributeValue = isAttributeValue;
    function isHomogeneousAttributeValueArray(arr) {
      let type;
      for (const element of arr) {
        if (element == null)
          continue;
        if (!type) {
          if (isValidPrimitiveAttributeValue(element)) {
            type = typeof element;
            continue;
          }
          return false;
        }
        if (typeof element === type) {
          continue;
        }
        return false;
      }
      return true;
    }
    function isValidPrimitiveAttributeValue(val) {
      switch (typeof val) {
        case "number":
          return true;
        case "boolean":
          return true;
        case "string":
          return true;
      }
      return false;
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/logging-error-handler.js
var require_logging_error_handler2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/logging-error-handler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.loggingErrorHandler = void 0;
    var api_1 = require_src();
    function loggingErrorHandler() {
      return (ex) => {
        api_1.diag.error(stringifyException(ex));
      };
    }
    exports2.loggingErrorHandler = loggingErrorHandler;
    function stringifyException(ex) {
      if (typeof ex === "string") {
        return ex;
      } else {
        return JSON.stringify(flattenException(ex));
      }
    }
    function flattenException(ex) {
      const result = {};
      let current = ex;
      while (current !== null) {
        Object.getOwnPropertyNames(current).forEach((propertyName) => {
          if (result[propertyName])
            return;
          const value = current[propertyName];
          if (value) {
            result[propertyName] = String(value);
          }
        });
        current = Object.getPrototypeOf(current);
      }
      return result;
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/global-error-handler.js
var require_global_error_handler2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/global-error-handler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.globalErrorHandler = exports2.setGlobalErrorHandler = void 0;
    var logging_error_handler_1 = require_logging_error_handler2();
    var delegateHandler = logging_error_handler_1.loggingErrorHandler();
    function setGlobalErrorHandler(handler) {
      delegateHandler = handler;
    }
    exports2.setGlobalErrorHandler = setGlobalErrorHandler;
    function globalErrorHandler(ex) {
      try {
        delegateHandler(ex);
      } catch (_a) {
      }
    }
    exports2.globalErrorHandler = globalErrorHandler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/sampling.js
var require_sampling2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/sampling.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TracesSamplerValues = void 0;
    var TracesSamplerValues;
    (function(TracesSamplerValues2) {
      TracesSamplerValues2["AlwaysOff"] = "always_off";
      TracesSamplerValues2["AlwaysOn"] = "always_on";
      TracesSamplerValues2["ParentBasedAlwaysOff"] = "parentbased_always_off";
      TracesSamplerValues2["ParentBasedAlwaysOn"] = "parentbased_always_on";
      TracesSamplerValues2["ParentBasedTraceIdRatio"] = "parentbased_traceidratio";
      TracesSamplerValues2["TraceIdRatio"] = "traceidratio";
    })(TracesSamplerValues = exports2.TracesSamplerValues || (exports2.TracesSamplerValues = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/environment.js
var require_environment3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/environment.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.parseEnvironment = exports2.DEFAULT_ENVIRONMENT = exports2.DEFAULT_ATTRIBUTE_COUNT_LIMIT = exports2.DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT = void 0;
    var api_1 = require_src();
    var sampling_1 = require_sampling2();
    var DEFAULT_LIST_SEPARATOR = ",";
    var ENVIRONMENT_NUMBERS_KEYS = [
      "OTEL_BSP_EXPORT_TIMEOUT",
      "OTEL_BSP_MAX_EXPORT_BATCH_SIZE",
      "OTEL_BSP_MAX_QUEUE_SIZE",
      "OTEL_BSP_SCHEDULE_DELAY",
      "OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT",
      "OTEL_ATTRIBUTE_COUNT_LIMIT",
      "OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT",
      "OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT",
      "OTEL_SPAN_EVENT_COUNT_LIMIT",
      "OTEL_SPAN_LINK_COUNT_LIMIT"
    ];
    function isEnvVarANumber(key) {
      return ENVIRONMENT_NUMBERS_KEYS.indexOf(key) > -1;
    }
    var ENVIRONMENT_LISTS_KEYS = [
      "OTEL_NO_PATCH_MODULES",
      "OTEL_PROPAGATORS"
    ];
    function isEnvVarAList(key) {
      return ENVIRONMENT_LISTS_KEYS.indexOf(key) > -1;
    }
    exports2.DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT = Infinity;
    exports2.DEFAULT_ATTRIBUTE_COUNT_LIMIT = 128;
    exports2.DEFAULT_ENVIRONMENT = {
      CONTAINER_NAME: "",
      ECS_CONTAINER_METADATA_URI_V4: "",
      ECS_CONTAINER_METADATA_URI: "",
      HOSTNAME: "",
      KUBERNETES_SERVICE_HOST: "",
      NAMESPACE: "",
      OTEL_BSP_EXPORT_TIMEOUT: 3e4,
      OTEL_BSP_MAX_EXPORT_BATCH_SIZE: 512,
      OTEL_BSP_MAX_QUEUE_SIZE: 2048,
      OTEL_BSP_SCHEDULE_DELAY: 5e3,
      OTEL_EXPORTER_JAEGER_AGENT_HOST: "",
      OTEL_EXPORTER_JAEGER_ENDPOINT: "",
      OTEL_EXPORTER_JAEGER_PASSWORD: "",
      OTEL_EXPORTER_JAEGER_USER: "",
      OTEL_EXPORTER_OTLP_ENDPOINT: "",
      OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: "",
      OTEL_EXPORTER_OTLP_METRICS_ENDPOINT: "",
      OTEL_EXPORTER_OTLP_HEADERS: "",
      OTEL_EXPORTER_OTLP_TRACES_HEADERS: "",
      OTEL_EXPORTER_OTLP_METRICS_HEADERS: "",
      OTEL_EXPORTER_ZIPKIN_ENDPOINT: "http://localhost:9411/api/v2/spans",
      OTEL_LOG_LEVEL: api_1.DiagLogLevel.INFO,
      OTEL_NO_PATCH_MODULES: [],
      OTEL_PROPAGATORS: ["tracecontext", "baggage"],
      OTEL_RESOURCE_ATTRIBUTES: "",
      OTEL_SERVICE_NAME: "",
      OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT: exports2.DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT,
      OTEL_ATTRIBUTE_COUNT_LIMIT: exports2.DEFAULT_ATTRIBUTE_COUNT_LIMIT,
      OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT: exports2.DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT,
      OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT: exports2.DEFAULT_ATTRIBUTE_COUNT_LIMIT,
      OTEL_SPAN_EVENT_COUNT_LIMIT: 128,
      OTEL_SPAN_LINK_COUNT_LIMIT: 128,
      OTEL_TRACES_EXPORTER: "none",
      OTEL_TRACES_SAMPLER: sampling_1.TracesSamplerValues.ParentBasedAlwaysOn,
      OTEL_TRACES_SAMPLER_ARG: ""
    };
    function parseNumber(name, environment, values, min = -Infinity, max = Infinity) {
      if (typeof values[name] !== "undefined") {
        const value = Number(values[name]);
        if (!isNaN(value)) {
          if (value < min) {
            environment[name] = min;
          } else if (value > max) {
            environment[name] = max;
          } else {
            environment[name] = value;
          }
        }
      }
    }
    function parseStringList(name, output, input, separator = DEFAULT_LIST_SEPARATOR) {
      const givenValue = input[name];
      if (typeof givenValue === "string") {
        output[name] = givenValue.split(separator).map((v) => v.trim());
      }
    }
    var logLevelMap = {
      ALL: api_1.DiagLogLevel.ALL,
      VERBOSE: api_1.DiagLogLevel.VERBOSE,
      DEBUG: api_1.DiagLogLevel.DEBUG,
      INFO: api_1.DiagLogLevel.INFO,
      WARN: api_1.DiagLogLevel.WARN,
      ERROR: api_1.DiagLogLevel.ERROR,
      NONE: api_1.DiagLogLevel.NONE
    };
    function setLogLevelFromEnv(key, environment, values) {
      const value = values[key];
      if (typeof value === "string") {
        const theLevel = logLevelMap[value.toUpperCase()];
        if (theLevel != null) {
          environment[key] = theLevel;
        }
      }
    }
    function parseEnvironment(values) {
      const environment = {};
      for (const env in exports2.DEFAULT_ENVIRONMENT) {
        const key = env;
        switch (key) {
          case "OTEL_LOG_LEVEL":
            setLogLevelFromEnv(key, environment, values);
            break;
          default:
            if (isEnvVarANumber(key)) {
              parseNumber(key, environment, values);
            } else if (isEnvVarAList(key)) {
              parseStringList(key, environment, values);
            } else {
              const value = values[key];
              if (typeof value !== "undefined" && value !== null) {
                environment[key] = String(value);
              }
            }
        }
      }
      return environment;
    }
    exports2.parseEnvironment = parseEnvironment;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/environment.js
var require_environment4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/environment.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getEnv = void 0;
    var os = require("os");
    var environment_1 = require_environment3();
    function getEnv2() {
      const processEnv = environment_1.parseEnvironment(process.env);
      return Object.assign({
        HOSTNAME: os.hostname()
      }, environment_1.DEFAULT_ENVIRONMENT, processEnv);
    }
    exports2.getEnv = getEnv2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/globalThis.js
var require_globalThis4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/globalThis.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2._globalThis = void 0;
    exports2._globalThis = typeof globalThis === "object" ? globalThis : global;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/hex-to-base64.js
var require_hex_to_base642 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/hex-to-base64.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.hexToBase64 = void 0;
    function hexToBase64(hexStr) {
      const hexStrLen = hexStr.length;
      let hexAsciiCharsStr = "";
      for (let i = 0; i < hexStrLen; i += 2) {
        const hexPair = hexStr.substring(i, i + 2);
        const hexVal = parseInt(hexPair, 16);
        hexAsciiCharsStr += String.fromCharCode(hexVal);
      }
      return Buffer.from(hexAsciiCharsStr, "ascii").toString("base64");
    }
    exports2.hexToBase64 = hexToBase64;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/RandomIdGenerator.js
var require_RandomIdGenerator2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/RandomIdGenerator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RandomIdGenerator = void 0;
    var SPAN_ID_BYTES = 8;
    var TRACE_ID_BYTES = 16;
    var RandomIdGenerator = class {
      constructor() {
        this.generateTraceId = getIdGenerator(TRACE_ID_BYTES);
        this.generateSpanId = getIdGenerator(SPAN_ID_BYTES);
      }
    };
    exports2.RandomIdGenerator = RandomIdGenerator;
    var SHARED_BUFFER = Buffer.allocUnsafe(TRACE_ID_BYTES);
    function getIdGenerator(bytes) {
      return function generateId() {
        for (let i = 0; i < bytes / 4; i++) {
          SHARED_BUFFER.writeUInt32BE(Math.random() * 2 ** 32 >>> 0, i * 4);
        }
        for (let i = 0; i < bytes; i++) {
          if (SHARED_BUFFER[i] > 0) {
            break;
          } else if (i === bytes - 1) {
            SHARED_BUFFER[bytes - 1] = 1;
          }
        }
        return SHARED_BUFFER.toString("hex", 0, bytes);
      };
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/performance.js
var require_performance2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/performance.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.otperformance = void 0;
    var perf_hooks_1 = require("perf_hooks");
    exports2.otperformance = perf_hooks_1.performance;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/version.js
var require_version9 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "1.0.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/trace/SemanticAttributes.js
var require_SemanticAttributes3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/trace/SemanticAttributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MessageTypeValues = exports2.RpcGrpcStatusCodeValues = exports2.MessagingOperationValues = exports2.MessagingDestinationKindValues = exports2.HttpFlavorValues = exports2.NetHostConnectionSubtypeValues = exports2.NetHostConnectionTypeValues = exports2.NetTransportValues = exports2.FaasInvokedProviderValues = exports2.FaasDocumentOperationValues = exports2.FaasTriggerValues = exports2.DbCassandraConsistencyLevelValues = exports2.DbSystemValues = exports2.SemanticAttributes = void 0;
    exports2.SemanticAttributes = {
      AWS_LAMBDA_INVOKED_ARN: "aws.lambda.invoked_arn",
      DB_SYSTEM: "db.system",
      DB_CONNECTION_STRING: "db.connection_string",
      DB_USER: "db.user",
      DB_JDBC_DRIVER_CLASSNAME: "db.jdbc.driver_classname",
      DB_NAME: "db.name",
      DB_STATEMENT: "db.statement",
      DB_OPERATION: "db.operation",
      DB_MSSQL_INSTANCE_NAME: "db.mssql.instance_name",
      DB_CASSANDRA_KEYSPACE: "db.cassandra.keyspace",
      DB_CASSANDRA_PAGE_SIZE: "db.cassandra.page_size",
      DB_CASSANDRA_CONSISTENCY_LEVEL: "db.cassandra.consistency_level",
      DB_CASSANDRA_TABLE: "db.cassandra.table",
      DB_CASSANDRA_IDEMPOTENCE: "db.cassandra.idempotence",
      DB_CASSANDRA_SPECULATIVE_EXECUTION_COUNT: "db.cassandra.speculative_execution_count",
      DB_CASSANDRA_COORDINATOR_ID: "db.cassandra.coordinator.id",
      DB_CASSANDRA_COORDINATOR_DC: "db.cassandra.coordinator.dc",
      DB_HBASE_NAMESPACE: "db.hbase.namespace",
      DB_REDIS_DATABASE_INDEX: "db.redis.database_index",
      DB_MONGODB_COLLECTION: "db.mongodb.collection",
      DB_SQL_TABLE: "db.sql.table",
      EXCEPTION_TYPE: "exception.type",
      EXCEPTION_MESSAGE: "exception.message",
      EXCEPTION_STACKTRACE: "exception.stacktrace",
      EXCEPTION_ESCAPED: "exception.escaped",
      FAAS_TRIGGER: "faas.trigger",
      FAAS_EXECUTION: "faas.execution",
      FAAS_DOCUMENT_COLLECTION: "faas.document.collection",
      FAAS_DOCUMENT_OPERATION: "faas.document.operation",
      FAAS_DOCUMENT_TIME: "faas.document.time",
      FAAS_DOCUMENT_NAME: "faas.document.name",
      FAAS_TIME: "faas.time",
      FAAS_CRON: "faas.cron",
      FAAS_COLDSTART: "faas.coldstart",
      FAAS_INVOKED_NAME: "faas.invoked_name",
      FAAS_INVOKED_PROVIDER: "faas.invoked_provider",
      FAAS_INVOKED_REGION: "faas.invoked_region",
      NET_TRANSPORT: "net.transport",
      NET_PEER_IP: "net.peer.ip",
      NET_PEER_PORT: "net.peer.port",
      NET_PEER_NAME: "net.peer.name",
      NET_HOST_IP: "net.host.ip",
      NET_HOST_PORT: "net.host.port",
      NET_HOST_NAME: "net.host.name",
      NET_HOST_CONNECTION_TYPE: "net.host.connection.type",
      NET_HOST_CONNECTION_SUBTYPE: "net.host.connection.subtype",
      NET_HOST_CARRIER_NAME: "net.host.carrier.name",
      NET_HOST_CARRIER_MCC: "net.host.carrier.mcc",
      NET_HOST_CARRIER_MNC: "net.host.carrier.mnc",
      NET_HOST_CARRIER_ICC: "net.host.carrier.icc",
      PEER_SERVICE: "peer.service",
      ENDUSER_ID: "enduser.id",
      ENDUSER_ROLE: "enduser.role",
      ENDUSER_SCOPE: "enduser.scope",
      THREAD_ID: "thread.id",
      THREAD_NAME: "thread.name",
      CODE_FUNCTION: "code.function",
      CODE_NAMESPACE: "code.namespace",
      CODE_FILEPATH: "code.filepath",
      CODE_LINENO: "code.lineno",
      HTTP_METHOD: "http.method",
      HTTP_URL: "http.url",
      HTTP_TARGET: "http.target",
      HTTP_HOST: "http.host",
      HTTP_SCHEME: "http.scheme",
      HTTP_STATUS_CODE: "http.status_code",
      HTTP_FLAVOR: "http.flavor",
      HTTP_USER_AGENT: "http.user_agent",
      HTTP_REQUEST_CONTENT_LENGTH: "http.request_content_length",
      HTTP_REQUEST_CONTENT_LENGTH_UNCOMPRESSED: "http.request_content_length_uncompressed",
      HTTP_RESPONSE_CONTENT_LENGTH: "http.response_content_length",
      HTTP_RESPONSE_CONTENT_LENGTH_UNCOMPRESSED: "http.response_content_length_uncompressed",
      HTTP_SERVER_NAME: "http.server_name",
      HTTP_ROUTE: "http.route",
      HTTP_CLIENT_IP: "http.client_ip",
      AWS_DYNAMODB_TABLE_NAMES: "aws.dynamodb.table_names",
      AWS_DYNAMODB_CONSUMED_CAPACITY: "aws.dynamodb.consumed_capacity",
      AWS_DYNAMODB_ITEM_COLLECTION_METRICS: "aws.dynamodb.item_collection_metrics",
      AWS_DYNAMODB_PROVISIONED_READ_CAPACITY: "aws.dynamodb.provisioned_read_capacity",
      AWS_DYNAMODB_PROVISIONED_WRITE_CAPACITY: "aws.dynamodb.provisioned_write_capacity",
      AWS_DYNAMODB_CONSISTENT_READ: "aws.dynamodb.consistent_read",
      AWS_DYNAMODB_PROJECTION: "aws.dynamodb.projection",
      AWS_DYNAMODB_LIMIT: "aws.dynamodb.limit",
      AWS_DYNAMODB_ATTRIBUTES_TO_GET: "aws.dynamodb.attributes_to_get",
      AWS_DYNAMODB_INDEX_NAME: "aws.dynamodb.index_name",
      AWS_DYNAMODB_SELECT: "aws.dynamodb.select",
      AWS_DYNAMODB_GLOBAL_SECONDARY_INDEXES: "aws.dynamodb.global_secondary_indexes",
      AWS_DYNAMODB_LOCAL_SECONDARY_INDEXES: "aws.dynamodb.local_secondary_indexes",
      AWS_DYNAMODB_EXCLUSIVE_START_TABLE: "aws.dynamodb.exclusive_start_table",
      AWS_DYNAMODB_TABLE_COUNT: "aws.dynamodb.table_count",
      AWS_DYNAMODB_SCAN_FORWARD: "aws.dynamodb.scan_forward",
      AWS_DYNAMODB_SEGMENT: "aws.dynamodb.segment",
      AWS_DYNAMODB_TOTAL_SEGMENTS: "aws.dynamodb.total_segments",
      AWS_DYNAMODB_COUNT: "aws.dynamodb.count",
      AWS_DYNAMODB_SCANNED_COUNT: "aws.dynamodb.scanned_count",
      AWS_DYNAMODB_ATTRIBUTE_DEFINITIONS: "aws.dynamodb.attribute_definitions",
      AWS_DYNAMODB_GLOBAL_SECONDARY_INDEX_UPDATES: "aws.dynamodb.global_secondary_index_updates",
      MESSAGING_SYSTEM: "messaging.system",
      MESSAGING_DESTINATION: "messaging.destination",
      MESSAGING_DESTINATION_KIND: "messaging.destination_kind",
      MESSAGING_TEMP_DESTINATION: "messaging.temp_destination",
      MESSAGING_PROTOCOL: "messaging.protocol",
      MESSAGING_PROTOCOL_VERSION: "messaging.protocol_version",
      MESSAGING_URL: "messaging.url",
      MESSAGING_MESSAGE_ID: "messaging.message_id",
      MESSAGING_CONVERSATION_ID: "messaging.conversation_id",
      MESSAGING_MESSAGE_PAYLOAD_SIZE_BYTES: "messaging.message_payload_size_bytes",
      MESSAGING_MESSAGE_PAYLOAD_COMPRESSED_SIZE_BYTES: "messaging.message_payload_compressed_size_bytes",
      MESSAGING_OPERATION: "messaging.operation",
      MESSAGING_CONSUMER_ID: "messaging.consumer_id",
      MESSAGING_RABBITMQ_ROUTING_KEY: "messaging.rabbitmq.routing_key",
      MESSAGING_KAFKA_MESSAGE_KEY: "messaging.kafka.message_key",
      MESSAGING_KAFKA_CONSUMER_GROUP: "messaging.kafka.consumer_group",
      MESSAGING_KAFKA_CLIENT_ID: "messaging.kafka.client_id",
      MESSAGING_KAFKA_PARTITION: "messaging.kafka.partition",
      MESSAGING_KAFKA_TOMBSTONE: "messaging.kafka.tombstone",
      RPC_SYSTEM: "rpc.system",
      RPC_SERVICE: "rpc.service",
      RPC_METHOD: "rpc.method",
      RPC_GRPC_STATUS_CODE: "rpc.grpc.status_code",
      RPC_JSONRPC_VERSION: "rpc.jsonrpc.version",
      RPC_JSONRPC_REQUEST_ID: "rpc.jsonrpc.request_id",
      RPC_JSONRPC_ERROR_CODE: "rpc.jsonrpc.error_code",
      RPC_JSONRPC_ERROR_MESSAGE: "rpc.jsonrpc.error_message",
      MESSAGE_TYPE: "message.type",
      MESSAGE_ID: "message.id",
      MESSAGE_COMPRESSED_SIZE: "message.compressed_size",
      MESSAGE_UNCOMPRESSED_SIZE: "message.uncompressed_size"
    };
    exports2.DbSystemValues = {
      OTHER_SQL: "other_sql",
      MSSQL: "mssql",
      MYSQL: "mysql",
      ORACLE: "oracle",
      DB2: "db2",
      POSTGRESQL: "postgresql",
      REDSHIFT: "redshift",
      HIVE: "hive",
      CLOUDSCAPE: "cloudscape",
      HSQLDB: "hsqldb",
      PROGRESS: "progress",
      MAXDB: "maxdb",
      HANADB: "hanadb",
      INGRES: "ingres",
      FIRSTSQL: "firstsql",
      EDB: "edb",
      CACHE: "cache",
      ADABAS: "adabas",
      FIREBIRD: "firebird",
      DERBY: "derby",
      FILEMAKER: "filemaker",
      INFORMIX: "informix",
      INSTANTDB: "instantdb",
      INTERBASE: "interbase",
      MARIADB: "mariadb",
      NETEZZA: "netezza",
      PERVASIVE: "pervasive",
      POINTBASE: "pointbase",
      SQLITE: "sqlite",
      SYBASE: "sybase",
      TERADATA: "teradata",
      VERTICA: "vertica",
      H2: "h2",
      COLDFUSION: "coldfusion",
      CASSANDRA: "cassandra",
      HBASE: "hbase",
      MONGODB: "mongodb",
      REDIS: "redis",
      COUCHBASE: "couchbase",
      COUCHDB: "couchdb",
      COSMOSDB: "cosmosdb",
      DYNAMODB: "dynamodb",
      NEO4J: "neo4j",
      GEODE: "geode",
      ELASTICSEARCH: "elasticsearch",
      MEMCACHED: "memcached",
      COCKROACHDB: "cockroachdb"
    };
    exports2.DbCassandraConsistencyLevelValues = {
      ALL: "all",
      EACH_QUORUM: "each_quorum",
      QUORUM: "quorum",
      LOCAL_QUORUM: "local_quorum",
      ONE: "one",
      TWO: "two",
      THREE: "three",
      LOCAL_ONE: "local_one",
      ANY: "any",
      SERIAL: "serial",
      LOCAL_SERIAL: "local_serial"
    };
    exports2.FaasTriggerValues = {
      DATASOURCE: "datasource",
      HTTP: "http",
      PUBSUB: "pubsub",
      TIMER: "timer",
      OTHER: "other"
    };
    exports2.FaasDocumentOperationValues = {
      INSERT: "insert",
      EDIT: "edit",
      DELETE: "delete"
    };
    exports2.FaasInvokedProviderValues = {
      ALIBABA_CLOUD: "alibaba_cloud",
      AWS: "aws",
      AZURE: "azure",
      GCP: "gcp"
    };
    exports2.NetTransportValues = {
      IP_TCP: "ip_tcp",
      IP_UDP: "ip_udp",
      IP: "ip",
      UNIX: "unix",
      PIPE: "pipe",
      INPROC: "inproc",
      OTHER: "other"
    };
    exports2.NetHostConnectionTypeValues = {
      WIFI: "wifi",
      WIRED: "wired",
      CELL: "cell",
      UNAVAILABLE: "unavailable",
      UNKNOWN: "unknown"
    };
    exports2.NetHostConnectionSubtypeValues = {
      GPRS: "gprs",
      EDGE: "edge",
      UMTS: "umts",
      CDMA: "cdma",
      EVDO_0: "evdo_0",
      EVDO_A: "evdo_a",
      CDMA2000_1XRTT: "cdma2000_1xrtt",
      HSDPA: "hsdpa",
      HSUPA: "hsupa",
      HSPA: "hspa",
      IDEN: "iden",
      EVDO_B: "evdo_b",
      LTE: "lte",
      EHRPD: "ehrpd",
      HSPAP: "hspap",
      GSM: "gsm",
      TD_SCDMA: "td_scdma",
      IWLAN: "iwlan",
      NR: "nr",
      NRNSA: "nrnsa",
      LTE_CA: "lte_ca"
    };
    exports2.HttpFlavorValues = {
      HTTP_1_0: "1.0",
      HTTP_1_1: "1.1",
      HTTP_2_0: "2.0",
      SPDY: "SPDY",
      QUIC: "QUIC"
    };
    exports2.MessagingDestinationKindValues = {
      QUEUE: "queue",
      TOPIC: "topic"
    };
    exports2.MessagingOperationValues = {
      RECEIVE: "receive",
      PROCESS: "process"
    };
    exports2.RpcGrpcStatusCodeValues = {
      OK: 0,
      CANCELLED: 1,
      UNKNOWN: 2,
      INVALID_ARGUMENT: 3,
      DEADLINE_EXCEEDED: 4,
      NOT_FOUND: 5,
      ALREADY_EXISTS: 6,
      PERMISSION_DENIED: 7,
      RESOURCE_EXHAUSTED: 8,
      FAILED_PRECONDITION: 9,
      ABORTED: 10,
      OUT_OF_RANGE: 11,
      UNIMPLEMENTED: 12,
      INTERNAL: 13,
      UNAVAILABLE: 14,
      DATA_LOSS: 15,
      UNAUTHENTICATED: 16
    };
    exports2.MessageTypeValues = {
      SENT: "SENT",
      RECEIVED: "RECEIVED"
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/trace/index.js
var require_trace4 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/trace/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_SemanticAttributes3(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/resource/SemanticResourceAttributes.js
var require_SemanticResourceAttributes3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/resource/SemanticResourceAttributes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TelemetrySdkLanguageValues = exports2.OsTypeValues = exports2.HostArchValues = exports2.AwsEcsLaunchtypeValues = exports2.CloudPlatformValues = exports2.CloudProviderValues = exports2.SemanticResourceAttributes = void 0;
    exports2.SemanticResourceAttributes = {
      CLOUD_PROVIDER: "cloud.provider",
      CLOUD_ACCOUNT_ID: "cloud.account.id",
      CLOUD_REGION: "cloud.region",
      CLOUD_AVAILABILITY_ZONE: "cloud.availability_zone",
      CLOUD_PLATFORM: "cloud.platform",
      AWS_ECS_CONTAINER_ARN: "aws.ecs.container.arn",
      AWS_ECS_CLUSTER_ARN: "aws.ecs.cluster.arn",
      AWS_ECS_LAUNCHTYPE: "aws.ecs.launchtype",
      AWS_ECS_TASK_ARN: "aws.ecs.task.arn",
      AWS_ECS_TASK_FAMILY: "aws.ecs.task.family",
      AWS_ECS_TASK_REVISION: "aws.ecs.task.revision",
      AWS_EKS_CLUSTER_ARN: "aws.eks.cluster.arn",
      AWS_LOG_GROUP_NAMES: "aws.log.group.names",
      AWS_LOG_GROUP_ARNS: "aws.log.group.arns",
      AWS_LOG_STREAM_NAMES: "aws.log.stream.names",
      AWS_LOG_STREAM_ARNS: "aws.log.stream.arns",
      CONTAINER_NAME: "container.name",
      CONTAINER_ID: "container.id",
      CONTAINER_RUNTIME: "container.runtime",
      CONTAINER_IMAGE_NAME: "container.image.name",
      CONTAINER_IMAGE_TAG: "container.image.tag",
      DEPLOYMENT_ENVIRONMENT: "deployment.environment",
      DEVICE_ID: "device.id",
      DEVICE_MODEL_IDENTIFIER: "device.model.identifier",
      DEVICE_MODEL_NAME: "device.model.name",
      FAAS_NAME: "faas.name",
      FAAS_ID: "faas.id",
      FAAS_VERSION: "faas.version",
      FAAS_INSTANCE: "faas.instance",
      FAAS_MAX_MEMORY: "faas.max_memory",
      HOST_ID: "host.id",
      HOST_NAME: "host.name",
      HOST_TYPE: "host.type",
      HOST_ARCH: "host.arch",
      HOST_IMAGE_NAME: "host.image.name",
      HOST_IMAGE_ID: "host.image.id",
      HOST_IMAGE_VERSION: "host.image.version",
      K8S_CLUSTER_NAME: "k8s.cluster.name",
      K8S_NODE_NAME: "k8s.node.name",
      K8S_NODE_UID: "k8s.node.uid",
      K8S_NAMESPACE_NAME: "k8s.namespace.name",
      K8S_POD_UID: "k8s.pod.uid",
      K8S_POD_NAME: "k8s.pod.name",
      K8S_CONTAINER_NAME: "k8s.container.name",
      K8S_REPLICASET_UID: "k8s.replicaset.uid",
      K8S_REPLICASET_NAME: "k8s.replicaset.name",
      K8S_DEPLOYMENT_UID: "k8s.deployment.uid",
      K8S_DEPLOYMENT_NAME: "k8s.deployment.name",
      K8S_STATEFULSET_UID: "k8s.statefulset.uid",
      K8S_STATEFULSET_NAME: "k8s.statefulset.name",
      K8S_DAEMONSET_UID: "k8s.daemonset.uid",
      K8S_DAEMONSET_NAME: "k8s.daemonset.name",
      K8S_JOB_UID: "k8s.job.uid",
      K8S_JOB_NAME: "k8s.job.name",
      K8S_CRONJOB_UID: "k8s.cronjob.uid",
      K8S_CRONJOB_NAME: "k8s.cronjob.name",
      OS_TYPE: "os.type",
      OS_DESCRIPTION: "os.description",
      OS_NAME: "os.name",
      OS_VERSION: "os.version",
      PROCESS_PID: "process.pid",
      PROCESS_EXECUTABLE_NAME: "process.executable.name",
      PROCESS_EXECUTABLE_PATH: "process.executable.path",
      PROCESS_COMMAND: "process.command",
      PROCESS_COMMAND_LINE: "process.command_line",
      PROCESS_COMMAND_ARGS: "process.command_args",
      PROCESS_OWNER: "process.owner",
      PROCESS_RUNTIME_NAME: "process.runtime.name",
      PROCESS_RUNTIME_VERSION: "process.runtime.version",
      PROCESS_RUNTIME_DESCRIPTION: "process.runtime.description",
      SERVICE_NAME: "service.name",
      SERVICE_NAMESPACE: "service.namespace",
      SERVICE_INSTANCE_ID: "service.instance.id",
      SERVICE_VERSION: "service.version",
      TELEMETRY_SDK_NAME: "telemetry.sdk.name",
      TELEMETRY_SDK_LANGUAGE: "telemetry.sdk.language",
      TELEMETRY_SDK_VERSION: "telemetry.sdk.version",
      TELEMETRY_AUTO_VERSION: "telemetry.auto.version",
      WEBENGINE_NAME: "webengine.name",
      WEBENGINE_VERSION: "webengine.version",
      WEBENGINE_DESCRIPTION: "webengine.description"
    };
    exports2.CloudProviderValues = {
      ALIBABA_CLOUD: "alibaba_cloud",
      AWS: "aws",
      AZURE: "azure",
      GCP: "gcp"
    };
    exports2.CloudPlatformValues = {
      ALIBABA_CLOUD_ECS: "alibaba_cloud_ecs",
      ALIBABA_CLOUD_FC: "alibaba_cloud_fc",
      AWS_EC2: "aws_ec2",
      AWS_ECS: "aws_ecs",
      AWS_EKS: "aws_eks",
      AWS_LAMBDA: "aws_lambda",
      AWS_ELASTIC_BEANSTALK: "aws_elastic_beanstalk",
      AZURE_VM: "azure_vm",
      AZURE_CONTAINER_INSTANCES: "azure_container_instances",
      AZURE_AKS: "azure_aks",
      AZURE_FUNCTIONS: "azure_functions",
      AZURE_APP_SERVICE: "azure_app_service",
      GCP_COMPUTE_ENGINE: "gcp_compute_engine",
      GCP_CLOUD_RUN: "gcp_cloud_run",
      GCP_KUBERNETES_ENGINE: "gcp_kubernetes_engine",
      GCP_CLOUD_FUNCTIONS: "gcp_cloud_functions",
      GCP_APP_ENGINE: "gcp_app_engine"
    };
    exports2.AwsEcsLaunchtypeValues = {
      EC2: "ec2",
      FARGATE: "fargate"
    };
    exports2.HostArchValues = {
      AMD64: "amd64",
      ARM32: "arm32",
      ARM64: "arm64",
      IA64: "ia64",
      PPC32: "ppc32",
      PPC64: "ppc64",
      X86: "x86"
    };
    exports2.OsTypeValues = {
      WINDOWS: "windows",
      LINUX: "linux",
      DARWIN: "darwin",
      FREEBSD: "freebsd",
      NETBSD: "netbsd",
      OPENBSD: "openbsd",
      DRAGONFLYBSD: "dragonflybsd",
      HPUX: "hpux",
      AIX: "aix",
      SOLARIS: "solaris",
      Z_OS: "z_os"
    };
    exports2.TelemetrySdkLanguageValues = {
      CPP: "cpp",
      DOTNET: "dotnet",
      ERLANG: "erlang",
      GO: "go",
      JAVA: "java",
      NODEJS: "nodejs",
      PHP: "php",
      PYTHON: "python",
      RUBY: "ruby",
      WEBJS: "webjs"
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/resource/index.js
var require_resource3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/resource/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_SemanticResourceAttributes3(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/index.js
var require_src23 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/semantic-conventions/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_trace4(), exports2);
    __exportStar(require_resource3(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/sdk-info.js
var require_sdk_info2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/sdk-info.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SDK_INFO = void 0;
    var version_1 = require_version9();
    var semantic_conventions_1 = require_src23();
    exports2.SDK_INFO = {
      [semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_NAME]: "opentelemetry",
      [semantic_conventions_1.SemanticResourceAttributes.PROCESS_RUNTIME_NAME]: "node",
      [semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_LANGUAGE]: semantic_conventions_1.TelemetrySdkLanguageValues.NODEJS,
      [semantic_conventions_1.SemanticResourceAttributes.TELEMETRY_SDK_VERSION]: version_1.VERSION
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/timer-util.js
var require_timer_util2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/timer-util.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.unrefTimer = void 0;
    function unrefTimer(timer) {
      timer.unref();
    }
    exports2.unrefTimer = unrefTimer;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/index.js
var require_node8 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/node/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_environment4(), exports2);
    __exportStar(require_globalThis4(), exports2);
    __exportStar(require_hex_to_base642(), exports2);
    __exportStar(require_RandomIdGenerator2(), exports2);
    __exportStar(require_performance2(), exports2);
    __exportStar(require_sdk_info2(), exports2);
    __exportStar(require_timer_util2(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/index.js
var require_platform7 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/platform/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_node8(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/time.js
var require_time2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/time.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isTimeInput = exports2.isTimeInputHrTime = exports2.hrTimeToMicroseconds = exports2.hrTimeToMilliseconds = exports2.hrTimeToNanoseconds = exports2.hrTimeToTimeStamp = exports2.hrTimeDuration = exports2.timeInputToHrTime = exports2.hrTime = void 0;
    var platform_1 = require_platform7();
    var NANOSECOND_DIGITS = 9;
    var SECOND_TO_NANOSECONDS = Math.pow(10, NANOSECOND_DIGITS);
    function numberToHrtime(epochMillis) {
      const epochSeconds = epochMillis / 1e3;
      const seconds = Math.trunc(epochSeconds);
      const nanos = Number((epochSeconds - seconds).toFixed(NANOSECOND_DIGITS)) * SECOND_TO_NANOSECONDS;
      return [seconds, nanos];
    }
    function getTimeOrigin() {
      let timeOrigin = platform_1.otperformance.timeOrigin;
      if (typeof timeOrigin !== "number") {
        const perf = platform_1.otperformance;
        timeOrigin = perf.timing && perf.timing.fetchStart;
      }
      return timeOrigin;
    }
    function hrTime(performanceNow) {
      const timeOrigin = numberToHrtime(getTimeOrigin());
      const now = numberToHrtime(typeof performanceNow === "number" ? performanceNow : platform_1.otperformance.now());
      let seconds = timeOrigin[0] + now[0];
      let nanos = timeOrigin[1] + now[1];
      if (nanos > SECOND_TO_NANOSECONDS) {
        nanos -= SECOND_TO_NANOSECONDS;
        seconds += 1;
      }
      return [seconds, nanos];
    }
    exports2.hrTime = hrTime;
    function timeInputToHrTime(time) {
      if (isTimeInputHrTime(time)) {
        return time;
      } else if (typeof time === "number") {
        if (time < getTimeOrigin()) {
          return hrTime(time);
        } else {
          return numberToHrtime(time);
        }
      } else if (time instanceof Date) {
        return numberToHrtime(time.getTime());
      } else {
        throw TypeError("Invalid input type");
      }
    }
    exports2.timeInputToHrTime = timeInputToHrTime;
    function hrTimeDuration(startTime, endTime) {
      let seconds = endTime[0] - startTime[0];
      let nanos = endTime[1] - startTime[1];
      if (nanos < 0) {
        seconds -= 1;
        nanos += SECOND_TO_NANOSECONDS;
      }
      return [seconds, nanos];
    }
    exports2.hrTimeDuration = hrTimeDuration;
    function hrTimeToTimeStamp(time) {
      const precision = NANOSECOND_DIGITS;
      const tmp = `${"0".repeat(precision)}${time[1]}Z`;
      const nanoString = tmp.substr(tmp.length - precision - 1);
      const date = new Date(time[0] * 1e3).toISOString();
      return date.replace("000Z", nanoString);
    }
    exports2.hrTimeToTimeStamp = hrTimeToTimeStamp;
    function hrTimeToNanoseconds(time) {
      return time[0] * SECOND_TO_NANOSECONDS + time[1];
    }
    exports2.hrTimeToNanoseconds = hrTimeToNanoseconds;
    function hrTimeToMilliseconds(time) {
      return Math.round(time[0] * 1e3 + time[1] / 1e6);
    }
    exports2.hrTimeToMilliseconds = hrTimeToMilliseconds;
    function hrTimeToMicroseconds(time) {
      return Math.round(time[0] * 1e6 + time[1] / 1e3);
    }
    exports2.hrTimeToMicroseconds = hrTimeToMicroseconds;
    function isTimeInputHrTime(value) {
      return Array.isArray(value) && value.length === 2 && typeof value[0] === "number" && typeof value[1] === "number";
    }
    exports2.isTimeInputHrTime = isTimeInputHrTime;
    function isTimeInput(value) {
      return isTimeInputHrTime(value) || typeof value === "number" || value instanceof Date;
    }
    exports2.isTimeInput = isTimeInput;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/types.js
var require_types14 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/common/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/ExportResult.js
var require_ExportResult2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/ExportResult.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ExportResultCode = void 0;
    var ExportResultCode;
    (function(ExportResultCode2) {
      ExportResultCode2[ExportResultCode2["SUCCESS"] = 0] = "SUCCESS";
      ExportResultCode2[ExportResultCode2["FAILED"] = 1] = "FAILED";
    })(ExportResultCode = exports2.ExportResultCode || (exports2.ExportResultCode = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/propagation/composite.js
var require_composite2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/propagation/composite.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.CompositePropagator = void 0;
    var api_1 = require_src();
    var CompositePropagator = class {
      constructor(config = {}) {
        var _a;
        this._propagators = (_a = config.propagators) !== null && _a !== void 0 ? _a : [];
        this._fields = Array.from(new Set(this._propagators.map((p) => typeof p.fields === "function" ? p.fields() : []).reduce((x, y) => x.concat(y), [])));
      }
      inject(context, carrier, setter) {
        for (const propagator of this._propagators) {
          try {
            propagator.inject(context, carrier, setter);
          } catch (err) {
            api_1.diag.warn(`Failed to inject with ${propagator.constructor.name}. Err: ${err.message}`);
          }
        }
      }
      extract(context, carrier, getter) {
        return this._propagators.reduce((ctx, propagator) => {
          try {
            return propagator.extract(ctx, carrier, getter);
          } catch (err) {
            api_1.diag.warn(`Failed to inject with ${propagator.constructor.name}. Err: ${err.message}`);
          }
          return ctx;
        }, context);
      }
      fields() {
        return this._fields.slice();
      }
    };
    exports2.CompositePropagator = CompositePropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/internal/validators.js
var require_validators2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/internal/validators.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.validateValue = exports2.validateKey = void 0;
    var VALID_KEY_CHAR_RANGE = "[_0-9a-z-*/]";
    var VALID_KEY = `[a-z]${VALID_KEY_CHAR_RANGE}{0,255}`;
    var VALID_VENDOR_KEY = `[a-z0-9]${VALID_KEY_CHAR_RANGE}{0,240}@[a-z]${VALID_KEY_CHAR_RANGE}{0,13}`;
    var VALID_KEY_REGEX = new RegExp(`^(?:${VALID_KEY}|${VALID_VENDOR_KEY})$`);
    var VALID_VALUE_BASE_REGEX = /^[ -~]{0,255}[!-~]$/;
    var INVALID_VALUE_COMMA_EQUAL_REGEX = /,|=/;
    function validateKey(key) {
      return VALID_KEY_REGEX.test(key);
    }
    exports2.validateKey = validateKey;
    function validateValue(value) {
      return VALID_VALUE_BASE_REGEX.test(value) && !INVALID_VALUE_COMMA_EQUAL_REGEX.test(value);
    }
    exports2.validateValue = validateValue;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/TraceState.js
var require_TraceState2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/TraceState.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TraceState = void 0;
    var validators_1 = require_validators2();
    var MAX_TRACE_STATE_ITEMS = 32;
    var MAX_TRACE_STATE_LEN = 512;
    var LIST_MEMBERS_SEPARATOR = ",";
    var LIST_MEMBER_KEY_VALUE_SPLITTER = "=";
    var TraceState = class {
      constructor(rawTraceState) {
        this._internalState = /* @__PURE__ */ new Map();
        if (rawTraceState)
          this._parse(rawTraceState);
      }
      set(key, value) {
        const traceState = this._clone();
        if (traceState._internalState.has(key)) {
          traceState._internalState.delete(key);
        }
        traceState._internalState.set(key, value);
        return traceState;
      }
      unset(key) {
        const traceState = this._clone();
        traceState._internalState.delete(key);
        return traceState;
      }
      get(key) {
        return this._internalState.get(key);
      }
      serialize() {
        return this._keys().reduce((agg, key) => {
          agg.push(key + LIST_MEMBER_KEY_VALUE_SPLITTER + this.get(key));
          return agg;
        }, []).join(LIST_MEMBERS_SEPARATOR);
      }
      _parse(rawTraceState) {
        if (rawTraceState.length > MAX_TRACE_STATE_LEN)
          return;
        this._internalState = rawTraceState.split(LIST_MEMBERS_SEPARATOR).reverse().reduce((agg, part) => {
          const listMember = part.trim();
          const i = listMember.indexOf(LIST_MEMBER_KEY_VALUE_SPLITTER);
          if (i !== -1) {
            const key = listMember.slice(0, i);
            const value = listMember.slice(i + 1, part.length);
            if (validators_1.validateKey(key) && validators_1.validateValue(value)) {
              agg.set(key, value);
            } else {
            }
          }
          return agg;
        }, /* @__PURE__ */ new Map());
        if (this._internalState.size > MAX_TRACE_STATE_ITEMS) {
          this._internalState = new Map(Array.from(this._internalState.entries()).reverse().slice(0, MAX_TRACE_STATE_ITEMS));
        }
      }
      _keys() {
        return Array.from(this._internalState.keys()).reverse();
      }
      _clone() {
        const traceState = new TraceState();
        traceState._internalState = new Map(this._internalState);
        return traceState;
      }
    };
    exports2.TraceState = TraceState;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/W3CTraceContextPropagator.js
var require_W3CTraceContextPropagator2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/W3CTraceContextPropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.W3CTraceContextPropagator = exports2.parseTraceParent = exports2.TRACE_STATE_HEADER = exports2.TRACE_PARENT_HEADER = void 0;
    var api_1 = require_src();
    var suppress_tracing_1 = require_suppress_tracing2();
    var TraceState_1 = require_TraceState2();
    exports2.TRACE_PARENT_HEADER = "traceparent";
    exports2.TRACE_STATE_HEADER = "tracestate";
    var VERSION = "00";
    var VERSION_PART = "(?!ff)[\\da-f]{2}";
    var TRACE_ID_PART = "(?![0]{32})[\\da-f]{32}";
    var PARENT_ID_PART = "(?![0]{16})[\\da-f]{16}";
    var FLAGS_PART = "[\\da-f]{2}";
    var TRACE_PARENT_REGEX = new RegExp(`^\\s?(${VERSION_PART})-(${TRACE_ID_PART})-(${PARENT_ID_PART})-(${FLAGS_PART})(-.*)?\\s?$`);
    function parseTraceParent(traceParent) {
      const match = TRACE_PARENT_REGEX.exec(traceParent);
      if (!match)
        return null;
      if (match[1] === "00" && match[5])
        return null;
      return {
        traceId: match[2],
        spanId: match[3],
        traceFlags: parseInt(match[4], 16)
      };
    }
    exports2.parseTraceParent = parseTraceParent;
    var W3CTraceContextPropagator = class {
      inject(context, carrier, setter) {
        const spanContext = api_1.trace.getSpanContext(context);
        if (!spanContext || suppress_tracing_1.isTracingSuppressed(context) || !api_1.isSpanContextValid(spanContext))
          return;
        const traceParent = `${VERSION}-${spanContext.traceId}-${spanContext.spanId}-0${Number(spanContext.traceFlags || api_1.TraceFlags.NONE).toString(16)}`;
        setter.set(carrier, exports2.TRACE_PARENT_HEADER, traceParent);
        if (spanContext.traceState) {
          setter.set(carrier, exports2.TRACE_STATE_HEADER, spanContext.traceState.serialize());
        }
      }
      extract(context, carrier, getter) {
        const traceParentHeader = getter.get(carrier, exports2.TRACE_PARENT_HEADER);
        if (!traceParentHeader)
          return context;
        const traceParent = Array.isArray(traceParentHeader) ? traceParentHeader[0] : traceParentHeader;
        if (typeof traceParent !== "string")
          return context;
        const spanContext = parseTraceParent(traceParent);
        if (!spanContext)
          return context;
        spanContext.isRemote = true;
        const traceStateHeader = getter.get(carrier, exports2.TRACE_STATE_HEADER);
        if (traceStateHeader) {
          const state = Array.isArray(traceStateHeader) ? traceStateHeader.join(",") : traceStateHeader;
          spanContext.traceState = new TraceState_1.TraceState(typeof state === "string" ? state : void 0);
        }
        return api_1.trace.setSpanContext(context, spanContext);
      }
      fields() {
        return [exports2.TRACE_PARENT_HEADER, exports2.TRACE_STATE_HEADER];
      }
    };
    exports2.W3CTraceContextPropagator = W3CTraceContextPropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/IdGenerator.js
var require_IdGenerator2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/IdGenerator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/rpc-metadata.js
var require_rpc_metadata2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/rpc-metadata.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getRPCMetadata = exports2.deleteRPCMetadata = exports2.setRPCMetadata = exports2.RPCType = void 0;
    var api_1 = require_src();
    var RPC_METADATA_KEY = api_1.createContextKey("OpenTelemetry SDK Context Key RPC_METADATA");
    var RPCType;
    (function(RPCType2) {
      RPCType2["HTTP"] = "http";
    })(RPCType = exports2.RPCType || (exports2.RPCType = {}));
    function setRPCMetadata(context, meta) {
      return context.setValue(RPC_METADATA_KEY, meta);
    }
    exports2.setRPCMetadata = setRPCMetadata;
    function deleteRPCMetadata(context) {
      return context.deleteValue(RPC_METADATA_KEY);
    }
    exports2.deleteRPCMetadata = deleteRPCMetadata;
    function getRPCMetadata(context) {
      return context.getValue(RPC_METADATA_KEY);
    }
    exports2.getRPCMetadata = getRPCMetadata;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOffSampler.js
var require_AlwaysOffSampler2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOffSampler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AlwaysOffSampler = void 0;
    var api_1 = require_src();
    var AlwaysOffSampler = class {
      shouldSample() {
        return {
          decision: api_1.SamplingDecision.NOT_RECORD
        };
      }
      toString() {
        return "AlwaysOffSampler";
      }
    };
    exports2.AlwaysOffSampler = AlwaysOffSampler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOnSampler.js
var require_AlwaysOnSampler2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/sampler/AlwaysOnSampler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AlwaysOnSampler = void 0;
    var api_1 = require_src();
    var AlwaysOnSampler = class {
      shouldSample() {
        return {
          decision: api_1.SamplingDecision.RECORD_AND_SAMPLED
        };
      }
      toString() {
        return "AlwaysOnSampler";
      }
    };
    exports2.AlwaysOnSampler = AlwaysOnSampler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/sampler/ParentBasedSampler.js
var require_ParentBasedSampler2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/sampler/ParentBasedSampler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ParentBasedSampler = void 0;
    var api_1 = require_src();
    var global_error_handler_1 = require_global_error_handler2();
    var AlwaysOffSampler_1 = require_AlwaysOffSampler2();
    var AlwaysOnSampler_1 = require_AlwaysOnSampler2();
    var ParentBasedSampler = class {
      constructor(config) {
        var _a, _b, _c, _d;
        this._root = config.root;
        if (!this._root) {
          global_error_handler_1.globalErrorHandler(new Error("ParentBasedSampler must have a root sampler configured"));
          this._root = new AlwaysOnSampler_1.AlwaysOnSampler();
        }
        this._remoteParentSampled = (_a = config.remoteParentSampled) !== null && _a !== void 0 ? _a : new AlwaysOnSampler_1.AlwaysOnSampler();
        this._remoteParentNotSampled = (_b = config.remoteParentNotSampled) !== null && _b !== void 0 ? _b : new AlwaysOffSampler_1.AlwaysOffSampler();
        this._localParentSampled = (_c = config.localParentSampled) !== null && _c !== void 0 ? _c : new AlwaysOnSampler_1.AlwaysOnSampler();
        this._localParentNotSampled = (_d = config.localParentNotSampled) !== null && _d !== void 0 ? _d : new AlwaysOffSampler_1.AlwaysOffSampler();
      }
      shouldSample(context, traceId, spanName, spanKind, attributes, links) {
        const parentContext = api_1.trace.getSpanContext(context);
        if (!parentContext || !api_1.isSpanContextValid(parentContext)) {
          return this._root.shouldSample(context, traceId, spanName, spanKind, attributes, links);
        }
        if (parentContext.isRemote) {
          if (parentContext.traceFlags & api_1.TraceFlags.SAMPLED) {
            return this._remoteParentSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
          }
          return this._remoteParentNotSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
        }
        if (parentContext.traceFlags & api_1.TraceFlags.SAMPLED) {
          return this._localParentSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
        }
        return this._localParentNotSampled.shouldSample(context, traceId, spanName, spanKind, attributes, links);
      }
      toString() {
        return `ParentBased{root=${this._root.toString()}, remoteParentSampled=${this._remoteParentSampled.toString()}, remoteParentNotSampled=${this._remoteParentNotSampled.toString()}, localParentSampled=${this._localParentSampled.toString()}, localParentNotSampled=${this._localParentNotSampled.toString()}}`;
      }
    };
    exports2.ParentBasedSampler = ParentBasedSampler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/sampler/TraceIdRatioBasedSampler.js
var require_TraceIdRatioBasedSampler2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/trace/sampler/TraceIdRatioBasedSampler.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TraceIdRatioBasedSampler = void 0;
    var api_1 = require_src();
    var TraceIdRatioBasedSampler = class {
      constructor(_ratio = 0) {
        this._ratio = _ratio;
        this._ratio = this._normalize(_ratio);
        this._upperBound = Math.floor(this._ratio * 4294967295);
      }
      shouldSample(context, traceId) {
        return {
          decision: api_1.isValidTraceId(traceId) && this._accumulate(traceId) < this._upperBound ? api_1.SamplingDecision.RECORD_AND_SAMPLED : api_1.SamplingDecision.NOT_RECORD
        };
      }
      toString() {
        return `TraceIdRatioBased{${this._ratio}}`;
      }
      _normalize(ratio) {
        if (typeof ratio !== "number" || isNaN(ratio))
          return 0;
        return ratio >= 1 ? 1 : ratio <= 0 ? 0 : ratio;
      }
      _accumulate(traceId) {
        let accumulation = 0;
        for (let i = 0; i < traceId.length / 8; i++) {
          const pos = i * 8;
          const part = parseInt(traceId.slice(pos, pos + 8), 16);
          accumulation = (accumulation ^ part) >>> 0;
        }
        return accumulation;
      }
    };
    exports2.TraceIdRatioBasedSampler = TraceIdRatioBasedSampler;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/lodash.merge.js
var require_lodash_merge2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/lodash.merge.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isPlainObject = void 0;
    var objectTag = "[object Object]";
    var nullTag = "[object Null]";
    var undefinedTag = "[object Undefined]";
    var funcProto = Function.prototype;
    var funcToString = funcProto.toString;
    var objectCtorString = funcToString.call(Object);
    var getPrototype = overArg(Object.getPrototypeOf, Object);
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var symToStringTag = Symbol ? Symbol.toStringTag : void 0;
    var nativeObjectToString = objectProto.toString;
    function overArg(func, transform) {
      return function(arg) {
        return func(transform(arg));
      };
    }
    function isPlainObject(value) {
      if (!isObjectLike(value) || baseGetTag(value) !== objectTag) {
        return false;
      }
      const proto = getPrototype(value);
      if (proto === null) {
        return true;
      }
      const Ctor = hasOwnProperty.call(proto, "constructor") && proto.constructor;
      return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString.call(Ctor) === objectCtorString;
    }
    exports2.isPlainObject = isPlainObject;
    function isObjectLike(value) {
      return value != null && typeof value == "object";
    }
    function baseGetTag(value) {
      if (value == null) {
        return value === void 0 ? undefinedTag : nullTag;
      }
      return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
    }
    function getRawTag(value) {
      const isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
      let unmasked = false;
      try {
        value[symToStringTag] = void 0;
        unmasked = true;
      } catch (e) {
      }
      const result = nativeObjectToString.call(value);
      if (unmasked) {
        if (isOwn) {
          value[symToStringTag] = tag;
        } else {
          delete value[symToStringTag];
        }
      }
      return result;
    }
    function objectToString(value) {
      return nativeObjectToString.call(value);
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/merge.js
var require_merge2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/merge.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.merge = void 0;
    var lodash_merge_1 = require_lodash_merge2();
    var MAX_LEVEL = 20;
    function merge(...args) {
      let result = args.shift();
      const objects = /* @__PURE__ */ new WeakMap();
      while (args.length > 0) {
        result = mergeTwoObjects(result, args.shift(), 0, objects);
      }
      return result;
    }
    exports2.merge = merge;
    function takeValue(value) {
      if (isArray(value)) {
        return value.slice();
      }
      return value;
    }
    function mergeTwoObjects(one, two, level = 0, objects) {
      let result;
      if (level > MAX_LEVEL) {
        return void 0;
      }
      level++;
      if (isPrimitive(one) || isPrimitive(two) || isFunction(two)) {
        result = takeValue(two);
      } else if (isArray(one)) {
        result = one.slice();
        if (isArray(two)) {
          for (let i = 0, j = two.length; i < j; i++) {
            result.push(takeValue(two[i]));
          }
        } else if (isObject(two)) {
          const keys = Object.keys(two);
          for (let i = 0, j = keys.length; i < j; i++) {
            const key = keys[i];
            result[key] = takeValue(two[key]);
          }
        }
      } else if (isObject(one)) {
        if (isObject(two)) {
          if (!shouldMerge(one, two)) {
            return two;
          }
          result = Object.assign({}, one);
          const keys = Object.keys(two);
          for (let i = 0, j = keys.length; i < j; i++) {
            const key = keys[i];
            const twoValue = two[key];
            if (isPrimitive(twoValue)) {
              if (typeof twoValue === "undefined") {
                delete result[key];
              } else {
                result[key] = twoValue;
              }
            } else {
              const obj1 = result[key];
              const obj2 = twoValue;
              if (wasObjectReferenced(one, key, objects) || wasObjectReferenced(two, key, objects)) {
                delete result[key];
              } else {
                if (isObject(obj1) && isObject(obj2)) {
                  const arr1 = objects.get(obj1) || [];
                  const arr2 = objects.get(obj2) || [];
                  arr1.push({ obj: one, key });
                  arr2.push({ obj: two, key });
                  objects.set(obj1, arr1);
                  objects.set(obj2, arr2);
                }
                result[key] = mergeTwoObjects(result[key], twoValue, level, objects);
              }
            }
          }
        } else {
          result = two;
        }
      }
      return result;
    }
    function wasObjectReferenced(obj, key, objects) {
      const arr = objects.get(obj[key]) || [];
      for (let i = 0, j = arr.length; i < j; i++) {
        const info = arr[i];
        if (info.key === key && info.obj === obj) {
          return true;
        }
      }
      return false;
    }
    function isArray(value) {
      return Array.isArray(value);
    }
    function isFunction(value) {
      return typeof value === "function";
    }
    function isObject(value) {
      return !isPrimitive(value) && !isArray(value) && !isFunction(value) && typeof value === "object";
    }
    function isPrimitive(value) {
      return typeof value === "string" || typeof value === "number" || typeof value === "boolean" || typeof value === "undefined" || value instanceof Date || value instanceof RegExp || value === null;
    }
    function shouldMerge(one, two) {
      if (!lodash_merge_1.isPlainObject(one) || !lodash_merge_1.isPlainObject(two)) {
        return false;
      }
      return true;
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/url.js
var require_url2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/url.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isUrlIgnored = exports2.urlMatches = void 0;
    function urlMatches(url, urlToMatch) {
      if (typeof urlToMatch === "string") {
        return url === urlToMatch;
      } else {
        return !!url.match(urlToMatch);
      }
    }
    exports2.urlMatches = urlMatches;
    function isUrlIgnored(url, ignoredUrls) {
      if (!ignoredUrls) {
        return false;
      }
      for (const ignoreUrl of ignoredUrls) {
        if (urlMatches(url, ignoreUrl)) {
          return true;
        }
      }
      return false;
    }
    exports2.isUrlIgnored = isUrlIgnored;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/wrap.js
var require_wrap2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/utils/wrap.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isWrapped = void 0;
    function isWrapped(func) {
      return typeof func === "function" && typeof func.__original === "function" && typeof func.__unwrap === "function" && func.__wrapped === true;
    }
    exports2.isWrapped = isWrapped;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/index.js
var require_src24 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/node_modules/@opentelemetry/core/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.baggageUtils = void 0;
    __exportStar(require_W3CBaggagePropagator2(), exports2);
    __exportStar(require_attributes3(), exports2);
    __exportStar(require_global_error_handler2(), exports2);
    __exportStar(require_logging_error_handler2(), exports2);
    __exportStar(require_time2(), exports2);
    __exportStar(require_types14(), exports2);
    __exportStar(require_ExportResult2(), exports2);
    __exportStar(require_version9(), exports2);
    exports2.baggageUtils = require_utils10();
    __exportStar(require_platform7(), exports2);
    __exportStar(require_composite2(), exports2);
    __exportStar(require_W3CTraceContextPropagator2(), exports2);
    __exportStar(require_IdGenerator2(), exports2);
    __exportStar(require_rpc_metadata2(), exports2);
    __exportStar(require_AlwaysOffSampler2(), exports2);
    __exportStar(require_AlwaysOnSampler2(), exports2);
    __exportStar(require_ParentBasedSampler2(), exports2);
    __exportStar(require_TraceIdRatioBasedSampler2(), exports2);
    __exportStar(require_suppress_tracing2(), exports2);
    __exportStar(require_TraceState2(), exports2);
    __exportStar(require_environment3(), exports2);
    __exportStar(require_merge2(), exports2);
    __exportStar(require_sampling2(), exports2);
    __exportStar(require_url2(), exports2);
    __exportStar(require_wrap2(), exports2);
    __exportStar(require_version9(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/enums/AttributeNames.js
var require_AttributeNames6 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/enums/AttributeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["HTTP_ERROR_NAME"] = "http.error_name";
      AttributeNames2["HTTP_ERROR_MESSAGE"] = "http.error_message";
      AttributeNames2["HTTP_STATUS_TEXT"] = "http.status_text";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/utils.js
var require_utils11 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.headerCapture = exports2.getIncomingRequestAttributesOnResponse = exports2.getIncomingRequestAttributes = exports2.getOutgoingRequestAttributesOnResponse = exports2.getAttributesFromHttpKind = exports2.getOutgoingRequestAttributes = exports2.isValidOptionsType = exports2.getRequestInfo = exports2.isCompressed = exports2.setResponseContentLengthAttribute = exports2.setRequestContentLengthAttribute = exports2.setSpanWithError = exports2.isIgnored = exports2.satisfiesPattern = exports2.hasExpectHeader = exports2.parseResponseStatus = exports2.getAbsoluteUrl = void 0;
    var api_1 = require_src();
    var semantic_conventions_1 = require_src23();
    var core_1 = require_src24();
    var url = require("url");
    var AttributeNames_1 = require_AttributeNames6();
    var getAbsoluteUrl = (requestUrl, headers, fallbackProtocol = "http:") => {
      const reqUrlObject = requestUrl || {};
      const protocol = reqUrlObject.protocol || fallbackProtocol;
      const port = (reqUrlObject.port || "").toString();
      const path = reqUrlObject.path || "/";
      let host = reqUrlObject.host || reqUrlObject.hostname || headers.host || "localhost";
      if (host.indexOf(":") === -1 && port && port !== "80" && port !== "443") {
        host += `:${port}`;
      }
      return `${protocol}//${host}${path}`;
    };
    exports2.getAbsoluteUrl = getAbsoluteUrl;
    var parseResponseStatus = (statusCode) => {
      if (statusCode === void 0) {
        return { code: api_1.SpanStatusCode.ERROR };
      }
      if (statusCode >= 100 && statusCode < 400) {
        return { code: api_1.SpanStatusCode.OK };
      }
      return { code: api_1.SpanStatusCode.ERROR };
    };
    exports2.parseResponseStatus = parseResponseStatus;
    var hasExpectHeader = (options) => {
      if (!options.headers) {
        return false;
      }
      const keys = Object.keys(options.headers);
      return !!keys.find((key) => key.toLowerCase() === "expect");
    };
    exports2.hasExpectHeader = hasExpectHeader;
    var satisfiesPattern = (constant, pattern) => {
      if (typeof pattern === "string") {
        return pattern === constant;
      } else if (pattern instanceof RegExp) {
        return pattern.test(constant);
      } else if (typeof pattern === "function") {
        return pattern(constant);
      } else {
        throw new TypeError("Pattern is in unsupported datatype");
      }
    };
    exports2.satisfiesPattern = satisfiesPattern;
    var isIgnored = (constant, list, onException) => {
      if (!list) {
        return false;
      }
      try {
        for (const pattern of list) {
          if (exports2.satisfiesPattern(constant, pattern)) {
            return true;
          }
        }
      } catch (e) {
        if (onException) {
          onException(e);
        }
      }
      return false;
    };
    exports2.isIgnored = isIgnored;
    var setSpanWithError = (span, error, obj) => {
      const message = error.message;
      span.setAttributes({
        [AttributeNames_1.AttributeNames.HTTP_ERROR_NAME]: error.name,
        [AttributeNames_1.AttributeNames.HTTP_ERROR_MESSAGE]: message
      });
      if (!obj) {
        span.setStatus({ code: api_1.SpanStatusCode.ERROR, message });
        return;
      }
      let status;
      if (obj.statusCode) {
        status = exports2.parseResponseStatus(obj.statusCode);
      } else if (obj.aborted) {
        status = { code: api_1.SpanStatusCode.ERROR };
      } else {
        status = { code: api_1.SpanStatusCode.ERROR };
      }
      status.message = message;
      span.setStatus(status);
    };
    exports2.setSpanWithError = setSpanWithError;
    var setRequestContentLengthAttribute = (request, attributes) => {
      const length = getContentLength(request.headers);
      if (length === null)
        return;
      if (exports2.isCompressed(request.headers)) {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_REQUEST_CONTENT_LENGTH] = length;
      } else {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_REQUEST_CONTENT_LENGTH_UNCOMPRESSED] = length;
      }
    };
    exports2.setRequestContentLengthAttribute = setRequestContentLengthAttribute;
    var setResponseContentLengthAttribute = (response, attributes) => {
      const length = getContentLength(response.headers);
      if (length === null)
        return;
      if (exports2.isCompressed(response.headers)) {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_RESPONSE_CONTENT_LENGTH] = length;
      } else {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_RESPONSE_CONTENT_LENGTH_UNCOMPRESSED] = length;
      }
    };
    exports2.setResponseContentLengthAttribute = setResponseContentLengthAttribute;
    function getContentLength(headers) {
      const contentLengthHeader = headers["content-length"];
      if (contentLengthHeader === void 0)
        return null;
      const contentLength = parseInt(contentLengthHeader, 10);
      if (isNaN(contentLength))
        return null;
      return contentLength;
    }
    var isCompressed = (headers) => {
      const encoding = headers["content-encoding"];
      return !!encoding && encoding !== "identity";
    };
    exports2.isCompressed = isCompressed;
    var getRequestInfo = (options, extraOptions) => {
      let pathname = "/";
      let origin = "";
      let optionsParsed;
      if (typeof options === "string") {
        optionsParsed = url.parse(options);
        pathname = optionsParsed.pathname || "/";
        origin = `${optionsParsed.protocol || "http:"}//${optionsParsed.host}`;
        if (extraOptions !== void 0) {
          Object.assign(optionsParsed, extraOptions);
        }
      } else if (options instanceof url.URL) {
        optionsParsed = {
          protocol: options.protocol,
          hostname: typeof options.hostname === "string" && options.hostname.startsWith("[") ? options.hostname.slice(1, -1) : options.hostname,
          path: `${options.pathname || ""}${options.search || ""}`
        };
        if (options.port !== "") {
          optionsParsed.port = Number(options.port);
        }
        if (options.username || options.password) {
          optionsParsed.auth = `${options.username}:${options.password}`;
        }
        pathname = options.pathname;
        origin = options.origin;
        if (extraOptions !== void 0) {
          Object.assign(optionsParsed, extraOptions);
        }
      } else {
        optionsParsed = Object.assign({ protocol: options.host ? "http:" : void 0 }, options);
        pathname = options.pathname;
        if (!pathname && optionsParsed.path) {
          pathname = url.parse(optionsParsed.path).pathname || "/";
        }
        origin = `${optionsParsed.protocol || "http:"}//${optionsParsed.host || `${optionsParsed.hostname}:${optionsParsed.port}`}`;
      }
      if (exports2.hasExpectHeader(optionsParsed)) {
        optionsParsed.headers = Object.assign({}, optionsParsed.headers);
      } else if (!optionsParsed.headers) {
        optionsParsed.headers = {};
      }
      const method = optionsParsed.method ? optionsParsed.method.toUpperCase() : "GET";
      return { origin, pathname, method, optionsParsed };
    };
    exports2.getRequestInfo = getRequestInfo;
    var isValidOptionsType = (options) => {
      if (!options) {
        return false;
      }
      const type = typeof options;
      return type === "string" || type === "object" && !Array.isArray(options);
    };
    exports2.isValidOptionsType = isValidOptionsType;
    var getOutgoingRequestAttributes = (requestOptions, options) => {
      const host = requestOptions.host;
      const hostname = requestOptions.hostname || (host === null || host === void 0 ? void 0 : host.replace(/^(.*)(:[0-9]{1,5})/, "$1")) || "localhost";
      const requestMethod = requestOptions.method;
      const method = requestMethod ? requestMethod.toUpperCase() : "GET";
      const headers = requestOptions.headers || {};
      const userAgent = headers["user-agent"];
      const attributes = {
        [semantic_conventions_1.SemanticAttributes.HTTP_URL]: exports2.getAbsoluteUrl(requestOptions, headers, `${options.component}:`),
        [semantic_conventions_1.SemanticAttributes.HTTP_METHOD]: method,
        [semantic_conventions_1.SemanticAttributes.HTTP_TARGET]: requestOptions.path || "/",
        [semantic_conventions_1.SemanticAttributes.NET_PEER_NAME]: hostname
      };
      if (userAgent !== void 0) {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_USER_AGENT] = userAgent;
      }
      return Object.assign(attributes, options.hookAttributes);
    };
    exports2.getOutgoingRequestAttributes = getOutgoingRequestAttributes;
    var getAttributesFromHttpKind = (kind) => {
      const attributes = {};
      if (kind) {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_FLAVOR] = kind;
        if (kind.toUpperCase() !== "QUIC") {
          attributes[semantic_conventions_1.SemanticAttributes.NET_TRANSPORT] = semantic_conventions_1.NetTransportValues.IP_TCP;
        } else {
          attributes[semantic_conventions_1.SemanticAttributes.NET_TRANSPORT] = semantic_conventions_1.NetTransportValues.IP_UDP;
        }
      }
      return attributes;
    };
    exports2.getAttributesFromHttpKind = getAttributesFromHttpKind;
    var getOutgoingRequestAttributesOnResponse = (response, options) => {
      const { statusCode, statusMessage, httpVersion, socket } = response;
      const { remoteAddress, remotePort } = socket;
      const attributes = {
        [semantic_conventions_1.SemanticAttributes.NET_PEER_IP]: remoteAddress,
        [semantic_conventions_1.SemanticAttributes.NET_PEER_PORT]: remotePort,
        [semantic_conventions_1.SemanticAttributes.HTTP_HOST]: `${options.hostname}:${remotePort}`
      };
      exports2.setResponseContentLengthAttribute(response, attributes);
      if (statusCode) {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_STATUS_CODE] = statusCode;
        attributes[AttributeNames_1.AttributeNames.HTTP_STATUS_TEXT] = (statusMessage || "").toUpperCase();
      }
      const httpKindAttributes = exports2.getAttributesFromHttpKind(httpVersion);
      return Object.assign(attributes, httpKindAttributes);
    };
    exports2.getOutgoingRequestAttributesOnResponse = getOutgoingRequestAttributesOnResponse;
    var getIncomingRequestAttributes = (request, options) => {
      const headers = request.headers;
      const userAgent = headers["user-agent"];
      const ips = headers["x-forwarded-for"];
      const method = request.method || "GET";
      const httpVersion = request.httpVersion;
      const requestUrl = request.url ? url.parse(request.url) : null;
      const host = (requestUrl === null || requestUrl === void 0 ? void 0 : requestUrl.host) || headers.host;
      const hostname = (requestUrl === null || requestUrl === void 0 ? void 0 : requestUrl.hostname) || (host === null || host === void 0 ? void 0 : host.replace(/^(.*)(:[0-9]{1,5})/, "$1")) || "localhost";
      const serverName = options.serverName;
      const attributes = {
        [semantic_conventions_1.SemanticAttributes.HTTP_URL]: exports2.getAbsoluteUrl(requestUrl, headers, `${options.component}:`),
        [semantic_conventions_1.SemanticAttributes.HTTP_HOST]: host,
        [semantic_conventions_1.SemanticAttributes.NET_HOST_NAME]: hostname,
        [semantic_conventions_1.SemanticAttributes.HTTP_METHOD]: method
      };
      if (typeof ips === "string") {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_CLIENT_IP] = ips.split(",")[0];
      }
      if (typeof serverName === "string") {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_SERVER_NAME] = serverName;
      }
      if (requestUrl) {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_TARGET] = requestUrl.pathname || "/";
      }
      if (userAgent !== void 0) {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_USER_AGENT] = userAgent;
      }
      exports2.setRequestContentLengthAttribute(request, attributes);
      const httpKindAttributes = exports2.getAttributesFromHttpKind(httpVersion);
      return Object.assign(attributes, httpKindAttributes, options.hookAttributes);
    };
    exports2.getIncomingRequestAttributes = getIncomingRequestAttributes;
    var getIncomingRequestAttributesOnResponse = (request, response) => {
      const { socket } = request;
      const { statusCode, statusMessage } = response;
      const { localAddress, localPort, remoteAddress, remotePort } = socket;
      const rpcMetadata = core_1.getRPCMetadata(api_1.context.active());
      const attributes = {
        [semantic_conventions_1.SemanticAttributes.NET_HOST_IP]: localAddress,
        [semantic_conventions_1.SemanticAttributes.NET_HOST_PORT]: localPort,
        [semantic_conventions_1.SemanticAttributes.NET_PEER_IP]: remoteAddress,
        [semantic_conventions_1.SemanticAttributes.NET_PEER_PORT]: remotePort,
        [semantic_conventions_1.SemanticAttributes.HTTP_STATUS_CODE]: statusCode,
        [AttributeNames_1.AttributeNames.HTTP_STATUS_TEXT]: (statusMessage || "").toUpperCase()
      };
      if ((rpcMetadata === null || rpcMetadata === void 0 ? void 0 : rpcMetadata.type) === core_1.RPCType.HTTP && rpcMetadata.route !== void 0) {
        attributes[semantic_conventions_1.SemanticAttributes.HTTP_ROUTE] = rpcMetadata.route;
      }
      return attributes;
    };
    exports2.getIncomingRequestAttributesOnResponse = getIncomingRequestAttributesOnResponse;
    function headerCapture(type, headers) {
      const normalizedHeaders = new Map(headers.map((header) => [header.toLowerCase(), header.toLowerCase().replace(/-/g, "_")]));
      return (span, getHeader) => {
        for (const [capturedHeader, normalizedHeader] of normalizedHeaders) {
          const value = getHeader(capturedHeader);
          if (value === void 0) {
            continue;
          }
          const key = `http.${type}.header.${normalizedHeader}`;
          if (typeof value === "string") {
            span.setAttribute(key, [value]);
          } else if (Array.isArray(value)) {
            span.setAttribute(key, value);
          } else {
            span.setAttribute(key, [value]);
          }
        }
      };
    }
    exports2.headerCapture = headerCapture;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/version.js
var require_version10 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.27.0";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/http.js
var require_http = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/http.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.HttpInstrumentation = void 0;
    var api_1 = require_src();
    var core_1 = require_src24();
    var semver = require_semver3();
    var url = require("url");
    var utils = require_utils11();
    var version_1 = require_version10();
    var instrumentation_1 = require_src13();
    var core_2 = require_src24();
    var HttpInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(config) {
        super("@opentelemetry/instrumentation-http", version_1.VERSION, config);
        this._spanNotEnded = /* @__PURE__ */ new WeakSet();
        this._version = process.versions.node;
        this._headerCapture = this._createHeaderCapture();
      }
      _getConfig() {
        return this._config;
      }
      setConfig(config) {
        super.setConfig(config);
        this._headerCapture = this._createHeaderCapture();
      }
      init() {
        return [this._getHttpsInstrumentation(), this._getHttpInstrumentation()];
      }
      _getHttpInstrumentation() {
        return new instrumentation_1.InstrumentationNodeModuleDefinition("http", ["*"], (moduleExports) => {
          this._diag.debug(`Applying patch for http@${this._version}`);
          if (instrumentation_1.isWrapped(moduleExports.request)) {
            this._unwrap(moduleExports, "request");
          }
          this._wrap(moduleExports, "request", this._getPatchOutgoingRequestFunction("http"));
          if (instrumentation_1.isWrapped(moduleExports.get)) {
            this._unwrap(moduleExports, "get");
          }
          this._wrap(moduleExports, "get", this._getPatchOutgoingGetFunction(moduleExports.request));
          if (instrumentation_1.isWrapped(moduleExports.Server.prototype.emit)) {
            this._unwrap(moduleExports.Server.prototype, "emit");
          }
          this._wrap(moduleExports.Server.prototype, "emit", this._getPatchIncomingRequestFunction("http"));
          return moduleExports;
        }, (moduleExports) => {
          if (moduleExports === void 0)
            return;
          this._diag.debug(`Removing patch for http@${this._version}`);
          this._unwrap(moduleExports, "request");
          this._unwrap(moduleExports, "get");
          this._unwrap(moduleExports.Server.prototype, "emit");
        });
      }
      _getHttpsInstrumentation() {
        return new instrumentation_1.InstrumentationNodeModuleDefinition("https", ["*"], (moduleExports) => {
          this._diag.debug(`Applying patch for https@${this._version}`);
          if (instrumentation_1.isWrapped(moduleExports.request)) {
            this._unwrap(moduleExports, "request");
          }
          this._wrap(moduleExports, "request", this._getPatchHttpsOutgoingRequestFunction("https"));
          if (instrumentation_1.isWrapped(moduleExports.get)) {
            this._unwrap(moduleExports, "get");
          }
          this._wrap(moduleExports, "get", this._getPatchHttpsOutgoingGetFunction(moduleExports.request));
          if (instrumentation_1.isWrapped(moduleExports.Server.prototype.emit)) {
            this._unwrap(moduleExports.Server.prototype, "emit");
          }
          this._wrap(moduleExports.Server.prototype, "emit", this._getPatchIncomingRequestFunction("https"));
          return moduleExports;
        }, (moduleExports) => {
          if (moduleExports === void 0)
            return;
          this._diag.debug(`Removing patch for https@${this._version}`);
          this._unwrap(moduleExports, "request");
          this._unwrap(moduleExports, "get");
          this._unwrap(moduleExports.Server.prototype, "emit");
        });
      }
      _getPatchIncomingRequestFunction(component) {
        return (original) => {
          return this._incomingRequestFunction(component, original);
        };
      }
      _getPatchOutgoingRequestFunction(component) {
        return (original) => {
          return this._outgoingRequestFunction(component, original);
        };
      }
      _getPatchOutgoingGetFunction(clientRequest) {
        return (_original) => {
          return function outgoingGetRequest(options, ...args) {
            const req = clientRequest(options, ...args);
            req.end();
            return req;
          };
        };
      }
      _getPatchHttpsOutgoingRequestFunction(component) {
        return (original) => {
          const instrumentation = this;
          return function httpsOutgoingRequest(options, ...args) {
            var _a;
            if (component === "https" && typeof options === "object" && ((_a = options === null || options === void 0 ? void 0 : options.constructor) === null || _a === void 0 ? void 0 : _a.name) !== "URL") {
              options = Object.assign({}, options);
              instrumentation._setDefaultOptions(options);
            }
            return instrumentation._getPatchOutgoingRequestFunction(component)(original)(options, ...args);
          };
        };
      }
      _setDefaultOptions(options) {
        options.protocol = options.protocol || "https:";
        options.port = options.port || 443;
      }
      _getPatchHttpsOutgoingGetFunction(clientRequest) {
        return (original) => {
          const instrumentation = this;
          return function httpsOutgoingRequest(options, ...args) {
            return instrumentation._getPatchOutgoingGetFunction(clientRequest)(original)(options, ...args);
          };
        };
      }
      _traceClientRequest(request, hostname, span) {
        if (this._getConfig().requestHook) {
          this._callRequestHook(span, request);
        }
        request.prependListener("response", (response) => {
          const responseAttributes = utils.getOutgoingRequestAttributesOnResponse(response, { hostname });
          span.setAttributes(responseAttributes);
          if (this._getConfig().responseHook) {
            this._callResponseHook(span, response);
          }
          this._headerCapture.client.captureRequestHeaders(span, (header) => request.getHeader(header));
          this._headerCapture.client.captureResponseHeaders(span, (header) => response.headers[header]);
          api_1.context.bind(api_1.context.active(), response);
          this._diag.debug("outgoingRequest on response()");
          response.on("end", () => {
            this._diag.debug("outgoingRequest on end()");
            let status;
            if (response.aborted && !response.complete) {
              status = { code: api_1.SpanStatusCode.ERROR };
            } else {
              status = utils.parseResponseStatus(response.statusCode);
            }
            span.setStatus(status);
            if (this._getConfig().applyCustomAttributesOnSpan) {
              instrumentation_1.safeExecuteInTheMiddle(() => this._getConfig().applyCustomAttributesOnSpan(span, request, response), () => {
              }, true);
            }
            this._closeHttpSpan(span);
          });
          response.on("error", (error) => {
            this._diag.debug("outgoingRequest on error()", error);
            utils.setSpanWithError(span, error, response);
            this._closeHttpSpan(span);
          });
        });
        request.on("close", () => {
          this._diag.debug("outgoingRequest on request close()");
          if (!request.aborted) {
            this._closeHttpSpan(span);
          }
        });
        request.on("error", (error) => {
          this._diag.debug("outgoingRequest on request error()", error);
          utils.setSpanWithError(span, error, request);
          this._closeHttpSpan(span);
        });
        this._diag.debug("http.ClientRequest return request");
        return request;
      }
      _incomingRequestFunction(component, original) {
        const instrumentation = this;
        return function incomingRequest(event, ...args) {
          if (event !== "request") {
            return original.apply(this, [event, ...args]);
          }
          const request = args[0];
          const response = args[1];
          const pathname = request.url ? url.parse(request.url).pathname || "/" : "/";
          const method = request.method || "GET";
          instrumentation._diag.debug(`${component} instrumentation incomingRequest`);
          if (utils.isIgnored(pathname, instrumentation._getConfig().ignoreIncomingPaths, (e) => instrumentation._diag.error("caught ignoreIncomingPaths error: ", e))) {
            return api_1.context.with(core_1.suppressTracing(api_1.context.active()), () => {
              api_1.context.bind(api_1.context.active(), request);
              api_1.context.bind(api_1.context.active(), response);
              return original.apply(this, [event, ...args]);
            });
          }
          const headers = request.headers;
          const spanOptions = {
            kind: api_1.SpanKind.SERVER,
            attributes: utils.getIncomingRequestAttributes(request, {
              component,
              serverName: instrumentation._getConfig().serverName,
              hookAttributes: instrumentation._callStartSpanHook(request, instrumentation._getConfig().startIncomingSpanHook)
            })
          };
          const ctx = api_1.propagation.extract(api_1.ROOT_CONTEXT, headers);
          const span = instrumentation._startHttpSpan(`${component.toLocaleUpperCase()} ${method}`, spanOptions, ctx);
          const rpcMetadata = {
            type: core_2.RPCType.HTTP,
            span
          };
          return api_1.context.with(core_2.setRPCMetadata(api_1.trace.setSpan(ctx, span), rpcMetadata), () => {
            api_1.context.bind(api_1.context.active(), request);
            api_1.context.bind(api_1.context.active(), response);
            if (instrumentation._getConfig().requestHook) {
              instrumentation._callRequestHook(span, request);
            }
            if (instrumentation._getConfig().responseHook) {
              instrumentation._callResponseHook(span, response);
            }
            instrumentation._headerCapture.server.captureRequestHeaders(span, (header) => request.headers[header]);
            const originalEnd = response.end;
            response.end = function(..._args) {
              response.end = originalEnd;
              const returned = instrumentation_1.safeExecuteInTheMiddle(() => response.end.apply(this, arguments), (error) => {
                if (error) {
                  utils.setSpanWithError(span, error);
                  instrumentation._closeHttpSpan(span);
                  throw error;
                }
              });
              const attributes = utils.getIncomingRequestAttributesOnResponse(request, response);
              instrumentation._headerCapture.server.captureResponseHeaders(span, (header) => response.getHeader(header));
              span.setAttributes(attributes).setStatus(utils.parseResponseStatus(response.statusCode));
              if (instrumentation._getConfig().applyCustomAttributesOnSpan) {
                instrumentation_1.safeExecuteInTheMiddle(() => instrumentation._getConfig().applyCustomAttributesOnSpan(span, request, response), () => {
                }, true);
              }
              instrumentation._closeHttpSpan(span);
              return returned;
            };
            return instrumentation_1.safeExecuteInTheMiddle(() => original.apply(this, [event, ...args]), (error) => {
              if (error) {
                utils.setSpanWithError(span, error);
                instrumentation._closeHttpSpan(span);
                throw error;
              }
            });
          });
        };
      }
      _outgoingRequestFunction(component, original) {
        const instrumentation = this;
        return function outgoingRequest(options, ...args) {
          var _a;
          if (!utils.isValidOptionsType(options)) {
            return original.apply(this, [options, ...args]);
          }
          const extraOptions = typeof args[0] === "object" && (typeof options === "string" || options instanceof url.URL) ? args.shift() : void 0;
          const { origin, pathname, method, optionsParsed } = utils.getRequestInfo(options, extraOptions);
          if (component === "http" && semver.lt(process.version, "9.0.0") && optionsParsed.protocol === "https:") {
            return original.apply(this, [optionsParsed, ...args]);
          }
          if (utils.isIgnored(origin + pathname, instrumentation._getConfig().ignoreOutgoingUrls, (e) => instrumentation._diag.error("caught ignoreOutgoingUrls error: ", e))) {
            return original.apply(this, [optionsParsed, ...args]);
          }
          const operationName = `${component.toUpperCase()} ${method}`;
          const hostname = optionsParsed.hostname || ((_a = optionsParsed.host) === null || _a === void 0 ? void 0 : _a.replace(/^(.*)(:[0-9]{1,5})/, "$1")) || "localhost";
          const attributes = utils.getOutgoingRequestAttributes(optionsParsed, {
            component,
            hostname,
            hookAttributes: instrumentation._callStartSpanHook(optionsParsed, instrumentation._getConfig().startOutgoingSpanHook)
          });
          const spanOptions = {
            kind: api_1.SpanKind.CLIENT,
            attributes
          };
          const span = instrumentation._startHttpSpan(operationName, spanOptions);
          const parentContext = api_1.context.active();
          const requestContext = api_1.trace.setSpan(parentContext, span);
          if (!optionsParsed.headers) {
            optionsParsed.headers = {};
          }
          api_1.propagation.inject(requestContext, optionsParsed.headers);
          return api_1.context.with(requestContext, () => {
            const cb = args[args.length - 1];
            if (typeof cb === "function") {
              args[args.length - 1] = api_1.context.bind(parentContext, cb);
            }
            const request = instrumentation_1.safeExecuteInTheMiddle(() => original.apply(this, [optionsParsed, ...args]), (error) => {
              if (error) {
                utils.setSpanWithError(span, error);
                instrumentation._closeHttpSpan(span);
                throw error;
              }
            });
            instrumentation._diag.debug(`${component} instrumentation outgoingRequest`);
            api_1.context.bind(parentContext, request);
            return instrumentation._traceClientRequest(request, hostname, span);
          });
        };
      }
      _startHttpSpan(name, options, ctx = api_1.context.active()) {
        const requireParent = options.kind === api_1.SpanKind.CLIENT ? this._getConfig().requireParentforOutgoingSpans : this._getConfig().requireParentforIncomingSpans;
        let span;
        const currentSpan = api_1.trace.getSpan(ctx);
        if (requireParent === true && currentSpan === void 0) {
          span = api_1.trace.wrapSpanContext(api_1.INVALID_SPAN_CONTEXT);
        } else if (requireParent === true && (currentSpan === null || currentSpan === void 0 ? void 0 : currentSpan.spanContext().isRemote)) {
          span = currentSpan;
        } else {
          span = this.tracer.startSpan(name, options, ctx);
        }
        this._spanNotEnded.add(span);
        return span;
      }
      _closeHttpSpan(span) {
        if (!this._spanNotEnded.has(span)) {
          return;
        }
        span.end();
        this._spanNotEnded.delete(span);
      }
      _callResponseHook(span, response) {
        instrumentation_1.safeExecuteInTheMiddle(() => this._getConfig().responseHook(span, response), () => {
        }, true);
      }
      _callRequestHook(span, request) {
        instrumentation_1.safeExecuteInTheMiddle(() => this._getConfig().requestHook(span, request), () => {
        }, true);
      }
      _callStartSpanHook(request, hookFunc) {
        if (typeof hookFunc === "function") {
          return instrumentation_1.safeExecuteInTheMiddle(() => hookFunc(request), () => {
          }, true);
        }
      }
      _createHeaderCapture() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
        const config = this._getConfig();
        return {
          client: {
            captureRequestHeaders: utils.headerCapture("request", (_c = (_b = (_a = config.headersToSpanAttributes) === null || _a === void 0 ? void 0 : _a.client) === null || _b === void 0 ? void 0 : _b.requestHeaders) !== null && _c !== void 0 ? _c : []),
            captureResponseHeaders: utils.headerCapture("response", (_f = (_e = (_d = config.headersToSpanAttributes) === null || _d === void 0 ? void 0 : _d.client) === null || _e === void 0 ? void 0 : _e.responseHeaders) !== null && _f !== void 0 ? _f : [])
          },
          server: {
            captureRequestHeaders: utils.headerCapture("request", (_j = (_h = (_g = config.headersToSpanAttributes) === null || _g === void 0 ? void 0 : _g.server) === null || _h === void 0 ? void 0 : _h.requestHeaders) !== null && _j !== void 0 ? _j : []),
            captureResponseHeaders: utils.headerCapture("response", (_m = (_l = (_k = config.headersToSpanAttributes) === null || _k === void 0 ? void 0 : _k.server) === null || _l === void 0 ? void 0 : _l.responseHeaders) !== null && _m !== void 0 ? _m : [])
          }
        };
      }
    };
    exports2.HttpInstrumentation = HttpInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/types.js
var require_types15 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/index.js
var require_src25 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-http/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_http(), exports2);
    __exportStar(require_types15(), exports2);
    __exportStar(require_utils11(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-ioredis/build/src/utils.js
var require_utils12 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-ioredis/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.defaultDbStatementSerializer = exports2.endSpan = void 0;
    var api_1 = require_src();
    var endSpan = (span, err) => {
      if (err) {
        span.recordException(err);
        span.setStatus({
          code: api_1.SpanStatusCode.ERROR,
          message: err.message
        });
      }
      span.end();
    };
    exports2.endSpan = endSpan;
    var defaultDbStatementSerializer = (cmdName, cmdArgs) => Array.isArray(cmdArgs) && cmdArgs.length ? `${cmdName} ${cmdArgs.join(" ")}` : cmdName;
    exports2.defaultDbStatementSerializer = defaultDbStatementSerializer;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-ioredis/build/src/version.js
var require_version11 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-ioredis/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.27.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-ioredis/build/src/instrumentation.js
var require_instrumentation8 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-ioredis/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.IORedisInstrumentation = void 0;
    var api_1 = require_src();
    var instrumentation_1 = require_src13();
    var semantic_conventions_1 = require_src3();
    var instrumentation_2 = require_src13();
    var utils_1 = require_utils12();
    var version_1 = require_version11();
    var DEFAULT_CONFIG = {
      requireParentSpan: true
    };
    var IORedisInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(_config = {}) {
        super("@opentelemetry/instrumentation-ioredis", version_1.VERSION, Object.assign({}, DEFAULT_CONFIG, _config));
        this.traceSendCommand = (original, moduleVersion) => {
          const instrumentation = this;
          return function(cmd) {
            if (arguments.length < 1 || typeof cmd !== "object") {
              return original.apply(this, arguments);
            }
            const config = instrumentation.getConfig();
            const dbStatementSerializer = (config === null || config === void 0 ? void 0 : config.dbStatementSerializer) || utils_1.defaultDbStatementSerializer;
            const hasNoParentSpan = api_1.trace.getSpan(api_1.context.active()) === void 0;
            if ((config === null || config === void 0 ? void 0 : config.requireParentSpan) === true && hasNoParentSpan) {
              return original.apply(this, arguments);
            }
            const span = instrumentation.tracer.startSpan(cmd.name, {
              kind: api_1.SpanKind.CLIENT,
              attributes: {
                [semantic_conventions_1.SemanticAttributes.DB_SYSTEM]: IORedisInstrumentation2.DB_SYSTEM,
                [semantic_conventions_1.SemanticAttributes.DB_STATEMENT]: dbStatementSerializer(cmd.name, cmd.args)
              }
            });
            if (config === null || config === void 0 ? void 0 : config.requestHook) {
              instrumentation_2.safeExecuteInTheMiddle(() => config === null || config === void 0 ? void 0 : config.requestHook(span, {
                moduleVersion,
                cmdName: cmd.name,
                cmdArgs: cmd.args
              }), (e) => {
                if (e) {
                  api_1.diag.error("ioredis instrumentation: request hook failed", e);
                }
              }, true);
            }
            const { host, port } = this.options;
            span.setAttributes({
              [semantic_conventions_1.SemanticAttributes.NET_PEER_NAME]: host,
              [semantic_conventions_1.SemanticAttributes.NET_PEER_PORT]: port,
              [semantic_conventions_1.SemanticAttributes.NET_PEER_IP]: `redis://${host}:${port}`
            });
            try {
              const result = original.apply(this, arguments);
              const origResolve = cmd.resolve;
              cmd.resolve = function(result2) {
                instrumentation_2.safeExecuteInTheMiddle(() => {
                  var _a;
                  return (_a = config === null || config === void 0 ? void 0 : config.responseHook) === null || _a === void 0 ? void 0 : _a.call(config, span, cmd.name, cmd.args, result2);
                }, (e) => {
                  if (e) {
                    api_1.diag.error("ioredis instrumentation: response hook failed", e);
                  }
                }, true);
                utils_1.endSpan(span, null);
                origResolve(result2);
              };
              const origReject = cmd.reject;
              cmd.reject = function(err) {
                utils_1.endSpan(span, err);
                origReject(err);
              };
              return result;
            } catch (error) {
              utils_1.endSpan(span, error);
              throw error;
            }
          };
        };
        this.traceConnection = (original) => {
          const instrumentation = this;
          return function() {
            const span = instrumentation.tracer.startSpan("connect", {
              kind: api_1.SpanKind.CLIENT,
              attributes: {
                [semantic_conventions_1.SemanticAttributes.DB_SYSTEM]: IORedisInstrumentation2.DB_SYSTEM,
                [semantic_conventions_1.SemanticAttributes.DB_STATEMENT]: "connect"
              }
            });
            const { host, port } = this.options;
            span.setAttributes({
              [semantic_conventions_1.SemanticAttributes.NET_PEER_NAME]: host,
              [semantic_conventions_1.SemanticAttributes.NET_PEER_PORT]: port,
              [semantic_conventions_1.SemanticAttributes.NET_PEER_IP]: `redis://${host}:${port}`
            });
            try {
              const client = original.apply(this, arguments);
              utils_1.endSpan(span, null);
              return client;
            } catch (error) {
              utils_1.endSpan(span, error);
              throw error;
            }
          };
        };
      }
      init() {
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("ioredis", [">1 <5"], (moduleExports, moduleVersion) => {
            api_1.diag.debug("Applying patch for ioredis");
            if (instrumentation_1.isWrapped(moduleExports.prototype.sendCommand)) {
              this._unwrap(moduleExports.prototype, "sendCommand");
            }
            this._wrap(moduleExports.prototype, "sendCommand", this._patchSendCommand(moduleVersion));
            if (instrumentation_1.isWrapped(moduleExports.prototype.connect)) {
              this._unwrap(moduleExports.prototype, "connect");
            }
            this._wrap(moduleExports.prototype, "connect", this._patchConnection());
            return moduleExports;
          }, (moduleExports) => {
            if (moduleExports === void 0)
              return;
            api_1.diag.debug("Removing patch for ioredis");
            this._unwrap(moduleExports.prototype, "sendCommand");
            this._unwrap(moduleExports.prototype, "connect");
          })
        ];
      }
      _patchSendCommand(moduleVersion) {
        return (original) => {
          return this.traceSendCommand(original, moduleVersion);
        };
      }
      _patchConnection() {
        return (original) => {
          return this.traceConnection(original);
        };
      }
    };
    exports2.IORedisInstrumentation = IORedisInstrumentation2;
    IORedisInstrumentation2.DB_SYSTEM = "redis";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-ioredis/build/src/index.js
var require_src26 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-ioredis/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation8(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/types.js
var require_types16 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.KoaComponentName = exports2.KoaLayerType = exports2.kLayerPatched = void 0;
    exports2.kLayerPatched = Symbol("koa-layer-patched");
    var KoaLayerType;
    (function(KoaLayerType2) {
      KoaLayerType2["ROUTER"] = "router";
      KoaLayerType2["MIDDLEWARE"] = "middleware";
    })(KoaLayerType = exports2.KoaLayerType || (exports2.KoaLayerType = {}));
    exports2.KoaComponentName = "koa";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/enums/AttributeNames.js
var require_AttributeNames7 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/enums/AttributeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["KOA_TYPE"] = "koa.type";
      AttributeNames2["KOA_NAME"] = "koa.name";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/version.js
var require_version12 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.28.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/utils.js
var require_utils13 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isLayerIgnored = exports2.getMiddlewareMetadata = void 0;
    var types_1 = require_types16();
    var AttributeNames_1 = require_AttributeNames7();
    var semantic_conventions_1 = require_src3();
    var getMiddlewareMetadata = (context, layer, isRouter, layerPath) => {
      var _a;
      if (isRouter) {
        return {
          attributes: {
            [AttributeNames_1.AttributeNames.KOA_NAME]: layerPath,
            [AttributeNames_1.AttributeNames.KOA_TYPE]: types_1.KoaLayerType.ROUTER,
            [semantic_conventions_1.SemanticAttributes.HTTP_ROUTE]: layerPath
          },
          name: `router - ${layerPath}`
        };
      } else {
        return {
          attributes: {
            [AttributeNames_1.AttributeNames.KOA_NAME]: (_a = layer.name) !== null && _a !== void 0 ? _a : "middleware",
            [AttributeNames_1.AttributeNames.KOA_TYPE]: types_1.KoaLayerType.MIDDLEWARE
          },
          name: `middleware - ${layer.name}`
        };
      }
    };
    exports2.getMiddlewareMetadata = getMiddlewareMetadata;
    var isLayerIgnored = (type, config) => {
      var _a;
      return !!(Array.isArray(config === null || config === void 0 ? void 0 : config.ignoreLayersType) && ((_a = config === null || config === void 0 ? void 0 : config.ignoreLayersType) === null || _a === void 0 ? void 0 : _a.includes(type)));
    };
    exports2.isLayerIgnored = isLayerIgnored;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/instrumentation.js
var require_instrumentation9 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.KoaInstrumentation = void 0;
    var api = require_src();
    var instrumentation_1 = require_src13();
    var types_1 = require_types16();
    var AttributeNames_1 = require_AttributeNames7();
    var version_1 = require_version12();
    var utils_1 = require_utils13();
    var core_1 = require_src4();
    var KoaInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(config) {
        super("@opentelemetry/instrumentation-koa", version_1.VERSION, config);
      }
      init() {
        return new instrumentation_1.InstrumentationNodeModuleDefinition("koa", ["^2.0.0"], (moduleExports) => {
          if (moduleExports == null) {
            return moduleExports;
          }
          api.diag.debug("Patching Koa");
          if (instrumentation_1.isWrapped(moduleExports.prototype.use)) {
            this._unwrap(moduleExports.prototype, "use");
          }
          this._wrap(moduleExports.prototype, "use", this._getKoaUsePatch.bind(this));
          return moduleExports;
        }, (moduleExports) => {
          api.diag.debug("Unpatching Koa");
          if (instrumentation_1.isWrapped(moduleExports.prototype.use)) {
            this._unwrap(moduleExports.prototype, "use");
          }
        });
      }
      _getKoaUsePatch(original) {
        const plugin = this;
        return function use(middlewareFunction) {
          let patchedFunction;
          if (middlewareFunction.router) {
            patchedFunction = plugin._patchRouterDispatch(middlewareFunction);
          } else {
            patchedFunction = plugin._patchLayer(middlewareFunction, false);
          }
          return original.apply(this, [patchedFunction]);
        };
      }
      _patchRouterDispatch(dispatchLayer) {
        var _a;
        api.diag.debug("Patching @koa/router dispatch");
        const router = dispatchLayer.router;
        const routesStack = (_a = router === null || router === void 0 ? void 0 : router.stack) !== null && _a !== void 0 ? _a : [];
        for (const pathLayer of routesStack) {
          const path = pathLayer.path;
          const pathStack = pathLayer.stack;
          for (let j = 0; j < pathStack.length; j++) {
            const routedMiddleware = pathStack[j];
            pathStack[j] = this._patchLayer(routedMiddleware, true, path);
          }
        }
        return dispatchLayer;
      }
      _patchLayer(middlewareLayer, isRouter, layerPath) {
        const layerType = isRouter ? types_1.KoaLayerType.ROUTER : types_1.KoaLayerType.MIDDLEWARE;
        if (middlewareLayer[types_1.kLayerPatched] === true || utils_1.isLayerIgnored(layerType, this._config))
          return middlewareLayer;
        middlewareLayer[types_1.kLayerPatched] = true;
        api.diag.debug("patching Koa middleware layer");
        return async (context, next) => {
          const parent = api.trace.getSpan(api.context.active());
          if (parent === void 0) {
            return middlewareLayer(context, next);
          }
          const metadata = utils_1.getMiddlewareMetadata(context, middlewareLayer, isRouter, layerPath);
          const span = this.tracer.startSpan(metadata.name, {
            attributes: metadata.attributes
          });
          const rpcMetadata = core_1.getRPCMetadata(api.context.active());
          if (metadata.attributes[AttributeNames_1.AttributeNames.KOA_TYPE] === types_1.KoaLayerType.ROUTER && (rpcMetadata === null || rpcMetadata === void 0 ? void 0 : rpcMetadata.type) === core_1.RPCType.HTTP) {
            rpcMetadata.span.updateName(`${context.method} ${context._matchedRoute}`);
          }
          let newContext = api.trace.setSpan(api.context.active(), span);
          if ((rpcMetadata === null || rpcMetadata === void 0 ? void 0 : rpcMetadata.type) === core_1.RPCType.HTTP) {
            newContext = core_1.setRPCMetadata(newContext, Object.assign(rpcMetadata, { route: context._matchedRoute }));
          }
          return api.context.with(newContext, async () => {
            try {
              return await middlewareLayer(context, next);
            } catch (err) {
              span.recordException(err);
              throw err;
            } finally {
              span.end();
            }
          });
        };
      }
    };
    exports2.KoaInstrumentation = KoaInstrumentation2;
    KoaInstrumentation2.component = types_1.KoaComponentName;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/index.js
var require_src27 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-koa/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation9(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mongodb/build/src/types.js
var require_types17 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mongodb/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MongodbCommandType = void 0;
    var MongodbCommandType;
    (function(MongodbCommandType2) {
      MongodbCommandType2["CREATE_INDEXES"] = "createIndexes";
      MongodbCommandType2["FIND_AND_MODIFY"] = "findAndModify";
      MongodbCommandType2["IS_MASTER"] = "isMaster";
      MongodbCommandType2["COUNT"] = "count";
      MongodbCommandType2["UNKNOWN"] = "unknown";
    })(MongodbCommandType = exports2.MongodbCommandType || (exports2.MongodbCommandType = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mongodb/build/src/version.js
var require_version13 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mongodb/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.28.0";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mongodb/build/src/instrumentation.js
var require_instrumentation10 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mongodb/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MongoDBInstrumentation = void 0;
    var api_1 = require_src();
    var instrumentation_1 = require_src13();
    var semantic_conventions_1 = require_src3();
    var types_1 = require_types17();
    var version_1 = require_version13();
    var supportedVersions = [">=3.3 <4"];
    var MongoDBInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(_config = {}) {
        super("@opentelemetry/instrumentation-mongodb", version_1.VERSION, _config);
        this._config = _config;
      }
      init() {
        const { patch, unpatch } = this._getPatches();
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("mongodb", supportedVersions, void 0, void 0, [
            new instrumentation_1.InstrumentationNodeModuleFile("mongodb/lib/core/wireprotocol/index.js", supportedVersions, patch, unpatch)
          ])
        ];
      }
      _getPatches() {
        return {
          patch: (moduleExports, moduleVersion) => {
            api_1.diag.debug(`Applying patch for mongodb@${moduleVersion}`);
            if (instrumentation_1.isWrapped(moduleExports.insert)) {
              this._unwrap(moduleExports, "insert");
            }
            this._wrap(moduleExports, "insert", this._getPatchOperation("insert"));
            if (instrumentation_1.isWrapped(moduleExports.remove)) {
              this._unwrap(moduleExports, "remove");
            }
            this._wrap(moduleExports, "remove", this._getPatchOperation("remove"));
            if (instrumentation_1.isWrapped(moduleExports.update)) {
              this._unwrap(moduleExports, "update");
            }
            this._wrap(moduleExports, "update", this._getPatchOperation("update"));
            if (instrumentation_1.isWrapped(moduleExports.command)) {
              this._unwrap(moduleExports, "command");
            }
            this._wrap(moduleExports, "command", this._getPatchCommand());
            if (instrumentation_1.isWrapped(moduleExports.query)) {
              this._unwrap(moduleExports, "query");
            }
            this._wrap(moduleExports, "query", this._getPatchFind());
            if (instrumentation_1.isWrapped(moduleExports.getMore)) {
              this._unwrap(moduleExports, "getMore");
            }
            this._wrap(moduleExports, "getMore", this._getPatchCursor());
            return moduleExports;
          },
          unpatch: (moduleExports, moduleVersion) => {
            if (moduleExports === void 0)
              return;
            api_1.diag.debug(`Removing internal patch for mongodb@${moduleVersion}`);
            this._unwrap(moduleExports, "insert");
            this._unwrap(moduleExports, "remove");
            this._unwrap(moduleExports, "update");
            this._unwrap(moduleExports, "command");
            this._unwrap(moduleExports, "query");
            this._unwrap(moduleExports, "getMore");
          }
        };
      }
      _getPatchOperation(operationName) {
        const instrumentation = this;
        return (original) => {
          return function patchedServerCommand(server, ns, ops, options, callback) {
            const currentSpan = api_1.trace.getSpan(api_1.context.active());
            const resultHandler = typeof options === "function" ? options : callback;
            if (!currentSpan || typeof resultHandler !== "function" || typeof ops !== "object") {
              if (typeof options === "function") {
                return original.call(this, server, ns, ops, options);
              } else {
                return original.call(this, server, ns, ops, options, callback);
              }
            }
            const span = instrumentation.tracer.startSpan(`mongodb.${operationName}`, {
              kind: api_1.SpanKind.CLIENT
            });
            instrumentation._populateAttributes(span, ns, server, ops[0]);
            const patchedCallback = instrumentation._patchEnd(span, resultHandler);
            if (typeof options === "function") {
              return original.call(this, server, ns, ops, patchedCallback);
            } else {
              return original.call(this, server, ns, ops, options, patchedCallback);
            }
          };
        };
      }
      _getPatchCommand() {
        const instrumentation = this;
        return (original) => {
          return function patchedServerCommand(server, ns, cmd, options, callback) {
            const currentSpan = api_1.trace.getSpan(api_1.context.active());
            const resultHandler = typeof options === "function" ? options : callback;
            if (!currentSpan || typeof resultHandler !== "function" || typeof cmd !== "object") {
              if (typeof options === "function") {
                return original.call(this, server, ns, cmd, options);
              } else {
                return original.call(this, server, ns, cmd, options, callback);
              }
            }
            const commandType = instrumentation._getCommandType(cmd);
            const type = commandType === types_1.MongodbCommandType.UNKNOWN ? "command" : commandType;
            const span = instrumentation.tracer.startSpan(`mongodb.${type}`, {
              kind: api_1.SpanKind.CLIENT
            });
            instrumentation._populateAttributes(span, ns, server, cmd);
            const patchedCallback = instrumentation._patchEnd(span, resultHandler);
            if (typeof options === "function") {
              return original.call(this, server, ns, cmd, patchedCallback);
            } else {
              return original.call(this, server, ns, cmd, options, patchedCallback);
            }
          };
        };
      }
      _getPatchFind() {
        const instrumentation = this;
        return (original) => {
          return function patchedServerCommand(server, ns, cmd, cursorState, options, callback) {
            const currentSpan = api_1.trace.getSpan(api_1.context.active());
            const resultHandler = typeof options === "function" ? options : callback;
            if (!currentSpan || typeof resultHandler !== "function" || typeof cmd !== "object") {
              if (typeof options === "function") {
                return original.call(this, server, ns, cmd, cursorState, options);
              } else {
                return original.call(this, server, ns, cmd, cursorState, options, callback);
              }
            }
            const span = instrumentation.tracer.startSpan("mongodb.find", {
              kind: api_1.SpanKind.CLIENT
            });
            instrumentation._populateAttributes(span, ns, server, cmd);
            const patchedCallback = instrumentation._patchEnd(span, resultHandler);
            if (typeof options === "function") {
              return original.call(this, server, ns, cmd, cursorState, patchedCallback);
            } else {
              return original.call(this, server, ns, cmd, cursorState, options, patchedCallback);
            }
          };
        };
      }
      _getPatchCursor() {
        const instrumentation = this;
        return (original) => {
          return function patchedServerCommand(server, ns, cursorState, batchSize, options, callback) {
            const currentSpan = api_1.trace.getSpan(api_1.context.active());
            const resultHandler = typeof options === "function" ? options : callback;
            if (!currentSpan || typeof resultHandler !== "function") {
              if (typeof options === "function") {
                return original.call(this, server, ns, cursorState, batchSize, options);
              } else {
                return original.call(this, server, ns, cursorState, batchSize, options, callback);
              }
            }
            const span = instrumentation.tracer.startSpan("mongodb.getMore", {
              kind: api_1.SpanKind.CLIENT
            });
            instrumentation._populateAttributes(span, ns, server, cursorState.cmd);
            const patchedCallback = instrumentation._patchEnd(span, resultHandler);
            if (typeof options === "function") {
              return original.call(this, server, ns, cursorState, batchSize, patchedCallback);
            } else {
              return original.call(this, server, ns, cursorState, batchSize, options, patchedCallback);
            }
          };
        };
      }
      _getCommandType(command) {
        if (command.createIndexes !== void 0) {
          return types_1.MongodbCommandType.CREATE_INDEXES;
        } else if (command.findandmodify !== void 0) {
          return types_1.MongodbCommandType.FIND_AND_MODIFY;
        } else if (command.ismaster !== void 0) {
          return types_1.MongodbCommandType.IS_MASTER;
        } else if (command.count !== void 0) {
          return types_1.MongodbCommandType.COUNT;
        } else {
          return types_1.MongodbCommandType.UNKNOWN;
        }
      }
      _populateAttributes(span, ns, topology, command) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        if (topology && topology.s) {
          let host = (_b = (_a = topology.s.options) === null || _a === void 0 ? void 0 : _a.host) !== null && _b !== void 0 ? _b : topology.s.host;
          let port = (_e = (_d = (_c = topology.s.options) === null || _c === void 0 ? void 0 : _c.port) !== null && _d !== void 0 ? _d : topology.s.port) === null || _e === void 0 ? void 0 : _e.toString();
          if (host == null || port == null) {
            const address = (_f = topology.description) === null || _f === void 0 ? void 0 : _f.address;
            if (address) {
              const addressSegments = address.split(":");
              host = addressSegments[0];
              port = addressSegments[1];
            }
          }
          if ((host === null || host === void 0 ? void 0 : host.length) && (port === null || port === void 0 ? void 0 : port.length)) {
            span.setAttributes({
              [semantic_conventions_1.SemanticAttributes.NET_HOST_NAME]: host,
              [semantic_conventions_1.SemanticAttributes.NET_HOST_PORT]: port
            });
          }
        }
        const [dbName, dbCollection] = ns.toString().split(".");
        span.setAttributes({
          [semantic_conventions_1.SemanticAttributes.DB_SYSTEM]: "mongodb",
          [semantic_conventions_1.SemanticAttributes.DB_NAME]: dbName,
          [semantic_conventions_1.SemanticAttributes.DB_MONGODB_COLLECTION]: dbCollection
        });
        if (command === void 0)
          return;
        const commandObj = (_h = (_g = command.query) !== null && _g !== void 0 ? _g : command.q) !== null && _h !== void 0 ? _h : command;
        const dbStatementSerializer = typeof this._config.dbStatementSerializer === "function" ? this._config.dbStatementSerializer : this._defaultDbStatementSerializer.bind(this);
        instrumentation_1.safeExecuteInTheMiddle(() => {
          const query = dbStatementSerializer(commandObj);
          span.setAttribute(semantic_conventions_1.SemanticAttributes.DB_STATEMENT, query);
        }, (err) => {
          if (err) {
            this._diag.error("Error running dbStatementSerializer hook", err);
          }
        }, true);
      }
      _defaultDbStatementSerializer(commandObj) {
        var _a;
        const enhancedDbReporting = !!((_a = this._config) === null || _a === void 0 ? void 0 : _a.enhancedDatabaseReporting);
        const resultObj = enhancedDbReporting ? commandObj : Object.keys(commandObj).reduce((obj, key) => {
          obj[key] = "?";
          return obj;
        }, {});
        return JSON.stringify(resultObj);
      }
      _handleExecutionResult(span, result) {
        const config = this.getConfig();
        if (typeof config.responseHook === "function") {
          instrumentation_1.safeExecuteInTheMiddle(() => {
            config.responseHook(span, { data: result });
          }, (err) => {
            if (err) {
              this._diag.error("Error running response hook", err);
            }
          }, true);
        }
      }
      _patchEnd(span, resultHandler) {
        const activeContext = api_1.context.active();
        const instrumentation = this;
        return function patchedEnd(...args) {
          const error = args[0];
          if (error instanceof Error) {
            span.setStatus({
              code: api_1.SpanStatusCode.ERROR,
              message: error.message
            });
          } else {
            const result = args[1];
            instrumentation._handleExecutionResult(span, result);
          }
          span.end();
          return api_1.context.with(activeContext, () => {
            return resultHandler.apply(this, args);
          });
        };
      }
    };
    exports2.MongoDBInstrumentation = MongoDBInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mongodb/build/src/index.js
var require_src28 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mongodb/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation10(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mysql/build/src/utils.js
var require_utils14 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mysql/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getSpanName = exports2.getDbStatement = exports2.getConnectionAttributes = void 0;
    var semantic_conventions_1 = require_src3();
    function getConnectionAttributes(config) {
      const { host, port, database, user } = getConfig(config);
      return {
        [semantic_conventions_1.SemanticAttributes.NET_PEER_NAME]: host,
        [semantic_conventions_1.SemanticAttributes.NET_PEER_PORT]: port,
        [semantic_conventions_1.SemanticAttributes.NET_PEER_IP]: getJDBCString(host, port, database),
        [semantic_conventions_1.SemanticAttributes.DB_NAME]: database,
        [semantic_conventions_1.SemanticAttributes.DB_USER]: user
      };
    }
    exports2.getConnectionAttributes = getConnectionAttributes;
    function getConfig(config) {
      const { host, port, database, user } = config && config.connectionConfig || config || {};
      return { host, port, database, user };
    }
    function getJDBCString(host, port, database) {
      let jdbcString = `jdbc:mysql://${host || "localhost"}`;
      if (typeof port === "number") {
        jdbcString += `:${port}`;
      }
      if (typeof database === "string") {
        jdbcString += `/${database}`;
      }
      return jdbcString;
    }
    function getDbStatement(query, format, values) {
      if (typeof query === "string") {
        return values ? format(query, values) : query;
      } else {
        return values || query.values ? format(query.sql, values || query.values) : query.sql;
      }
    }
    exports2.getDbStatement = getDbStatement;
    function getSpanName(query) {
      if (typeof query === "object") {
        return query.sql;
      }
      return query.split(" ")[0];
    }
    exports2.getSpanName = getSpanName;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mysql/build/src/version.js
var require_version14 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mysql/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.27.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mysql/build/src/instrumentation.js
var require_instrumentation11 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mysql/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MySQLInstrumentation = void 0;
    var api_1 = require_src();
    var instrumentation_1 = require_src13();
    var semantic_conventions_1 = require_src3();
    var utils_1 = require_utils14();
    var version_1 = require_version14();
    var MySQLInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(config) {
        super("@opentelemetry/instrumentation-mysql", version_1.VERSION, config);
      }
      init() {
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("mysql", ["2.*"], (moduleExports, moduleVersion) => {
            api_1.diag.debug(`Patching mysql@${moduleVersion}`);
            api_1.diag.debug("Patching mysql.createConnection");
            if (instrumentation_1.isWrapped(moduleExports.createConnection)) {
              this._unwrap(moduleExports, "createConnection");
            }
            this._wrap(moduleExports, "createConnection", this._patchCreateConnection(moduleExports.format));
            api_1.diag.debug("Patching mysql.createPool");
            if (instrumentation_1.isWrapped(moduleExports.createPool)) {
              this._unwrap(moduleExports, "createPool");
            }
            this._wrap(moduleExports, "createPool", this._patchCreatePool(moduleExports.format));
            api_1.diag.debug("Patching mysql.createPoolCluster");
            if (instrumentation_1.isWrapped(moduleExports.createPoolCluster)) {
              this._unwrap(moduleExports, "createPoolCluster");
            }
            this._wrap(moduleExports, "createPoolCluster", this._patchCreatePoolCluster(moduleExports.format));
            return moduleExports;
          }, (moduleExports) => {
            if (moduleExports === void 0)
              return;
            this._unwrap(moduleExports, "createConnection");
            this._unwrap(moduleExports, "createPool");
            this._unwrap(moduleExports, "createPoolCluster");
          })
        ];
      }
      _patchCreateConnection(format) {
        return (originalCreateConnection) => {
          const thisPlugin = this;
          api_1.diag.debug("MySQLInstrumentation#patch: patched mysql createConnection");
          return function createConnection(_connectionUri) {
            const originalResult = originalCreateConnection(...arguments);
            thisPlugin._wrap(originalResult, "query", thisPlugin._patchQuery(originalResult, format));
            return originalResult;
          };
        };
      }
      _patchCreatePool(format) {
        return (originalCreatePool) => {
          const thisPlugin = this;
          api_1.diag.debug("MySQLInstrumentation#patch: patched mysql createPool");
          return function createPool(_config) {
            const pool = originalCreatePool(...arguments);
            thisPlugin._wrap(pool, "query", thisPlugin._patchQuery(pool, format));
            thisPlugin._wrap(pool, "getConnection", thisPlugin._patchGetConnection(pool, format));
            return pool;
          };
        };
      }
      _patchCreatePoolCluster(format) {
        return (originalCreatePoolCluster) => {
          const thisPlugin = this;
          api_1.diag.debug("MySQLInstrumentation#patch: patched mysql createPoolCluster");
          return function createPool(_config) {
            const cluster = originalCreatePoolCluster(...arguments);
            thisPlugin._wrap(cluster, "getConnection", thisPlugin._patchGetConnection(cluster, format));
            return cluster;
          };
        };
      }
      _patchGetConnection(pool, format) {
        return (originalGetConnection) => {
          const thisPlugin = this;
          api_1.diag.debug("MySQLInstrumentation#patch: patched mysql pool getConnection");
          return function getConnection(arg1, arg2, arg3) {
            if (!thisPlugin["_enabled"]) {
              thisPlugin._unwrap(pool, "getConnection");
              return originalGetConnection.apply(pool, arguments);
            }
            if (arguments.length === 1 && typeof arg1 === "function") {
              const patchFn = thisPlugin._getConnectionCallbackPatchFn(arg1, format);
              return originalGetConnection.call(pool, patchFn);
            }
            if (arguments.length === 2 && typeof arg2 === "function") {
              const patchFn = thisPlugin._getConnectionCallbackPatchFn(arg2, format);
              return originalGetConnection.call(pool, arg1, patchFn);
            }
            if (arguments.length === 3 && typeof arg3 === "function") {
              const patchFn = thisPlugin._getConnectionCallbackPatchFn(arg3, format);
              return originalGetConnection.call(pool, arg1, arg2, patchFn);
            }
            return originalGetConnection.apply(pool, arguments);
          };
        };
      }
      _getConnectionCallbackPatchFn(cb, format) {
        const thisPlugin = this;
        const activeContext = api_1.context.active();
        return function(err, connection) {
          if (connection) {
            if (!instrumentation_1.isWrapped(connection.query)) {
              thisPlugin._wrap(connection, "query", thisPlugin._patchQuery(connection, format));
            }
          }
          if (typeof cb === "function") {
            api_1.context.with(activeContext, cb, this, err, connection);
          }
        };
      }
      _patchQuery(connection, format) {
        return (originalQuery) => {
          const thisPlugin = this;
          api_1.diag.debug("MySQLInstrumentation: patched mysql query");
          return function query(query, _valuesOrCallback, _callback) {
            if (!thisPlugin["_enabled"]) {
              thisPlugin._unwrap(connection, "query");
              return originalQuery.apply(connection, arguments);
            }
            const span = thisPlugin.tracer.startSpan(utils_1.getSpanName(query), {
              kind: api_1.SpanKind.CLIENT,
              attributes: Object.assign(Object.assign({}, MySQLInstrumentation2.COMMON_ATTRIBUTES), utils_1.getConnectionAttributes(connection.config))
            });
            let values;
            if (Array.isArray(_valuesOrCallback)) {
              values = _valuesOrCallback;
            } else if (arguments[2]) {
              values = [_valuesOrCallback];
            }
            span.setAttribute(semantic_conventions_1.SemanticAttributes.DB_STATEMENT, utils_1.getDbStatement(query, format, values));
            const cbIndex = Array.from(arguments).findIndex((arg) => typeof arg === "function");
            if (cbIndex === -1) {
              const streamableQuery = originalQuery.apply(connection, arguments);
              return streamableQuery.on("error", (err) => span.setStatus({
                code: api_1.SpanStatusCode.ERROR,
                message: err.message
              })).on("end", () => {
                span.end();
              });
            } else {
              thisPlugin._wrap(arguments, cbIndex, thisPlugin._patchCallbackQuery(span));
              return originalQuery.apply(connection, arguments);
            }
          };
        };
      }
      _patchCallbackQuery(span) {
        return (originalCallback) => {
          return function(err, results, fields) {
            if (err) {
              span.setStatus({
                code: api_1.SpanStatusCode.ERROR,
                message: err.message
              });
            }
            span.end();
            return originalCallback(...arguments);
          };
        };
      }
    };
    exports2.MySQLInstrumentation = MySQLInstrumentation2;
    MySQLInstrumentation2.COMPONENT = "mysql";
    MySQLInstrumentation2.COMMON_ATTRIBUTES = {
      [semantic_conventions_1.SemanticAttributes.DB_SYSTEM]: MySQLInstrumentation2.COMPONENT
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mysql/build/src/index.js
var require_src29 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-mysql/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation11(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/types.js
var require_types18 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/types.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TLSAttributes = exports2.SocketEvent = void 0;
    var SocketEvent;
    (function(SocketEvent2) {
      SocketEvent2["CLOSE"] = "close";
      SocketEvent2["CONNECT"] = "connect";
      SocketEvent2["ERROR"] = "error";
      SocketEvent2["SECURE_CONNECT"] = "secureConnect";
    })(SocketEvent = exports2.SocketEvent || (exports2.SocketEvent = {}));
    var TLSAttributes;
    (function(TLSAttributes2) {
      TLSAttributes2["PROTOCOL"] = "tls.protocol";
      TLSAttributes2["AUTHORIZED"] = "tls.authorized";
      TLSAttributes2["CIPHER_NAME"] = "tls.cipher.name";
      TLSAttributes2["CIPHER_VERSION"] = "tls.cipher.version";
      TLSAttributes2["CERTIFICATE_FINGERPRINT"] = "tls.certificate.fingerprint";
      TLSAttributes2["CERTIFICATE_SERIAL_NUMBER"] = "tls.certificate.serialNumber";
      TLSAttributes2["CERTIFICATE_VALID_FROM"] = "tls.certificate.validFrom";
      TLSAttributes2["CERTIFICATE_VALID_TO"] = "tls.certificate.validTo";
      TLSAttributes2["ALPN_PROTOCOL"] = "tls.alpnProtocol";
    })(TLSAttributes = exports2.TLSAttributes || (exports2.TLSAttributes = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/utils.js
var require_utils15 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getNormalizedArgs = exports2.IPC_TRANSPORT = void 0;
    var semantic_conventions_1 = require_src3();
    var os_1 = require("os");
    exports2.IPC_TRANSPORT = os_1.platform() === "win32" ? semantic_conventions_1.NetTransportValues.PIPE : semantic_conventions_1.NetTransportValues.UNIX;
    function getNormalizedArgs(args) {
      const opt = args[0];
      if (!opt) {
        return;
      }
      switch (typeof opt) {
        case "number":
          return {
            port: opt,
            host: typeof args[1] === "string" ? args[1] : "localhost"
          };
        case "object":
          if (Array.isArray(opt)) {
            return getNormalizedArgs(opt);
          }
          return opt;
        case "string":
          return {
            path: opt
          };
        default:
          return;
      }
    }
    exports2.getNormalizedArgs = getNormalizedArgs;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/version.js
var require_version15 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.27.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/instrumentation.js
var require_instrumentation12 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.NetInstrumentation = void 0;
    var api_1 = require_src();
    var instrumentation_1 = require_src13();
    var semantic_conventions_1 = require_src3();
    var types_1 = require_types18();
    var utils_1 = require_utils15();
    var version_1 = require_version15();
    var tls_1 = require("tls");
    var NetInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(_config) {
        super("@opentelemetry/instrumentation-net", version_1.VERSION, _config);
      }
      init() {
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("net", ["*"], (moduleExports) => {
            api_1.diag.debug("Applying patch for net module");
            if (instrumentation_1.isWrapped(moduleExports.Socket.prototype.connect)) {
              this._unwrap(moduleExports.Socket.prototype, "connect");
            }
            this._wrap(moduleExports.Socket.prototype, "connect", this._getPatchedConnect());
            return moduleExports;
          }, (moduleExports) => {
            if (moduleExports === void 0)
              return;
            api_1.diag.debug("Removing patch from net module");
            this._unwrap(moduleExports.Socket.prototype, "connect");
          })
        ];
      }
      _getPatchedConnect() {
        return (original) => {
          const plugin = this;
          return function patchedConnect(...args) {
            const options = utils_1.getNormalizedArgs(args);
            const span = this instanceof tls_1.TLSSocket ? plugin._startTLSSpan(options, this) : plugin._startSpan(options, this);
            return instrumentation_1.safeExecuteInTheMiddle(() => original.apply(this, args), (error) => {
              if (error !== void 0) {
                span.setStatus({
                  code: api_1.SpanStatusCode.ERROR,
                  message: error.message
                });
                span.recordException(error);
                span.end();
              }
            });
          };
        };
      }
      _startSpan(options, socket) {
        if (!options) {
          return this._startGenericSpan(socket);
        }
        if (options.path) {
          return this._startIpcSpan(options, socket);
        }
        return this._startTcpSpan(options, socket);
      }
      _startTLSSpan(options, socket) {
        const tlsSpan = this.tracer.startSpan("tls.connect");
        const netSpan = this._startSpan(options, socket);
        const otelTlsSpanListener = () => {
          const peerCertificate = socket.getPeerCertificate(true);
          const cipher = socket.getCipher();
          const protocol = socket.getProtocol();
          const attributes = {
            [types_1.TLSAttributes.PROTOCOL]: String(protocol),
            [types_1.TLSAttributes.AUTHORIZED]: String(socket.authorized),
            [types_1.TLSAttributes.CIPHER_NAME]: cipher.name,
            [types_1.TLSAttributes.CIPHER_VERSION]: cipher.version,
            [types_1.TLSAttributes.CERTIFICATE_FINGERPRINT]: peerCertificate.fingerprint,
            [types_1.TLSAttributes.CERTIFICATE_SERIAL_NUMBER]: peerCertificate.serialNumber,
            [types_1.TLSAttributes.CERTIFICATE_VALID_FROM]: peerCertificate.valid_from,
            [types_1.TLSAttributes.CERTIFICATE_VALID_TO]: peerCertificate.valid_to,
            [types_1.TLSAttributes.ALPN_PROTOCOL]: ""
          };
          if (socket.alpnProtocol) {
            attributes[types_1.TLSAttributes.ALPN_PROTOCOL] = socket.alpnProtocol;
          }
          tlsSpan.setAttributes(attributes);
          tlsSpan.end();
        };
        const otelTlsErrorListener = (e) => {
          tlsSpan.setStatus({
            code: api_1.SpanStatusCode.ERROR,
            message: e.message
          });
          tlsSpan.end();
        };
        socket.prependOnceListener(types_1.SocketEvent.SECURE_CONNECT, otelTlsSpanListener);
        socket.once(types_1.SocketEvent.ERROR, otelTlsErrorListener);
        const otelTlsRemoveListeners = () => {
          socket.removeListener(types_1.SocketEvent.SECURE_CONNECT, otelTlsSpanListener);
          socket.removeListener(types_1.SocketEvent.ERROR, otelTlsErrorListener);
          for (const event of SOCKET_EVENTS) {
            socket.removeListener(event, otelTlsRemoveListeners);
          }
        };
        for (const event of [types_1.SocketEvent.CLOSE, types_1.SocketEvent.ERROR]) {
          socket.once(event, otelTlsRemoveListeners);
        }
        return netSpan;
      }
      _startGenericSpan(socket) {
        const span = this.tracer.startSpan("connect");
        registerListeners(socket, span);
        return span;
      }
      _startIpcSpan(options, socket) {
        const span = this.tracer.startSpan("ipc.connect", {
          attributes: {
            [semantic_conventions_1.SemanticAttributes.NET_TRANSPORT]: utils_1.IPC_TRANSPORT,
            [semantic_conventions_1.SemanticAttributes.NET_PEER_NAME]: options.path
          }
        });
        registerListeners(socket, span);
        return span;
      }
      _startTcpSpan(options, socket) {
        const span = this.tracer.startSpan("tcp.connect", {
          attributes: {
            [semantic_conventions_1.SemanticAttributes.NET_TRANSPORT]: semantic_conventions_1.NetTransportValues.IP_TCP,
            [semantic_conventions_1.SemanticAttributes.NET_PEER_NAME]: options.host,
            [semantic_conventions_1.SemanticAttributes.NET_PEER_PORT]: options.port
          }
        });
        registerListeners(socket, span, { hostAttributes: true });
        return span;
      }
    };
    exports2.NetInstrumentation = NetInstrumentation2;
    var SOCKET_EVENTS = [
      types_1.SocketEvent.CLOSE,
      types_1.SocketEvent.CONNECT,
      types_1.SocketEvent.ERROR
    ];
    function spanEndHandler(span) {
      return () => {
        span.end();
      };
    }
    function spanErrorHandler(span) {
      return (e) => {
        span.setStatus({
          code: api_1.SpanStatusCode.ERROR,
          message: e.message
        });
      };
    }
    function registerListeners(socket, span, { hostAttributes = false } = {}) {
      const setSpanError = spanErrorHandler(span);
      const setSpanEnd = spanEndHandler(span);
      const setHostAttributes = () => {
        span.setAttributes({
          [semantic_conventions_1.SemanticAttributes.NET_PEER_IP]: socket.remoteAddress,
          [semantic_conventions_1.SemanticAttributes.NET_HOST_IP]: socket.localAddress,
          [semantic_conventions_1.SemanticAttributes.NET_HOST_PORT]: socket.localPort
        });
      };
      socket.once(types_1.SocketEvent.ERROR, setSpanError);
      if (hostAttributes) {
        socket.once(types_1.SocketEvent.CONNECT, setHostAttributes);
      }
      const removeListeners = () => {
        socket.removeListener(types_1.SocketEvent.ERROR, setSpanError);
        socket.removeListener(types_1.SocketEvent.CONNECT, setHostAttributes);
        for (const event of SOCKET_EVENTS) {
          socket.removeListener(event, setSpanEnd);
          socket.removeListener(event, removeListeners);
        }
      };
      for (const event of SOCKET_EVENTS) {
        socket.once(event, setSpanEnd);
        socket.once(event, removeListeners);
      }
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/index.js
var require_src30 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-net/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation12(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/enums/AttributeNames.js
var require_AttributeNames8 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/enums/AttributeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["PG_VALUES"] = "db.postgresql.values";
      AttributeNames2["PG_PLAN"] = "db.postgresql.plan";
      AttributeNames2["IDLE_TIMEOUT_MILLIS"] = "db.postgresql.idle.timeout.millis";
      AttributeNames2["MAX_CLIENT"] = "db.postgresql.max.client";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/utils.js
var require_utils16 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.patchCallbackPGPool = exports2.patchCallback = exports2.handleExecutionResult = exports2.handleInvalidQuery = exports2.handleTextQuery = exports2.handleParameterizedQuery = exports2.handleConfigQuery = exports2.getJDBCString = void 0;
    var api_1 = require_src();
    var AttributeNames_1 = require_AttributeNames8();
    var semantic_conventions_1 = require_src3();
    var _1 = require_src31();
    var instrumentation_1 = require_src13();
    function arrayStringifyHelper(arr) {
      return "[" + arr.toString() + "]";
    }
    function getCommandFromText(text) {
      if (!text)
        return "unknown";
      const words = text.split(" ");
      return words[0].length > 0 ? words[0] : "unknown";
    }
    function getJDBCString(params) {
      const host = params.host || "localhost";
      const port = params.port || 5432;
      const database = params.database || "";
      return `jdbc:postgresql://${host}:${port}/${database}`;
    }
    exports2.getJDBCString = getJDBCString;
    function pgStartSpan(tracer, client, name) {
      const jdbcString = getJDBCString(client.connectionParameters);
      return tracer.startSpan(name, {
        kind: api_1.SpanKind.CLIENT,
        attributes: {
          [semantic_conventions_1.SemanticAttributes.DB_NAME]: client.connectionParameters.database,
          [semantic_conventions_1.SemanticAttributes.DB_SYSTEM]: semantic_conventions_1.DbSystemValues.POSTGRESQL,
          [semantic_conventions_1.SemanticAttributes.DB_CONNECTION_STRING]: jdbcString,
          [semantic_conventions_1.SemanticAttributes.NET_PEER_NAME]: client.connectionParameters.host,
          [semantic_conventions_1.SemanticAttributes.NET_PEER_PORT]: client.connectionParameters.port,
          [semantic_conventions_1.SemanticAttributes.DB_USER]: client.connectionParameters.user
        }
      });
    }
    function handleConfigQuery(tracer, instrumentationConfig, queryConfig) {
      const queryCommand = getCommandFromText(queryConfig.name || queryConfig.text);
      const name = _1.PgInstrumentation.BASE_SPAN_NAME + ":" + queryCommand;
      const span = pgStartSpan(tracer, this, name);
      if (queryConfig.text) {
        span.setAttribute(semantic_conventions_1.SemanticAttributes.DB_STATEMENT, queryConfig.text);
      }
      if (instrumentationConfig.enhancedDatabaseReporting && queryConfig.values instanceof Array) {
        span.setAttribute(AttributeNames_1.AttributeNames.PG_VALUES, arrayStringifyHelper(queryConfig.values));
      }
      if (queryConfig.name) {
        span.setAttribute(AttributeNames_1.AttributeNames.PG_PLAN, queryConfig.name);
      }
      return span;
    }
    exports2.handleConfigQuery = handleConfigQuery;
    function handleParameterizedQuery(tracer, instrumentationConfig, query, values) {
      const queryCommand = getCommandFromText(query);
      const name = _1.PgInstrumentation.BASE_SPAN_NAME + ":" + queryCommand;
      const span = pgStartSpan(tracer, this, name);
      span.setAttribute(semantic_conventions_1.SemanticAttributes.DB_STATEMENT, query);
      if (instrumentationConfig.enhancedDatabaseReporting) {
        span.setAttribute(AttributeNames_1.AttributeNames.PG_VALUES, arrayStringifyHelper(values));
      }
      return span;
    }
    exports2.handleParameterizedQuery = handleParameterizedQuery;
    function handleTextQuery(tracer, query) {
      const queryCommand = getCommandFromText(query);
      const name = _1.PgInstrumentation.BASE_SPAN_NAME + ":" + queryCommand;
      const span = pgStartSpan(tracer, this, name);
      span.setAttribute(semantic_conventions_1.SemanticAttributes.DB_STATEMENT, query);
      return span;
    }
    exports2.handleTextQuery = handleTextQuery;
    function handleInvalidQuery(tracer, originalQuery, ...args) {
      let result;
      const span = pgStartSpan(tracer, this, _1.PgInstrumentation.BASE_SPAN_NAME);
      try {
        result = originalQuery.apply(this, args);
      } catch (e) {
        span.setStatus({ code: api_1.SpanStatusCode.ERROR, message: e.message });
        throw e;
      } finally {
        span.end();
      }
      return result;
    }
    exports2.handleInvalidQuery = handleInvalidQuery;
    function handleExecutionResult(config, span, pgResult) {
      if (typeof config.responseHook === "function") {
        instrumentation_1.safeExecuteInTheMiddle(() => {
          config.responseHook(span, {
            data: pgResult
          });
        }, (err) => {
          if (err) {
            api_1.diag.error("Error running response hook", err);
          }
        }, true);
      }
    }
    exports2.handleExecutionResult = handleExecutionResult;
    function patchCallback(instrumentationConfig, span, cb) {
      return function patchedCallback(err, res) {
        if (err) {
          span.setStatus({
            code: api_1.SpanStatusCode.ERROR,
            message: err.message
          });
        } else {
          handleExecutionResult(instrumentationConfig, span, res);
        }
        span.end();
        cb.call(this, err, res);
      };
    }
    exports2.patchCallback = patchCallback;
    function patchCallbackPGPool(span, cb) {
      return function patchedCallback(err, res, done) {
        if (err) {
          span.setStatus({
            code: api_1.SpanStatusCode.ERROR,
            message: err.message
          });
        }
        span.end();
        cb.call(this, err, res, done);
      };
    }
    exports2.patchCallbackPGPool = patchCallbackPGPool;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/version.js
var require_version16 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.28.0";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/instrumentation.js
var require_instrumentation13 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.PgInstrumentation = void 0;
    var instrumentation_1 = require_src13();
    var api_1 = require_src();
    var utils = require_utils16();
    var AttributeNames_1 = require_AttributeNames8();
    var semantic_conventions_1 = require_src3();
    var version_1 = require_version16();
    var PG_POOL_COMPONENT = "pg-pool";
    var PgInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(config = {}) {
        super("@opentelemetry/instrumentation-pg", version_1.VERSION, Object.assign({}, config));
      }
      init() {
        const modulePG = new instrumentation_1.InstrumentationNodeModuleDefinition("pg", ["7.*", "8.*"], (moduleExports) => {
          if (instrumentation_1.isWrapped(moduleExports.Client.prototype.query)) {
            this._unwrap(moduleExports.Client.prototype, "query");
          }
          this._wrap(moduleExports.Client.prototype, "query", this._getClientQueryPatch());
          return moduleExports;
        }, (moduleExports) => {
          if (instrumentation_1.isWrapped(moduleExports.Client.prototype.query)) {
            this._unwrap(moduleExports.Client.prototype, "query");
          }
        });
        const modulePGPool = new instrumentation_1.InstrumentationNodeModuleDefinition("pg-pool", ["2.*", "3.*"], (moduleExports) => {
          if (instrumentation_1.isWrapped(moduleExports.prototype.connect)) {
            this._unwrap(moduleExports.prototype, "connect");
          }
          this._wrap(moduleExports.prototype, "connect", this._getPoolConnectPatch());
          return moduleExports;
        }, (moduleExports) => {
          if (instrumentation_1.isWrapped(moduleExports.prototype.connect)) {
            this._unwrap(moduleExports.prototype, "connect");
          }
        });
        return [modulePG, modulePGPool];
      }
      _getClientQueryPatch() {
        const plugin = this;
        return (original) => {
          api_1.diag.debug(`Patching ${PgInstrumentation2.COMPONENT}.Client.prototype.query`);
          return function query(...args) {
            let span;
            if (typeof args[0] === "string") {
              const query2 = args[0];
              if (args.length > 1 && args[1] instanceof Array) {
                const params = args[1];
                span = utils.handleParameterizedQuery.call(this, plugin.tracer, plugin.getConfig(), query2, params);
              } else {
                span = utils.handleTextQuery.call(this, plugin.tracer, query2);
              }
            } else if (typeof args[0] === "object") {
              const queryConfig = args[0];
              span = utils.handleConfigQuery.call(this, plugin.tracer, plugin.getConfig(), queryConfig);
            } else {
              return utils.handleInvalidQuery.call(this, plugin.tracer, original, ...args);
            }
            if (args.length > 0) {
              const parentSpan = api_1.trace.getSpan(api_1.context.active());
              if (typeof args[args.length - 1] === "function") {
                args[args.length - 1] = utils.patchCallback(plugin.getConfig(), span, args[args.length - 1]);
                if (parentSpan) {
                  args[args.length - 1] = api_1.context.bind(api_1.context.active(), args[args.length - 1]);
                }
              } else if (typeof args[0].callback === "function") {
                let callback = utils.patchCallback(plugin.getConfig(), span, args[0].callback);
                if (parentSpan) {
                  callback = api_1.context.bind(api_1.context.active(), callback);
                }
                args[0] = Object.assign(Object.assign({}, args[0]), { callback });
              }
            }
            const result = original.apply(this, args);
            if (result instanceof Promise) {
              return result.then((result2) => {
                return new Promise((resolve) => {
                  utils.handleExecutionResult(plugin.getConfig(), span, result2);
                  span.end();
                  resolve(result2);
                });
              }).catch((error) => {
                return new Promise((_, reject) => {
                  span.setStatus({
                    code: api_1.SpanStatusCode.ERROR,
                    message: error.message
                  });
                  span.end();
                  reject(error);
                });
              });
            }
            return result;
          };
        };
      }
      _getPoolConnectPatch() {
        const plugin = this;
        return (originalConnect) => {
          return function connect(callback) {
            const jdbcString = utils.getJDBCString(this.options);
            const span = plugin.tracer.startSpan(`${PG_POOL_COMPONENT}.connect`, {
              kind: api_1.SpanKind.CLIENT,
              attributes: {
                [semantic_conventions_1.SemanticAttributes.DB_SYSTEM]: semantic_conventions_1.DbSystemValues.POSTGRESQL,
                [semantic_conventions_1.SemanticAttributes.DB_NAME]: this.options.database,
                [semantic_conventions_1.SemanticAttributes.NET_PEER_NAME]: this.options.host,
                [semantic_conventions_1.SemanticAttributes.DB_CONNECTION_STRING]: jdbcString,
                [semantic_conventions_1.SemanticAttributes.NET_PEER_PORT]: this.options.port,
                [semantic_conventions_1.SemanticAttributes.DB_USER]: this.options.user,
                [AttributeNames_1.AttributeNames.IDLE_TIMEOUT_MILLIS]: this.options.idleTimeoutMillis,
                [AttributeNames_1.AttributeNames.MAX_CLIENT]: this.options.maxClient
              }
            });
            if (callback) {
              const parentSpan = api_1.trace.getSpan(api_1.context.active());
              callback = utils.patchCallbackPGPool(span, callback);
              if (parentSpan) {
                callback = api_1.context.bind(api_1.context.active(), callback);
              }
            }
            const connectResult = originalConnect.call(this, callback);
            if (connectResult instanceof Promise) {
              const connectResultPromise = connectResult;
              return api_1.context.bind(api_1.context.active(), connectResultPromise.then((result) => {
                return new Promise((resolve) => {
                  span.end();
                  resolve(result);
                });
              }).catch((error) => {
                return new Promise((_, reject) => {
                  span.setStatus({
                    code: api_1.SpanStatusCode.ERROR,
                    message: error.message
                  });
                  span.end();
                  reject(error);
                });
              }));
            }
            return connectResult;
          };
        };
      }
    };
    exports2.PgInstrumentation = PgInstrumentation2;
    PgInstrumentation2.COMPONENT = "pg";
    PgInstrumentation2.BASE_SPAN_NAME = PgInstrumentation2.COMPONENT + ".query";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/index.js
var require_src31 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-pg/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation13(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-redis/build/src/utils.js
var require_utils17 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-redis/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getTracedInternalSendCommand = exports2.getTracedCreateStreamTrace = exports2.getTracedCreateClient = void 0;
    var api_1 = require_src();
    var _1 = require_src32();
    var semantic_conventions_1 = require_src3();
    var instrumentation_1 = require_src13();
    var endSpan = (span, err) => {
      if (err) {
        span.setStatus({
          code: api_1.SpanStatusCode.ERROR,
          message: err.message
        });
      }
      span.end();
    };
    var getTracedCreateClient = (tracer, original) => {
      return function createClientTrace() {
        const client = original.apply(this, arguments);
        return api_1.context.bind(api_1.context.active(), client);
      };
    };
    exports2.getTracedCreateClient = getTracedCreateClient;
    var getTracedCreateStreamTrace = (tracer, original) => {
      return function create_stream_trace() {
        if (!Object.prototype.hasOwnProperty.call(this, "stream")) {
          Object.defineProperty(this, "stream", {
            get() {
              return this._patched_redis_stream;
            },
            set(val) {
              api_1.context.bind(api_1.context.active(), val);
              this._patched_redis_stream = val;
            }
          });
        }
        return original.apply(this, arguments);
      };
    };
    exports2.getTracedCreateStreamTrace = getTracedCreateStreamTrace;
    var defaultDbStatementSerializer = (cmdName) => cmdName;
    var getTracedInternalSendCommand = (tracer, original, config) => {
      return function internal_send_command_trace(cmd) {
        if (arguments.length !== 1 || typeof cmd !== "object") {
          return original.apply(this, arguments);
        }
        const hasNoParentSpan = api_1.trace.getSpan(api_1.context.active()) === void 0;
        if ((config === null || config === void 0 ? void 0 : config.requireParentSpan) === true && hasNoParentSpan) {
          return original.apply(this, arguments);
        }
        const dbStatementSerializer = (config === null || config === void 0 ? void 0 : config.dbStatementSerializer) || defaultDbStatementSerializer;
        const span = tracer.startSpan(`${_1.RedisInstrumentation.COMPONENT}-${cmd.command}`, {
          kind: api_1.SpanKind.CLIENT,
          attributes: {
            [semantic_conventions_1.SemanticAttributes.DB_SYSTEM]: _1.RedisInstrumentation.COMPONENT,
            [semantic_conventions_1.SemanticAttributes.DB_STATEMENT]: dbStatementSerializer(cmd.command, cmd.args)
          }
        });
        if (this.options) {
          span.setAttributes({
            [semantic_conventions_1.SemanticAttributes.NET_PEER_NAME]: this.options.host,
            [semantic_conventions_1.SemanticAttributes.NET_PEER_PORT]: this.options.port
          });
        }
        if (this.address) {
          span.setAttribute(semantic_conventions_1.SemanticAttributes.NET_PEER_IP, `redis://${this.address}`);
        }
        const originalCallback = arguments[0].callback;
        if (originalCallback) {
          const originalContext = api_1.context.active();
          arguments[0].callback = function callback(err, reply) {
            if (config === null || config === void 0 ? void 0 : config.responseHook) {
              const responseHook = config.responseHook;
              instrumentation_1.safeExecuteInTheMiddle(() => {
                responseHook(span, cmd.command, cmd.args, reply);
              }, (err2) => {
                api_1.diag.error("Error executing responseHook", err2);
              }, true);
            }
            endSpan(span, err);
            return api_1.context.with(originalContext, originalCallback, this, ...arguments);
          };
        }
        try {
          return original.apply(this, arguments);
        } catch (rethrow) {
          endSpan(span, rethrow);
          throw rethrow;
        }
      };
    };
    exports2.getTracedInternalSendCommand = getTracedInternalSendCommand;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-redis/build/src/version.js
var require_version17 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-redis/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.28.0";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-redis/build/src/instrumentation.js
var require_instrumentation14 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-redis/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RedisInstrumentation = void 0;
    var api_1 = require_src();
    var instrumentation_1 = require_src13();
    var utils_1 = require_utils17();
    var version_1 = require_version17();
    var DEFAULT_CONFIG = {
      requireParentSpan: false
    };
    var RedisInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(_config = {}) {
        super("@opentelemetry/instrumentation-redis", version_1.VERSION, _config);
        this._config = _config;
      }
      setConfig(config = {}) {
        this._config = Object.assign({}, DEFAULT_CONFIG, config);
      }
      init() {
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("redis", ["^2.6.0", "^3.0.0"], (moduleExports, moduleVersion) => {
            api_1.diag.debug(`Patching redis@${moduleVersion}`);
            api_1.diag.debug("Patching redis.RedisClient.internal_send_command");
            if (instrumentation_1.isWrapped(moduleExports.RedisClient.prototype["internal_send_command"])) {
              this._unwrap(moduleExports.RedisClient.prototype, "internal_send_command");
            }
            this._wrap(moduleExports.RedisClient.prototype, "internal_send_command", this._getPatchInternalSendCommand());
            api_1.diag.debug("patching redis.RedisClient.create_stream");
            if (instrumentation_1.isWrapped(moduleExports.RedisClient.prototype["create_stream"])) {
              this._unwrap(moduleExports.RedisClient.prototype, "create_stream");
            }
            this._wrap(moduleExports.RedisClient.prototype, "create_stream", this._getPatchCreateStream());
            api_1.diag.debug("patching redis.createClient");
            if (instrumentation_1.isWrapped(moduleExports.createClient)) {
              this._unwrap(moduleExports, "createClient");
            }
            this._wrap(moduleExports, "createClient", this._getPatchCreateClient());
            return moduleExports;
          }, (moduleExports) => {
            if (moduleExports === void 0)
              return;
            this._unwrap(moduleExports.RedisClient.prototype, "internal_send_command");
            this._unwrap(moduleExports.RedisClient.prototype, "create_stream");
            this._unwrap(moduleExports, "createClient");
          })
        ];
      }
      _getPatchInternalSendCommand() {
        const tracer = this.tracer;
        const config = this._config;
        return function internal_send_command(original) {
          return utils_1.getTracedInternalSendCommand(tracer, original, config);
        };
      }
      _getPatchCreateClient() {
        const tracer = this.tracer;
        return function createClient(original) {
          return utils_1.getTracedCreateClient(tracer, original);
        };
      }
      _getPatchCreateStream() {
        const tracer = this.tracer;
        return function createReadStream(original) {
          return utils_1.getTracedCreateStreamTrace(tracer, original);
        };
      }
    };
    exports2.RedisInstrumentation = RedisInstrumentation2;
    RedisInstrumentation2.COMPONENT = "redis";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-redis/build/src/index.js
var require_src32 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-redis/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation14(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/enums/AttributeNames.js
var require_AttributeNames9 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/enums/AttributeNames.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.FastifyNames = exports2.FastifyTypes = exports2.AttributeNames = void 0;
    var AttributeNames;
    (function(AttributeNames2) {
      AttributeNames2["FASTIFY_NAME"] = "fastify.name";
      AttributeNames2["FASTIFY_TYPE"] = "fastify.type";
      AttributeNames2["HOOK_NAME"] = "hook.name";
      AttributeNames2["PLUGIN_NAME"] = "plugin.name";
    })(AttributeNames = exports2.AttributeNames || (exports2.AttributeNames = {}));
    var FastifyTypes;
    (function(FastifyTypes2) {
      FastifyTypes2["MIDDLEWARE"] = "middleware";
      FastifyTypes2["REQUEST_HANDLER"] = "request_handler";
    })(FastifyTypes = exports2.FastifyTypes || (exports2.FastifyTypes = {}));
    var FastifyNames;
    (function(FastifyNames2) {
      FastifyNames2["MIDDLEWARE"] = "middleware";
      FastifyNames2["REQUEST_HANDLER"] = "request handler";
    })(FastifyNames = exports2.FastifyNames || (exports2.FastifyNames = {}));
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/constants.js
var require_constants5 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.applicationHookNames = exports2.spanRequestSymbol = void 0;
    exports2.spanRequestSymbol = Symbol("opentelemetry.instrumentation.fastify.request_active_span");
    exports2.applicationHookNames = [
      "onRegister",
      "onRoute",
      "onReady",
      "onClose"
    ];
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/utils.js
var require_utils18 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.safeExecuteInTheMiddleMaybePromise = exports2.endSpan = exports2.startSpan = void 0;
    var api_1 = require_src();
    var constants_1 = require_constants5();
    function startSpan(reply, tracer, spanName, spanAttributes = {}) {
      const span = tracer.startSpan(spanName, { attributes: spanAttributes });
      const spans = reply[constants_1.spanRequestSymbol] || [];
      spans.push(span);
      Object.defineProperty(reply, constants_1.spanRequestSymbol, {
        enumerable: false,
        configurable: true,
        value: spans
      });
      return span;
    }
    exports2.startSpan = startSpan;
    function endSpan(reply, err) {
      const spans = reply[constants_1.spanRequestSymbol] || [];
      if (!spans.length) {
        return;
      }
      spans.forEach((span) => {
        if (err) {
          span.setStatus({
            code: api_1.SpanStatusCode.ERROR,
            message: err.message
          });
          span.recordException(err);
        }
        span.end();
      });
      delete reply[constants_1.spanRequestSymbol];
    }
    exports2.endSpan = endSpan;
    function safeExecuteInTheMiddleMaybePromise(execute, onFinish, preventThrowingError) {
      let error;
      let result = void 0;
      try {
        result = execute();
        if (isPromise(result)) {
          result.then((res) => onFinish(void 0, res), (err) => onFinish(err));
        }
      } catch (e) {
        error = e;
      } finally {
        if (!isPromise(result)) {
          onFinish(error, result);
          if (error && !preventThrowingError) {
            throw error;
          }
        }
        return result;
      }
    }
    exports2.safeExecuteInTheMiddleMaybePromise = safeExecuteInTheMiddleMaybePromise;
    function isPromise(val) {
      var _a;
      return typeof val === "object" && val && typeof ((_a = Object.getOwnPropertyDescriptor(val, "then")) === null || _a === void 0 ? void 0 : _a.value) === "function" || false;
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/version.js
var require_version18 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.26.0";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/instrumentation.js
var require_instrumentation15 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.FastifyInstrumentation = exports2.ANONYMOUS_NAME = void 0;
    var api_1 = require_src();
    var core_1 = require_src4();
    var instrumentation_1 = require_src13();
    var semantic_conventions_1 = require_src3();
    var constants_1 = require_constants5();
    var AttributeNames_1 = require_AttributeNames9();
    var utils_1 = require_utils18();
    var version_1 = require_version18();
    exports2.ANONYMOUS_NAME = "anonymous";
    var FastifyInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(config = {}) {
        super("@opentelemetry/instrumentation-fastify", version_1.VERSION, Object.assign({}, config));
      }
      init() {
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition("fastify", ["^3.0.0"], (moduleExports, moduleVersion) => {
            this._diag.debug(`Applying patch for fastify@${moduleVersion}`);
            return this._patchConstructor(moduleExports);
          })
        ];
      }
      _hookOnRequest() {
        const instrumentation = this;
        return function onRequest(request, reply, done) {
          if (!instrumentation.isEnabled()) {
            return done();
          }
          instrumentation._wrap(reply, "send", instrumentation._patchSend());
          const rpcMetadata = core_1.getRPCMetadata(api_1.context.active());
          const routeName = request.routerPath;
          if (routeName && (rpcMetadata === null || rpcMetadata === void 0 ? void 0 : rpcMetadata.type) === core_1.RPCType.HTTP) {
            rpcMetadata.span.setAttribute(semantic_conventions_1.SemanticAttributes.HTTP_ROUTE, routeName);
            rpcMetadata.span.updateName(`${request.method} ${routeName}`);
          }
          done();
        };
      }
      _wrapHandler(pluginName, hookName, original, syncFunctionWithDone) {
        const instrumentation = this;
        return function(...args) {
          if (!instrumentation.isEnabled()) {
            return original.apply(this, args);
          }
          const spanName = `${AttributeNames_1.FastifyNames.MIDDLEWARE} - ${original.name || exports2.ANONYMOUS_NAME}`;
          const reply = args[1];
          const span = utils_1.startSpan(reply, instrumentation.tracer, spanName, {
            [AttributeNames_1.AttributeNames.FASTIFY_TYPE]: AttributeNames_1.FastifyTypes.MIDDLEWARE,
            [AttributeNames_1.AttributeNames.PLUGIN_NAME]: pluginName,
            [AttributeNames_1.AttributeNames.HOOK_NAME]: hookName
          });
          const origDone = syncFunctionWithDone && args[args.length - 1];
          if (origDone) {
            args[args.length - 1] = function(...doneArgs) {
              utils_1.endSpan(reply);
              origDone.apply(this, doneArgs);
            };
          }
          return api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => {
            return utils_1.safeExecuteInTheMiddleMaybePromise(() => {
              return original.apply(this, args);
            }, (err) => {
              if (err instanceof Error) {
                span.setStatus({
                  code: api_1.SpanStatusCode.ERROR,
                  message: err.message
                });
                span.recordException(err);
              }
              if (!syncFunctionWithDone) {
                utils_1.endSpan(reply);
              }
            });
          });
        };
      }
      _wrapAddHook() {
        const instrumentation = this;
        return function(original) {
          return function wrappedAddHook(...args) {
            const name = args[0];
            const handler = args[1];
            const pluginName = this.pluginName;
            if (constants_1.applicationHookNames.includes(name)) {
              return original.apply(this, [name, handler]);
            }
            const syncFunctionWithDone = typeof args[args.length - 1] === "function" && handler.constructor.name !== "AsyncFunction";
            return original.apply(this, [
              name,
              instrumentation._wrapHandler(pluginName, name, handler, syncFunctionWithDone)
            ]);
          };
        };
      }
      _patchConstructor(original) {
        const instrumentation = this;
        function fastify(...args) {
          const app = original.apply(this, args);
          app.addHook("onRequest", instrumentation._hookOnRequest());
          app.addHook("preHandler", instrumentation._hookPreHandler());
          instrumentation._wrap(app, "addHook", instrumentation._wrapAddHook());
          return app;
        }
        fastify.fastify = fastify;
        fastify.default = fastify;
        return fastify;
      }
      _patchSend() {
        const instrumentation = this;
        return function patchSend(original) {
          return function send(...args) {
            const maybeError = args[0];
            if (!instrumentation.isEnabled()) {
              return original.apply(this, args);
            }
            return instrumentation_1.safeExecuteInTheMiddle(() => {
              return original.apply(this, args);
            }, (err) => {
              if (!err && maybeError instanceof Error) {
                err = maybeError;
              }
              utils_1.endSpan(this, err);
            });
          };
        };
      }
      _hookPreHandler() {
        const instrumentation = this;
        return function preHandler(request, reply, done) {
          var _a;
          if (!instrumentation.isEnabled()) {
            return done();
          }
          const requestContext = request.context || {};
          const handlerName = (((_a = requestContext.handler) === null || _a === void 0 ? void 0 : _a.name) || "").substr(6);
          const spanName = `${AttributeNames_1.FastifyNames.REQUEST_HANDLER} - ${handlerName || exports2.ANONYMOUS_NAME}`;
          const spanAttributes = {
            [AttributeNames_1.AttributeNames.PLUGIN_NAME]: this.pluginName,
            [AttributeNames_1.AttributeNames.FASTIFY_TYPE]: AttributeNames_1.FastifyTypes.REQUEST_HANDLER,
            [semantic_conventions_1.SemanticAttributes.HTTP_ROUTE]: request.routerPath
          };
          if (handlerName) {
            spanAttributes[AttributeNames_1.AttributeNames.FASTIFY_NAME] = handlerName;
          }
          const span = utils_1.startSpan(reply, instrumentation.tracer, spanName, spanAttributes);
          return api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => {
            done();
          });
        };
      }
    };
    exports2.FastifyInstrumentation = FastifyInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/index.js
var require_src33 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-fastify/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_AttributeNames9(), exports2);
    __exportStar(require_instrumentation15(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-aws-xray/build/src/AWSXRayPropagator.js
var require_AWSXRayPropagator = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-aws-xray/build/src/AWSXRayPropagator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AWSXRayPropagator = exports2.AWSXRAY_TRACE_ID_HEADER = void 0;
    var api_1 = require_src();
    exports2.AWSXRAY_TRACE_ID_HEADER = "x-amzn-trace-id";
    var TRACE_HEADER_DELIMITER = ";";
    var KV_DELIMITER = "=";
    var TRACE_ID_KEY = "Root";
    var TRACE_ID_LENGTH = 35;
    var TRACE_ID_VERSION = "1";
    var TRACE_ID_DELIMITER = "-";
    var TRACE_ID_DELIMITER_INDEX_1 = 1;
    var TRACE_ID_DELIMITER_INDEX_2 = 10;
    var TRACE_ID_FIRST_PART_LENGTH = 8;
    var PARENT_ID_KEY = "Parent";
    var SAMPLED_FLAG_KEY = "Sampled";
    var IS_SAMPLED = "1";
    var NOT_SAMPLED = "0";
    var AWSXRayPropagator = class {
      inject(context, carrier, setter) {
        var _a;
        const spanContext = (_a = api_1.trace.getSpan(context)) === null || _a === void 0 ? void 0 : _a.spanContext();
        if (!spanContext || !api_1.isSpanContextValid(spanContext))
          return;
        const otTraceId = spanContext.traceId;
        const timestamp = otTraceId.substring(0, TRACE_ID_FIRST_PART_LENGTH);
        const randomNumber = otTraceId.substring(TRACE_ID_FIRST_PART_LENGTH);
        const parentId = spanContext.spanId;
        const samplingFlag = (api_1.TraceFlags.SAMPLED & spanContext.traceFlags) === api_1.TraceFlags.SAMPLED ? IS_SAMPLED : NOT_SAMPLED;
        const traceHeader = `Root=1-${timestamp}-${randomNumber};Parent=${parentId};Sampled=${samplingFlag}`;
        setter.set(carrier, exports2.AWSXRAY_TRACE_ID_HEADER, traceHeader);
      }
      extract(context, carrier, getter) {
        const spanContext = this.getSpanContextFromHeader(carrier, getter);
        if (!api_1.isSpanContextValid(spanContext))
          return context;
        return api_1.trace.setSpan(context, api_1.trace.wrapSpanContext(spanContext));
      }
      fields() {
        return [exports2.AWSXRAY_TRACE_ID_HEADER];
      }
      getSpanContextFromHeader(carrier, getter) {
        const traceHeader = getter.get(carrier, exports2.AWSXRAY_TRACE_ID_HEADER);
        if (!traceHeader || typeof traceHeader !== "string")
          return api_1.INVALID_SPAN_CONTEXT;
        let pos = 0;
        let trimmedPart;
        let parsedTraceId = api_1.INVALID_TRACEID;
        let parsedSpanId = api_1.INVALID_SPANID;
        let parsedTraceFlags = null;
        while (pos < traceHeader.length) {
          const delimiterIndex = traceHeader.indexOf(TRACE_HEADER_DELIMITER, pos);
          if (delimiterIndex >= 0) {
            trimmedPart = traceHeader.substring(pos, delimiterIndex).trim();
            pos = delimiterIndex + 1;
          } else {
            trimmedPart = traceHeader.substring(pos).trim();
            pos = traceHeader.length;
          }
          const equalsIndex = trimmedPart.indexOf(KV_DELIMITER);
          const value = trimmedPart.substring(equalsIndex + 1);
          if (trimmedPart.startsWith(TRACE_ID_KEY)) {
            parsedTraceId = AWSXRayPropagator._parseTraceId(value);
          } else if (trimmedPart.startsWith(PARENT_ID_KEY)) {
            parsedSpanId = AWSXRayPropagator._parseSpanId(value);
          } else if (trimmedPart.startsWith(SAMPLED_FLAG_KEY)) {
            parsedTraceFlags = AWSXRayPropagator._parseTraceFlag(value);
          }
        }
        if (parsedTraceFlags === null) {
          return api_1.INVALID_SPAN_CONTEXT;
        }
        const resultSpanContext = {
          traceId: parsedTraceId,
          spanId: parsedSpanId,
          traceFlags: parsedTraceFlags,
          isRemote: true
        };
        if (!api_1.isSpanContextValid(resultSpanContext)) {
          return api_1.INVALID_SPAN_CONTEXT;
        }
        return resultSpanContext;
      }
      static _parseTraceId(xrayTraceId) {
        if (xrayTraceId.length !== TRACE_ID_LENGTH) {
          return api_1.INVALID_TRACEID;
        }
        if (!xrayTraceId.startsWith(TRACE_ID_VERSION)) {
          return api_1.INVALID_TRACEID;
        }
        if (xrayTraceId.charAt(TRACE_ID_DELIMITER_INDEX_1) !== TRACE_ID_DELIMITER || xrayTraceId.charAt(TRACE_ID_DELIMITER_INDEX_2) !== TRACE_ID_DELIMITER) {
          return api_1.INVALID_TRACEID;
        }
        const epochPart = xrayTraceId.substring(TRACE_ID_DELIMITER_INDEX_1 + 1, TRACE_ID_DELIMITER_INDEX_2);
        const uniquePart = xrayTraceId.substring(TRACE_ID_DELIMITER_INDEX_2 + 1, TRACE_ID_LENGTH);
        const resTraceId = epochPart + uniquePart;
        if (!api_1.isValidTraceId(resTraceId)) {
          return api_1.INVALID_TRACEID;
        }
        return resTraceId;
      }
      static _parseSpanId(xrayParentId) {
        return api_1.isValidSpanId(xrayParentId) ? xrayParentId : api_1.INVALID_SPANID;
      }
      static _parseTraceFlag(xraySampledFlag) {
        if (xraySampledFlag === NOT_SAMPLED) {
          return api_1.TraceFlags.NONE;
        }
        if (xraySampledFlag === IS_SAMPLED) {
          return api_1.TraceFlags.SAMPLED;
        }
        return null;
      }
    };
    exports2.AWSXRayPropagator = AWSXRayPropagator;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-aws-xray/build/src/index.js
var require_src34 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/propagator-aws-xray/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_AWSXRayPropagator(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-lambda/build/src/version.js
var require_version19 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-lambda/build/src/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.28.1";
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-lambda/build/src/instrumentation.js
var require_instrumentation16 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-lambda/build/src/instrumentation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AwsLambdaInstrumentation = exports2.traceContextEnvironmentKey = void 0;
    var path = require("path");
    var instrumentation_1 = require_src13();
    var api_1 = require_src();
    var propagator_aws_xray_1 = require_src34();
    var semantic_conventions_1 = require_src3();
    var version_1 = require_version19();
    var awsPropagator = new propagator_aws_xray_1.AWSXRayPropagator();
    var headerGetter = {
      keys(carrier) {
        return Object.keys(carrier);
      },
      get(carrier, key) {
        return carrier[key];
      }
    };
    exports2.traceContextEnvironmentKey = "_X_AMZN_TRACE_ID";
    var AwsLambdaInstrumentation2 = class extends instrumentation_1.InstrumentationBase {
      constructor(_config = {}) {
        super("@opentelemetry/instrumentation-aws-lambda", version_1.VERSION, _config);
        this._config = _config;
      }
      setConfig(config = {}) {
        this._config = config;
      }
      init() {
        const taskRoot = process.env.LAMBDA_TASK_ROOT;
        const handlerDef = process.env._HANDLER;
        if (!taskRoot || !handlerDef) {
          return [];
        }
        const handler = path.basename(handlerDef);
        const moduleRoot = handlerDef.substr(0, handlerDef.length - handler.length);
        const [module3, functionName] = handler.split(".", 2);
        let filename = path.resolve(taskRoot, moduleRoot, module3);
        if (!filename.endsWith(".js")) {
          filename += ".js";
        }
        return [
          new instrumentation_1.InstrumentationNodeModuleDefinition(filename, ["*"], void 0, void 0, [
            new instrumentation_1.InstrumentationNodeModuleFile(module3, ["*"], (moduleExports) => {
              api_1.diag.debug("Applying patch for lambda handler");
              if (instrumentation_1.isWrapped(moduleExports[functionName])) {
                this._unwrap(moduleExports, functionName);
              }
              this._wrap(moduleExports, functionName, this._getHandler());
              return moduleExports;
            }, (moduleExports) => {
              if (moduleExports == void 0)
                return;
              api_1.diag.debug("Removing patch for lambda handler");
              this._unwrap(moduleExports, functionName);
            })
          ])
        ];
      }
      _getHandler() {
        return (original) => {
          return this._getPatchHandler(original);
        };
      }
      _getPatchHandler(original) {
        api_1.diag.debug("patch handler function");
        const plugin = this;
        return function patchedHandler(event, context, callback) {
          const config = plugin._config;
          const parent = AwsLambdaInstrumentation2._determineParent(event, config.disableAwsContextPropagation === true, config.eventContextExtractor || AwsLambdaInstrumentation2._defaultEventContextExtractor);
          const name = context.functionName;
          const span = plugin.tracer.startSpan(name, {
            kind: api_1.SpanKind.SERVER,
            attributes: {
              [semantic_conventions_1.SemanticAttributes.FAAS_EXECUTION]: context.awsRequestId,
              [semantic_conventions_1.SemanticResourceAttributes.FAAS_ID]: context.invokedFunctionArn,
              [semantic_conventions_1.SemanticResourceAttributes.CLOUD_ACCOUNT_ID]: AwsLambdaInstrumentation2._extractAccountId(context.invokedFunctionArn)
            }
          }, parent);
          if (config.requestHook) {
            instrumentation_1.safeExecuteInTheMiddle(() => config.requestHook(span, { event, context }), (e) => {
              if (e)
                api_1.diag.error("aws-lambda instrumentation: requestHook error", e);
            }, true);
          }
          return api_1.context.with(api_1.trace.setSpan(api_1.context.active(), span), () => {
            const wrappedCallback = plugin._wrapCallback(callback, span);
            const maybePromise = instrumentation_1.safeExecuteInTheMiddle(() => original.apply(this, [event, context, wrappedCallback]), (error) => {
              if (error != null) {
                plugin._applyResponseHook(span, error);
                plugin._endSpan(span, error, () => {
                });
              }
            });
            if (typeof (maybePromise === null || maybePromise === void 0 ? void 0 : maybePromise.then) === "function") {
              return maybePromise.then((value) => {
                plugin._applyResponseHook(span, null, value);
                return new Promise((resolve) => plugin._endSpan(span, void 0, () => resolve(value)));
              }, (err) => {
                plugin._applyResponseHook(span, err);
                return new Promise((resolve, reject) => plugin._endSpan(span, err, () => reject(err)));
              });
            }
            return maybePromise;
          });
        };
      }
      setTracerProvider(tracerProvider2) {
        super.setTracerProvider(tracerProvider2);
        this._forceFlush = this._getForceFlush(tracerProvider2);
      }
      _getForceFlush(tracerProvider2) {
        if (!tracerProvider2)
          return void 0;
        let currentProvider = tracerProvider2;
        if (typeof currentProvider.getDelegate === "function") {
          currentProvider = currentProvider.getDelegate();
        }
        if (typeof currentProvider.forceFlush === "function") {
          return currentProvider.forceFlush.bind(currentProvider);
        }
        return void 0;
      }
      _wrapCallback(original, span) {
        const plugin = this;
        return function wrappedCallback(err, res) {
          api_1.diag.debug("executing wrapped lookup callback function");
          plugin._applyResponseHook(span, err, res);
          plugin._endSpan(span, err, () => {
            api_1.diag.debug("executing original lookup callback function");
            return original.apply(this, [err, res]);
          });
        };
      }
      _endSpan(span, err, callback) {
        if (err) {
          span.recordException(err);
        }
        let errMessage;
        if (typeof err === "string") {
          errMessage = err;
        } else if (err) {
          errMessage = err.message;
        }
        if (errMessage) {
          span.setStatus({
            code: api_1.SpanStatusCode.ERROR,
            message: errMessage
          });
        }
        span.end();
        if (this._forceFlush) {
          this._forceFlush().then(() => callback(), () => callback());
        } else {
          api_1.diag.error("Spans may not be exported for the lambda function because we are not force flushing before callback.");
          callback();
        }
      }
      _applyResponseHook(span, err, res) {
        var _a;
        if ((_a = this._config) === null || _a === void 0 ? void 0 : _a.responseHook) {
          instrumentation_1.safeExecuteInTheMiddle(() => this._config.responseHook(span, { err, res }), (e) => {
            if (e)
              api_1.diag.error("aws-lambda instrumentation: responseHook error", e);
          }, true);
        }
      }
      static _extractAccountId(arn) {
        const parts = arn.split(":");
        if (parts.length >= 5) {
          return parts[4];
        }
        return void 0;
      }
      static _defaultEventContextExtractor(event) {
        const httpHeaders = event.headers || {};
        return api_1.propagation.extract(api_1.context.active(), httpHeaders, headerGetter);
      }
      static _determineParent(event, disableAwsContextPropagation, eventContextExtractor) {
        var _a, _b;
        let parent = void 0;
        if (!disableAwsContextPropagation) {
          const lambdaTraceHeader = process.env[exports2.traceContextEnvironmentKey];
          if (lambdaTraceHeader) {
            parent = awsPropagator.extract(api_1.context.active(), { [propagator_aws_xray_1.AWSXRAY_TRACE_ID_HEADER]: lambdaTraceHeader }, headerGetter);
          }
          if (parent) {
            const spanContext = (_a = api_1.trace.getSpan(parent)) === null || _a === void 0 ? void 0 : _a.spanContext();
            if (spanContext && (spanContext.traceFlags & api_1.TraceFlags.SAMPLED) === api_1.TraceFlags.SAMPLED) {
              return parent;
            }
          }
        }
        const extractedContext = instrumentation_1.safeExecuteInTheMiddle(() => eventContextExtractor(event), (e) => {
          if (e)
            api_1.diag.error("aws-lambda instrumentation: eventContextExtractor error", e);
        }, true);
        if ((_b = api_1.trace.getSpan(extractedContext)) === null || _b === void 0 ? void 0 : _b.spanContext()) {
          return extractedContext;
        }
        if (!parent) {
          return api_1.ROOT_CONTEXT;
        }
        return parent;
      }
    };
    exports2.AwsLambdaInstrumentation = AwsLambdaInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-lambda/build/src/index.js
var require_src35 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/@opentelemetry/instrumentation-aws-lambda/build/src/index.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      Object.defineProperty(o, k2, { enumerable: true, get: function() {
        return m[k];
      } });
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports2 && exports2.__exportStar || function(m, exports3) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports3, p))
          __createBinding(exports3, m, p);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    __exportStar(require_instrumentation16(), exports2);
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/aws-lambda-instrumentation.js
var require_aws_lambda_instrumentation = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/aws-lambda-instrumentation.js"(exports2, module2) {
    "use strict";
    var { AwsLambdaInstrumentation: AwsLambdaInstrumentation2 } = require_src35();
    AwsLambdaInstrumentation2.prototype.init = function() {
      if (AwsLambdaInstrumentation2._instance) {
        throw new Error("Unexpected doubled initialization");
      }
      AwsLambdaInstrumentation2._instance = this;
      return Array(1);
    };
    AwsLambdaInstrumentation2.prototype.enable = function() {
      this._modules = [];
      delete AwsLambdaInstrumentation2.prototype.enable;
      return this.enable();
    };
    module2.exports = AwsLambdaInstrumentation2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/lodash.clone/index.js
var require_lodash = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/lodash.clone/index.js"(exports2, module2) {
    var LARGE_ARRAY_SIZE = 200;
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    var MAX_SAFE_INTEGER = 9007199254740991;
    var argsTag = "[object Arguments]";
    var arrayTag = "[object Array]";
    var boolTag = "[object Boolean]";
    var dateTag = "[object Date]";
    var errorTag = "[object Error]";
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var mapTag = "[object Map]";
    var numberTag = "[object Number]";
    var objectTag = "[object Object]";
    var promiseTag = "[object Promise]";
    var regexpTag = "[object RegExp]";
    var setTag = "[object Set]";
    var stringTag = "[object String]";
    var symbolTag = "[object Symbol]";
    var weakMapTag = "[object WeakMap]";
    var arrayBufferTag = "[object ArrayBuffer]";
    var dataViewTag = "[object DataView]";
    var float32Tag = "[object Float32Array]";
    var float64Tag = "[object Float64Array]";
    var int8Tag = "[object Int8Array]";
    var int16Tag = "[object Int16Array]";
    var int32Tag = "[object Int32Array]";
    var uint8Tag = "[object Uint8Array]";
    var uint8ClampedTag = "[object Uint8ClampedArray]";
    var uint16Tag = "[object Uint16Array]";
    var uint32Tag = "[object Uint32Array]";
    var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
    var reFlags = /\w*$/;
    var reIsHostCtor = /^\[object .+?Constructor\]$/;
    var reIsUint = /^(?:0|[1-9]\d*)$/;
    var cloneableTags = {};
    cloneableTags[argsTag] = cloneableTags[arrayTag] = cloneableTags[arrayBufferTag] = cloneableTags[dataViewTag] = cloneableTags[boolTag] = cloneableTags[dateTag] = cloneableTags[float32Tag] = cloneableTags[float64Tag] = cloneableTags[int8Tag] = cloneableTags[int16Tag] = cloneableTags[int32Tag] = cloneableTags[mapTag] = cloneableTags[numberTag] = cloneableTags[objectTag] = cloneableTags[regexpTag] = cloneableTags[setTag] = cloneableTags[stringTag] = cloneableTags[symbolTag] = cloneableTags[uint8Tag] = cloneableTags[uint8ClampedTag] = cloneableTags[uint16Tag] = cloneableTags[uint32Tag] = true;
    cloneableTags[errorTag] = cloneableTags[funcTag] = cloneableTags[weakMapTag] = false;
    var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
    var freeSelf = typeof self == "object" && self && self.Object === Object && self;
    var root = freeGlobal || freeSelf || Function("return this")();
    var freeExports = typeof exports2 == "object" && exports2 && !exports2.nodeType && exports2;
    var freeModule = freeExports && typeof module2 == "object" && module2 && !module2.nodeType && module2;
    var moduleExports = freeModule && freeModule.exports === freeExports;
    function addMapEntry(map, pair) {
      map.set(pair[0], pair[1]);
      return map;
    }
    function addSetEntry(set, value) {
      set.add(value);
      return set;
    }
    function arrayEach(array, iteratee) {
      var index = -1, length = array ? array.length : 0;
      while (++index < length) {
        if (iteratee(array[index], index, array) === false) {
          break;
        }
      }
      return array;
    }
    function arrayPush(array, values) {
      var index = -1, length = values.length, offset = array.length;
      while (++index < length) {
        array[offset + index] = values[index];
      }
      return array;
    }
    function arrayReduce(array, iteratee, accumulator, initAccum) {
      var index = -1, length = array ? array.length : 0;
      if (initAccum && length) {
        accumulator = array[++index];
      }
      while (++index < length) {
        accumulator = iteratee(accumulator, array[index], index, array);
      }
      return accumulator;
    }
    function baseTimes(n, iteratee) {
      var index = -1, result = Array(n);
      while (++index < n) {
        result[index] = iteratee(index);
      }
      return result;
    }
    function getValue(object, key) {
      return object == null ? void 0 : object[key];
    }
    function isHostObject(value) {
      var result = false;
      if (value != null && typeof value.toString != "function") {
        try {
          result = !!(value + "");
        } catch (e) {
        }
      }
      return result;
    }
    function mapToArray(map) {
      var index = -1, result = Array(map.size);
      map.forEach(function(value, key) {
        result[++index] = [key, value];
      });
      return result;
    }
    function overArg(func, transform) {
      return function(arg) {
        return func(transform(arg));
      };
    }
    function setToArray(set) {
      var index = -1, result = Array(set.size);
      set.forEach(function(value) {
        result[++index] = value;
      });
      return result;
    }
    var arrayProto = Array.prototype;
    var funcProto = Function.prototype;
    var objectProto = Object.prototype;
    var coreJsData = root["__core-js_shared__"];
    var maskSrcKey = function() {
      var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
      return uid ? "Symbol(src)_1." + uid : "";
    }();
    var funcToString = funcProto.toString;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var objectToString = objectProto.toString;
    var reIsNative = RegExp("^" + funcToString.call(hasOwnProperty).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
    var Buffer2 = moduleExports ? root.Buffer : void 0;
    var Symbol2 = root.Symbol;
    var Uint8Array2 = root.Uint8Array;
    var getPrototype = overArg(Object.getPrototypeOf, Object);
    var objectCreate = Object.create;
    var propertyIsEnumerable = objectProto.propertyIsEnumerable;
    var splice = arrayProto.splice;
    var nativeGetSymbols = Object.getOwnPropertySymbols;
    var nativeIsBuffer = Buffer2 ? Buffer2.isBuffer : void 0;
    var nativeKeys = overArg(Object.keys, Object);
    var DataView = getNative(root, "DataView");
    var Map2 = getNative(root, "Map");
    var Promise2 = getNative(root, "Promise");
    var Set2 = getNative(root, "Set");
    var WeakMap2 = getNative(root, "WeakMap");
    var nativeCreate = getNative(Object, "create");
    var dataViewCtorString = toSource(DataView);
    var mapCtorString = toSource(Map2);
    var promiseCtorString = toSource(Promise2);
    var setCtorString = toSource(Set2);
    var weakMapCtorString = toSource(WeakMap2);
    var symbolProto = Symbol2 ? Symbol2.prototype : void 0;
    var symbolValueOf = symbolProto ? symbolProto.valueOf : void 0;
    function Hash(entries) {
      var index = -1, length = entries ? entries.length : 0;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function hashClear() {
      this.__data__ = nativeCreate ? nativeCreate(null) : {};
    }
    function hashDelete(key) {
      return this.has(key) && delete this.__data__[key];
    }
    function hashGet(key) {
      var data = this.__data__;
      if (nativeCreate) {
        var result = data[key];
        return result === HASH_UNDEFINED ? void 0 : result;
      }
      return hasOwnProperty.call(data, key) ? data[key] : void 0;
    }
    function hashHas(key) {
      var data = this.__data__;
      return nativeCreate ? data[key] !== void 0 : hasOwnProperty.call(data, key);
    }
    function hashSet(key, value) {
      var data = this.__data__;
      data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED : value;
      return this;
    }
    Hash.prototype.clear = hashClear;
    Hash.prototype["delete"] = hashDelete;
    Hash.prototype.get = hashGet;
    Hash.prototype.has = hashHas;
    Hash.prototype.set = hashSet;
    function ListCache(entries) {
      var index = -1, length = entries ? entries.length : 0;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function listCacheClear() {
      this.__data__ = [];
    }
    function listCacheDelete(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        return false;
      }
      var lastIndex = data.length - 1;
      if (index == lastIndex) {
        data.pop();
      } else {
        splice.call(data, index, 1);
      }
      return true;
    }
    function listCacheGet(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      return index < 0 ? void 0 : data[index][1];
    }
    function listCacheHas(key) {
      return assocIndexOf(this.__data__, key) > -1;
    }
    function listCacheSet(key, value) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        data.push([key, value]);
      } else {
        data[index][1] = value;
      }
      return this;
    }
    ListCache.prototype.clear = listCacheClear;
    ListCache.prototype["delete"] = listCacheDelete;
    ListCache.prototype.get = listCacheGet;
    ListCache.prototype.has = listCacheHas;
    ListCache.prototype.set = listCacheSet;
    function MapCache(entries) {
      var index = -1, length = entries ? entries.length : 0;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function mapCacheClear() {
      this.__data__ = {
        "hash": new Hash(),
        "map": new (Map2 || ListCache)(),
        "string": new Hash()
      };
    }
    function mapCacheDelete(key) {
      return getMapData(this, key)["delete"](key);
    }
    function mapCacheGet(key) {
      return getMapData(this, key).get(key);
    }
    function mapCacheHas(key) {
      return getMapData(this, key).has(key);
    }
    function mapCacheSet(key, value) {
      getMapData(this, key).set(key, value);
      return this;
    }
    MapCache.prototype.clear = mapCacheClear;
    MapCache.prototype["delete"] = mapCacheDelete;
    MapCache.prototype.get = mapCacheGet;
    MapCache.prototype.has = mapCacheHas;
    MapCache.prototype.set = mapCacheSet;
    function Stack(entries) {
      this.__data__ = new ListCache(entries);
    }
    function stackClear() {
      this.__data__ = new ListCache();
    }
    function stackDelete(key) {
      return this.__data__["delete"](key);
    }
    function stackGet(key) {
      return this.__data__.get(key);
    }
    function stackHas(key) {
      return this.__data__.has(key);
    }
    function stackSet(key, value) {
      var cache = this.__data__;
      if (cache instanceof ListCache) {
        var pairs = cache.__data__;
        if (!Map2 || pairs.length < LARGE_ARRAY_SIZE - 1) {
          pairs.push([key, value]);
          return this;
        }
        cache = this.__data__ = new MapCache(pairs);
      }
      cache.set(key, value);
      return this;
    }
    Stack.prototype.clear = stackClear;
    Stack.prototype["delete"] = stackDelete;
    Stack.prototype.get = stackGet;
    Stack.prototype.has = stackHas;
    Stack.prototype.set = stackSet;
    function arrayLikeKeys(value, inherited) {
      var result = isArray(value) || isArguments(value) ? baseTimes(value.length, String) : [];
      var length = result.length, skipIndexes = !!length;
      for (var key in value) {
        if ((inherited || hasOwnProperty.call(value, key)) && !(skipIndexes && (key == "length" || isIndex(key, length)))) {
          result.push(key);
        }
      }
      return result;
    }
    function assignValue(object, key, value) {
      var objValue = object[key];
      if (!(hasOwnProperty.call(object, key) && eq(objValue, value)) || value === void 0 && !(key in object)) {
        object[key] = value;
      }
    }
    function assocIndexOf(array, key) {
      var length = array.length;
      while (length--) {
        if (eq(array[length][0], key)) {
          return length;
        }
      }
      return -1;
    }
    function baseAssign(object, source) {
      return object && copyObject(source, keys(source), object);
    }
    function baseClone(value, isDeep, isFull, customizer, key, object, stack) {
      var result;
      if (customizer) {
        result = object ? customizer(value, key, object, stack) : customizer(value);
      }
      if (result !== void 0) {
        return result;
      }
      if (!isObject(value)) {
        return value;
      }
      var isArr = isArray(value);
      if (isArr) {
        result = initCloneArray(value);
        if (!isDeep) {
          return copyArray(value, result);
        }
      } else {
        var tag = getTag(value), isFunc = tag == funcTag || tag == genTag;
        if (isBuffer(value)) {
          return cloneBuffer(value, isDeep);
        }
        if (tag == objectTag || tag == argsTag || isFunc && !object) {
          if (isHostObject(value)) {
            return object ? value : {};
          }
          result = initCloneObject(isFunc ? {} : value);
          if (!isDeep) {
            return copySymbols(value, baseAssign(result, value));
          }
        } else {
          if (!cloneableTags[tag]) {
            return object ? value : {};
          }
          result = initCloneByTag(value, tag, baseClone, isDeep);
        }
      }
      stack || (stack = new Stack());
      var stacked = stack.get(value);
      if (stacked) {
        return stacked;
      }
      stack.set(value, result);
      if (!isArr) {
        var props = isFull ? getAllKeys(value) : keys(value);
      }
      arrayEach(props || value, function(subValue, key2) {
        if (props) {
          key2 = subValue;
          subValue = value[key2];
        }
        assignValue(result, key2, baseClone(subValue, isDeep, isFull, customizer, key2, value, stack));
      });
      return result;
    }
    function baseCreate(proto) {
      return isObject(proto) ? objectCreate(proto) : {};
    }
    function baseGetAllKeys(object, keysFunc, symbolsFunc) {
      var result = keysFunc(object);
      return isArray(object) ? result : arrayPush(result, symbolsFunc(object));
    }
    function baseGetTag(value) {
      return objectToString.call(value);
    }
    function baseIsNative(value) {
      if (!isObject(value) || isMasked(value)) {
        return false;
      }
      var pattern = isFunction(value) || isHostObject(value) ? reIsNative : reIsHostCtor;
      return pattern.test(toSource(value));
    }
    function baseKeys(object) {
      if (!isPrototype(object)) {
        return nativeKeys(object);
      }
      var result = [];
      for (var key in Object(object)) {
        if (hasOwnProperty.call(object, key) && key != "constructor") {
          result.push(key);
        }
      }
      return result;
    }
    function cloneBuffer(buffer, isDeep) {
      if (isDeep) {
        return buffer.slice();
      }
      var result = new buffer.constructor(buffer.length);
      buffer.copy(result);
      return result;
    }
    function cloneArrayBuffer(arrayBuffer) {
      var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
      new Uint8Array2(result).set(new Uint8Array2(arrayBuffer));
      return result;
    }
    function cloneDataView(dataView, isDeep) {
      var buffer = isDeep ? cloneArrayBuffer(dataView.buffer) : dataView.buffer;
      return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
    }
    function cloneMap(map, isDeep, cloneFunc) {
      var array = isDeep ? cloneFunc(mapToArray(map), true) : mapToArray(map);
      return arrayReduce(array, addMapEntry, new map.constructor());
    }
    function cloneRegExp(regexp) {
      var result = new regexp.constructor(regexp.source, reFlags.exec(regexp));
      result.lastIndex = regexp.lastIndex;
      return result;
    }
    function cloneSet(set, isDeep, cloneFunc) {
      var array = isDeep ? cloneFunc(setToArray(set), true) : setToArray(set);
      return arrayReduce(array, addSetEntry, new set.constructor());
    }
    function cloneSymbol(symbol) {
      return symbolValueOf ? Object(symbolValueOf.call(symbol)) : {};
    }
    function cloneTypedArray(typedArray, isDeep) {
      var buffer = isDeep ? cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
      return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
    }
    function copyArray(source, array) {
      var index = -1, length = source.length;
      array || (array = Array(length));
      while (++index < length) {
        array[index] = source[index];
      }
      return array;
    }
    function copyObject(source, props, object, customizer) {
      object || (object = {});
      var index = -1, length = props.length;
      while (++index < length) {
        var key = props[index];
        var newValue = customizer ? customizer(object[key], source[key], key, object, source) : void 0;
        assignValue(object, key, newValue === void 0 ? source[key] : newValue);
      }
      return object;
    }
    function copySymbols(source, object) {
      return copyObject(source, getSymbols(source), object);
    }
    function getAllKeys(object) {
      return baseGetAllKeys(object, keys, getSymbols);
    }
    function getMapData(map, key) {
      var data = map.__data__;
      return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
    }
    function getNative(object, key) {
      var value = getValue(object, key);
      return baseIsNative(value) ? value : void 0;
    }
    var getSymbols = nativeGetSymbols ? overArg(nativeGetSymbols, Object) : stubArray;
    var getTag = baseGetTag;
    if (DataView && getTag(new DataView(new ArrayBuffer(1))) != dataViewTag || Map2 && getTag(new Map2()) != mapTag || Promise2 && getTag(Promise2.resolve()) != promiseTag || Set2 && getTag(new Set2()) != setTag || WeakMap2 && getTag(new WeakMap2()) != weakMapTag) {
      getTag = function(value) {
        var result = objectToString.call(value), Ctor = result == objectTag ? value.constructor : void 0, ctorString = Ctor ? toSource(Ctor) : void 0;
        if (ctorString) {
          switch (ctorString) {
            case dataViewCtorString:
              return dataViewTag;
            case mapCtorString:
              return mapTag;
            case promiseCtorString:
              return promiseTag;
            case setCtorString:
              return setTag;
            case weakMapCtorString:
              return weakMapTag;
          }
        }
        return result;
      };
    }
    function initCloneArray(array) {
      var length = array.length, result = array.constructor(length);
      if (length && typeof array[0] == "string" && hasOwnProperty.call(array, "index")) {
        result.index = array.index;
        result.input = array.input;
      }
      return result;
    }
    function initCloneObject(object) {
      return typeof object.constructor == "function" && !isPrototype(object) ? baseCreate(getPrototype(object)) : {};
    }
    function initCloneByTag(object, tag, cloneFunc, isDeep) {
      var Ctor = object.constructor;
      switch (tag) {
        case arrayBufferTag:
          return cloneArrayBuffer(object);
        case boolTag:
        case dateTag:
          return new Ctor(+object);
        case dataViewTag:
          return cloneDataView(object, isDeep);
        case float32Tag:
        case float64Tag:
        case int8Tag:
        case int16Tag:
        case int32Tag:
        case uint8Tag:
        case uint8ClampedTag:
        case uint16Tag:
        case uint32Tag:
          return cloneTypedArray(object, isDeep);
        case mapTag:
          return cloneMap(object, isDeep, cloneFunc);
        case numberTag:
        case stringTag:
          return new Ctor(object);
        case regexpTag:
          return cloneRegExp(object);
        case setTag:
          return cloneSet(object, isDeep, cloneFunc);
        case symbolTag:
          return cloneSymbol(object);
      }
    }
    function isIndex(value, length) {
      length = length == null ? MAX_SAFE_INTEGER : length;
      return !!length && (typeof value == "number" || reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
    }
    function isKeyable(value) {
      var type = typeof value;
      return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
    }
    function isMasked(func) {
      return !!maskSrcKey && maskSrcKey in func;
    }
    function isPrototype(value) {
      var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto;
      return value === proto;
    }
    function toSource(func) {
      if (func != null) {
        try {
          return funcToString.call(func);
        } catch (e) {
        }
        try {
          return func + "";
        } catch (e) {
        }
      }
      return "";
    }
    function clone(value) {
      return baseClone(value, false, true);
    }
    function eq(value, other) {
      return value === other || value !== value && other !== other;
    }
    function isArguments(value) {
      return isArrayLikeObject(value) && hasOwnProperty.call(value, "callee") && (!propertyIsEnumerable.call(value, "callee") || objectToString.call(value) == argsTag);
    }
    var isArray = Array.isArray;
    function isArrayLike(value) {
      return value != null && isLength(value.length) && !isFunction(value);
    }
    function isArrayLikeObject(value) {
      return isObjectLike(value) && isArrayLike(value);
    }
    var isBuffer = nativeIsBuffer || stubFalse;
    function isFunction(value) {
      var tag = isObject(value) ? objectToString.call(value) : "";
      return tag == funcTag || tag == genTag;
    }
    function isLength(value) {
      return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
    }
    function isObject(value) {
      var type = typeof value;
      return !!value && (type == "object" || type == "function");
    }
    function isObjectLike(value) {
      return !!value && typeof value == "object";
    }
    function keys(object) {
      return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
    }
    function stubArray() {
      return [];
    }
    function stubFalse() {
      return false;
    }
    module2.exports = clone;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/span-processor.js
var require_span_processor = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/span-processor.js"(exports2, module2) {
    "use strict";
    var { SimpleSpanProcessor } = require_src7();
    var clone = require_lodash();
    var SlsSpanProcessor2 = class extends SimpleSpanProcessor {
      constructor(...args) {
        super(...args);
        this.incompleteSpans = {};
      }
      onStart(span) {
        this.incompleteSpans[span.name] = span;
      }
      onEnd(span) {
        delete this.incompleteSpans[span.name];
        super.onEnd(span);
      }
      finishAllSpans() {
        Object.keys(this.incompleteSpans).forEach((id) => {
          const span = clone(this.incompleteSpans[id]);
          span.end();
          this.onEnd(span);
        });
      }
    };
    module2.exports = SlsSpanProcessor2;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/lodash.get/index.js
var require_lodash2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/node_modules/lodash.get/index.js"(exports2, module2) {
    var FUNC_ERROR_TEXT = "Expected a function";
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    var INFINITY = 1 / 0;
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var symbolTag = "[object Symbol]";
    var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
    var reIsPlainProp = /^\w*$/;
    var reLeadingDot = /^\./;
    var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
    var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
    var reEscapeChar = /\\(\\)?/g;
    var reIsHostCtor = /^\[object .+?Constructor\]$/;
    var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
    var freeSelf = typeof self == "object" && self && self.Object === Object && self;
    var root = freeGlobal || freeSelf || Function("return this")();
    function getValue(object, key) {
      return object == null ? void 0 : object[key];
    }
    function isHostObject(value) {
      var result = false;
      if (value != null && typeof value.toString != "function") {
        try {
          result = !!(value + "");
        } catch (e) {
        }
      }
      return result;
    }
    var arrayProto = Array.prototype;
    var funcProto = Function.prototype;
    var objectProto = Object.prototype;
    var coreJsData = root["__core-js_shared__"];
    var maskSrcKey = function() {
      var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
      return uid ? "Symbol(src)_1." + uid : "";
    }();
    var funcToString = funcProto.toString;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var objectToString = objectProto.toString;
    var reIsNative = RegExp("^" + funcToString.call(hasOwnProperty).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
    var Symbol2 = root.Symbol;
    var splice = arrayProto.splice;
    var Map2 = getNative(root, "Map");
    var nativeCreate = getNative(Object, "create");
    var symbolProto = Symbol2 ? Symbol2.prototype : void 0;
    var symbolToString = symbolProto ? symbolProto.toString : void 0;
    function Hash(entries) {
      var index = -1, length = entries ? entries.length : 0;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function hashClear() {
      this.__data__ = nativeCreate ? nativeCreate(null) : {};
    }
    function hashDelete(key) {
      return this.has(key) && delete this.__data__[key];
    }
    function hashGet(key) {
      var data = this.__data__;
      if (nativeCreate) {
        var result = data[key];
        return result === HASH_UNDEFINED ? void 0 : result;
      }
      return hasOwnProperty.call(data, key) ? data[key] : void 0;
    }
    function hashHas(key) {
      var data = this.__data__;
      return nativeCreate ? data[key] !== void 0 : hasOwnProperty.call(data, key);
    }
    function hashSet(key, value) {
      var data = this.__data__;
      data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED : value;
      return this;
    }
    Hash.prototype.clear = hashClear;
    Hash.prototype["delete"] = hashDelete;
    Hash.prototype.get = hashGet;
    Hash.prototype.has = hashHas;
    Hash.prototype.set = hashSet;
    function ListCache(entries) {
      var index = -1, length = entries ? entries.length : 0;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function listCacheClear() {
      this.__data__ = [];
    }
    function listCacheDelete(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        return false;
      }
      var lastIndex = data.length - 1;
      if (index == lastIndex) {
        data.pop();
      } else {
        splice.call(data, index, 1);
      }
      return true;
    }
    function listCacheGet(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      return index < 0 ? void 0 : data[index][1];
    }
    function listCacheHas(key) {
      return assocIndexOf(this.__data__, key) > -1;
    }
    function listCacheSet(key, value) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        data.push([key, value]);
      } else {
        data[index][1] = value;
      }
      return this;
    }
    ListCache.prototype.clear = listCacheClear;
    ListCache.prototype["delete"] = listCacheDelete;
    ListCache.prototype.get = listCacheGet;
    ListCache.prototype.has = listCacheHas;
    ListCache.prototype.set = listCacheSet;
    function MapCache(entries) {
      var index = -1, length = entries ? entries.length : 0;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function mapCacheClear() {
      this.__data__ = {
        "hash": new Hash(),
        "map": new (Map2 || ListCache)(),
        "string": new Hash()
      };
    }
    function mapCacheDelete(key) {
      return getMapData(this, key)["delete"](key);
    }
    function mapCacheGet(key) {
      return getMapData(this, key).get(key);
    }
    function mapCacheHas(key) {
      return getMapData(this, key).has(key);
    }
    function mapCacheSet(key, value) {
      getMapData(this, key).set(key, value);
      return this;
    }
    MapCache.prototype.clear = mapCacheClear;
    MapCache.prototype["delete"] = mapCacheDelete;
    MapCache.prototype.get = mapCacheGet;
    MapCache.prototype.has = mapCacheHas;
    MapCache.prototype.set = mapCacheSet;
    function assocIndexOf(array, key) {
      var length = array.length;
      while (length--) {
        if (eq(array[length][0], key)) {
          return length;
        }
      }
      return -1;
    }
    function baseGet(object, path) {
      path = isKey(path, object) ? [path] : castPath(path);
      var index = 0, length = path.length;
      while (object != null && index < length) {
        object = object[toKey(path[index++])];
      }
      return index && index == length ? object : void 0;
    }
    function baseIsNative(value) {
      if (!isObject(value) || isMasked(value)) {
        return false;
      }
      var pattern = isFunction(value) || isHostObject(value) ? reIsNative : reIsHostCtor;
      return pattern.test(toSource(value));
    }
    function baseToString(value) {
      if (typeof value == "string") {
        return value;
      }
      if (isSymbol(value)) {
        return symbolToString ? symbolToString.call(value) : "";
      }
      var result = value + "";
      return result == "0" && 1 / value == -INFINITY ? "-0" : result;
    }
    function castPath(value) {
      return isArray(value) ? value : stringToPath(value);
    }
    function getMapData(map, key) {
      var data = map.__data__;
      return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
    }
    function getNative(object, key) {
      var value = getValue(object, key);
      return baseIsNative(value) ? value : void 0;
    }
    function isKey(value, object) {
      if (isArray(value)) {
        return false;
      }
      var type = typeof value;
      if (type == "number" || type == "symbol" || type == "boolean" || value == null || isSymbol(value)) {
        return true;
      }
      return reIsPlainProp.test(value) || !reIsDeepProp.test(value) || object != null && value in Object(object);
    }
    function isKeyable(value) {
      var type = typeof value;
      return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
    }
    function isMasked(func) {
      return !!maskSrcKey && maskSrcKey in func;
    }
    var stringToPath = memoize(function(string) {
      string = toString(string);
      var result = [];
      if (reLeadingDot.test(string)) {
        result.push("");
      }
      string.replace(rePropName, function(match, number, quote, string2) {
        result.push(quote ? string2.replace(reEscapeChar, "$1") : number || match);
      });
      return result;
    });
    function toKey(value) {
      if (typeof value == "string" || isSymbol(value)) {
        return value;
      }
      var result = value + "";
      return result == "0" && 1 / value == -INFINITY ? "-0" : result;
    }
    function toSource(func) {
      if (func != null) {
        try {
          return funcToString.call(func);
        } catch (e) {
        }
        try {
          return func + "";
        } catch (e) {
        }
      }
      return "";
    }
    function memoize(func, resolver) {
      if (typeof func != "function" || resolver && typeof resolver != "function") {
        throw new TypeError(FUNC_ERROR_TEXT);
      }
      var memoized = function() {
        var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
        if (cache.has(key)) {
          return cache.get(key);
        }
        var result = func.apply(this, args);
        memoized.cache = cache.set(key, result);
        return result;
      };
      memoized.cache = new (memoize.Cache || MapCache)();
      return memoized;
    }
    memoize.Cache = MapCache;
    function eq(value, other) {
      return value === other || value !== value && other !== other;
    }
    var isArray = Array.isArray;
    function isFunction(value) {
      var tag = isObject(value) ? objectToString.call(value) : "";
      return tag == funcTag || tag == genTag;
    }
    function isObject(value) {
      var type = typeof value;
      return !!value && (type == "object" || type == "function");
    }
    function isObjectLike(value) {
      return !!value && typeof value == "object";
    }
    function isSymbol(value) {
      return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
    }
    function toString(value) {
      return value == null ? "" : baseToString(value);
    }
    function get(object, path, defaultValue) {
      var result = object == null ? void 0 : baseGet(object, path);
      return result === void 0 ? defaultValue : result;
    }
    module2.exports = get;
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/alexa-skill.js
var require_alexa_skill = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/alexa-skill.js"(exports2, module2) {
    "use strict";
    var get = require_lodash2();
    module2.exports = function eventType(e) {
      const type = "aws.alexaskill";
      return get(e, "session.attributes") && get(e, "session.user") && get(e, "context.System") && get(e, "request.requestId") ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/api-gateway.js
var require_api_gateway = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/api-gateway.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.apigateway.http";
      const apiGatewayRequiredKeys = ["path", "headers", "requestContext", "resource", "httpMethod"];
      if (typeof event === "object") {
        return apiGatewayRequiredKeys.every((key) => key in event) ? type : false;
      }
      return false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/api-gateway-v2.js
var require_api_gateway_v2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/api-gateway-v2.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.apigatewayv2.http";
      const apiGatewayV2RequiredKeys = ["rawPath", "headers", "requestContext", "routeKey", "version"];
      if (typeof event === "object") {
        return apiGatewayV2RequiredKeys.every((key) => key in event) && event.version === "2.0" ? type : false;
      }
      return false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/custom-authorizer.js
var require_custom_authorizer = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/custom-authorizer.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.apigateway.authorizer";
      if (typeof event === "object") {
        const hasMethodArn = event.methodArn;
        const hasType = ["TOKEN", "REQUEST"].includes(event.type);
        return hasMethodArn && hasType ? type : false;
      }
      return false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/cloud-front.js
var require_cloud_front = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/cloud-front.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.cloudfront";
      const { Records = [] } = event;
      return Records[0] && Records[0].cf ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/cloud-watch-event.js
var require_cloud_watch_event = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/cloud-watch-event.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.cloudwatch.event";
      return event.source && event.detail ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/cloud-watch-log.js
var require_cloud_watch_log = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/cloud-watch-log.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.cloudwatch.log";
      return event.awslogs && event.awslogs.data ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/dynamodb.js
var require_dynamodb2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/dynamodb.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.dynamodb";
      const { Records = [] } = event;
      const [firstEvent = {}] = Records;
      const { eventSource } = firstEvent;
      return eventSource === "aws:dynamodb" ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/firehose.js
var require_firehose = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/firehose.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.firehose";
      const { records = [] } = event;
      return event.deliveryStreamArn && records[0] && records[0].kinesisRecordMetadata ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/kinesis.js
var require_kinesis = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/kinesis.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.kinesis";
      const { Records = [] } = event;
      const [firstEvent = {}] = Records;
      const { eventSource } = firstEvent;
      return eventSource === "aws:kinesis" ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/s3.js
var require_s3 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/s3.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.s3";
      const { Records = [] } = event;
      const [firstEvent = {}] = Records;
      const { eventSource } = firstEvent;
      return eventSource === "aws:s3" ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/scheduled.js
var require_scheduled = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/scheduled.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.scheduled";
      return event.source === "aws.events" ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/ses.js
var require_ses = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/ses.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.ses";
      const { Records = [] } = event;
      const [firstEvent = {}] = Records;
      const { eventSource } = firstEvent;
      return eventSource === "aws:ses" ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/sns.js
var require_sns2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/sns.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.sns";
      const { Records = [] } = event;
      const [firstEvent = {}] = Records;
      const { EventSource } = firstEvent;
      return EventSource === "aws:sns" ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/sqs.js
var require_sqs2 = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/event-types/sqs.js"(exports2, module2) {
    "use strict";
    module2.exports = function eventType(event) {
      const type = "aws.sqs";
      const { Records = [] } = event;
      const [firstEvent = {}] = Records;
      const { eventSource } = firstEvent;
      return eventSource === "aws:sqs" ? type : false;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/index.js
var require_event_detection = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/event-detection/index.js"(exports2, module2) {
    "use strict";
    var alexaSkill = require_alexa_skill();
    var apiGateway = require_api_gateway();
    var apiGatewayV2 = require_api_gateway_v2();
    var customAuthorizer = require_custom_authorizer();
    var cloudFront = require_cloud_front();
    var cloudwatchEvent = require_cloud_watch_event();
    var cloudwatchLogs = require_cloud_watch_log();
    var dynamodb = require_dynamodb2();
    var firehose = require_firehose();
    var kinesis = require_kinesis();
    var s3 = require_s3();
    var scheduled = require_scheduled();
    var ses = require_ses();
    var sns = require_sns2();
    var sqs = require_sqs2();
    var detectEventType2 = (event) => alexaSkill(event) || customAuthorizer(event) || apiGateway(event) || apiGatewayV2(event) || cloudFront(event) || cloudwatchLogs(event) || firehose(event) || kinesis(event) || s3(event) || scheduled(event) || ses(event) || sns(event) || sqs(event) || dynamodb(event) || cloudwatchEvent(event) || null;
    module2.exports = { detectEventType: detectEventType2 };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/user-settings.js
var require_user_settings = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/user-settings.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      common: { destination: {} },
      logs: {},
      metrics: { outputType: "protobuf" },
      request: {},
      response: {},
      traces: { outputType: "protobuf" }
    };
    var userSettingsText = process.env.SLS_OTEL_USER_SETTINGS;
    if (!userSettingsText)
      return;
    var userSettings2 = (() => {
      try {
        return JSON.parse(userSettingsText);
      } catch (error) {
        process._rawDebug(`Resolution of user settings failed with: ${error.message}`);
        return null;
      }
    })();
    if (!userSettings2)
      return;
    if (userSettings2.common) {
      if (userSettings2.common.destination) {
        Object.assign(module2.exports.common.destination, userSettings2.common.destination);
      }
    }
    for (const subSettingsName of ["logs", "metrics", "request", "request", "response", "traces"]) {
      if (userSettings2[subSettingsName]) {
        Object.assign(module2.exports[subSettingsName], userSettings2[subSettingsName]);
      }
    }
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/prepare-wrapper.js
var require_prepare_wrapper = __commonJS({
  "../aws-lambda-otel-extension/internal/otel-extension-internal-node/prepare-wrapper.js"(exports2, module2) {
    "use strict";
    module2.exports = () => {
      const result = { handlerLoadDuration: 0n };
      if (!process.env._HANDLER.includes(".") || process.env._HANDLER.includes("..")) {
        return result;
      }
      const path = require("path");
      const handlerDirname = path.dirname(process.env._HANDLER);
      const handlerBasename = path.basename(process.env._HANDLER);
      const handlerModuleBasename = handlerBasename.slice(0, handlerBasename.indexOf("."));
      const handlerModuleDirname = path.resolve(process.env.LAMBDA_TASK_ROOT, handlerDirname);
      const handlerModuleName = path.resolve(handlerModuleDirname, handlerModuleBasename);
      const nodeVersionMajor = Number(process.version.split(".")[0].slice(1));
      const isAsyncLoader = nodeVersionMajor >= 16;
      const importEsm = (() => {
        if (isAsyncLoader) {
          return async (p) => {
            return await import(p);
          };
        }
        try {
          return require(path.resolve(process.env.LAMBDA_RUNTIME_DIR, "deasync")).deasyncify(async (p) => {
            return await import(p);
          });
        } catch (error) {
          return null;
        }
      })();
      const doesModuleExist = (filename) => {
        try {
          require.resolve(filename);
          return true;
        } catch {
          return false;
        }
      };
      let hasInitializationFailed = false;
      const startTime = process.hrtime.bigint();
      const handlerModule = (() => {
        try {
          if (importEsm) {
            if (doesModuleExist(`${handlerModuleName}.mjs`)) {
              return importEsm(`${handlerModuleName}.mjs`);
            }
            if (doesModuleExist(`${handlerModuleName}.js`)) {
              if (!handlerModuleDirname.endsWith("/node_modules") && (() => {
                try {
                  return require(path.resolve(handlerModuleDirname, "package.json")).type === "module";
                } catch {
                  return false;
                }
              })()) {
                return importEsm(`${handlerModuleName}.js`);
              }
            }
          }
          if (doesModuleExist(handlerModuleName))
            return require(handlerModuleName);
          return require("module").createRequire(handlerModuleName)(handlerModuleBasename);
        } catch (error) {
          hasInitializationFailed = true;
          EvalError.$serverlessHandlerModuleInitializationError = error;
          return null;
        }
      })();
      result.handlerLoadDuration = process.hrtime.bigint() - startTime;
      if (!hasInitializationFailed) {
        let handlerContext = handlerModule;
        if (handlerContext == null)
          return result;
        if (isAsyncLoader && typeof handlerContext.then === "function") {
          EvalError.$serverlessHandlerDeferred = handlerContext;
        } else {
          const handlerPropertyPathTokens = handlerBasename.slice(handlerModuleBasename.length + 1).split(".");
          const handlerFunctionName = handlerPropertyPathTokens.pop();
          while (handlerPropertyPathTokens.length) {
            handlerContext = handlerContext[handlerPropertyPathTokens.shift()];
            if (handlerContext == null)
              return result;
          }
          const handlerFunction = handlerContext[handlerFunctionName];
          if (typeof handlerFunction !== "function")
            return result;
          EvalError.$serverlessHandlerFunction = handlerFunction;
        }
        EvalError.$serverlessAwsLambdaInstrumentation = require_aws_lambda_instrumentation();
      }
      process.env._ORIGIN_HANDLER = process.env._HANDLER;
      process.env._HANDLER = "/opt/otel-extension-internal-node/wrapper.handler";
      return result;
    };
  }
});

// ../aws-lambda-otel-extension/internal/otel-extension-internal-node/index.js
var processStartTime = process.hrtime.bigint();
var debugLog = (...args) => {
  if (process.env.DEBUG_SLS_OTEL_LAYER) {
    process._rawDebug(...args);
  }
};
debugLog("Internal extension: Init");
var http = require("http");
var { NodeTracerProvider } = require_src9();
var { InMemorySpanExporter } = require_src7();
var { registerInstrumentations } = require_src13();
var { detectResources, envDetector, processDetector } = require_src6();
var { AwsInstrumentation } = require_src15();
var { getEnv } = require_src4();
var { awsLambdaDetector } = require_src16();
var { DnsInstrumentation } = require_src17();
var { ExpressInstrumentation } = require_src18();
var { GraphQLInstrumentation } = require_src19();
var { GrpcInstrumentation } = require_src21();
var { HapiInstrumentation } = require_src22();
var { HttpInstrumentation } = require_src25();
var { IORedisInstrumentation } = require_src26();
var { KoaInstrumentation } = require_src27();
var { MongoDBInstrumentation } = require_src28();
var { MySQLInstrumentation } = require_src29();
var { NetInstrumentation } = require_src30();
var { PgInstrumentation } = require_src31();
var { RedisInstrumentation } = require_src32();
var { FastifyInstrumentation } = require_src33();
var AwsLambdaInstrumentation = require_aws_lambda_instrumentation();
var { diag, DiagConsoleLogger } = require_src();
var SlsSpanProcessor = require_span_processor();
var { detectEventType } = require_event_detection();
var userSettings = require_user_settings();
var OTEL_SERVER_PORT = 2772;
var logLevel = getEnv().OTEL_LOG_LEVEL;
diag.setLogger(new DiagConsoleLogger(), logLevel);
var telemetryServerUrl = `http://localhost:${OTEL_SERVER_PORT}`;
var keepAliveAgent = new http.Agent({ keepAlive: true });
var tracerProvider = new NodeTracerProvider();
var memoryExporter = new InMemorySpanExporter();
var spanProcessor = new SlsSpanProcessor(memoryExporter);
tracerProvider.addSpanProcessor(spanProcessor);
tracerProvider.register();
var eventData = {};
var timeoutHandler;
var transactionCount = 0;
var requestHandler = async (span, { event, context }) => {
  handleTimeouts(context.getRemainingTimeInMillis());
  const eventType = detectEventType(event);
  eventData[context.awsRequestId] = {
    ...tracerProvider.resource.attributes,
    computeCustomArn: context.invokedFunctionArn,
    functionName: process.env.AWS_LAMBDA_FUNCTION_NAME,
    computeRegion: process.env.AWS_REGION,
    computeRuntime: `aws.lambda.nodejs.${process.versions.node}`,
    computeCustomFunctionVersion: process.env.AWS_LAMBDA_FUNCTION_VERSION,
    computeMemorySize: process.env.AWS_LAMBDA_FUNCTION_MEMORY_SIZE,
    eventCustomXTraceId: process.env._X_AMZN_TRACE_ID,
    computeCustomLogGroupName: process.env.AWS_LAMBDA_LOG_GROUP_NAME,
    computeCustomLogStreamName: process.env.AWS_LAMBDA_LOG_STREAM_NAME,
    computeCustomEnvArch: process.arch,
    eventType,
    eventCustomRequestId: context.awsRequestId,
    computeIsColdStart: ++transactionCount === 1,
    eventCustomDomain: null,
    eventCustomRequestTimeEpoch: null
  };
  if (eventType === "aws.apigateway.http") {
    eventData[context.awsRequestId].eventCustomApiId = event.requestContext.apiId;
    eventData[context.awsRequestId].eventSource = "aws.apigateway";
    eventData[context.awsRequestId].eventCustomAccountId = event.requestContext.accountId;
    eventData[context.awsRequestId].httpPath = event.requestContext.resourcePath;
    eventData[context.awsRequestId].rawHttpPath = event.path;
    eventData[context.awsRequestId].eventCustomHttpMethod = event.requestContext.httpMethod;
    eventData[context.awsRequestId].eventCustomDomain = event.requestContext.domainName;
    eventData[context.awsRequestId].eventCustomRequestTimeEpoch = event.requestContext.requestTimeEpoch;
  } else if (eventType === "aws.apigatewayv2.http") {
    eventData[context.awsRequestId].eventCustomApiId = event.requestContext.apiId;
    eventData[context.awsRequestId].eventSource = "aws.apigateway";
    eventData[context.awsRequestId].eventCustomAccountId = event.requestContext.accountId;
    const routeKey = event.requestContext.routeKey;
    eventData[context.awsRequestId].httpPath = routeKey.split(" ")[1] || event.requestContext.routeKey;
    eventData[context.awsRequestId].rawHttpPath = event.rawPath;
    eventData[context.awsRequestId].eventCustomHttpMethod = event.requestContext.http.method;
    eventData[context.awsRequestId].eventCustomDomain = event.requestContext.domainName;
    eventData[context.awsRequestId].eventCustomRequestTimeEpoch = event.requestContext.timeEpoch;
  }
  const eventDataPayload = {
    recordType: "eventData",
    record: {
      eventData: { [context.awsRequestId]: eventData[context.awsRequestId] },
      span: {
        traceId: span.spanContext().traceId,
        spanId: span.spanContext().spanId
      }
    }
  };
  if (!userSettings.request.disabled) {
    eventDataPayload.record.requestEventPayload = {
      traceId: span.spanContext().traceId,
      spanId: span.spanContext().spanId,
      requestData: event,
      timestamp: EvalError.$serverlessInvocationStart,
      executionId: context.awsRequestId
    };
  }
  const requestBody = JSON.stringify(eventDataPayload);
  debugLog("Internal extension: Send event data");
  if (process.env.TEST_DRY_LOG) {
    process.stdout.write(`\u26A1 eventData: ${requestBody}
`);
  } else {
    const requestStartTime = process.hrtime.bigint();
    let requestSocket;
    try {
      await new Promise((resolve, reject) => {
        const request = http.request(telemetryServerUrl, {
          agent: keepAliveAgent,
          method: "post",
          headers: {
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(requestBody)
          }
        }, (response) => {
          if (response.statusCode === 200) {
            resolve();
          } else {
            reject(new Error(`Unexpected response status code: ${response.statusCode}`));
          }
        });
        request.on("error", reject);
        request.on("socket", (socket) => requestSocket = socket);
        request.write(requestBody);
        request.end();
      });
    } finally {
      if (requestSocket)
        requestSocket.unref();
    }
    debugLog(`Internal extension request [eventData]: ok in: ${Math.round(Number(process.hrtime.bigint() - requestStartTime) / 1e6)}ms`);
  }
};
var responseHandler = async (span, { res, err }, isTimeout) => {
  await tracerProvider.forceFlush();
  spanProcessor.finishAllSpans();
  const spans = memoryExporter.getFinishedSpans();
  let pathData;
  let functionData;
  let executionId;
  if (span) {
    executionId = span.attributes["faas.execution"];
    functionData = eventData[span.attributes["faas.execution"]];
    pathData = {
      "http.path": functionData.httpPath
    };
  } else {
    pathData = spans.reduce((obj, val) => {
      if (val.instrumentationLibrary.name === "@opentelemetry/instrumentation-aws-lambda") {
        executionId = val.attributes["faas.execution"];
        functionData = eventData[val.attributes["faas.execution"]];
        return {
          "http.path": eventData[val.attributes["faas.execution"]].httpPath
        };
      }
      return obj;
    }, { "http.status_code": 500 });
  }
  const { startTime: st, endTime: et } = spans.reduce((obj, val) => {
    if (val.instrumentationLibrary.name === "@opentelemetry/instrumentation-aws-lambda") {
      const spanStartTime = val.startTime || [0, 0];
      const spanEndTime = val.endTime || [0, 0];
      return {
        startTime: new Date((spanStartTime[0] * 1e9 + spanStartTime[1]) / 1e6),
        endTime: new Date((spanEndTime[0] * 1e9 + spanEndTime[1]) / 1e6)
      };
    }
    return obj;
  }, { startTime: new Date(), endTime: new Date() });
  functionData.startTime = st.getTime();
  functionData.endTime = et.getTime();
  if (!err && !res) {
    pathData["http.status_code"] = 500;
  } else if (pathData) {
    let statusCode = (res || {}).statusCode || 200;
    if (err && !(res || {}).statusCode) {
      statusCode = 500;
    }
    pathData["http.status_code"] = statusCode;
  }
  functionData.error = false;
  functionData.timeout = isTimeout;
  if (isTimeout) {
    functionData.error = true;
    functionData.errorCulprit = "timeout";
    functionData.errorType = "timeout";
  } else if (err) {
    functionData.error = true;
    functionData.errorCulprit = err.message;
    functionData.errorType = "handled";
    functionData.errorMessage = err.message;
    functionData.errorStacktrace = err.stack;
  } else if (pathData["http.status_code"] >= 500 && ["aws.apigateway.http", "aws.apigatewayv2.http"].includes(functionData.eventType)) {
    functionData.error = true;
    functionData.errorCulprit = "internal server error";
    functionData.errorType = "handled";
    functionData.errorMessage = "internal server error";
    functionData.errorStacktrace = "internal server error";
  }
  const grouped = spans.reduce((obj, val) => {
    const key = `${val.instrumentationLibrary.name}-${val.instrumentationLibrary.version}`;
    if (!obj[key])
      obj[key] = [];
    return {
      ...obj,
      [key]: [...obj[key], val]
    };
  }, {});
  pathData["http.path"] = spans.reduce((finalPath, val) => {
    if (val.instrumentationLibrary.name === "@opentelemetry/instrumentation-express" && val.name === "middleware - bound " || val.instrumentationLibrary.name === "@opentelemetry/instrumentation-express" && /request handler - /i.test(val.name) || val.instrumentationLibrary.name === "@opentelemetry/instrumentation-fastify" && /request handler - /i.test(val.name)) {
      return val.attributes["http.route"];
    }
    return finalPath;
  }, pathData["http.path"]);
  pathData["http.path"] = spans.reduce((finalPath, val) => {
    if (val.instrumentationLibrary.name === "@opentelemetry/instrumentation-koa" && /router - /gi.test(val.name)) {
      return val.attributes["http.route"];
    }
    return finalPath;
  }, pathData["http.path"]);
  functionData.httpPath = pathData["http.path"];
  functionData.httpStatusCode = pathData["http.status_code"];
  const data = Object.keys(grouped).map((key) => {
    const spanList = grouped[key];
    const firstThing = spanList[0];
    const spanObj = spanList.map((val) => {
      const { traceId, spanId } = val.spanContext();
      const spanStartTime = val.startTime || [0, 0];
      const spanEndTime = val.endTime || [0, 0];
      let attributes = {
        ...val.attributes,
        "sls.original_properties": Object.keys(val.attributes).join(",")
      };
      if (firstThing.instrumentationLibrary.name === "@opentelemetry/instrumentation-aws-lambda") {
        attributes = {
          ...val.attributes,
          "sls.original_properties": Object.keys(val.attributes).join(","),
          ...!pathData["http.path"] ? {} : pathData
        };
      }
      return {
        traceId,
        spanId,
        parentSpanId: val.parentSpanId,
        name: val.name === "middleware - bound " ? `request handler - ${pathData["http.path"]}` : val.name,
        kind: "SPAN_KIND_SERVER",
        startTimeUnixNano: `${spanStartTime[0] * 1e9 + spanStartTime[1]}`,
        endTimeUnixNano: `${spanEndTime[0] * 1e9 + spanEndTime[1]}`,
        attributes,
        status: {}
      };
    }).reduce((obj, innerSpan) => {
      obj[innerSpan.spanId] = innerSpan;
      return obj;
    }, {});
    return {
      instrumentationLibrary: {
        name: firstThing.instrumentationLibrary.name,
        version: firstThing.instrumentationLibrary.version
      },
      spans: Object.values(spanObj)
    };
  });
  const telemetryDataPayload = {
    recordType: "telemetryData",
    requestId: executionId,
    record: {
      function: functionData,
      traces: {
        resourceSpans: [
          {
            resource: tracerProvider.resource.attributes,
            instrumentationLibrarySpans: data
          }
        ]
      }
    }
  };
  if (!userSettings.response.disabled) {
    telemetryDataPayload.record.responseEventPayload = {
      responseData: res,
      errorData: err,
      executionId,
      isTimeout,
      traceId: span ? span.spanContext().traceId : null,
      spanId: span ? span.spanContext().spanId : null
    };
  }
  const requestBody = JSON.stringify(telemetryDataPayload);
  debugLog("Internal extension: Send telemetry data");
  if (process.env.TEST_DRY_LOG) {
    process.stdout.write(`\u26A1 telemetryData: ${requestBody}
`);
  } else {
    const requestStartTime = process.hrtime.bigint();
    let requestSocket;
    try {
      await new Promise((resolve, reject) => {
        const request = http.request(telemetryServerUrl, {
          agent: keepAliveAgent,
          method: "post",
          headers: {
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(requestBody)
          }
        }, (response) => {
          if (response.statusCode === 200) {
            resolve();
          } else {
            reject(new Error(`Unexpected response status code: ${response.statusCode}`));
          }
        });
        request.on("error", reject);
        request.on("socket", (socket) => requestSocket = socket);
        request.write(requestBody);
        request.end();
      });
    } finally {
      if (requestSocket)
        requestSocket.unref();
    }
    debugLog(`Internal extension request [telemetryData]: ok in: ${Math.round(Number(process.hrtime.bigint() - requestStartTime) / 1e6)}ms`);
  }
  memoryExporter.reset();
};
var handleTimeouts = (remainingTime) => {
  timeoutHandler = setTimeout(() => {
    responseHandler(null, {}, true);
  }, remainingTime - 50).unref();
};
registerInstrumentations({
  tracerProvider,
  instrumentations: [
    new AwsInstrumentation({
      suppressInternalInstrumentation: true
    }),
    new AwsLambdaInstrumentation({
      disableAwsContextPropagation: true,
      requestHook: (...args) => {
        EvalError.$serverlessRequestHandlerPromise = requestHandler(...args);
      },
      responseHook: (span, { err, res }) => {
        clearTimeout(timeoutHandler);
        EvalError.$serverlessResponseHandlerPromise = responseHandler(span, { err, res });
      }
    }),
    new DnsInstrumentation(),
    new ExpressInstrumentation(),
    new GraphQLInstrumentation(),
    new GrpcInstrumentation(),
    new HapiInstrumentation(),
    new HttpInstrumentation(),
    new IORedisInstrumentation(),
    new KoaInstrumentation(),
    new MongoDBInstrumentation(),
    new MySQLInstrumentation(),
    new NetInstrumentation(),
    new PgInstrumentation(),
    new RedisInstrumentation(),
    new FastifyInstrumentation()
  ]
});
module.exports = detectResources({
  detectors: [awsLambdaDetector, envDetector, processDetector]
}).then((resource) => tracerProvider.resource = tracerProvider.resource.merge(resource));
var { handlerLoadDuration } = require_prepare_wrapper()();
if (process.env.DEBUG_SLS_OTEL_LAYER) {
  process._rawDebug("Extension overhead duration: internal initialization:", `${Math.round(Number(process.hrtime.bigint() - processStartTime - handlerLoadDuration) / 1e6)}ms`);
}
