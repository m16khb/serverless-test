"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_serverless_express_1 = require("aws-serverless-express");
const middleware_1 = require("aws-serverless-express/middleware");
const core_1 = require("@nestjs/core");
const platform_express_1 = require("@nestjs/platform-express");
const app_module_1 = require("./app.module");
const nest_winston_1 = require("nest-winston");
const winston = require("winston");
const express = require('express');
const binaryMimeTypes = [];
let cachedServer;
async function bootstrapServer() {
    if (!cachedServer) {
        const expressApp = express();
        const nestApp = await core_1.NestFactory.create(app_module_1.AppModule, new platform_express_1.ExpressAdapter(expressApp), {
            logger: nest_winston_1.WinstonModule.createLogger({
                transports: [
                    new winston.transports.Console({
                        level: process.env.NODE_ENV === 'production' ? 'info' : 'silly',
                        format: winston.format.combine(winston.format.uncolorize({}), winston.format.simple(), winston.format.label({ label: 'serverless-test' }), winston.format.timestamp(), winston.format.printf(({ level, message, label, timestamp }) => {
                            return `${timestamp} [${label}] ${level}: ${message}`;
                        })),
                    }),
                ],
            }),
        });
        nestApp.use(middleware_1.eventContext());
        await nestApp.init();
        cachedServer = aws_serverless_express_1.createServer(expressApp, undefined, binaryMimeTypes);
    }
    return cachedServer;
}
exports.handler = async (event, context) => {
    cachedServer = await bootstrapServer();
    return aws_serverless_express_1.proxy(cachedServer, event, context, 'PROMISE').promise;
};
//# sourceMappingURL=lambda.js.map