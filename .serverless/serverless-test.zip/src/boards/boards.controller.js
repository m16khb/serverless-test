"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const boards_service_1 = require("./boards.service");
let BoardsController = class BoardsController {
    constructor(logger, boardsService) {
        this.logger = logger;
        this.boardsService = boardsService;
    }
    async getBoard(title, res) {
        const board = await this.boardsService.getBoard(title);
        return (res
            .status(common_1.HttpStatus.OK)
            .json(board));
    }
    async getBoards(res) {
        this.printWinstonLog('test');
        const boards = await this.boardsService.getBoards();
        return (res
            .status(common_1.HttpStatus.OK)
            .json(boards));
    }
    async createBoard(dto, res) {
        const result = await this.boardsService.createBoard(dto);
        return (res
            .status(common_1.HttpStatus.CREATED)
            .json(result));
    }
    async updateBoard(bid, dto, res) {
        const result = await this.boardsService.updateBoard(bid, dto);
        return (res
            .status(common_1.HttpStatus.NO_CONTENT)
            .json(result));
    }
    async deleteBoard(bid, res) {
        const result = await this.boardsService.deleteBoard(bid);
        return (res
            .status(common_1.HttpStatus.NO_CONTENT)
            .json(result));
    }
    printWinstonLog(test) {
        this.logger.error(test);
        this.logger.warn(test);
        this.logger.verbose(test);
        this.logger.debug(test);
    }
};
__decorate([
    common_1.Get('/:title'),
    __param(0, common_1.Param('title')), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], BoardsController.prototype, "getBoard", null);
__decorate([
    common_1.Get(),
    __param(0, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BoardsController.prototype, "getBoards", null);
__decorate([
    common_1.Post(),
    __param(0, common_1.Body()), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], BoardsController.prototype, "createBoard", null);
__decorate([
    common_1.Put('/:bid'),
    __param(0, common_1.Param('bid')),
    __param(1, common_1.Body()),
    __param(2, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], BoardsController.prototype, "updateBoard", null);
__decorate([
    common_1.Delete('/:bid'),
    __param(0, common_1.Param('bid')), __param(1, common_1.Res()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], BoardsController.prototype, "deleteBoard", null);
BoardsController = __decorate([
    common_1.Controller('boards'),
    __param(0, common_1.Inject(common_1.Logger)),
    __metadata("design:paramtypes", [Object, boards_service_1.BoardsService])
], BoardsController);
exports.BoardsController = BoardsController;
//# sourceMappingURL=boards.controller.js.map