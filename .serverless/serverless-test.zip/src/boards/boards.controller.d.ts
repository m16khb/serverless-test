import { LoggerService } from '@nestjs/common';
import { BoardsService } from './boards.service';
export declare class BoardsController {
    private readonly logger;
    private readonly boardsService;
    constructor(logger: LoggerService, boardsService: BoardsService);
    getBoard(title: string, res: any): Promise<any>;
    getBoards(res: any): Promise<any>;
    createBoard(dto: any, res: any): Promise<any>;
    updateBoard(bid: string, dto: any, res: any): Promise<any>;
    deleteBoard(bid: string, res: any): Promise<any>;
    private printWinstonLog;
}
