export declare class BoardsRepository {
    private tableName;
    private db;
    constructor();
    getBoard(title: string): Promise<object>;
    getBoards(): Promise<object[]>;
    createBoard(dto: any): Promise<void>;
    updateBoard(bid: string, dto: any): Promise<void>;
    deleteBoard(bid: string): Promise<void>;
}
