import { BoardsRepository } from './boards.repository';
export declare class BoardsService {
    private readonly boardsRepository;
    constructor(boardsRepository: BoardsRepository);
    getBoard(title: string): Promise<object>;
    getBoards(): Promise<object[]>;
    createBoard(dto: any): Promise<void>;
    updateBoard(bid: string, dto: any): Promise<void>;
    deleteBoard(bid: string): Promise<void>;
}
