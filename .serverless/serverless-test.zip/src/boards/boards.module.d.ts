export declare class BoardsModule {
}
