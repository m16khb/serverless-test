"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const AWS = require("aws-sdk");
const uuid_1 = require("uuid");
let BoardsRepository = class BoardsRepository {
    constructor() {
        this.tableName = 'boards';
        this.db = new AWS.DynamoDB.DocumentClient();
    }
    async getBoard(title) {
        let board;
        try {
            const result = await this.db
                .query({
                TableName: this.tableName,
                IndexName: 'title-index',
                KeyConditionExpression: 'title = :t',
                ExpressionAttributeValues: {
                    ':t': title,
                },
            })
                .promise();
            board = result.Items;
        }
        catch (error) {
            throw new common_1.InternalServerErrorException(error);
        }
        if (!board) {
            throw new common_1.NotFoundException(`not found board`);
        }
        return board;
    }
    async getBoards() {
        let boards;
        try {
            const result = await this.db
                .scan({
                TableName: this.tableName,
            })
                .promise();
            boards = result.Items;
        }
        catch (error) {
            throw new common_1.InternalServerErrorException(error);
        }
        if (!boards) {
            throw new common_1.NotFoundException(`not found board`);
        }
        return boards;
    }
    async createBoard(dto) {
        const { title, content } = dto;
        try {
            const result = await this.db
                .put({
                TableName: 'boards',
                Item: {
                    bid: uuid_1.v1(),
                    title: title,
                    content: content,
                },
            })
                .promise();
        }
        catch (error) {
            throw new common_1.InternalServerErrorException(error);
        }
    }
    async updateBoard(bid, dto) {
        const { title, content } = dto;
        try {
            const result = await this.db
                .update({
                TableName: this.tableName,
                Key: { bid: bid },
                UpdateExpression: 'set title = :t, content = :c',
                ExpressionAttributeValues: {
                    ':t': title,
                    ':c': content,
                },
            })
                .promise();
            console.log(result);
        }
        catch (error) {
            throw new common_1.InternalServerErrorException(error);
        }
    }
    async deleteBoard(bid) {
        try {
            const result = await this.db
                .delete({
                TableName: this.tableName,
                Key: { bid: bid },
            })
                .promise();
            console.log(result);
        }
        catch (error) {
            throw new common_1.InternalServerErrorException(error);
        }
    }
};
BoardsRepository = __decorate([
    common_1.Injectable(),
    __metadata("design:paramtypes", [])
], BoardsRepository);
exports.BoardsRepository = BoardsRepository;
//# sourceMappingURL=boards.repository.js.map